#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "alg.h"
#include "protocolalg.h"
#include "datatype.h"


#ifdef _WIN32
#ifdef _DEBUG
#include "vld.h"
#endif // _DEBUG
#endif // _WIN32

NegPressCollectChannel *g_negCollectHandle;
CRPCollectChannel *g_crpCollectHandle;
CRPCollectChannel *g_highCrpCollectHandle;
item_cal_factor_t g_calFactor;
crp_para_info g_stCrpParaInfo;

double g_fRatioWbWBC = 305.1f;
double g_fRatioWbPLT = 16498.5f;
double g_fRatioPreWBC = 502;
double g_fRatioPrePLT = 16449.4f;



int AlgAddNegPressData_test(NegPressCollectChannel *pstHandle);
int AlgAddCrpData_test(CRPCollectChannel *pstHandle, CRPCollectChannel *pstHighHandle);
extern DataCollectHandle *alg_test_data();
void AlgSetCrpParaInfo_test(crp_para_info *pstPara);
void AlgSetCalFactor_test(item_cal_factor_t *pstCalFactor);
extern int bk_generate_new_inf_file(unsigned char *buff, DataCollectHandle *data_handle, 
	sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result);
DataCollectHandle *alg_test_data();

void main()
{
	DataCollectHandle *data_handle;
	item_evt_count_temp_t bk_result;
	sample_info_t s_sample_info;
	NegPressCollectChannel air_handle;
	crp_cal_reaction_info crp_reaction_info;
	alg_output_info out_info;
	CRPCollectChannel crp_handle, highs_crp_handle;
	item_cal_factor_t s_cal_factor;
	crp_para_info crp_para;


	data_handle = alg_test_data();
	memset(&bk_result, 0, sizeof(item_evt_count_temp_t));
	s_sample_info.bm = BloodModeWL;
	s_sample_info.am = AnalysisModeCRP;
	s_sample_info.wm = WorkModeCount;
	s_sample_info.hgbBlankMs = 100;
	s_sample_info.hgbParaMs = 35200;
	s_sample_info.gainCrp = 10;
	s_sample_info.gainWbc = 42;
	s_sample_info.gainRbc = 20;
	s_sample_info.gainHgb = 5;
	strcpy(s_sample_info.id, "spline_wb_2_2");
	strcpy(s_sample_info.versionAlg, "v0.1.1012");
	strcpy(s_sample_info.versionMainFpga, "v0.2.1012");
	strcpy(s_sample_info.versionSystem, "v0.3.1012");
	strcpy(s_sample_info.versionTimeseq, "v0.4.1012");
	strcpy(s_sample_info.versionDriveFpga, "v0.dfpga.1012");
	strcpy(s_sample_info.versionMCU, "v0.mcu.1012");
	AlgAddCrpData_test(&crp_handle,&highs_crp_handle);
	// ����CRP������Ϣ
	crp_reaction_info.lItemCount = 5;
	crp_reaction_info.bm = BloodModeWL;
	crp_reaction_info.astItems[0].crpValue = 20.0;
	crp_reaction_info.astItems[1].crpValue = 5.0;
	crp_reaction_info.astItems[2].crpValue = 0.0;
	crp_reaction_info.astItems[3].crpValue = 40.0;
	crp_reaction_info.astItems[4].crpValue = 80.0;
	crp_reaction_info.astItems[5].crpValue = 160.0;
	// 2#
	crp_reaction_info.astItems[0].crpReaction = 0.0;
	crp_reaction_info.astItems[1].crpReaction = 33.0;
	crp_reaction_info.astItems[2].crpReaction = 195.0;
	crp_reaction_info.astItems[3].crpReaction = 327.0;
	crp_reaction_info.astItems[4].crpReaction = 445.0;
	crp_reaction_info.astItems[5].crpReaction = 530.0;
	// 7#
	crp_reaction_info.astItems[0].crpReaction = 144.8;
	crp_reaction_info.astItems[1].crpReaction = 28.7;
	crp_reaction_info.astItems[2].crpReaction = 0;
	crp_reaction_info.astItems[3].crpReaction = 279.6;
	crp_reaction_info.astItems[4].crpReaction = 354.2;
	crp_reaction_info.astItems[5].crpReaction = (float)1080.0;
	//AlgSetCrpCalInfo(&crp_reaction_info,&crp_cal_para);
	

	AlgSetCalFactor_test(&s_cal_factor);
	AlgSetCrpParaInfo_test(&crp_para);
	AlgAddNegPressData_test(&air_handle);

	//write_air_pressure_data_to_inf();
	bk_generate_new_inf_file((unsigned char *)data_handle, data_handle, &s_sample_info,&bk_result);
	
	FREE_POINTER(data_handle);
	FREE_POINTER(g_negCollectHandle->punAddr);
	FREE_POINTER(g_crpCollectHandle->punAddr);
	FREE_POINTER(g_highCrpCollectHandle->punAddr);
	return 0;
}

static int read_fpga_pulse_data(byte **buff, const char *file_path);
static void get_file_path(char *path, const char dir[], const char *name);

DataCollectHandle *alg_test_data()
{
	int wbc_len, rbc_len, plt_len, hgb_len, whole_len, rhole_len, total_len;
	byte *wbc_buff, *rbc_buff, *plt_buff, *hgb_buff, *buff, *whole_buff,
		*rhole_buff;
	DataCollectHandle *data_handle;
	//item_evt_count_temp_t bk_result;

	//int error_code;
#ifdef _WIN32
	const char dir[] = "G:/shared_folder/example/0925/result01/";
#else
	const char dir[] = "../example/0925/result01/";
#endif // _WIN


	char file_path[MAX_PATH];

	wbc_buff = NULL; rbc_buff = NULL; plt_buff = NULL; hgb_buff = NULL;
	get_file_path(file_path, dir, "Wbc");
	wbc_len = read_fpga_pulse_data(&wbc_buff, file_path);
	get_file_path(file_path, dir, "Rbc");
	rbc_len = read_fpga_pulse_data(&rbc_buff, file_path);
	get_file_path(file_path, dir, "Plt");
	plt_len = read_fpga_pulse_data(&plt_buff, file_path);
	get_file_path(file_path, dir, "Hgb");
	hgb_len = read_fpga_pulse_data(&hgb_buff, file_path);
	get_file_path(file_path, dir, "WbcAperture");
	whole_len = read_fpga_pulse_data(&whole_buff, file_path);
	get_file_path(file_path, dir, "RbcAperture");
	rhole_len = read_fpga_pulse_data(&rhole_buff, file_path);
	total_len = wbc_len + rbc_len + plt_len + hgb_len + whole_len + rhole_len +
		sizeof(DataCollectHandle);

	buff = (byte *)calloc(total_len, sizeof(byte));
	data_handle = (DataCollectHandle *)buff;

	buff += sizeof(DataCollectHandle);
	memcpy(buff, wbc_buff, wbc_len);
	buff += wbc_len;
	memcpy(buff, rbc_buff, rbc_len);
	buff += rbc_len;
	memcpy(buff, plt_buff, plt_len);
	buff += plt_len;
	memcpy(buff, hgb_buff, hgb_len);
	buff += hgb_len;
	memcpy(buff, whole_buff, whole_len);
	buff += whole_len;
	memcpy(buff, rhole_buff, rhole_len);
	FREE_POINTER(wbc_buff);
	FREE_POINTER(rbc_buff);
	FREE_POINTER(plt_buff);
	FREE_POINTER(hgb_buff);
	FREE_POINTER(whole_buff);
	FREE_POINTER(rhole_buff);

	memset(data_handle, 0, sizeof(DataCollectHandle));
	data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulAddr =
		sizeof(DataCollectHandle);
	data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulCount = wbc_len;
	data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulAddr =
		sizeof(DataCollectHandle) + wbc_len;
	data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulCount = rbc_len;
	data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulAddr =
		sizeof(DataCollectHandle) + wbc_len + rbc_len;
	data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulCount = plt_len;
	data_handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr =
		sizeof(DataCollectHandle) + wbc_len + rbc_len + plt_len;
	data_handle->astChannels[COLLECT_CHANNEL_HGB].ulCount = hgb_len;
	data_handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr =
		sizeof(DataCollectHandle) + wbc_len + rbc_len + plt_len + hgb_len;
	data_handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount =
		whole_len;
	data_handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr =
		sizeof(DataCollectHandle) + wbc_len + rbc_len + plt_len + hgb_len + whole_len;
	data_handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount =
		rhole_len;

	//error_code = BK_alg_main(buff, &data_handle, &bk_result);

	//	FREE_POINTER(buff);
	//	printf("error_code = %d\n", error_code);


	return data_handle;



}

static void get_file_path(char *path, const char dir[], const char *name)
{
	char tmp[MAX_PATH];


	strcpy(tmp, dir);
	strcat(tmp, name);
	memset(path, 0, MAX_PATH);
	memcpy(path, tmp, MAX_PATH);
	return;


}

static int read_fpga_pulse_data(byte **buff, const char *file_path)
{
	FILE *fp;
	int file_len;

	if (!(fp = fopen(file_path, "rb")))
		return 111; //�ļ��򿪴���

	fseek(fp, 0, SEEK_END);
	file_len = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	*buff = (byte *)calloc(file_len, sizeof(byte));

	file_len = (int)fread(*buff, sizeof(byte), file_len, fp);
	fclose(fp);


	return file_len;

}


void AlgSetCrpParaInfo_test(crp_para_info *pstPara)
{
	pstPara->calMethod = CRP_METHOD_LOG4P;
	pstPara->stWbPara.lParaNum = 4;
	//
	pstPara->stWbPara.afPara[0] = 31607.74;
	pstPara->stWbPara.afPara[1] = 82.43;
	pstPara->stWbPara.afPara[2] = 1.14;
	pstPara->stWbPara.afPara[3] = 19977619.1;
	memcpy(&g_stCrpParaInfo, pstPara, sizeof(crp_para_info));
}



void AlgSetCalFactor_test(item_cal_factor_t *pstCalFactor)
{
	memset(pstCalFactor, 0, sizeof(item_cal_factor_t));
	pstCalFactor->wbFactoryCalFactor.fWbc = (float)101;
	pstCalFactor->wbCalFactor.fWbc = (float)99;
	pstCalFactor->wbFactoryCalFactor.fRbc = (float)102;
	pstCalFactor->wbCalFactor.fRbc = (float)98;
	pstCalFactor->wbFactoryCalFactor.fMcv = (float)103;
	pstCalFactor->wbCalFactor.fMcv = (float)97;
	pstCalFactor->wbFactoryCalFactor.fPlt = (float)104;
	pstCalFactor->wbCalFactor.fPlt = (float)94;
	pstCalFactor->wbFactoryCalFactor.fHgb = (float)105;
	pstCalFactor->wbCalFactor.fHgb = (float)95;
	printf("SetAlgCalFactor test alg\n");
	memcpy(&g_calFactor, pstCalFactor, sizeof(g_calFactor));
	return;
}

int AlgAddNegPressData_test(NegPressCollectChannel *pstHandle)
{

	int i, count = 5000;
	memset(pstHandle, 0, sizeof(NegPressCollectChannel));
	pstHandle->punAddr = (unsigned short *)calloc(count, sizeof(unsigned short));
	for (i = 0; i < count; i++)
		pstHandle->punAddr[i] = (unsigned short)(i + 1);
	pstHandle->ulCount = count;
	g_negCollectHandle = pstHandle;
	printf("AlgAddNegPressData test alg\n");
	return 0;
}

int AlgAddCrpData_test(CRPCollectChannel *pstLowHandle, CRPCollectChannel *pstHighHandle)
{
	int i, count = 300;
	memset(pstLowHandle, 0, sizeof(CRPCollectChannel));
	memset(pstHighHandle, 0, sizeof(CRPCollectChannel));
	pstLowHandle->punAddr = (unsigned short *)calloc(count, sizeof(unsigned short));
	pstHighHandle->punAddr = (unsigned short *)calloc(count, sizeof(unsigned short));
	for (i = 0; i < count; i++)
	{
		pstLowHandle->punAddr[i] = (unsigned short)(3 * i + 1);
		pstHighHandle->punAddr[i] = (unsigned short)((3 * i + 1) * 40);
	}

	pstLowHandle->ulCount = count;
	pstHighHandle->ulCount = count;
	g_crpCollectHandle = pstLowHandle;
	g_highCrpCollectHandle = pstHighHandle;
	printf("AlgAddCrpData test alg\n");
	printf("AlgAddCrpData alg. ulCount = %ld.  punAddr = %ld, ulCount = %ld.  punAddr = %ld\n",
		pstLowHandle->ulCount, (int)(pstLowHandle->punAddr), pstHighHandle->ulCount, (int)(pstHighHandle->punAddr));
	return 0;
}