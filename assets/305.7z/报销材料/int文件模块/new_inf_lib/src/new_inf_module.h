#ifndef ALG_LIB_NEW_INF_MODULE_H  
#define ALG_LIB_NEW_INF_MODULE_H

#include "alg.h"
#include "protocolalg.h"

#ifndef INF_STR_LEN
#define INF_STR_LEN 32
#endif

#ifndef MAX_MONITOR_NUM
#define MAX_MONITOR_NUM 6000
#endif

typedef struct
{
	char inf_ver[INF_STR_LEN];
	char project_code[INF_STR_LEN]; 
	char system_ver[INF_STR_LEN];
	char timeseq_ver[INF_STR_LEN];
	char main_fpga_ver[INF_STR_LEN];
	char drive_fpga_ver[INF_STR_LEN];
	char drive_mcu_ver[INF_STR_LEN];
	char alg_ver[INF_STR_LEN];
}INT_HEADER; //record #1

typedef struct
{
	char sample_id[INF_STR_LEN];
	char analysis_mode;
	char blood_mode;
	char introduction_mode;
	char work_mode;
	char crp_cali_mode;
}INT_SAMPLE; // record #2

typedef struct
{
	char patient_name[INF_STR_LEN];
}INT_PATIENT; // record #3

typedef struct
{
	int diff_channel_error;
	int wbc_channel_error;
	int hgb_channel_error;
	int rbc_channel_error;
	int crp_channel_error;
	int ret_channel_error;
}INT_SYSTEM_STATE; // record #20

typedef struct
{
	double factory_cali_coef;
	double user_cali_coef;
	double intro_transfer_coef;
	double analysis_transfer_coef;
	double reserve;
}PARA_COEF; // 

typedef struct
{
	double channel_volume;
	double channel_dilution_ratio;
	double sampling_time;
	double sample_flow_capacity;
}CHANNEL_INFO; // 


typedef struct
{
	PARA_COEF wbc_coef;
	PARA_COEF neu_num_coef;
	PARA_COEF lym_num_coef;
	PARA_COEF mon_num_coef;
	PARA_COEF eos_num_coef;
	PARA_COEF bas_num_coef;
	PARA_COEF neu_per_coef;
	PARA_COEF lym_per_coef;
	PARA_COEF mon_per_coef;
	PARA_COEF eos_per_coef;
	PARA_COEF bas_per_coef;
	PARA_COEF aly_num_coef;
	PARA_COEF lic_num_coef;
	PARA_COEF aly_per_coef;
	PARA_COEF lic_per_coef;

	PARA_COEF grann_coef;
	PARA_COEF midn_coef;
	PARA_COEF lymn_coef;
	PARA_COEF granp_coef;
	PARA_COEF midp_coef;
	PARA_COEF lymp_coef;

	PARA_COEF rbc_coef;
	PARA_COEF hgb_coef;
	PARA_COEF hct_coef;
	PARA_COEF mcv_coef;
	PARA_COEF mch_coef;
	PARA_COEF mchc_coef;
	PARA_COEF rdw_cv_coef;
	PARA_COEF rdw_sd_coef;

	PARA_COEF plt_coef;
	PARA_COEF mpv_coef;
	PARA_COEF pdw_coef;
	PARA_COEF pct_coef;
	PARA_COEF plcr_coef;
	PARA_COEF plcc_coef;

	PARA_COEF nmcrp_coef;
	PARA_COEF hscrp_coef;
	PARA_COEF flcrp_coef;

	int wbc_measuring_method;
	int diff_measuring_method;
	int rbc_measuring_method;
	int plt_measuring_method;
	int hgb_measuring_method;

	CHANNEL_INFO wbc_channel;
	CHANNEL_INFO diff_channel;
	CHANNEL_INFO rbc_channel;
	CHANNEL_INFO plt_channel;
	CHANNEL_INFO hgb_channel;

	double log4p_para[4];
}INT_ALG_INFO; // record #21

typedef struct
{
	int data_num;
	unsigned short *data;
}MONITOR_PARA;

typedef struct
{
	double ambient_temperature;
	double diff_channel_temperature;
	MONITOR_PARA vacuum_pressure;
	MONITOR_PARA hydraulic_pressure;
}INT_AMBIENT_PARA; // record #24

typedef struct
{
	int cell_num;
	unsigned char *buff;
}CELLLIST_DATA;

typedef struct
{
	CELLLIST_DATA wbc_list;
	CELLLIST_DATA diff_list;
	CELLLIST_DATA baso_list;
	CELLLIST_DATA rbc_list;
	CELLLIST_DATA plt_list;
	MONITOR_PARA  hgb_data;
	MONITOR_PARA  crp_data_lows;
	MONITOR_PARA  crp_data_highs;
}INT_LIST; // record #40

typedef struct
{
	MONITOR_PARA  wbc_aperaperture_voltage;
	MONITOR_PARA  rbc_aperaperture_voltage;
	MONITOR_PARA  wbc_baseline;
	MONITOR_PARA  rbc_baseline;
	MONITOR_PARA  opti_background_voltage;
	MONITOR_PARA  opti_baseline;
}INT_MONITOR_PARA; // record #41

typedef struct
{
	INT_HEADER header;
	INT_SAMPLE sample;
	INT_PATIENT patient;
	INT_SYSTEM_STATE system_state;
	INT_ALG_INFO alg_info;
	INT_AMBIENT_PARA ambient_para;
	INT_LIST list;
	INT_MONITOR_PARA monitor_para;
}INT_FILE; // INT_FILE

int generate_int_file(char *file_path, INT_FILE *int_file);

int bk_generate_new_inf_file(unsigned char *buff, DataCollectHandle *data_handle,
	sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result);

#endif