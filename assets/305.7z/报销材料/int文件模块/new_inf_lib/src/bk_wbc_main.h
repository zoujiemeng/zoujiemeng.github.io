#ifndef BK_ALG_LIB_WBC_MAIN_H
#define BK_ALG_LIB_WBC_MAIN_H

#include <stdlib.h>
#include "impedance.h"

#define WBC_NPS_SEG_NUM (4)
#define WBC_NPS_MAX_NUM (100)
#define WBC_HIST_MAX_FL (400)

// WBCͨ��----------------------------------------------------------------------
// ͼ����Ϣ
typedef struct
{
	stHist  org_hist;                           // ԭʼֱ��ͼ
	stHist  dsp_hist;                           // ��ʾֱ��ͼ
}S_WBC_GRAPH;

// �������
typedef struct
{
	double wbc_value;                                  // 
	double lym_per;                                  // 
	double mid_per;                               // 
	double gran_per;                               // 
	double lym_value;
	double mid_value;
	double gran_value;
	
}S_WBC_REPORT_PARA;

// �о�����
typedef struct
{
	int    nps_abnormal_flag;
	int    lym_peak_index;
	int    gran_peak_index;
	double reserve;
	double R1_tell;
	double R2_tell;
	double R3_tell;
	double R4_tell;
}S_WBC_RESEARCH_PARA;


// ��������
typedef struct
{
	stImpdCellList s_cell_list;
	
}S_WBC_CELL_INFO;

// ��������
typedef struct
{
	int wbc_total_num;                              // 
	double wbc_mcv;
	double lym_mcv;
	int wbc_hist_flag;
	
}S_WBC_OTHER_PARA;

typedef struct 
{
	S_WBC_GRAPH s_graph;
	S_WBC_REPORT_PARA s_report_para;
	S_WBC_RESEARCH_PARA s_research_para;
	S_WBC_CELL_INFO s_cell_info;
	S_WBC_OTHER_PARA s_other_para;

}S_BK_WBC_OUTPUT;

typedef struct 
{
	// ģʽ��Ϣ
	MODE_WORK           WorkMode;                // ����ģʽ
	MODE_BLOOD          BloodMode;               // Ѫ��ģʽ
	MODE_ANALYSIS       AnalyMode;               // ����ģʽ
	MODE_SAMPLE         SampleMode;              // ����ģʽ

	// ϵͳ��Ϣ
	double              Volume;                  // �������
	double              Dilution;                // ����ϡ�ͱ�
	double              MeasureTime;             // ����ʱ��
	double              MeasureFlow;             // ��������

	// ͨ����Ϣ
	int                 pulse_num;                
	unsigned char      *DataAddr;                // ���ݵ�ַ 
	unsigned long       data_num;                // ���ݳ���
	// ������
	int                 lines[Alg_Hist_LineLen];
	stImpdCellList      cell_list;

	//
	float factory_cal_factor;
	float user_cal_factor;
}S_WBC_INPUT;

typedef struct 
{
	char file_path[MAX_PATH];
	int  alg_pos[2];
	S_WBC_INPUT wbc_input;
}S_BK_WBC_INPUT;

/*----------------------------------------------------------------------------*/
#ifdef __cplusplus      // avoid c++ name mangling
extern "C" {
#endif
int BK_wbc_main(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output);

int BK_wbc_main_offline(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output);

int bk_wbc_main_org_alg(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output);
#ifdef __cplusplus
}
#endif
#endif
