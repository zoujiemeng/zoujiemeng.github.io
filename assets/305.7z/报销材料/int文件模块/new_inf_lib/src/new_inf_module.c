#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "datatype.h"
#include "new_inf_module.h"
#include "common_func.h"


//#define ALG_VERSION "1.1.0417"
//#define BK_LINUX_TEST


extern item_cal_factor_t g_calFactor;
extern crp_para_info g_stCrpParaInfo;
extern const CRPCollectChannel *g_crpCollectHandle;
extern const CRPCollectChannel *g_highCrpCollectHandle;
extern const NegPressCollectChannel *g_negCollectHandle;

extern double g_fRatioWbWBC;
extern double g_fRatioWbPLT;
extern double g_fRatioPreWBC;
extern double g_fRatioPrePLT;


#define RECORD_HEADER_LEN (18)

// CRC check function
uint32 crc_check(byte *buff, int buff_len)
{
	unsigned int crc = 0;
	unsigned char i;
	unsigned char *ptr = buff;
	while (buff_len--) {
		for (i = 0x80; i != 0; i = i >> 1) {
			if ((crc & 0x8000) != 0) {
				crc = crc << 1;
				crc = crc ^ 0x1021;
			}
			else {
				crc = crc << 1;
			}
			if ((*ptr & i) != 0) {
				crc = crc ^ 0x1021;
			}
		}
		ptr++;
	}
	return crc;
}

static void write_record_header(FILE *fp, int record_id, int record_len, int crc)
{
	fwrite(&record_id, sizeof(int), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
}

static void write_field_data(FILE *fp, char *buff, int field_id, 
	int data_num, char datatype)
{
	int datatype_len;
	switch (datatype)
	{
	case 1:
	case 2:
		datatype_len = 1;
		break;
	case 3:
		datatype_len = 2;
		break;
	case 4:
	case 5:
		datatype_len = 4;
		break;
	case 6:
		datatype_len = 8;
		break;
	case 7:
		datatype_len = 16;
		break;
	default:
		datatype_len = 0;
		break;
	}
	fwrite(&field_id, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&data_num, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&datatype, sizeof(char), 1, fp);
	fflush(fp);
	fwrite(buff, datatype_len, data_num, fp);
	fflush(fp);
}

static void write_inf_header(FILE *fp, INT_HEADER *header)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 1;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);
	write_field_data(fp, header->inf_ver, 1, INF_STR_LEN, 2);
	write_field_data(fp, header->project_code, 2, INF_STR_LEN, 2);
	write_field_data(fp, header->system_ver, 3, INF_STR_LEN, 2);
	write_field_data(fp, header->timeseq_ver, 4, INF_STR_LEN, 2);
	write_field_data(fp, header->main_fpga_ver, 5, INF_STR_LEN, 2);
	write_field_data(fp, header->drive_fpga_ver, 6, INF_STR_LEN, 2);
	write_field_data(fp, header->drive_mcu_ver, 7, INF_STR_LEN, 2);
	write_field_data(fp, header->alg_ver, 8, INF_STR_LEN, 2);
	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);
	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static void write_inf_sample(FILE *fp, INT_SAMPLE *sample)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 2;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);
	write_field_data(fp, sample->sample_id, 1, INF_STR_LEN, 2);
	write_field_data(fp, &sample->analysis_mode, 2, 1, 2);
	write_field_data(fp, &sample->blood_mode, 3, 1, 2);
	write_field_data(fp, &sample->work_mode, 5, 1, 2);
	write_field_data(fp, &sample->crp_cali_mode, 7, 1, 2);
	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);

	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static void write_inf_system_state(FILE *fp, INT_SYSTEM_STATE *system_state)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 20;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);

	write_field_data(fp, (char *)&system_state->diff_channel_error, 1, 1, 4);
	write_field_data(fp, (char *)&system_state->wbc_channel_error, 2, 1, 4);
	write_field_data(fp, (char *)&system_state->hgb_channel_error, 3, 1, 4);
	write_field_data(fp, (char *)&system_state->rbc_channel_error, 4, 1, 4);
	write_field_data(fp, (char *)&system_state->crp_channel_error, 5, 1, 4);
	write_field_data(fp, (char *)&system_state->ret_channel_error, 6, 1, 4);
	
	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);
	
	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static int write_inf_coef(FILE *fp, PARA_COEF *coef, int index)
{
	write_field_data(fp, (char *)&coef->factory_cali_coef, index, 1, 6);
	write_field_data(fp, (char *)&coef->user_cali_coef, index + 1, 1, 6);
	write_field_data(fp, (char *)&coef->intro_transfer_coef, index + 2, 1, 6);
	write_field_data(fp, (char *)&coef->analysis_transfer_coef, index + 3, 1, 6);
	write_field_data(fp, (char *)&coef->reserve, index + 4, 1, 6);
	return index + 5;
}

static void write_inf_alg_info(FILE *fp, INT_ALG_INFO *alg_info)
{
	int record_id, record_len, coef_index;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 21;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);

	coef_index = 1;
	coef_index = write_inf_coef(fp, &alg_info->wbc_coef, 1);
	/*coef_index = write_inf_coef(fp, &alg_info->neu_num_coef, 6);
	coef_index = write_inf_coef(fp, &alg_info->lym_num_coef, 11);
	coef_index = write_inf_coef(fp, &alg_info->mon_num_coef, 16);
	coef_index = write_inf_coef(fp, &alg_info->eos_num_coef, 21);
	coef_index = write_inf_coef(fp, &alg_info->bas_num_coef, 26);
	coef_index = write_inf_coef(fp, &alg_info->neu_per_coef, 31);
	coef_index = write_inf_coef(fp, &alg_info->lym_per_coef, 36);
	coef_index = write_inf_coef(fp, &alg_info->mon_per_coef, 41);
	coef_index = write_inf_coef(fp, &alg_info->eos_per_coef, 46);
	coef_index = write_inf_coef(fp, &alg_info->bas_per_coef, 51);
	coef_index = write_inf_coef(fp, &alg_info->aly_num_coef, 56);
	coef_index = write_inf_coef(fp, &alg_info->lic_num_coef, 61);
	coef_index = write_inf_coef(fp, &alg_info->aly_per_coef, 66);
	coef_index = write_inf_coef(fp, &alg_info->lic_per_coef, 71);*/
	/*coef_index = write_inf_coef(fp, &alg_info->grann_coef, 76);
	coef_index = write_inf_coef(fp, &alg_info->midn_coef, 81);
	coef_index = write_inf_coef(fp, &alg_info->lymn_coef, 86);
	coef_index = write_inf_coef(fp, &alg_info->granp_coef, 91);
	coef_index = write_inf_coef(fp, &alg_info->midp_coef, 96);
	coef_index = write_inf_coef(fp, &alg_info->lymp_coef, 101);*/

	write_inf_coef(fp, &alg_info->rbc_coef, 201);
	write_inf_coef(fp, &alg_info->hgb_coef, 206);
	//write_inf_coef(fp, &alg_info->hct_coef, 211);
	write_inf_coef(fp, &alg_info->mcv_coef, 216);
	/*write_inf_coef(fp, &alg_info->mch_coef, 221);
	write_inf_coef(fp, &alg_info->mchc_coef, 226);
	write_inf_coef(fp, &alg_info->rdw_cv_coef, 231);
	write_inf_coef(fp, &alg_info->rdw_sd_coef, 236);*/

	write_inf_coef(fp, &alg_info->plt_coef, 301);
	/*write_inf_coef(fp, &alg_info->mpv_coef, 306);
	write_inf_coef(fp, &alg_info->pdw_coef, 311);
	write_inf_coef(fp, &alg_info->pct_coef, 316);
	write_inf_coef(fp, &alg_info->plcr_coef, 321);
	write_inf_coef(fp, &alg_info->plcc_coef, 326);*/

	write_inf_coef(fp, &alg_info->nmcrp_coef, 401);
	//write_inf_coef(fp, &alg_info->hscrp_coef, 406);
	/*write_inf_coef(fp, &alg_info->flcrp_coef, 411);*/

	write_field_data(fp, (char *)&alg_info->wbc_measuring_method, 2001, 1, 4);
	/*write_field_data(fp, &alg_info->diff_measuring_method, 2002, 1, 4);*/
	write_field_data(fp, (char *)&alg_info->rbc_measuring_method, 2003, 1, 4);
	write_field_data(fp, (char *)&alg_info->plt_measuring_method, 2004, 1, 4);
	write_field_data(fp, (char *)&alg_info->hgb_measuring_method, 2005, 1, 4);

	write_field_data(fp, (char *)&alg_info->wbc_channel.channel_volume, 2101, 1, 6);
	write_field_data(fp, (char *)&alg_info->wbc_channel.channel_dilution_ratio, 2102, 1, 6);
	/*write_field_data(fp, &alg_info->diff_channel.channel_volume, 2103, 1, 6);
	write_field_data(fp, &alg_info->diff_channel.channel_dilution_ratio, 2104, 1, 6);*/
	write_field_data(fp, (char *)&alg_info->rbc_channel.channel_volume, 2105, 1, 6);
	write_field_data(fp, (char *)&alg_info->rbc_channel.channel_dilution_ratio, 2106, 1, 6);
	write_field_data(fp, (char *)&alg_info->plt_channel.channel_volume, 2107, 1, 6);
	write_field_data(fp, (char *)&alg_info->plt_channel.channel_dilution_ratio, 2108, 1, 6);
	write_field_data(fp, (char *)&alg_info->hgb_channel.channel_volume, 2109, 1, 6);
	write_field_data(fp, (char *)&alg_info->hgb_channel.channel_dilution_ratio, 2110, 1, 6);

	write_field_data(fp, (char *)&alg_info->wbc_channel.sampling_time, 2201, 1, 6);
	write_field_data(fp, (char *)&alg_info->wbc_channel.sample_flow_capacity, 2202, 1, 6);
	/*write_field_data(fp, &alg_info->diff_channel.sampling_time, 2203, 1, 6);
	write_field_data(fp, &alg_info->diff_channel.sample_flow_capacity, 2204, 1, 6);*/
	write_field_data(fp, (char *)&alg_info->rbc_channel.sampling_time, 2205, 1, 6);
	write_field_data(fp, (char *)&alg_info->rbc_channel.sample_flow_capacity, 2206, 1, 6);
	write_field_data(fp, (char *)&alg_info->plt_channel.sampling_time, 2207, 1, 6);
	write_field_data(fp, (char *)&alg_info->plt_channel.sample_flow_capacity, 2208, 1, 6);
	write_field_data(fp, (char *)&alg_info->hgb_channel.sampling_time, 2209, 1, 6);
	write_field_data(fp, (char *)&alg_info->hgb_channel.sample_flow_capacity, 2210, 1, 6);

	write_field_data(fp, (char *)&alg_info->log4p_para[0], 3001, 1, 6);
	write_field_data(fp, (char *)&alg_info->log4p_para[1], 3002, 1, 6);
	write_field_data(fp, (char *)&alg_info->log4p_para[2], 3003, 1, 6);
	write_field_data(fp, (char *)&alg_info->log4p_para[3], 3004, 1, 6);
	
	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);

	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static void write_inf_ambient_para(FILE *fp, INT_AMBIENT_PARA *ambient_para)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 24;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);

	write_field_data(fp, (char *)&ambient_para->ambient_temperature, 1, 1, 6);
	/*write_field_data(fp, &ambient_para->diff_channel_temperature, 2, 1, 6);*/
	write_field_data(fp, (char *)ambient_para->vacuum_pressure.data, 3,
		ambient_para->vacuum_pressure.data_num, 3);
	/*write_field_data(fp, (char *)ambient_para->hydraulic_pressure.data, 4,
		ambient_para->hydraulic_pressure.data_num, 3);*/
	

	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);
	
	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static void write_inf_list(FILE *fp, INT_LIST *list)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 40;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);

	write_field_data(fp, (char *)list->wbc_list.buff, 1, list->wbc_list.cell_num, 7);
	/*write_field_data(fp, (char *)list->diff_list.buff, 2, list->diff_list.cell_num, 7);
	write_field_data(fp, (char *)list->baso_list.buff, 3, list->baso_list.cell_num, 7);*/
	write_field_data(fp, (char *)list->rbc_list.buff, 4, list->rbc_list.cell_num, 7);
	write_field_data(fp, (char *)list->plt_list.buff, 5, list->plt_list.cell_num, 7);
	write_field_data(fp, (char *)list->hgb_data.data, 6, list->hgb_data.data_num, 3);
	write_field_data(fp, (char *)list->crp_data_lows.data, 7, list->crp_data_lows.data_num, 3);
	write_field_data(fp, (char *)list->crp_data_highs.data, 8, list->crp_data_highs.data_num, 3);

	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);

	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

static void write_inf_monitor_para(FILE *fp, INT_MONITOR_PARA *monitor_para)
{
	int record_id, record_len;
	uint32 crc;
	char record_header[RECORD_HEADER_LEN] = { 0 };
	long field_start_offset, field_end_offset;
	byte *buff;

	record_id = 41;
	fwrite(record_header, sizeof(char), RECORD_HEADER_LEN, fp);
	field_start_offset = ftell(fp);

	write_field_data(fp, (char *)monitor_para->wbc_aperaperture_voltage.data, 1,
		monitor_para->wbc_aperaperture_voltage.data_num, 3);
	write_field_data(fp, (char *)monitor_para->rbc_aperaperture_voltage.data, 2,
		monitor_para->rbc_aperaperture_voltage.data_num, 3);
	write_field_data(fp, (char *)monitor_para->wbc_baseline.data, 3,
		monitor_para->wbc_baseline.data_num, 3);
	write_field_data(fp, (char *)monitor_para->rbc_baseline.data, 4,
		monitor_para->rbc_baseline.data_num, 3);
	/*write_field_data(fp, (char *)monitor_para->opti_background_voltage.data, 5,
		monitor_para->opti_background_voltage.data_num, 3);
	write_field_data(fp, (char *)monitor_para->opti_baseline.data, 6,
		monitor_para->opti_baseline.data_num, 3);*/


	field_end_offset = ftell(fp);

	record_len = field_end_offset - field_start_offset;
	if (NULL == (buff = (byte *)malloc(sizeof(byte)*record_len)))
	{
		crc = 0;
	}
	else
	{
		fseek(fp, field_start_offset, SEEK_SET);
		fread(buff, sizeof(byte), record_len, fp);
		crc = crc_check(buff, record_len);
	}
	FREE_POINTER(buff);

	fseek(fp, field_start_offset - RECORD_HEADER_LEN, SEEK_SET);
	write_record_header(fp, record_id, record_len, crc);
	fseek(fp, field_end_offset, SEEK_SET);

}

int generate_int_file(char *file_path, INT_FILE *int_file)
{
	FILE *fp;

	if (!(fp = fopen(file_path, "wb+")))
		return 1; //�ļ��򿪴���

	write_inf_header(fp, &int_file->header);
	write_inf_sample(fp, &int_file->sample);
	write_inf_system_state(fp, &int_file->system_state);
	write_inf_alg_info(fp, &int_file->alg_info);
	write_inf_ambient_para(fp, &int_file->ambient_para);
	write_inf_list(fp, &int_file->list);
	write_inf_monitor_para(fp, &int_file->monitor_para);

	fclose(fp);
	return 0;
}

static void collect_new_inf_alg_info(INT_FILE *int_file, sample_info_t *sample_info)
{
	int i;
	switch (sample_info->bm)
	{
	case BloodModeWL:
		int_file->alg_info.wbc_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fWbc / 100;
		int_file->alg_info.wbc_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fWbc / 100;
		int_file->alg_info.rbc_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fRbc / 100;
		int_file->alg_info.rbc_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fRbc / 100;
		int_file->alg_info.mcv_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fMcv / 100;
		int_file->alg_info.mcv_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fMcv / 100;
		int_file->alg_info.hgb_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fHgb / 100;
		int_file->alg_info.hgb_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fHgb / 100;
		int_file->alg_info.plt_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fPlt / 100;
		int_file->alg_info.plt_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fPlt / 100;
		int_file->alg_info.nmcrp_coef.factory_cali_coef =
			g_calFactor.wbFactoryCalFactor.fCrp / 100;
		int_file->alg_info.nmcrp_coef.user_cali_coef =
			g_calFactor.wbCalFactor.fCrp / 100;
		// channel info
		int_file->alg_info.wbc_channel.channel_dilution_ratio = g_fRatioWbWBC;
		int_file->alg_info.hgb_channel.channel_dilution_ratio = g_fRatioWbWBC;
		int_file->alg_info.rbc_channel.channel_dilution_ratio = g_fRatioWbPLT;
		int_file->alg_info.plt_channel.channel_dilution_ratio = g_fRatioWbPLT;
		// crp coef
		for (i = 0; i < g_stCrpParaInfo.stWbPara.lParaNum; i++)
		{
			printf("crp_cali_para[%d]:%f\n", i, g_stCrpParaInfo.stWbPara.afPara[i]);
			int_file->alg_info.log4p_para[i] = g_stCrpParaInfo.stWbPara.afPara[i];
		}
		break;
	case BloodModePD:
		int_file->alg_info.wbc_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fWbc / 100;
		int_file->alg_info.wbc_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fWbc / 100;
		int_file->alg_info.rbc_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fRbc / 100;
		int_file->alg_info.rbc_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fRbc / 100;
		int_file->alg_info.mcv_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fMcv / 100;
		int_file->alg_info.mcv_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fMcv / 100;
		int_file->alg_info.hgb_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fHgb / 100;
		int_file->alg_info.hgb_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fHgb / 100;
		int_file->alg_info.plt_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fPlt / 100;
		int_file->alg_info.plt_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fPlt / 100;
		int_file->alg_info.nmcrp_coef.factory_cali_coef =
			g_calFactor.pdFactoryCalFactor.fCrp / 100;
		int_file->alg_info.nmcrp_coef.user_cali_coef =
			g_calFactor.pdCalFactor.fCrp / 100;
		// channel info
		int_file->alg_info.wbc_channel.channel_dilution_ratio = g_fRatioPreWBC;
		int_file->alg_info.hgb_channel.channel_dilution_ratio = g_fRatioPreWBC;
		int_file->alg_info.rbc_channel.channel_dilution_ratio = g_fRatioPrePLT;
		int_file->alg_info.plt_channel.channel_dilution_ratio = g_fRatioPrePLT;
		// crp coef
		for (i = 0; i < g_stCrpParaInfo.stPrePara.lParaNum; i++)
		{
			printf("crp_cali_para[%d]:%f\n", i, g_stCrpParaInfo.stPrePara.afPara[i]);
			int_file->alg_info.log4p_para[i] = g_stCrpParaInfo.stPrePara.afPara[i];
		}
		break;
	default:
		break;
	}
	int_file->alg_info.wbc_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.wbc_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.grann_coef.factory_cali_coef = 1.0;
	int_file->alg_info.grann_coef.user_cali_coef = 1.0;
	int_file->alg_info.grann_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.grann_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.midn_coef.factory_cali_coef = 1.0;
	int_file->alg_info.midn_coef.user_cali_coef = 1.0;
	int_file->alg_info.midn_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.midn_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.lymn_coef.factory_cali_coef = 1.0;
	int_file->alg_info.lymn_coef.user_cali_coef = 1.0;
	int_file->alg_info.lymn_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.lymn_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.granp_coef.factory_cali_coef = 1.0;
	int_file->alg_info.granp_coef.user_cali_coef = 1.0;
	int_file->alg_info.granp_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.granp_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.midp_coef.factory_cali_coef = 1.0;
	int_file->alg_info.midp_coef.user_cali_coef = 1.0;
	int_file->alg_info.midp_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.midp_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.lymp_coef.factory_cali_coef = 1.0;
	int_file->alg_info.lymp_coef.user_cali_coef = 1.0;
	int_file->alg_info.lymp_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.lymp_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.rbc_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.rbc_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.hgb_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.hgb_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.hct_coef.factory_cali_coef = 1.0;
	int_file->alg_info.hct_coef.user_cali_coef = 1.0;
	int_file->alg_info.hct_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.hct_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.mcv_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.mcv_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.mch_coef.factory_cali_coef = 1.0;
	int_file->alg_info.mch_coef.user_cali_coef = 1.0;
	int_file->alg_info.mch_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.mch_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.mchc_coef.factory_cali_coef = 1.0;
	int_file->alg_info.mchc_coef.user_cali_coef = 1.0;
	int_file->alg_info.mchc_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.mchc_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.rdw_cv_coef.factory_cali_coef = 1.0;
	int_file->alg_info.rdw_cv_coef.user_cali_coef = 1.0;
	int_file->alg_info.rdw_cv_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.rdw_cv_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.rdw_sd_coef.factory_cali_coef = 1.0;
	int_file->alg_info.rdw_sd_coef.user_cali_coef = 1.0;
	int_file->alg_info.rdw_sd_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.rdw_sd_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.plt_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.plt_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.mpv_coef.factory_cali_coef = 1.0;
	int_file->alg_info.mpv_coef.user_cali_coef = 1.0;
	int_file->alg_info.mpv_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.mpv_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.pdw_coef.factory_cali_coef = 1.0;
	int_file->alg_info.pdw_coef.user_cali_coef = 1.0;
	int_file->alg_info.pdw_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.pdw_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.pct_coef.factory_cali_coef = 1.0;
	int_file->alg_info.pct_coef.user_cali_coef = 1.0;
	int_file->alg_info.pct_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.pct_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.plcr_coef.factory_cali_coef = 1.0;
	int_file->alg_info.plcr_coef.user_cali_coef = 1.0;
	int_file->alg_info.plcr_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.plcr_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.plcc_coef.factory_cali_coef = 1.0;
	int_file->alg_info.plcc_coef.user_cali_coef = 1.0;
	int_file->alg_info.plcc_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.plcc_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.nmcrp_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.nmcrp_coef.analysis_transfer_coef = 1.0;

	int_file->alg_info.hscrp_coef.factory_cali_coef = 1.0;
	int_file->alg_info.hscrp_coef.user_cali_coef = 1.0;
	int_file->alg_info.hscrp_coef.intro_transfer_coef = 1.0;
	int_file->alg_info.hscrp_coef.analysis_transfer_coef = 1.0;

	
}

void collect_new_inf_info(INT_FILE *int_file, unsigned char *buff,
	DataCollectHandle *data_handle, sample_info_t *sample_info)
{

	memset(int_file, 0, sizeof(INT_FILE));
	// record #1 header
	strcpy(int_file->header.inf_ver, "1.0");
	strcpy(int_file->header.project_code, "bk");
	strcpy(int_file->header.system_ver, sample_info->versionSystem);
	strcpy(int_file->header.drive_fpga_ver, sample_info->versionDriveFpga);
	strcpy(int_file->header.drive_mcu_ver, sample_info->versionMCU);
	strcpy(int_file->header.main_fpga_ver, sample_info->versionMainFpga);
	strcpy(int_file->header.timeseq_ver, sample_info->versionTimeseq);
	strcpy(int_file->header.alg_ver, sample_info->versionAlg);
	// record #2 sample
	strcpy(int_file->sample.sample_id, sample_info->id);
	switch (sample_info->am)
	{
	case AnalysisModeCBC:
		int_file->sample.analysis_mode = '1';
		break;
	case AnalysisModeCRP:
		int_file->sample.analysis_mode = '4';
		break;
	case AnalysisModeCBC_CRP:
		int_file->sample.analysis_mode = '5';
		break;
	default:
		break;
	}
	switch (sample_info->bm)
	{
	case BloodModeWL:
		int_file->sample.blood_mode = '1';
		break;
	case BloodModePD:
		int_file->sample.blood_mode = '2';
		break;
	default:
		break;
	}
	switch (sample_info->wm)
	{
	case WorkModeCount:
		int_file->sample.work_mode = '2';
		break;
	case WorkModeQC:
		int_file->sample.work_mode = '4';
		break;
	case WorkModeCal:
		int_file->sample.work_mode = '6';
		break;
	case WorkModeCalFactory:
		int_file->sample.work_mode = '5';
		break;
	case WorkModeCrpCal:
		int_file->sample.work_mode = '8';
		break;
	default:
		break;
	}
	printf("crp_cali_method:%d\n", g_stCrpParaInfo.calMethod);
	switch (g_stCrpParaInfo.calMethod)
	{
	case CRP_METHOD_LOG4P:
		int_file->sample.crp_cali_mode = '1';
		break;
	case CRP_METHOD_SPLINE:
		int_file->sample.crp_cali_mode = '2';
		break;
	default:
		break;
	}
	
	// record #20 sample
	int_file->system_state.diff_channel_error = 0;
	int_file->system_state.wbc_channel_error = 0;
	int_file->system_state.hgb_channel_error = 0;
	int_file->system_state.rbc_channel_error = 0;
	int_file->system_state.crp_channel_error = 0;
	int_file->system_state.ret_channel_error = 0;
	// record #21 alg_info
	collect_new_inf_alg_info(int_file, sample_info);
	// record #24 ambient_para
	int_file->ambient_para.vacuum_pressure.data = g_negCollectHandle->punAddr;
	int_file->ambient_para.vacuum_pressure.data_num = g_negCollectHandle->ulCount;
	// record #40 list
	int_file->list.wbc_list.buff = buff +
		data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulAddr;
	int_file->list.wbc_list.cell_num = data_handle->
		astChannels[COLLECT_CHANNEL_WBC_PULSE].ulCount / FPGA_PACK_SIZE;

	int_file->list.rbc_list.buff = buff +
		data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulAddr;
	int_file->list.rbc_list.cell_num = data_handle->
		astChannels[COLLECT_CHANNEL_RBC_PULSE].ulCount / FPGA_PACK_SIZE;

	int_file->list.plt_list.buff = buff +
		data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulAddr;
	int_file->list.plt_list.cell_num = data_handle->
		astChannels[COLLECT_CHANNEL_PLT_PULSE].ulCount / FPGA_PACK_SIZE;

	int_file->list.hgb_data.data = (unsigned short *)(buff +
		data_handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr);
	int_file->list.hgb_data.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_HGB].ulCount / sizeof(unsigned short);

	int_file->list.crp_data_lows.data = g_crpCollectHandle->punAddr;
	int_file->list.crp_data_lows.data_num = g_crpCollectHandle->ulCount;

	int_file->list.crp_data_highs.data = g_highCrpCollectHandle->punAddr;
	int_file->list.crp_data_highs.data_num = g_highCrpCollectHandle->ulCount;
	// record #41 monitor_para
	int_file->monitor_para.wbc_aperaperture_voltage.data = (unsigned short *)(buff +
		data_handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr);
	int_file->monitor_para.wbc_aperaperture_voltage.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);

	int_file->monitor_para.rbc_aperaperture_voltage.data = (unsigned short *)(buff +
		data_handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr);
	int_file->monitor_para.rbc_aperaperture_voltage.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);

	int_file->monitor_para.wbc_baseline.data = (unsigned short *)(buff +
		data_handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr);
	int_file->monitor_para.wbc_baseline.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount / sizeof(short);

	int_file->monitor_para.rbc_baseline.data = (unsigned short *)(buff +
		data_handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr);
	int_file->monitor_para.rbc_baseline.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount / sizeof(short);
}

int bk_generate_new_inf_file(unsigned char *buff, DataCollectHandle *data_handle,
	sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result)
{
	INT_FILE int_file;
	// ����������л�ȡinf�ļ���Ҫ����Ϣ������ֵ����Ӧ�Ľṹ���Ա
	collect_new_inf_info(&int_file, buff, data_handle, s_sample_info);
	// ����inf�ļ�����ر���
	char file_path[256];
	char tmp[256];
	time_t t;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".int");
	strcat(file_path, tmp);
	// ����õ��ļ�·����������ṹ��
	memcpy(bk_result->otherresult.infFilePath, file_path, sizeof(char) * 64);
	printf("new_inf_file_path: %s\n", bk_result->otherresult.infFilePath);
	// ����inf�ļ�
	generate_int_file(file_path, &int_file);
	// ����inf�ļ���ִ��CRCУ����ԣ�release�汾ע�ͣ�
	//test_new_inf_file(file_path);
	return 0;
}
