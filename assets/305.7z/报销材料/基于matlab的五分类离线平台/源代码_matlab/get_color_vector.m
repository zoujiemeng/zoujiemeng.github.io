function color = get_color_vector(celltype)

switch celltype
    case 0
        rgb_color = [255 255 255];
    case 1
        rgb_color = [0 0 255];
    case 2
        rgb_color = [0 255 255];
    case 3
        rgb_color = [0 255 0];
    case 4
        rgb_color = [255 0 255];

%     case 2
%         rgb_color = [255 0 255];
%     case 3
%         rgb_color = [0 255 255];
%     case 4
%         rgb_color = [0 255 0];
    case 5
        rgb_color = [217 83 25];
    case 6
        rgb_color = [191 0 191];
    case 7
        rgb_color = [237 177 32];
    case 8
        rgb_color = [255 255 0];
    case 9
        rgb_color = [191 191 0];
    case 10
        rgb_color = [59 113 86];
    case 11
        rgb_color = [245 0 118];
end
color = double (rgb_color)/255;