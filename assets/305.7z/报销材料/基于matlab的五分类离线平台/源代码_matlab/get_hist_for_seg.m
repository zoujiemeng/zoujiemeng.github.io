function hist_data = get_hist_for_seg(hist_len,data_in,max)

factor = double(max)/double(hist_len);
hist_data = zeros(hist_len,1);
for i = 1:length(data_in)
    index = round(data_in(i)/factor);
    if index > hist_len
        index = hist_len;
    else if index == 0
            continue;
        end
    end
    hist_data(index) = hist_data(index) + 1;
end