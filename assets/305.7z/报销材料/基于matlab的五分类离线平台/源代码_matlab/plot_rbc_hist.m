function plot_rbc_hist(rbc_dsp_hist,line,h_axes)

%% RBCֱ��ͼ��ʾ
rbc_dsp_hist = [0;rbc_dsp_hist;0];
max_x = 320;
line = double(line)*max_x/length(rbc_dsp_hist);
step = max_x/length(rbc_dsp_hist);
x = step:step:max_x;
fill(h_axes,x,rbc_dsp_hist,'r');
set(h_axes,'color',[0,0,0],'xlim',[0 max_x],'XTick',(step:80:max_x),'XTickLabel',{'0' '80' '160' '240' '320'});
hold(h_axes,'on');
plot(h_axes,[line(1) line(1)],[0 max(rbc_dsp_hist)*1.5],'w--');
plot(h_axes,[line(2) line(2)],[0 max(rbc_dsp_hist)*1.5],'w--');
hold(h_axes,'off');