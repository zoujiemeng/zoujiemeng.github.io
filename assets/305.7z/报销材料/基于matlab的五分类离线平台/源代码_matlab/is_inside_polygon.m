function bool = is_inside_polygon(poly_x,poly_y,test_x,test_y)

bool = 0;
x = test_x;
y = test_y;
if (x < min(poly_x) || x > max(poly_x) || y < min(poly_y) || y > max(poly_y))
    bool = 0;
    return;
end
num = length(poly_x);
i = 1;
j = num;
while i <= num
    if ((poly_y(i)>y)~=(poly_y(j)>y)) && (x<((poly_x(j)-poly_x(i))*(y-poly_y(i))/(poly_y(j)-poly_y(i))+poly_x(i)))
        bool = ~bool;
    end
    j = i;
    i = i + 1;
end