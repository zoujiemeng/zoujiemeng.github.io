function plot_opti_hist(dsp_hist,h_axes)

%% RBCֱ��ͼ��ʾ
dsp_hist = [0;dsp_hist;0];
x = 1:length(dsp_hist);
fill(h_axes,x,dsp_hist,'r');
set(h_axes,'color',[0,0,0],'xlim',[0 length(dsp_hist)],'xtick',[]);