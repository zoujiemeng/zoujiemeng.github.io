function plot_crp(crp_data,h_axes)
%% WBCֱ��ͼ��ʾ

plot(h_axes,1:length(crp_data),crp_data,'g','linewidth',2);
set(h_axes,'color',[0,0,0],'ylim',[0 max(crp_data)*1.5]);
