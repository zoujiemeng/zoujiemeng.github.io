function opti_channel_3d_plot(plot_info,h_axes)

cla(h_axes);
hold(h_axes,'on');
color = zeros(length(plot_info.celltype),3);
for i = 1:length(plot_info.celltype)
    color(i,:) = get_color_vector(plot_info.celltype(i));
%     plot3(h_axes,plot_info.ls_peak(i),plot_info.ms_peak(i),...
%         plot_info.hs_peak(i),'.','markersize',1.0,'MarkerEdgeColor',color);
end
scatter3(h_axes,plot_info.ms_peak,plot_info.ls_peak,...
         plot_info.hs_peak,1.0,color);
hold(h_axes,'off');
%plot3(h_axes,x,y,z,'.','markersize',1.0,'markeredgecolor','m');
set(h_axes,'color',[0,0,0],'gridcolor',[1,1,1],'linewidth',1.5,'xtick',...
    [],'ytick',[],'ztick',[],'xlim',[0 4095],'ylim',[0 4095],'zlim',[0 4095]);
% xlim = get(h_axes, 'xlim');
% ylim = get(h_axes, 'ylim');
% zlim = get(h_axes, 'zlim');
% xlabel(h_axes,'ls','position',[xlim(2)/2,-0.05,0]);
% ylabel(h_axes,'ms','position',[-0.05,ylim(2)/2,0]);
% zlabel(h_axes,'hs','position',[0,-0.05,zlim(2)/2]);
xlabel(h_axes,'ls');
ylabel(h_axes,'ms');
zlabel(h_axes,'hs');
grid(h_axes,'off');
box(h_axes,'on');