function diff_2d_plot(x,y,celltype,h_axes)

cla(h_axes);
hold(h_axes,'on');
color = zeros(length(celltype),3);
for i = 1:length(celltype)
    color(i,:) = get_color_vector(celltype(i));
end
scatter(h_axes,x,y,1.0,color);

hold(h_axes,'off');
set(h_axes,'color',[0,0,0],'xticklabel',[],'yticklabel',[],'xlim',[0 4095],'ylim',[min(y) 4095]);
xlabel(h_axes,'ls');
ylabel(h_axes,'ms');