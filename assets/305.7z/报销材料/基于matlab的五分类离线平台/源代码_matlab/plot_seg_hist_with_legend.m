function plot_seg_hist_with_legend(org_data,seg_num,channel_num,h_axes)

index_max = length(org_data) - mod(length(org_data),seg_num);
proc_data = reshape(org_data(1:index_max),[],seg_num);

for i = 1:seg_num
    hist_data = get_hist_for_seg(max(org_data),proc_data(:,i),max(org_data));
    x = 1:length(hist_data);
    plot(h_axes,x,hist_data,'linewidth',1.0);
    if i == 1
        hold(h_axes,'on');
    end
    hist_legend{i} = num2str(i);
end
legend(h_axes,hist_legend,'Location','northoutside','Orientation','horizontal');
hold(h_axes,'off');
set(h_axes,'color',[0,0,0],'xlim',[1 length(hist_data)],...
    'ytick',[],'XTick',[]);