function varargout = VK_offline_platform(varargin)
%{
    
    HOW TO CREATE A NEW TAB

    1. Create or copy PANEL and TEXT objects in GUI



    2. Rename tag of PANEL to "tabNPanel" and TEXT for "tabNtext", where N
    - is a sequential number. 
    Example: tab3Panel, tab3text, tab4Panel, tab4text etc.
    
    3. Add to Tab Code - Settings in m-file of GUI a name of the tab to
    TabNames variable

   
%}

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @VK_offline_platform_OpeningFcn, ...
                   'gui_OutputFcn',  @VK_offline_platform_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before VK_offline_platform is made visible.
function VK_offline_platform_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to VK_offline_platform (see VARARGIN)

% Choose default command line output for VK_offline_platform
handles.output = hObject;
set(0,'Units','normalized') %��ò�����ʾ����ʾ����Ϊ[0,0,1,1]�ĸ�ʽ�������������ڶ��ķֱ�������ʾ��������GUI�����ȶ��Ὣ��ʾ������Ϊ[0,0,1,1]
f=gcf;%���GUI���
set(f,'units','norm','position',[.1 .1 .5 .5]) % Set units to norm, and re-size.%��GUI����ʾҲ����Ϊnormalized����ʱGUI�����пؼ��ĵ�λ����normalized��ͬʱ������ʼλ��.



%% Tabs Code
% Settings
TabFontSize = 10;
TabNames = {'��ģ��','DIFFģ��','BASOģ��','RBC/PLTģ��','���ģ��','�ȶ���ģ��','�㷨���ӻ�','����Ա�ģ��'};
FigWidth = 0.265;


% Figure resize
set(handles.SimpleOptimizedTab,'Units','normalized')
pos = get(handles. SimpleOptimizedTab, 'Position');
set(handles. SimpleOptimizedTab, 'Position', [pos(1) pos(2) FigWidth pos(4)])

% Tabs Execution
handles = TabsFun(handles,TabFontSize,TabNames);


%% ��ȡ������Ϣ
option = read_vk_offline_plat_config();
%% ��ȡָ��Ŀ¼���ļ�
num = read_file_list_with_str(option.filedir,'*.inf', handles, 1);
%% ��ʼ������
%% ��ѡ���λ����Ч���ϴ��ļ�λ��
if num > 0
    file_cellstr = get(handles.listbox1, 'String');
    if ~isempty(file_cellstr)
        for i = 1:num
            if iscell(file_cellstr)
                filename = char(file_cellstr(i));
            else
                filename = file_cellstr;
            end
            if strcmp(filename,option.inf_file_name);
                set(handles.listbox1,'value',i);
                %% �������㷨
%                 inf_present_main(hObject,eventdata,handles,option.filedir,filename);
                
                break;
            end
        end
    end
end
% Update handles structure
handles.option = option;
guidata(hObject, handles);

movegui(gcf,'center');

% UIWAIT makes VK_offline_platform wait for user response (see UIRESUME)
% uiwait(handles.SimpleOptimizedTab);

% --- TabsFun creates axes and text objects for tabs
function handles = TabsFun(handles,TabFontSize,TabNames)

% Set the colors indicating a selected/unselected tab
handles.selectedTabColor=get(handles.tab1Panel,'BackgroundColor');
handles.unselectedTabColor=handles.selectedTabColor-0.1;

% Create Tabs
TabsNumber = length(TabNames);
handles.TabsNumber = TabsNumber;
TabColor = handles.selectedTabColor;
for i = 1:TabsNumber
    n = num2str(i);
    
    % Get text objects position
    set(handles.(['tab',n,'text']),'Units','normalized')
    pos=get(handles.(['tab',n,'text']),'Position');

    % Create axes with callback function
    handles.(['a',n]) = axes('Units','normalized',...
                    'Box','on',...
                    'XTick',[],...
                    'YTick',[],...
                    'Color',TabColor,...
                    'Position',[pos(1) pos(2) pos(3) pos(4)+0.01],...
                    'Tag',n,...
                    'ButtonDownFcn',[mfilename,'(''ClickOnTab'',gcbo,[],guidata(gcbo))']);
                    
    % Create text with callback function
    handles.(['t',n]) = text('String',TabNames{i},...
                    'Units','normalized',...
                    'Position',[pos(3),pos(2)/2+pos(4)],...
                    'HorizontalAlignment','left',...
                    'VerticalAlignment','middle',...
                    'Margin',0.001,...
                    'FontSize',TabFontSize,...
                    'Backgroundcolor',TabColor,...
                    'Tag',n,...
                    'ButtonDownFcn',[mfilename,'(''ClickOnTab'',gcbo,[],guidata(gcbo))']);

    TabColor = handles.unselectedTabColor;
end
            
% Manage panels (place them in the correct position and manage visibilities)
set(handles.tab1Panel,'Units','normalized')
pan1pos=get(handles.tab1Panel,'Position');
set(handles.tab1text,'Visible','off')
for i = 2:TabsNumber
    n = num2str(i);
    set(handles.(['tab',n,'Panel']),'Units','normalized')
    set(handles.(['tab',n,'Panel']),'Position',pan1pos)
    set(handles.(['tab',n,'Panel']),'Visible','off')
    set(handles.(['tab',n,'text']),'Visible','off')
end

% --- Callback function for clicking on tab
function ClickOnTab(hObject,~,handles)

global vk_cellinfo;
m = str2double(get(hObject,'Tag'));
vk_cellinfo.tab = m;
vk_cellinfo.diff_pindex = 0;
vk_cellinfo.baso_pindex = 0;

for i = 1:handles.TabsNumber;
    n = num2str(i);
    if i == m
        set(handles.(['a',n]),'Color',handles.selectedTabColor)
        set(handles.(['t',n]),'BackgroundColor',handles.selectedTabColor)
        set(handles.(['tab',n,'Panel']),'Visible','on')
    else
        set(handles.(['a',n]),'Color',handles.unselectedTabColor)
        set(handles.(['t',n]),'BackgroundColor',handles.unselectedTabColor)
        set(handles.(['tab',n,'Panel']),'Visible','off')
    end
end

% --- Outputs from this function are returned to the command line.
function varargout = VK_offline_platform_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
javaFrame = get(gcf,'JavaFrame');  
set(javaFrame,'Maximized',1); 

function option = read_vk_offline_plat_config()

if ~exist('VK_offline_platform_config.ini','file');
    fid = fopen('VK_offline_platform_config.ini','wt');
    fprintf(fid,'%s\n','C:\');
    fprintf(fid,'%s\n','None');
    fprintf(fid,'%s\n','None');
    fclose(fid);
end;
fid = fopen('VK_offline_platform_config.ini','rt');
option.filedir = fgetl(fid);
option.inf_file_name = fgetl(fid);
option.wbcfilename = fgetl(fid);
fclose(fid);

function set_diff_manual_result(diff_info,h_uitable)

total = length(find(diff_info.celltype ~= 1 & diff_info.celltype ~= 0));
if total == 0
    total = 1;
end
ghost_total = length(diff_info.celltype);
data = {'ѪӰ';'����';'�ܰ�';'����';'����';'�ȼ�D';'ԭ��';'����';'ԭ��';'�к˺�';'����';'δ����'};
len = size(data,1);
num_vector = zeros(len,1);
num_str = cell(len,1);
for i = 1:ghost_total
    index = diff_info.celltype(i);
    if  index == 0
        num_vector(len) = num_vector(len) + 1;
    else 
        num_vector(index) = num_vector(index) + 1;
    end
end
per = num_vector/total;
per_vector = cell(len,1);
num_str{1} = num2str(num_vector(1));
per_vector{1} = sprintf('%4.1f',num_vector(1)/ghost_total*100);
for i = 2:length(per)
    num_str{i} = num2str(num_vector(i));
    tmp = sprintf('%4.1f',per(i)*100);
    per_vector{i} = tmp;
end
per_vector{len} = sprintf('%4.1f',num_vector(len)/ghost_total*100);
data = [data num_str per_vector];
set(h_uitable,'data',data);



function diff_present_main(hObject,eventdata,handles,diff_info)

global vk_cellinfo;
vk_cellinfo.diff_info = diff_info;
% �Զ�������չʾ
set_diff_manual_result(diff_info,handles.diff_uitable_auto);
% �ֶ�������ˢ��
set_diff_manual_result(diff_info,handles.diff_uitable_manual);
% ������άɢ��ͼ
opti_channel_3d_plot(diff_info,handles.diff_axes_3d_scatter);
% ������ģ����άɢ��ͼ
opti_channel_3d_plot(diff_info,handles.main_axes_diff);
% ѡ���άɢ��ͼ���ƽǶ�
diff_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles);
% ѡ���ֶ�����ϸ������
diff_buttongroup_color_SelectionChangedFcn(hObject, eventdata, handles);
 
%% ��ͨ����ֱ��ͼչʾ
diff_ls.hist = get_hist_for_seg(256,diff_info.ls_peak,4095);
diff_ms.hist = get_hist_for_seg(256,diff_info.ms_peak,4095);
diff_hs.hist = get_hist_for_seg(256,diff_info.hs_peak,4095);
plot_opti_hist(diff_ls.hist,handles.diff_axes_lshist);
plot_opti_hist(diff_ms.hist,handles.diff_axes_mshist);
plot_opti_hist(diff_hs.hist,handles.diff_axes_hshist);

%% �ֶ�ֱ��ͼ��ʾ
diff_popup_segnum_Callback(hObject, eventdata, handles);

%% NPS����ͼ��ʾ
num = max(diff_info.time_stamp);
if num > 0
    for i = 1:num-1
        index = find(diff_info.time_stamp==i);
        diff_nps(i) = length(index);
    end
    vk_cellinfo.diff_nps = diff_nps;
    diff_popup_nps_smooth_Callback(hObject, eventdata, handles);
end

function wbc_val = set_baso_auto_result(baso_info,h_uitable)

total = length(find(baso_info.celltype ~= 1 & baso_info.celltype ~= 0));
if total == 0
    total = 1;
end
ghost_total = length(baso_info.celltype);
data = {'ѪӰ';'�ȼ�';'NMLE';'����4';'����5';'����6';'����7';'����8';'����9';'����10';'����';'δ����'};
len = size(data,1);
num_vector = zeros(len,1);
num_str = cell(len,1);
for i = 1:ghost_total
    index = baso_info.celltype(i);
    if  index == 0
        num_vector(len) = num_vector(len) + 1;
    else 
        num_vector(index) = num_vector(index) + 1;
    end
end
per = num_vector/total;
per_vector = cell(len,1);
num_str{1} = num2str(num_vector(1));
per_vector{1} = sprintf('%4.1f',num_vector(1)/ghost_total*100);
for i = 2:length(per)
    num_str{i} = num2str(num_vector(i));
    tmp = sprintf('%4.1f',per(i)*100);
    per_vector{i} = tmp;
end
per_vector{len} = sprintf('%4.1f',num_vector(len)/ghost_total*100);
data = [data num_str per_vector];
% wbc_num = length(find(baso_info.celltype ~= 1));
% wbc_val = wbc_num*124.4/(8.5754*11.7)/1000;
% wbc_str = {'WBC' num2str(wbc_num) sprintf('%4.2f 10^9/L',wbc_val)};
% data = [wbc_str;data];
wbc_val = 0;
set(h_uitable,'data',data);


function set_baso_manual_result(baso_info,h_uitable)

total = length(find(baso_info.celltype ~= 1 & baso_info.celltype ~= 0));
if total == 0
    total = 1;
end
ghost_total = length(baso_info.celltype);
data = {'ѪӰ';'�ȼ�';'NMLE';'����4';'����5';'����6';'����7';'����8';'����9';'����10';'����';'δ����'};
len = size(data,1);
num_vector = zeros(len,1);
num_str = cell(len,1);
for i = 1:ghost_total
    index = baso_info.celltype(i);
    if  index == 0
        num_vector(len) = num_vector(len) + 1;
    else 
        num_vector(index) = num_vector(index) + 1;
    end
end
per = num_vector/total;
per_vector = cell(len,1);
num_str{1} = num2str(num_vector(1));
per_vector{1} = sprintf('%4.1f',num_vector(1)/ghost_total*100);
for i = 2:length(per)
    num_str{i} = num2str(num_vector(i));
    tmp = sprintf('%4.1f',per(i)*100);
    per_vector{i} = tmp;
end
per_vector{len} = sprintf('%4.1f',num_vector(len)/ghost_total*100);
data = [data num_str per_vector];
set(h_uitable,'data',data);

function baso_re = baso_present_main(hObject,eventdata,handles,baso_info)

global vk_cellinfo;

% չʾ�Զ�������
baso_info.celltype(baso_info.celltype == 11) = 2;
baso_info.celltype(baso_info.celltype == 12) = 3;
baso_re.wbc = set_baso_auto_result(baso_info,handles.baso_uitable_auto);
% �ֶ�������ˢ��
set_baso_manual_result(baso_info,handles.baso_uitable_manual);
% ������άɢ��ͼ
baso_info.celltype(baso_info.celltype == 2) = 4;
baso_info.celltype(baso_info.celltype == 3) = 2;
opti_channel_3d_plot(baso_info,handles.baso_axes_3d_scatter);
% ������ģ����άɢ��ͼ
opti_channel_3d_plot(baso_info,handles.main_axes_baso);
vk_cellinfo.baso_info = baso_info;
% ѡ���άɢ��ͼ���ƽǶ�
baso_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles);
% ѡ���ֶ�����ϸ������
baso_buttongroup_color_SelectionChangedFcn(hObject, eventdata, handles);
%% ��ͨ����ֱ��ͼչʾ
baso_ls.hist = get_hist_for_seg(256,baso_info.ls_peak,4095);
baso_ms.hist = get_hist_for_seg(256,baso_info.ms_peak,4095);
baso_hs.hist = get_hist_for_seg(256,baso_info.hs_peak,4095);
plot_opti_hist(baso_ls.hist,handles.baso_axes_lshist);
plot_opti_hist(baso_ms.hist,handles.baso_axes_mshist);
plot_opti_hist(baso_hs.hist,handles.baso_axes_hshist);

%% �ֶ�ֱ��ͼ��ʾ
baso_popup_segnum_Callback(hObject, eventdata, handles);

%% NPS����ͼ��ʾ
num = max(baso_info.time_stamp);
if num > 0
    for i = 1:num-1
        index = find(baso_info.time_stamp==i);
        baso_nps(i) = length(index);
    end
    vk_cellinfo.baso_nps = baso_nps;
    baso_popup_nps_smooth_Callback(hObject, eventdata, handles);
end

function plot_monitor_from_short_data(monitor_data,xlabel_str,ylabel_str,h_axes)

if ~isempty(monitor_data)
    tmp_data = monitor_data;
    if strcmp(ylabel_str,'kPa')
        data = -(bitand(tmp_data,32767,'int16'));
        data = double(data)/10;
    else
        data = double(tmp_data);
    end
    plot(h_axes,1:length(data),data,'r');
    set(h_axes,'color',[0,0,0],'xlim',[1 length(data)+100]);
    xlabel(h_axes,xlabel_str);
    ylabel(h_axes,ylabel_str);
%     hold(h_axes,'on');
%     plot(h_axes,pos.start,data(pos.start),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
%     plot(h_axes,pos.end,data(pos.end),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
%     hold(h_axes,'off');
else
    cla(h_axes);
end

function para_present_main(re,h_uitable)

%%������ʾ
tmp = sprintf('%4.2f',re.wbc);
wbc = {'WBC' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.neup);
neup = {'NEU%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.lymp);
lymp = {'LYM%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.monp);
monp = {'MON%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.eosp);
eosp = {'EOS%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.basp);
basp = {'BAS%' tmp ' ' '%'};
tmp = sprintf('%4.2f',re.neun);
neun = {'NEU#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.lymn);
lymn = {'LYM#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.monn);
monn = {'MON#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.eosn);
eosn = {'EOS#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.basn);
basn = {'BAS#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.rbc);
rbc = {'RBC' tmp ' ' '10^12/L'};
tmp = sprintf('%5.2f',re.hgb);
hgb = {'HGB' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.hct);
hct = {'HCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.mcv);
mcv = {'MCV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.mch);
mch = {'MCH' tmp ' ' 'pg'};
tmp = sprintf('%4.0f',re.mchc);
mchc = {'MCHC' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.rdw_cv);
rdw_cv = {'RDW_CV' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.rdw_sd);
rdw_sd = {'RDW_SD' tmp ' ' 'fL'};
tmp = sprintf('%5.1f',re.plt);
plt = {'PLT' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.mpv);
mpv = {'MPV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.pdw);
pdw = {'PDW' tmp ' ' ' '};
tmp = sprintf('%4.3f',re.pct);
pct = {'PCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.plcc);
plcc = {'PLCC' tmp ' ' '10^9/L'};
tmp = sprintf('%5.1f',re.plcr);
plcr = {'PLCR' tmp ' ' '%'};

blank = {' ' ' ' ' ' ' ' };

data = [wbc;neup;lymp;monp;eosp;basp;neun;lymn;monn;eosn;basn;blank;...
    rbc;hgb;hct;mcv;mch;mchc;rdw_cv;rdw_sd;blank;plt;mpv;pdw;pct;plcr;...
    plcc];
set(h_uitable,'data',data);

function present_sample_info(sample,header,h_uitable)

switch sample.analysis_mode
    case 0 %CBC
        am_str = 'CBC';
    case 1 %CRP
        am_str = 'CRP';
    case 2 %CBC+CRP
        am_str = 'CBC+CRP';
    otherwise
        am_str = 'Unknown';
end
am_str = {'����ģʽ' am_str};
switch sample.blood_mode
    case 0 %ȫѪ
        bm_str = 'ȫѪ';
    case 1 %Ԥϡ��
        bm_str = 'Ԥϡ��';
    otherwise
        bm_str = 'Unknown';
end
bm_str = {'Ѫ��ģʽ' bm_str};
switch sample.sample_type
    case 0 %����Ѫ
        st_str = '����Ѫ';
    otherwise
        st_str = 'Unknown';
end
st_str = {'��������' st_str};
blank = {' ' ' '};

system_ver = {'ϵͳ�汾��' header.system_ver};
timeseq_ver = {'Һ·�汾��' header.timeseq_ver};
mainfpga_ver = {'���ذ�FPGA�汾��' header.main_ver};
alg_ver = {'�㷨�汾��' header.alg_ver};
inf_ver = {'INF�汾��' sprintf('%d',header.inf_ver)};
driverfpga_ver = {'������FPGA�汾��' header.drivefpga_ver};
drivermcu_ver = {'������MCU�汾��' header.mcu_ver};
machine_info = {'������Ϣ' 'δ��¼'};
oem_info = {'OEM��Ϣ' 'δ��¼'};
alg_type = {'�㷨����' '����'};


data = [am_str;bm_str;st_str;system_ver;timeseq_ver;alg_ver;...
    mainfpga_ver;driverfpga_ver;drivermcu_ver;machine_info;oem_info;alg_type;inf_ver];
set(h_uitable,'data',data,'columnwidth',{150 100});

function plot_matrix(h_axes,x,y,z)

[X,Y] = meshgrid(x,y);
colormap(hsv);
surf(h_axes,X,Y,z);
shading faceted;
set(h_axes,'color',[0,0,0],'xlim',[1 length(x)],'ylim',[1 length(y)],'zlim',[0 max(max(z))],...
    'GridLineStyle','--');

function inf_present_main(hObject,eventdata,handles,filedir,filename)

%% ��ʼ���ļ���
filepath = fullfile(filedir,filename);
config.sample_id = filename(1:length(filename)-4);
config.crp_start_pos = 20;
config.crp_end_pos = 230;
config.crp_seglen = 5;
%% �����㷨��
[header,sample,vk_re,cell_info,monitor] = vk_inf_recal(filepath,config);
%% ls_ms_alg_matrix
plot_matrix(handles.axes_ls_ms_alg,1:64,1:64,cell_info.ls_ms_alg');
plot_matrix(handles.axes_ls_hs_alg,1:64,1:64,cell_info.ls_hs_alg');
%% �汾����ʾ
present_sample_info(sample,header,handles.uitable_sampleinfo);
%% diff
if isempty(cell_info.diff_info.ls_peak)
    msgbox('DIFFͨ�������ݣ�','��ʾ');
else
    diff_present_main(hObject,eventdata,handles,cell_info.diff_info);
end
%% baso
if isempty(cell_info.baso_info.ls_peak)
    msgbox('BASOͨ�������ݣ�','��ʾ');
else
    baso_present_main(hObject,eventdata,handles,cell_info.baso_info);
end
%% stability
option = initial_sta_option(handles);
stability_present_main(option,handles,'sta_axes_scatter');
%% hgbģ��
hgb_pos.bk = 10;
hgb_pos.me = 3140;
hgb_vol = double(monitor.hgb_data);
h_hgb = plot_hgb_data(hgb_vol,hgb_pos,handles.axes_hgb);
handles.h_hgb = h_hgb;
guidata(hObject,handles);

%% RBC/PLTģ��
handles.re = vk_re.old;
re = vk_re.old;
guidata(hObject, handles);
% ���������ʾ
para_present_rbc(re,handles);
% ֱ��ͼ��ʾ
plot_rbc_hist(re.rbc_hist,re.rbc_line,handles.axes_rbc_hist);
plot_plt_hist(re.plt_hist,re.plt_line,handles.axes_plt_hist);
% RBC�ֶ�ֱ��ͼ�洢����ʾ
width_data = cell_info.rbc_fullwidth;
if isempty(width_data)
    cla(handles.axes_rbc_width);
    cla(handles.axes_rbc_vol);
    cla(handles.axes_rbc_nps);
else
    handles.rbc_width_data = width_data;
    handles.rbc_peak_data = cell_info.rbc_peak;
    handles.rbc_time = cell_info.rbc_time;
    guidata(hObject, handles);
    popup_rbc_seg_Callback(hObject, eventdata, handles);
end

% PLT�ֶ�ֱ��ͼ�洢����ʾ
width_data = cell_info.plt_fullwidth;
if isempty(width_data)
    cla(handles.axes_plt_width);
    cla(handles.axes_plt_vol);
    cla(handles.axes_plt_nps);
else
    handles.plt_width_data = width_data;
    handles.plt_peak_data = cell_info.plt_peak;
    handles.plt_time = cell_info.plt_time;
    guidata(hObject, handles);
    popup_plt_seg_Callback(hObject, eventdata, handles);
    % NPSģ�����ݴ洢����ʾ
    num = max(cell_info.rbc_time);
    for i = 1:num
        index = find(cell_info.rbc_time==i);
        rbc_nps(i) = length(index);
    end
    handles.rbc_nps = rbc_nps;
    guidata(hObject, handles);
    popup_rbc_nps_sec_Callback(hObject, eventdata, handles);
    %plot_nps_manual_line(handles.axes_rbc_nps,BK_rbc_config.nps_start,BK_rbc_config.nps_end,'g');
    
    num = max(cell_info.plt_time);
    if num > 0
        for i = 1:num
            index = find(cell_info.plt_time==i);
            plt_nps(i) = length(index);
        end
        
        handles.plt_nps = plt_nps;
        guidata(hObject, handles);
        
        popup_plt_nps_sec_Callback(hObject, eventdata, handles);
        %plot_nps_manual_line(handles.axes_plt_nps,BK_rbc_config.nps_start,BK_rbc_config.nps_end,'w');
    end
end
%% ��ģ��
% ���չʾ����ʱ��
para_present_main(re,handles.uitable_main_re);
% У׼ϵ��չʾģ��
present_main_cb(sample,handles.uitable_main_cb);
% ֱ��ͼ��ʾ
plot_rbc_hist(re.rbc_hist,re.rbc_line,handles.main_axes_rbc);
plot_plt_hist(re.plt_hist,re.plt_line,handles.main_axes_plt);
%% monitorģ��
% ��ѧ���׵�ѹ
plot_monitor_from_short_data(monitor.opti_vol_data,'0.01s','AD',handles.axes_opti_vol);
% ��ѧ����
plot_monitor_from_short_data(monitor.opti_base_data,'0.01s','AD',handles.axes_opti_base);
% RBCС�׵�ѹ
plot_monitor_from_short_data(monitor.rhole_data,'0.01s','AD',handles.axes_rhole);
% RBC����
plot_monitor_from_short_data(monitor.rbase_data,'0.01s','AD',handles.axes_rbase);
% ���ѹ��
plot_monitor_from_short_data(monitor.airp_data,'0.05s','kPa',handles.axes_air_pressure);
% Һ��ѹ��
plot_monitor_from_short_data(monitor.hydp_data,'0.05s','0.1kPa',handles.axes_hydr_pressure);
%% CRPģ��

%% ����Ա�ģ��

function present_main_gain(re,h_uitable)

tmp = sprintf('%4.0f',re.wbc_gain);
wbc = {'WBC' tmp};
tmp = sprintf('%4.0f',re.rbc_gain);
rbc = {'RBC' tmp};
tmp = sprintf('%4.0f',re.hgb_gain);
hgb = {'HGB' tmp};
tmp = sprintf('%4.0f',re.crp_gain);
crp = {'CRP' tmp};

data = [wbc;rbc;hgb;crp];
set(h_uitable,'data',data);


function present_main_cb(re,h_uitable)

tmp1 = sprintf('%5.2f',re.wbc_fcb*100);
tmp2 = sprintf('%5.2f',re.wbc_ucb*100);
wbc = {'WBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.rbc_fcb*100);
tmp2 = sprintf('%5.2f',re.rbc_ucb*100);
rbc = {'RBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.plt_fcb*100);
tmp2 = sprintf('%5.2f',re.plt_ucb*100);
plt = {'PLT' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.hgb_fcb*100);
tmp2 = sprintf('%5.2f',re.hgb_ucb*100);
hgb = {'HGB' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.mcv_fcb*100);
tmp2 = sprintf('%5.2f',re.mcv_ucb*100);
mcv = {'MCV' tmp1 tmp2};
data = [wbc;rbc;hgb;mcv;plt];
set(h_uitable,'data',data);

function stability_present_main(option,handles,scatter_str)

global vk_cellinfo;
switch option.channel
    case 'DIFF'
        cellinfo = vk_cellinfo.diff_info;
        cell_time = cellinfo.time_stamp(cellinfo.time_stamp ~= 116);
    case 'BASO'
        cellinfo = vk_cellinfo.baso_info;
        cell_time = cellinfo.time_stamp;
end
time_seglen = floor(double(max(cell_time))/option.segnum);
cellnum_str = [];
for i = 1:8
    if i > option.segnum
        set(handles.([scatter_str,num2str(i)]),'xticklabel',[],'yticklabel',[]);
        cla(handles.([scatter_str,num2str(i)]));
    else
        index = find(cell_time >= (i-1)*time_seglen & cell_time < i*time_seglen);
        cellnum_str = [cellnum_str;{num2str(i) num2str(length(index))}];
        seg_diff_2d_plot(cellinfo.ms_peak(index),cellinfo.ls_peak(index),...
            cellinfo.celltype(index),handles.([scatter_str,num2str(i)]));
    end
end
set(handles.uitable_sta_cellnum,'data',cellnum_str);


function seg_diff_2d_plot(x,y,celltype,h_axes)

cla(h_axes);
hold(h_axes,'on');
color = zeros(length(celltype),3);
for i = 1:length(celltype)
    color(i,:) = get_color_vector(celltype(i));
end
scatter(h_axes,x,y,1.0,'w');

hold(h_axes,'off');
set(h_axes,'color',[0,0,0],'xticklabel',[],'yticklabel',[],'xlim',[0 4095],'ylim',[0 4095]);


function para_present_rbc(re,handles)

%%21�������ʾ
tmp = sprintf('%4.2f',re.rbc);
rbc = {'RBC' tmp ' ' '10^12/L'};
tmp = sprintf('%5.2f',re.hgb);
hgb = {'HGB' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.hct);
hct = {'HCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.mcv);
mcv = {'MCV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.mch);
mch = {'MCH' tmp ' ' 'pg'};
tmp = sprintf('%4.0f',re.mchc);
mchc = {'MCHC' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.rdw_cv);
rdw_cv = {'RDW_CV' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.rdw_sd);
rdw_sd = {'RDW_SD' tmp ' ' 'fL'};
tmp = sprintf('%5.1f',re.plt);
plt = {'PLT' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.mpv);
mpv = {'MPV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.pdw);
pdw = {'PDW' tmp ' ' ' '};
tmp = sprintf('%4.3f',re.pct);
pct = {'PCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.plcc);
plcc = {'PLCC' tmp ' ' '10^9/L'};
tmp = sprintf('%5.1f',re.plcr);
plcr = {'PLCR' tmp ' ' '%'};

blank = {' ' ' ' ' ' ' ' };

tmp = sprintf('%9.0f',re.rbc_total_num);
rbc_total_num = {'RBC��Ч������' tmp ' ' ''};
tmp = sprintf('%9.0f',re.plt_total_num);
plt_total_num = {'PLT��Ч������' tmp ' ' ''};

tmp = sprintf('%9.0f',re.rbc_org_num);
rbc_org_num = {'RBCʶ��������' tmp ' ' ''};
tmp = sprintf('%9.0f',re.plt_org_num);
plt_org_num = {'PLTʶ��������' tmp ' ' ''};
tmp = sprintf('%4.2f',re.hgb_bk_volt);
hgb_bk_volt = {'HGB���׵�ѹֵ' tmp ' ' 'V'};
tmp = sprintf('%4.2f',re.hgb_me_volt);
hgb_me_volt = {'HGB������ѹֵ' tmp ' ' 'V'};


data = [rbc;hgb;hct;mcv;mch;mchc;rdw_cv;rdw_sd;blank;plt;mpv;pdw;pct;plcr;...
    plcc;blank;rbc_total_num;rbc_org_num;plt_total_num;plt_org_num;...
    hgb_bk_volt;hgb_me_volt];
set(handles.uitable_rbc_re,'data',data);


function [hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample)

config = readtable('configure_table.csv');
switch sample.analysis_mode
    case 0 %CBC
        hgb_pos.bk = str2double(cell2mat(config.cbc_hgb_bk_pos(3)))*100;
        hgb_pos.me = str2double(cell2mat(config.cbc_hgb_me_pos(3)))*100;
        whole_pos_start = str2double(cell2mat(config.cbc_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_wbc_end_pos(3)))*100 - ap_start);
    case 2 %CBC+CRP
        hgb_pos.bk = str2double(cell2mat(config.cbc_crp_hgb_bk_pos(3)))*100;
        hgb_pos.me = str2double(cell2mat(config.cbc_crp_hgb_me_pos(3)))*100;
        whole_pos_start = str2double(cell2mat(config.cbc_crp_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_crp_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_crp_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - ap_start);
    otherwise
        hgb_pos.bk = str2double(cell2mat(config.cbc_crp_hgb_bk_pos(3)))*100;
        hgb_pos.me = str2double(cell2mat(config.cbc_crp_hgb_me_pos(3)))*100;
        whole_pos_start = str2double(cell2mat(config.cbc_crp_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_crp_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_crp_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - ap_start);
end

function msg_out = identify_abnormal_base(data,h_table,module,alarm_msg)

overflow_num = 0;
for i = 1:length(data)
    if data(i) == 4095
        overflow_num = overflow_num + 1;
    end
end
if overflow_num > 10
    tmp = {module '���������쳣' '�������'};
    msg_out = [alarm_msg;tmp];
else
    msg_out = alarm_msg;
end


function msg_out = identify_abnormal_voltage(data,h_table,module,alarm_msg)

step = 9;
for i = 1:length(data)/step-1
    df(i) = data(step*(i+1))-data(step*i);
end
tmp = [];
thresh = 4;
for i = 1:length(df)-3
    if df(i) > thresh && df(i+1) > thresh  && df(i+2) > thresh-1 && df(i+3) > thresh-2
        tmp = {module 'С�׵�ѹ�쳣' '�쳣����'};
    else if df(i) < -1*thresh && df(i+1) < -1*thresh+1 && df(i+2) < -1*thresh+1 && df(i+3) < -1*thresh+2
            tmp = {module 'С�׵�ѹ�쳣' '�쳣�½�'};
        end
    end
end
if ~isempty(tmp)
    if isempty(alarm_msg)
        msg_out = tmp;
    else
        msg_out = [alarm_msg;tmp];
    end
else
    msg_out = alarm_msg;
end

function bool = if_abnormal_voltage(data)

step = 9;
for i = 1:length(data)/step-1
    df(i) = data(step*(i+1))-data(step*i);
end
bool = 0;
thresh = 4;
for i = 1:length(df)-3
    if df(i) > thresh && df(i+1) > thresh  && df(i+2) > thresh-1 && df(i+3) > thresh-2
        bool = 1;
    else if df(i) < -1*thresh && df(i+1) < -1*thresh+1 && df(i+2) < -1*thresh+1 && df(i+3) < -1*thresh+2
            bool = 1;
        end
    end
end


% set(h_table,'data',msg_out);

function plot_aperture_vol(data,h_axes,pos)

if ~isempty(data)
    plot(h_axes,1:length(data),data,'r');
    set(h_axes,'color',[0,0,0],'xlim',[1 length(data)+100],...
        'XTick',(1:1000:length(data)+100),'XTickLabel',{'10' '20' '30' '40'});
    hold(h_axes,'on');
    plot(h_axes,pos.start,data(pos.start),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
    plot(h_axes,pos.end,data(pos.end),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
    hold(h_axes,'off');
end

function edit_path_Callback(hObject, eventdata, handles)
% hObject    handle to edit_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_path as text
%        str2double(get(hObject,'String')) returns contents of edit_path as a double


% --- Executes during object creation, after setting all properties.
function edit_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_browse.
function button_browse_Callback(hObject, eventdata, handles)
% hObject    handle to button_browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
FileInPath = get(handles.edit_path,'String');
filter = strcat(FileInPath,'*.inf');
[~,folder_name]= uigetfile(filter,'�򿪹�ѧFPGAʶ�����ļ�');
% folder_name = uigetdir(char(FileInPath),'��inf�ļ�');
if folder_name == 0
    folder_name = 'C:/';
end
num = read_file_list_with_str(folder_name,'*.inf', handles, 0);
if num > 0
    option.filedir = folder_name;
    handles.option = option;
    guidata(hObject,handles);
end

% --- Executes on button press in button_analyse.
function button_analyse_Callback(hObject, eventdata, handles)
% hObject    handle to button_analyse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;

tempstr = cellstr(get(handles.listbox1,'String'));
value = get(handles.listbox1,'Value');
filename = tempstr{value};


inf_present_main(hObject,eventdata,handles,option.filedir,filename);

%% ������ر���
option.inf_file_name = filename;
handles.option = option;
guidata(hObject,handles);


%% WBCֱ��ͼ�ֶ�����ģ��
function wbc_hist_with_callback(wbc_dsp_hist,line,handles)

%% WBCֱ��ͼ��ʾ
line = [15;44;68];
wbc_dsp_hist = [wbc_dsp_hist;0];
wbc_dsp_hist = smooth(double(wbc_dsp_hist));
h_wbc_hist = fill(handles.axes_wbc,1:length(wbc_dsp_hist),wbc_dsp_hist,'w');
ylim_max = max(wbc_dsp_hist)*1.5;
if ylim_max <= 0
    ylim_max = 1;
end
set(handles.axes_wbc,'color',[0,0,0],'ytick',[],'xlim',[0 length(wbc_dsp_hist)],...
    'ylim',[0 ylim_max]);
hold(handles.axes_wbc,'on');
plot(handles.axes_wbc,[line(1) line(1)],[0 max(wbc_dsp_hist)*1.5],'w--');
plot(handles.axes_wbc,[line(2) line(2)],[0 max(wbc_dsp_hist)*1.5],'w--');
plot(handles.axes_wbc,[line(3) line(3)],[0 max(wbc_dsp_hist)*1.5],'w--');
hold(handles.axes_wbc,'off');
set(h_wbc_hist,'ButtonDownFcn',{@wbc_hist_buttondown_Callback,handles});


function wbc_hist_buttondown_Callback(hObject,eventdata, handles) %�Զ����callback����

global BK_wbc_config;

if strcmp(get(gcf,'SelectionType'),'normal') % ����������
    ClickPoint = get(gca,'currentpoint');
    col_coordinate = round(ClickPoint(1,1));
    if col_coordinate < 2 || col_coordinate > 255
        msgbox('��������ѡ��Χ��','����');
        return;
    end
    BK_wbc_config.wbc_line(BK_wbc_config.line_index) = col_coordinate;
    wbc_hist_with_callback(handles.wbc_dsp_hist,BK_wbc_config.wbc_line,handles);
    
    
else if strcmp(get(gcf,'SelectionType'),'alt') % ����Ҽ�����
        
    end;
        
end;

function crp_result_present(re,handles)

tmp = sprintf('%4.1f',re.crp_val);
crp = {'CRP' tmp};
tmp = sprintf('%4.1f',re.crp_ori_val);
crp_ori = {'CRP_ori' tmp};
tmp = sprintf('%4.2f',re.crp_reaction);
reaction = {'reaction' tmp};


data = [crp;crp_ori;reaction];
set(handles.uitable_crp_re,'data',data);


function config_present(re,handles)

tmp = sprintf('%4.0f',re.wbc_gain);
wbc = {'WBC' tmp};
tmp = sprintf('%4.0f',re.rbc_gain);
rbc = {'RBC' tmp};
tmp = sprintf('%4.0f',re.hgb_gain);
hgb = {'HGB' tmp};
tmp = sprintf('%4.0f',re.crp_gain);
crp = {'CRP' tmp};

data = [wbc;rbc;hgb;crp];
set(handles.uitable_main_gain,'data',data);

tmp1 = sprintf('%5.2f',re.wbc_fcb*100);
tmp2 = sprintf('%5.2f',re.wbc_ucb*100);
wbc = {'WBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.rbc_fcb*100);
tmp2 = sprintf('%5.2f',re.rbc_ucb*100);
rbc = {'RBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.plt_fcb*100);
tmp2 = sprintf('%5.2f',re.plt_ucb*100);
plt = {'PLT' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.hgb_fcb*100);
tmp2 = sprintf('%5.2f',re.hgb_ucb*100);
hgb = {'HGB' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.mcv_fcb*100);
tmp2 = sprintf('%5.2f',re.mcv_ucb*100);
mcv = {'MCV' tmp1 tmp2};
data = [wbc;rbc;hgb;mcv;plt];
set(handles.uitable_main_cb,'data',data);


function para_present_wbc(re,handles)

%%21�������ʾ
tmp = sprintf('%4.2f',re.wbc);
wbc = {'WBC' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.lymn);
lymn = {'LYM#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.midn);
midn = {'MID#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.grann);
grann = {'GRAN#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.lymp);
lymp = {'LYM%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.midp);
midp = {'MID%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.granp);
granp = {'GRAN%' tmp ' ' '%'};

blank = {' ' ' ' ' ' ' ' };

tmp = sprintf('%9.0f',re.wbc_total_num);
wbc_total_num = {'WBC��Ч������' tmp ' ' ''};
tmp = sprintf('%4.1f',re.wbc_mcv);
wbc_mcv = {'WBC_MCV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.lym_mcv);
lym_mcv = {'LYM_MCV' tmp ' ' 'fL'};

data = [wbc;lymn;midn;grann;lymp;midp;granp;blank;wbc_total_num;wbc_mcv;lym_mcv];
set(handles.uitable_wbc_re,'data',data);

% --- Executes on selection change in popup_bm.
function popup_bm_Callback(hObject, eventdata, handles)
% hObject    handle to popup_bm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_bm contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_bm


% --- Executes during object creation, after setting all properties.
function popup_bm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_bm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_am.
function popup_am_Callback(hObject, eventdata, handles)
% hObject    handle to popup_am (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_am contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_am


% --- Executes during object creation, after setting all properties.
function popup_am_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_am (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_file_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popup_wbc_seg.
function popup_wbc_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_seg
contents = cellstr(get(handles.popup_wbc_seg,'String'));
seg_num = str2double(contents{get(handles.popup_wbc_seg,'Value')});
index_max = length(handles.wbc_width_data) - mod(length(handles.wbc_width_data),seg_num);
width_data = reshape(handles.wbc_width_data(1:index_max),[],seg_num);
%eqwidth_data = reshape(handles.eqwidth_data(1:index_max),[],seg_num);
peak_data = reshape(handles.wbc_peak_data(1:index_max),[],seg_num);

for i = 1:seg_num
    width_hist = get_hist_for_seg(60,width_data(:,i),max(handles.wbc_width_data(1:index_max)));
    x = 1:length(width_hist);
    plot(handles.axes_wbc_width,x,width_hist,'linewidth',1.0);
    %eqwidth_hist = get_hist_for_seg(256,eqwidth_data(:,i),max(handles.eqwidth_data(1:index_max)));
    %x = 1:length(eqwidth_hist);
    %plot(handles.axes_seg_eqwidth,x,eqwidth_hist);
    area_hist = get_hist_for_seg(256,peak_data(:,i),max(handles.wbc_peak_data(1:index_max)));
    x = 1:length(area_hist);
    plot(handles.axes_wbc_vol,x,area_hist);
    if i == 1
        hold(handles.axes_wbc_width,'on');
        %hold(handles.axes_seg_eqwidth,'on');
        hold(handles.axes_wbc_vol,'on');
    end
    width_legend{i} = num2str(i); 
end
legend(handles.axes_wbc_width,width_legend,'Location','northoutside','Orientation','horizontal');
% legend(handles.axes_wbc_width,'boxoff');
hold(handles.axes_wbc_width,'off');
%hold(handles.axes_seg_eqwidth,'off');
hold(handles.axes_wbc_vol,'off');
set(handles.axes_wbc_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
% set(handles.axes_seg_eqwidth,'color',[0,0,0],'xlim',[1 length(eqwidth_hist)],...
%     'ytick',[],'XTick',[]);
set(handles.axes_wbc_vol,'color',[0,0,0],'xlim',[1 length(area_hist)],...
    'ytick',[],'XTick',[]);


% --- Executes during object creation, after setting all properties.
function popup_wbc_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_wbc_nps_sec.
function popup_wbc_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_nps_sec
contents = cellstr(get(handles.popup_wbc_nps_sec,'String'));
switch contents{get(handles.popup_wbc_nps_sec,'Value')};
    case '10ms'
        handles.wbc_nps_sec = 1;
    case '50ms'
        handles.wbc_nps_sec = 5;
    case '100ms'
        handles.wbc_nps_sec = 10;
    case '200ms'
        handles.wbc_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.wbc_nps,handles.wbc_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_wbc_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_wbc_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_wbc_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
h_wbc_nps = nps_monitor_alone(nps_data,handles.wbc_nps_sec,handles.axes_wbc_nps,'w',ylim);
%set(h_wbc_nps,'ButtonDownFcn',{@nps_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback
handles.h_rbc_nps = h_wbc_nps;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popup_wbc_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_wbc_nps_smooth.
function popup_wbc_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_nps_smooth
popup_wbc_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_wbc_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_seg.
function popup_rbc_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_seg
contents = cellstr(get(handles.popup_rbc_seg,'String'));
seg_num = str2double(contents{get(handles.popup_rbc_seg,'Value')});
% index_max = length(handles.rbc_peak_data) - mod(length(handles.rbc_peak_data),seg_num);
% width_data = double(reshape(handles.rbc_width_data(1:index_max),[],seg_num));
% peak_data = reshape(handles.rbc_peak_data(1:index_max),[],seg_num);
rbc_time = handles.rbc_time;
time_seglen = floor(double(max(rbc_time))/seg_num);
width_data = double(handles.rbc_width_data);
peak_data = double(handles.rbc_peak_data);

for i = 1:seg_num
    width_hist = get_hist_for_seg(max(handles.rbc_width_data),...
        width_data(rbc_time >= (i-1)*time_seglen & rbc_time < i*time_seglen),max(handles.rbc_width_data));
    x = 1:length(width_hist);
    plot(handles.axes_rbc_width,x,width_hist,'linewidth',1.0);
    peak_hist = get_hist_for_seg(256,peak_data(rbc_time >= (i-1)*time_seglen & rbc_time < i*time_seglen),...
        max(handles.rbc_peak_data));
    x = 1:length(peak_hist);
    plot(handles.axes_rbc_vol,x,peak_hist);
    if i == 1
        hold(handles.axes_rbc_width,'on');
        hold(handles.axes_rbc_vol,'on');
    end
    width_legend{i} = num2str(i); 
end

legend(handles.axes_rbc_width,width_legend,'Location','northoutside','Orientation','horizontal');
hold(handles.axes_rbc_width,'off');
hold(handles.axes_rbc_vol,'off');
set(handles.axes_rbc_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
set(handles.axes_rbc_vol,'color',[0,0,0],'xlim',[1 length(peak_hist)],...
    'ytick',[],'XTick',[]);

% --- Executes during object creation, after setting all properties.
function popup_rbc_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_plt_nps_smooth.
function popup_plt_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_nps_smooth
popup_plt_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_plt_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_plt_nps_sec.
function popup_plt_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_nps_sec
contents = cellstr(get(handles.popup_plt_nps_sec,'String'));
switch contents{get(handles.popup_plt_nps_sec,'Value')};
    case '10ms'
        handles.plt_nps_sec = 1;
    case '50ms'
        handles.plt_nps_sec = 5;
    case '100ms'
        handles.plt_nps_sec = 10;
    case '200ms'
        handles.plt_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.plt_nps,handles.plt_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_plt_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_plt_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_plt_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
nps_monitor_alone(nps_data,handles.plt_nps_sec,handles.axes_plt_nps,'g',ylim);

% --- Executes during object creation, after setting all properties.
function popup_plt_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_nps_sec.
function popup_rbc_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_nps_sec
contents = cellstr(get(handles.popup_rbc_nps_sec,'String'));
switch contents{get(handles.popup_rbc_nps_sec,'Value')};
    case '10ms'
        handles.rbc_nps_sec = 1;
    case '50ms'
        handles.rbc_nps_sec = 5;
    case '100ms'
        handles.rbc_nps_sec = 10;
    case '200ms'
        handles.rbc_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.rbc_nps,handles.rbc_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_rbc_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_rbc_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_rbc_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
h_rbc_nps = nps_monitor_alone(nps_data,handles.rbc_nps_sec,handles.axes_rbc_nps,'r',ylim);
%set(h_rbc_nps,'ButtonDownFcn',{@nps_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback
handles.h_rbc_nps = h_rbc_nps;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popup_rbc_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_nps_smooth.
function popup_rbc_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_nps_smooth
popup_rbc_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_rbc_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_edit_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_edit_batch_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_batch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ѡ�������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼��������������Ľ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('����������������¼��������ļ�_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBC(10^9/L),LYM#(10^9/L),MID#(10^9/L),GRAN#(10^9/L),LYM%%(%%),MID%%(%%),GRAN%%(%%),');
        fprintf(fid,'RBC(10^12/L),HGB(g/L),HCT(%%),MCV(fL),MCH(pg),MCHC(g/L),RDW_SD(fL),RDW_CV(%%),PLT(10^9/L),MPV(fL),PDW,PCT(%%),PLCR(%%),PLCC(10^9/L),CRP(mg/L)\n');
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(VK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                [header,sample,re,cell,monitor] = bk_inf_recal(filepath,sample_id);
                if header.error_code
                    continue;
                end
                %%
                fprintf(fid,'%s,%5.2f,%5.2f,%5.2f,%5.2f,%3.1f,%3.1f,%3.1f,',sample_num,...
                    re.old.wbc,re.old.lymn,re.old.midn,re.old.grann,re.old.lymp,re.old.midp,re.old.granp);
                if header.inf_ver > 3
                    crp = re.old.crp_val;
                else
                    crp = 0;
                end
                fprintf(fid,'%4.2f,%3.0f,%3.1f,%4.1f,%4.1f,%4.0f,%4.1f,%3.1f,',...
                    re.old.rbc,re.old.hgb,re.old.hct,re.old.mcv,re.old.mch,re.old.mchc,re.old.rdw_sd,re.old.rdw_cv);
                fprintf(fid,'%4.0f,%3.1f,%3.1f,%4.3f,%3.1f,%4.0f,%3.1f\n',...
                    re.old.plt,re.old.mpv,re.old.pdw,re.old.pct,re.old.plcr,re.old.plcc,crp);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(VK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end

% --------------------------------------------------------------------
function menu_edit_hgb_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hgb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            item_num = 1;
            data_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %%
                data_mat(1:length(monitor.hgb_data),i) = monitor.hgb_data;
                waitbar(i/(size(file_cellstr,1)+item_num),h);                
            end
        end
         %% ����HGB����
        now = fix(clock());
        now_str = sprintf('����������HGB����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(data_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+item_num),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
    case 'ȡ��'
        
end

function VK_offline_refresh_config(option)

fid = fopen('VK_offline_platform_config.ini','wt');
fprintf(fid,'%s\n',option.filedir);
fprintf(fid,'%s\n',option.inf_file_name);
fprintf(fid,'%s\n',option.wbcfilename);
fclose(fid);


% --- Executes when user attempts to close SimpleOptimizedTab.
function SimpleOptimizedTab_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to SimpleOptimizedTab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
VK_offline_refresh_config(handles.option);
delete(hObject);


% --- Executes when selected object is changed in uibuttongroup_wbc_manual.
function uibuttongroup_wbc_manual_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uibuttongroup_wbc_manual 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_wbc_config;
if get(handles.radio_wbc_l1,'value')
    BK_wbc_config.line_index = 1;
    
else if get(handles.radio_wbc_l2,'value')
        BK_wbc_config.line_index = 2; 
        
    else if get(handles.radio_wbc_l3,'value')
            BK_wbc_config.line_index = 3;
            
        end
    end
end



% --- Executes on button press in button_wbc_refresh.
function button_wbc_refresh_Callback(hObject, eventdata, handles)
% hObject    handle to button_wbc_refresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_wbc_config;
line = BK_wbc_config.wbc_line;
line = [15;44;68];
hist = handles.wbc_dsp_hist;
if line(1) < line(2) && line(2) < line(3)
    lym_num = sum(hist(line(1)+1:line(2)));
    mid_num = sum(hist(line(2)+1:line(3)));
    gran_num = sum(hist(line(3)+1:length(hist)));
    wbc_num = lym_num + mid_num + gran_num;
    tmp.wbc = wbc_num * 305.1 / 402.8 / 1000;
    tmp.lymp = lym_num/wbc_num*100;
    tmp.midp = mid_num/wbc_num*100;
    tmp.granp = gran_num/wbc_num*100;
    tmp.lymn = tmp.wbc*lym_num/wbc_num;
    tmp.midn = tmp.wbc*mid_num/wbc_num;
    tmp.grann = tmp.wbc*gran_num/wbc_num;
    para_present_wbc(tmp,handles);
else
    msgbox('�����ߴ�С������,���������á�','��ʾ');
    return;
end


% --------------------------------------------------------------------
function menu_edit_hist_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������ֱ��ͼ�Ƚ��������csv�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            for i = 1:size(file_cellstr,1)
                %% ��ʼ������
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                
                config.sample_id = filename(1:length(filename)-4);
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                 %% ����C���Կ�
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                re = re.old;
                rbc_hist_mat(:,i) = re.rbc_hist;
                plt_hist_mat(:,i) = re.plt_hist(1:64);
%                 rbc_width_hist_mat(:,i) = get_hist_for_seg(max(cell_info.rbc_fullwidth),cell_info.rbc_fullwidth,max(cell_info.rbc_fullwidth));
%                 plt_width_hist_mat(:,i) = get_hist_for_seg(60,cell_info.plt_fullwidth,max(cell_info.plt_fullwidth));
                waitbar(i/(size(file_cellstr,1)+4),h);    
            end
        end

        %% ����RBCֱ��ͼ����
        now = fix(clock());
        now_str = sprintf('����������RBCֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(rbc_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+1)/(size(file_cellstr,1)+4),h);
         %% ����PLTֱ��ͼ����
        now_str = sprintf('����������PLTֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(plt_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+2)/(size(file_cellstr,1)+4),h);
         %% ����RBC����ֱ��ͼ����
%         now_str = sprintf('����������RBC����ֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
%         outfilepath = fullfile(option.filedir,now_str);
%         cell_data = [sample_name_cell;num2cell(rbc_width_hist_mat)];
%         data = cell2table(cell_data);
%         writetable(data, outfilepath);
        waitbar((i+3)/(size(file_cellstr,1)+4),h);
         %% ����RBC����ֱ��ͼ����
%         now_str = sprintf('����������PLT����ֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
%         outfilepath = fullfile(option.filedir,now_str);
%         cell_data = [sample_name_cell;num2cell(plt_width_hist_mat)];
%         data = cell2table(cell_data);
%         writetable(data, outfilepath);
%         waitbar((i+4)/(size(file_cellstr,1)+4),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
                
    case 'ȡ��'
    
end


% --------------------------------------------------------------------
function menu_edit_crp_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_crp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������ֱ��ͼ�Ƚ��������csv�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            data_mat = zeros(300,size(file_cellstr,1));
            index = 0;
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %%
                index = index + 1;
                sample_name_cell{index} = sample_num;
                data_mat(1:length(monitor.crp_data),index) = monitor.crp_data;
                waitbar(i/(size(file_cellstr,1)+1),h);                
            end
        end
         %% ����crp����
         if index == 0
            close(h);
            msgbox('Ŀ���ļ�����û�а���crp���ݵ�inf�ļ���','��ʾ');
            return;
        end
        now = fix(clock());
        now_str = sprintf('����������CRP����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(data_mat(:,1:index));
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+1),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
    case 'ȡ��'
    
end


% --------------------------------------------------------------------
function menu_edit_hole_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hole (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            rhole_mat = zeros(6000,size(file_cellstr,1));
            rbase_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %%
                rhole_mat(1:length(monitor.rhole_data),i) = monitor.rhole_data;
                rbase_mat(1:length(monitor.rbase_data),i) = monitor.rbase_data;
                waitbar(i/(size(file_cellstr,1)+2),h);                
            end
        end
         %% ����RBC��������
        now = fix(clock());
        now_str = sprintf('����������RBCС�׵�ѹ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(rhole_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+2),h);
          %% ����RBC��������
        now_str = sprintf('����������RBC��������_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(rbase_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+2)/(size(file_cellstr,1)+2),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end

% --------------------------------------------------------------------
function menu_edit_kpa_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_kpa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            data_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                %%
                ap_data = -(bitand(monitor.airp_data,32767,'int16'));
                ap_data = double(ap_data)/10;
                data_mat(1:length(ap_data),i) = ap_data;
                waitbar(i/(size(file_cellstr,1)+1),h);
            end
        end
         %% �������ѹ������
        now = fix(clock());
        now_str = sprintf('�������������ѹ������_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(data_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+1),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_file_open_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
button_browse_Callback(hObject, eventdata, handles);


% --------------------------------------------------------------------
function menu_test_Callback(hObject, eventdata, handles)
% hObject    handle to menu_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_test_hole_vol_Callback(hObject, eventdata, handles)
% hObject    handle to menu_test_hole_vol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global VK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼���������ѹ�����ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('�����������¿��㷨���Ա���_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(VK_offline_ini.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBCͨ��,RBCͨ��\n');
        file_cellstr = get(handles.listbox1, 'String');
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
              %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(VK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                [header,sample,re,cellinfo,monitor] = read_inf_file_mexw64(filepath);
                [hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample);
                % WBCС�׵�ѹ
                alarm_msg = [];
                if wbc_pos.start < length(monitor.whole_data) && wbc_pos.end < length(monitor.whole_data)
                    wbc_bool = if_abnormal_voltage(monitor.whole_data(wbc_pos.start-290:wbc_pos.end));
                    if wbc_bool
                        wbc_msg = '�¿�';
                    else
                        wbc_msg = '����';
                    end
                end
                % RBCС�׵�ѹ
                if rbc_pos.start < length(monitor.rhole_data) && rbc_pos.end < length(monitor.rhole_data)
                    rbc_bool = if_abnormal_voltage(monitor.rhole_data(wbc_pos.start-290:wbc_pos.end));
                    if rbc_bool
                        rbc_msg = '�¿�';
                    else
                        rbc_msg = '����';
                    end
                end
               %%
                fprintf(fid,'%s,%s,%s\n',sample_num,wbc_msg,rbc_msg);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(VK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_edit_recal_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_recal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ѡ�������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼��������������Ľ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('�����������㷨�����������ļ�_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
%         index = strfind(option.filedir,'\');
%         tmp_dir = option.filedir(1:index(length(index)-1));
        outfilepath = fullfile(option.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBC(10^9/L),NEU%%(%%),LYM%%(%%),MON%%(%%),EOS%%(%%),BAS%%(%%),NEU#(10^9/L),LYM#(10^9/L),MON#(10^9/L),EOS#(10^9/L),BAS#(10^9/L),');
%         fprintf(fid,'sample_ID,WBC(10^9/L),');
        fprintf(fid,'RBC(10^12/L),HGB(g/L),HCT(%%),MCV(fL),MCH(pg),MCHC(g/L),RDW_SD(fL),RDW_CV(%%),PLT(10^9/L),MPV(fL),PDW,PCT(%%),PLCR(%%),PLCC(10^9/L),CRP(mg/L),����ģʽ,����ģʽ\n');
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                switch sample.analysis_mode
                    case 0 %CBC
                        am_str = 'CBC';
                    case 1 %CRP
                        am_str = 'CRP';
                    case 2 %CBC+CRP
                        am_str = 'CBC+CRP';
                    otherwise
                        am_str = 'Unknown';
                end
                switch sample.blood_mode
                    case 0 %ȫѪ
                        bm_str = 'ȫѪ';
                    case 1 %Ԥϡ��
                        bm_str = 'Ԥϡ��';
                    otherwise
                        bm_str = 'Unknown';
                end
                
                %%
                para_re = re.old;
                fprintf(fid,'%s,%5.2f,%4.1f,%4.1f,%4.1f,%4.1f,%4.1f,%5.2f,%5.2f,%5.2f,%5.2f,%5.2f,',...
                    sample_num,para_re.wbc,para_re.neup,para_re.lymp,para_re.monp,para_re.eosp,para_re.basp,...
                    para_re.neun,para_re.lymn,para_re.monn,para_re.eosn,para_re.basn);
                crp = para_re.crp_val;
                fprintf(fid,'%4.2f,%3.0f,%3.1f,%4.1f,%4.1f,%4.0f,%4.1f,%3.1f,',...
                    para_re.rbc,para_re.hgb,para_re.hct,para_re.mcv,para_re.mch,para_re.mchc,para_re.rdw_sd,para_re.rdw_cv);
                fprintf(fid,'%4.0f,%3.1f,%3.1f,%4.3f,%3.1f,%4.0f,%3.1f,%s,%s\n',...
                    para_re.plt,para_re.mpv,para_re.pdw,para_re.pct,para_re.plcr,para_re.plcc,crp,am_str,bm_str);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
    case 'ȡ��'
        
end

function copy_histogram(h_axes)

tmpf = figure('visible','off');
copyobj(h_axes,tmpf);
set(tmpf,'units','centimeters','position',[0 0 12.19 3.97]);
hgexport(tmpf,'-clipboard');
delete(tmpf);


% --- Executes on button press in button_copy_whist.
function button_copy_whist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_whist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_main_wbc);



% --- Executes on button press in button_copy_phist.
function button_copy_phist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_phist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.main_axes_plt);


% --- Executes on button press in button_copy_rhist.
function button_copy_rhist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_rhist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.main_axes_rbc);


% --- Executes on button press in radio_without_cb.
function radio_without_cb_Callback(hObject, eventdata, handles)
% hObject    handle to radio_without_cb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radio_without_cb


% --- Executes on selection change in popup_plt_seg.
function popup_plt_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_seg
contents = cellstr(get(handles.popup_plt_seg,'String'));
seg_num = str2double(contents{get(handles.popup_plt_seg,'Value')});
% index_max = length(handles.plt_peak_data) - mod(length(handles.plt_peak_data),seg_num);
% width_data = double(reshape(handles.plt_width_data(1:index_max),[],seg_num));
% peak_data = reshape(handles.plt_peak_data(1:index_max),[],seg_num);
plt_time = handles.plt_time;
time_seglen = floor(double(max(plt_time))/seg_num);
width_data = double(handles.plt_width_data);
peak_data = double(handles.plt_peak_data);

for i = 1:seg_num
    width_hist = get_hist_for_seg(max(handles.plt_width_data),...
        width_data(plt_time >= (i-1)*time_seglen & plt_time < i*time_seglen),max(handles.plt_width_data));
    x = 1:length(width_hist);
    plot(handles.axes_plt_width,x,width_hist,'linewidth',1.0);
    peak_hist = get_hist_for_seg(round(2200/4096*128),...
        peak_data(plt_time >= (i-1)*time_seglen & plt_time < i*time_seglen),max(handles.plt_peak_data));
    x = 1:length(peak_hist);
    plot(handles.axes_plt_vol,x,peak_hist);
    if i == 1
        hold(handles.axes_plt_width,'on');
        hold(handles.axes_plt_vol,'on');
    end
    width_legend{i} = num2str(i); 
end

legend(handles.axes_plt_width,width_legend,'Location','northoutside','Orientation','horizontal');
hold(handles.axes_plt_width,'off');
hold(handles.axes_plt_vol,'off');
set(handles.axes_plt_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
set(handles.axes_plt_vol,'color',[0,0,0],'xlim',[1 length(peak_hist)],...
    'ytick',[],'XTick',[]);

% --- Executes during object creation, after setting all properties.
function popup_plt_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in diff_popup_nps_smooth.
function diff_popup_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to diff_popup_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns diff_popup_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from diff_popup_nps_smooth
global vk_cellinfo;
nps_data = vk_cellinfo.diff_nps;
ylim = [min(nps_data)*0.7 max(nps_data*1.3)];
smooth_contents = cellstr(get(handles.diff_popup_nps_smooth,'String'));
switch smooth_contents{get(handles.diff_popup_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.diff_popup_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
nps_monitor_alone(nps_data,10,handles.diff_axes_nps,'r',ylim);

% --- Executes during object creation, after setting all properties.
function diff_popup_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to diff_popup_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in diff_popup_segnum.
function diff_popup_segnum_Callback(hObject, eventdata, handles)
% hObject    handle to diff_popup_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns diff_popup_segnum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from diff_popup_segnum
global vk_cellinfo;
contents = cellstr(get(handles.diff_popup_segnum,'String'));
seg_num = str2double(contents{get(handles.diff_popup_segnum,'Value')});
width_data = double(vk_cellinfo.diff_info.ls_width);
plot_seg_hist_with_legend(width_data,seg_num,64,handles.diff_axes_width_seg);

% --- Executes during object creation, after setting all properties.
function diff_popup_segnum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to diff_popup_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in diff_button_refresh.
function diff_button_refresh_Callback(hObject, eventdata, handles)
% hObject    handle to diff_button_refresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
index = vk_cellinfo.diff_pindex;
if index == 0
    return;
end
polygon_x = vk_cellinfo.diff_click_x(1:index);
polygon_y = vk_cellinfo.diff_click_y(1:index);
diff_info = vk_cellinfo.diff_info;
cell_len = length(diff_info.celltype);
if get(handles.diff_radio_view_ml,'value')
    test_x = diff_info.ms_peak;
    test_y = diff_info.ls_peak;
else if get(handles.diff_radio_view_hm,'value')
        test_x = diff_info.hs_peak;
        test_y = diff_info.ms_peak;
    else if get(handles.diff_radio_view_hl,'value')
            test_x = diff_info.hs_peak;
            test_y = diff_info.ls_peak;
        end
    end
end

for i = 1:cell_len
    bool = is_inside_polygon(polygon_x,polygon_y,test_x(i),test_y(i));
    if bool
        diff_info.celltype(i) = vk_cellinfo.diff_celltype; 
    end
end
set_diff_manual_result(diff_info,handles.diff_uitable_manual);
vk_cellinfo.diff_info = diff_info;
% ��άɢ��ͼ����
opti_channel_3d_plot(diff_info,handles.diff_axes_3d_scatter);
% ��άɢ��ͼ����
diff_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles);
if vk_cellinfo.diff_celltype == 11
    %% ��ȡ��ͨ����ֱ��ͼ����ز�������
    sta_index = find(diff_info.celltype == vk_cellinfo.diff_celltype);
    ls_sta_peak = double(diff_info.ls_peak(sta_index))*256/4096;
    ms_sta_peak = double(diff_info.ms_peak(sta_index))*256/4096;
    hs_sta_peak = double(diff_info.hs_peak(sta_index))*256/4096;
    diff_ls.hist = get_hist_for_seg(256,diff_info.ls_peak(sta_index),4095);
    diff_ms.hist = get_hist_for_seg(256,diff_info.ms_peak(sta_index),4095);
    diff_hs.hist = get_hist_for_seg(256,diff_info.hs_peak(sta_index),4095);
    diff_ls.cellnum = sum(diff_ls.hist);
    diff_ms.cellnum = sum(diff_ms.hist);
    diff_hs.cellnum = sum(diff_hs.hist);
    diff_ls.barycentre = cal_barycentre_of_hist(diff_ls.hist);
    diff_ms.barycentre = cal_barycentre_of_hist(diff_ms.hist);
    diff_hs.barycentre = cal_barycentre_of_hist(diff_hs.hist);
    diff_ls.hist_width = cal_width_of_hist(diff_ls.hist,ls_sta_peak);
    diff_ms.hist_width = cal_width_of_hist(diff_ms.hist,ms_sta_peak);
    diff_hs.hist_width = cal_width_of_hist(diff_hs.hist,hs_sta_peak);
    
    diff_ls.hist_sd = std(ls_sta_peak);
    diff_ms.hist_sd = std(ms_sta_peak);
    diff_hs.hist_sd = std(hs_sta_peak);
    
    diff_ls.peak_mean = mean(ls_sta_peak);
    diff_ms.peak_mean = mean(ms_sta_peak);
    diff_hs.peak_mean = mean(hs_sta_peak);
    
    diff_ls.hist_cv1 = diff_ls.hist_width/diff_ls.barycentre*100;
    diff_ls.hist_cv2 = diff_ls.hist_sd/mean(ls_sta_peak)*100;
    diff_ms.hist_cv1 = diff_ms.hist_width/diff_ms.barycentre*100;
    diff_ms.hist_cv2 = diff_ms.hist_sd/mean(ms_sta_peak)*100;
    diff_hs.hist_cv1 = diff_hs.hist_width/diff_hs.barycentre*100;
    diff_hs.hist_cv2 = diff_hs.hist_sd/mean(hs_sta_peak)*100;
    evaluation_of_standard_particle(diff_ls,diff_ms,diff_hs,handles.diff_uitable_hist_info);
end

% --- Executes on selection change in baso_popup_nps_smooth.
function baso_popup_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to baso_popup_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns baso_popup_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from baso_popup_nps_smooth
global vk_cellinfo;
nps_data = vk_cellinfo.baso_nps;
ylim = [min(nps_data)*0.7 max(nps_data*1.3)];
smooth_contents = cellstr(get(handles.baso_popup_nps_smooth,'String'));
switch smooth_contents{get(handles.baso_popup_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.baso_popup_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
nps_monitor_alone(nps_data,10,handles.baso_axes_nps,'r',ylim);

% --- Executes during object creation, after setting all properties.
function baso_popup_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to baso_popup_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in baso_popup_segnum.
function baso_popup_segnum_Callback(hObject, eventdata, handles)
% hObject    handle to baso_popup_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns baso_popup_segnum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from baso_popup_segnum
global vk_cellinfo;
contents = cellstr(get(handles.baso_popup_segnum,'String'));
seg_num = str2double(contents{get(handles.baso_popup_segnum,'Value')});
width_data = double(vk_cellinfo.baso_info.ls_width);
plot_seg_hist_with_legend(width_data,seg_num,64,handles.baso_axes_width_seg);

% --- Executes during object creation, after setting all properties.
function baso_popup_segnum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to baso_popup_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in baso_button_refresh.
function baso_button_refresh_Callback(hObject, eventdata, handles)
% hObject    handle to baso_button_refresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
index = vk_cellinfo.baso_pindex;
if index == 0
    return;
end
polygon_x = vk_cellinfo.baso_click_x(1:index);
polygon_y = vk_cellinfo.baso_click_y(1:index);
baso_info = vk_cellinfo.baso_info;
cell_len = length(baso_info.celltype);
if get(handles.baso_radio_view_ml,'value')
    test_x = baso_info.ms_peak;
    test_y = baso_info.ls_peak;
else if get(handles.baso_radio_view_hm,'value')
        test_x = baso_info.hs_peak;
        test_y = baso_info.ms_peak;
    else if get(handles.baso_radio_view_hl,'value')
            test_x = baso_info.hs_peak;
            test_y = baso_info.ls_peak;
        end
    end
end

for i = 1:cell_len
    bool = is_inside_polygon(polygon_x,polygon_y,test_x(i),test_y(i));
    if bool
        baso_info.celltype(i) = vk_cellinfo.baso_celltype; 
    end
end
set_baso_manual_result(baso_info,handles.baso_uitable_manual);
vk_cellinfo.baso_info = baso_info;
% ��άɢ��ͼ����
opti_channel_3d_plot(baso_info,handles.baso_axes_3d_scatter);
% ��άɢ��ͼ����
baso_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles);
if vk_cellinfo.baso_celltype == 11
    %% ��ȡ��ͨ����ֱ��ͼ����ز�������
    sta_index = find(baso_info.celltype == vk_cellinfo.baso_celltype);
    ls_sta_peak = double(baso_info.ls_peak(sta_index))*256/4096;
    ms_sta_peak = double(baso_info.ms_peak(sta_index))*256/4096;
    hs_sta_peak = double(baso_info.hs_peak(sta_index))*256/4096;
    baso_ls.hist = get_hist_for_seg(256,baso_info.ls_peak(sta_index),4095);
    baso_ms.hist = get_hist_for_seg(256,baso_info.ms_peak(sta_index),4095);
    baso_hs.hist = get_hist_for_seg(256,baso_info.hs_peak(sta_index),4095);
    baso_ls.cellnum = sum(baso_ls.hist);
    baso_ms.cellnum = sum(baso_ms.hist);
    baso_hs.cellnum = sum(baso_hs.hist);
    baso_ls.barycentre = cal_barycentre_of_hist(baso_ls.hist);
    baso_ms.barycentre = cal_barycentre_of_hist(baso_ms.hist);
    baso_hs.barycentre = cal_barycentre_of_hist(baso_hs.hist);
    baso_ls.hist_width = cal_width_of_hist(baso_ls.hist,ls_sta_peak);
    baso_ms.hist_width = cal_width_of_hist(baso_ms.hist,ms_sta_peak);
    baso_hs.hist_width = cal_width_of_hist(baso_hs.hist,hs_sta_peak);
    
    baso_ls.hist_sd = std(ls_sta_peak);
    baso_ms.hist_sd = std(ms_sta_peak);
    baso_hs.hist_sd = std(hs_sta_peak);
    
    baso_ls.peak_mean = mean(ls_sta_peak);
    baso_ms.peak_mean = mean(ms_sta_peak);
    baso_hs.peak_mean = mean(hs_sta_peak);
    
    baso_ls.hist_cv1 = baso_ls.hist_width/baso_ls.barycentre*100;
    baso_ls.hist_cv2 = baso_ls.hist_sd/mean(ls_sta_peak)*100;
    baso_ms.hist_cv1 = baso_ms.hist_width/baso_ms.barycentre*100;
    baso_ms.hist_cv2 = baso_ms.hist_sd/mean(ms_sta_peak)*100;
    baso_hs.hist_cv1 = baso_hs.hist_width/baso_hs.barycentre*100;
    baso_hs.hist_cv2 = baso_hs.hist_sd/mean(hs_sta_peak)*100;
    evaluation_of_standard_particle(baso_ls,baso_ms,baso_hs,handles.baso_uitable_hist_info);
end

function option = initial_sta_option(handles)

contents = cellstr(get(handles.sta_option_segnum,'String'));
option.segnum = str2double(contents{get(handles.sta_option_segnum,'Value')});
contents = cellstr(get(handles.sta_option_channel,'String'));
option.channel = contents{get(handles.sta_option_channel,'Value')};
contents = cellstr(get(handles.sta_option_type,'String'));
option.type = contents{get(handles.sta_option_type,'Value')};
contents = cellstr(get(handles.sta_option_smooth,'String'));
option.smooth = str2double(contents{get(handles.sta_option_smooth,'Value')});

% --- Executes on selection change in sta_option_segnum.
function sta_option_segnum_Callback(hObject, eventdata, handles)
% hObject    handle to sta_option_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sta_option_segnum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sta_option_segnum
option = initial_sta_option(handles);
stability_present_main(option,handles,'sta_axes_scatter');



% --- Executes during object creation, after setting all properties.
function sta_option_segnum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sta_option_segnum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in sta_option_channel.
function sta_option_channel_Callback(hObject, eventdata, handles)
% hObject    handle to sta_option_channel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sta_option_channel contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sta_option_channel
option = initial_sta_option(handles);
stability_present_main(option,handles,'sta_axes_scatter');

% --- Executes during object creation, after setting all properties.
function sta_option_channel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sta_option_channel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in sta_option_type.
function sta_option_type_Callback(hObject, eventdata, handles)
% hObject    handle to sta_option_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sta_option_type contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sta_option_type
option = initial_sta_option(handles);
stability_present_main(option,handles,'sta_axes_scatter');

% --- Executes during object creation, after setting all properties.
function sta_option_type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sta_option_type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in sta_option_smooth.
function sta_option_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to sta_option_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sta_option_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sta_option_smooth
option = initial_sta_option(handles);
stability_present_main(option,handles,'sta_axes_scatter');

% --- Executes during object creation, after setting all properties.
function sta_option_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sta_option_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when selected object is changed in diff_buttongroup_view.
function diff_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in diff_buttongroup_view 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
vk_cellinfo.diff_pindex = 0;
diff_info = vk_cellinfo.diff_info;
if get(handles.diff_radio_view_ml,'value')
    diff_2d_plot(diff_info.ms_peak,diff_info.ls_peak,diff_info.celltype,handles.diff_axes_2d_scatter);
    xlabel(handles.diff_axes_2d_scatter,'ms','position',[max(diff_info.ms_peak),1],'color','k');
    ylabel(handles.diff_axes_2d_scatter,'ls','position',[1,max(diff_info.ls_peak)],'color','k');
    return;
end
if get(handles.diff_radio_view_hm,'value')
    diff_2d_plot(diff_info.hs_peak,diff_info.ms_peak,diff_info.celltype,handles.diff_axes_2d_scatter);
    xlabel(handles.diff_axes_2d_scatter,'hs','position',[max(diff_info.hs_peak),1],'color','k');
    ylabel(handles.diff_axes_2d_scatter,'ms','position',[1,max(diff_info.ms_peak)],'color','k');
    return;
end
if get(handles.diff_radio_view_hl,'value')
    diff_2d_plot(diff_info.hs_peak,diff_info.ls_peak,diff_info.celltype,handles.diff_axes_2d_scatter);
    xlabel(handles.diff_axes_2d_scatter,'hs','position',[max(diff_info.hs_peak),1],'color','k');
    ylabel(handles.diff_axes_2d_scatter,'ls','position',[1,max(diff_info.ls_peak)],'color','k');
    return;
end

function celltype = get_diff_mannual_celltype(handles)

celltype = 0;
if get(handles.diff_color_ghost,'value')
    celltype = 1;
    return;
end
if get(handles.diff_color_mon,'value')
    celltype = 4;
    return;
end
if get(handles.diff_color_neu,'value')
    celltype = 2;
    return;
end
if get(handles.diff_color_lym,'value')
    celltype = 3;
    return;
end
if get(handles.diff_color_eos,'value')
    celltype = 5;
    return;
end
if get(handles.diff_color_bas,'value')
    celltype = 6;
    return;
end
if get(handles.diff_color_monb,'value')
    celltype = 7;
    return;
end
if get(handles.diff_color_bla,'value')
    celltype = 8;
    return;
end
if get(handles.diff_color_lymb,'value')
    celltype = 9;
    return;
end
if get(handles.diff_color_nrbc,'value')
    celltype = 10;
    return;
end
if get(handles.diff_color_sta,'value')
    celltype = 11;
    return;
end

% --- Executes when selected object is changed in diff_buttongroup_color.
function diff_buttongroup_color_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in diff_buttongroup_color 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
vk_cellinfo.diff_pindex = 0;
vk_cellinfo.diff_celltype = get_diff_mannual_celltype(handles);


% --- Executes on mouse press over axes background.
function diff_axes_2d_scatter_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to diff_axes_2d_scatter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function SimpleOptimizedTab_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to SimpleOptimizedTab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
if ~isfield(vk_cellinfo,'tab')
    return;
end
if vk_cellinfo.tab == 2
    if strcmp(get(gcf,'SelectionType'),'normal') % ����������
        celltype = vk_cellinfo.diff_celltype;
        color = get_color_vector(celltype);
        if isfield(vk_cellinfo,'diff_h')
            delete(vk_cellinfo.diff_h);
        end
        vk_cellinfo.diff_pindex = vk_cellinfo.diff_pindex + 1;
        i = vk_cellinfo.diff_pindex;
        ClickPoint = get(gca,'currentpoint');
        vk_cellinfo.diff_click_x(i) = ClickPoint(1,1)+65;
        vk_cellinfo.diff_click_y(i) = ClickPoint(1,2)-185;
        hold(handles.diff_axes_2d_scatter,'on');
        vk_cellinfo.diff_h = plot(handles.diff_axes_2d_scatter,vk_cellinfo.diff_click_x(1:i),...
            vk_cellinfo.diff_click_y(1:i),'-x','color',color);
        
    else if strcmp(get(gcf,'SelectionType'),'alt') % ����Ҽ�����
            if isfield(vk_cellinfo,'diff_h')
                delete(vk_cellinfo.diff_h);
                vk_cellinfo.diff_pindex = 0;
            end
        end;
    end;
else if vk_cellinfo.tab == 3
        if strcmp(get(gcf,'SelectionType'),'normal') % ����������
            celltype = vk_cellinfo.baso_celltype;
            color = get_color_vector(celltype);
            if isfield(vk_cellinfo,'baso_h')
                delete(vk_cellinfo.baso_h);
            end
            vk_cellinfo.baso_pindex = vk_cellinfo.baso_pindex + 1;
            i = vk_cellinfo.baso_pindex;
            ClickPoint = get(gca,'currentpoint');
            vk_cellinfo.baso_click_x(i) = ClickPoint(1,1)+65;
            vk_cellinfo.baso_click_y(i) = ClickPoint(1,2)-185;
            hold(handles.baso_axes_2d_scatter,'on');
            vk_cellinfo.baso_h = plot(handles.baso_axes_2d_scatter,vk_cellinfo.baso_click_x(1:i),...
                vk_cellinfo.baso_click_y(1:i),'-x','color',color);
            
        else if strcmp(get(gcf,'SelectionType'),'alt') % ����Ҽ�����
                if isfield(vk_cellinfo,'baso_h')
                    delete(vk_cellinfo.baso_h);
                    vk_cellinfo.baso_pindex = 0;
                end
            end;
        end;
    else
        return;
    end
    
end

% --- Executes when SimpleOptimizedTab is resized.
function SimpleOptimizedTab_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to SimpleOptimizedTab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when selected object is changed in baso_buttongroup_view.
function baso_buttongroup_view_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in baso_buttongroup_view 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
vk_cellinfo.baso_pindex = 0;
baso_info = vk_cellinfo.baso_info;
if get(handles.baso_radio_view_ml,'value')
    diff_2d_plot(baso_info.ms_peak,baso_info.ls_peak,baso_info.celltype,handles.baso_axes_2d_scatter);
    xlabel(handles.baso_axes_2d_scatter,'ms','position',[max(baso_info.ms_peak),1],'color','k');
    ylabel(handles.baso_axes_2d_scatter,'ls','position',[1,max(baso_info.ls_peak)],'color','k');
    return;
end
if get(handles.baso_radio_view_hm,'value')
    diff_2d_plot(baso_info.hs_peak,baso_info.ms_peak,baso_info.celltype,handles.baso_axes_2d_scatter);
    xlabel(handles.baso_axes_2d_scatter,'hs','position',[max(baso_info.hs_peak),1],'color','k');
    ylabel(handles.baso_axes_2d_scatter,'ms','position',[1,max(baso_info.ms_peak)],'color','k');
    return;
end
if get(handles.baso_radio_view_hl,'value')
    diff_2d_plot(baso_info.hs_peak,baso_info.ls_peak,baso_info.celltype,handles.baso_axes_2d_scatter);
    xlabel(handles.baso_axes_2d_scatter,'hs','position',[max(baso_info.hs_peak),1],'color','k');
    ylabel(handles.baso_axes_2d_scatter,'ls','position',[1,max(baso_info.ls_peak)],'color','k');
    return;
end

function celltype = get_baso_mannual_celltype(handles)

celltype = 0;
if get(handles.baso_color_ghost,'value')
    celltype = 1;
    return;
end
if get(handles.baso_color_bas,'value')
    celltype = 2;
    return;
end
if get(handles.baso_color_nmle,'value')
    celltype = 3;
    return;
end
if get(handles.baso_color_par4,'value')
    celltype = 4;
    return;
end
if get(handles.baso_color_par5,'value')
    celltype = 5;
    return;
end
if get(handles.baso_color_par6,'value')
    celltype = 6;
    return;
end
if get(handles.baso_color_par7,'value')
    celltype = 7;
    return;
end
if get(handles.baso_color_par8,'value')
    celltype = 8;
    return;
end
if get(handles.baso_color_par9,'value')
    celltype = 9;
    return;
end
if get(handles.baso_color_par10,'value')
    celltype = 10;
    return;
end
if get(handles.baso_color_sta,'value')
    celltype = 11;
    return;
end

% --- Executes when selected object is changed in baso_buttongroup_color.
function baso_buttongroup_color_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in baso_buttongroup_color 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vk_cellinfo;
vk_cellinfo.baso_pindex = 0;
vk_cellinfo.baso_celltype = get_baso_mannual_celltype(handles);


% --- Executes on mouse press over axes background.
function baso_axes_2d_scatter_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to baso_axes_2d_scatter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_edit_opti_monitor_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_opti_monitor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            opti_vol_mat = zeros(6000,size(file_cellstr,1));
            opti_base_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %%
                opti_vol_mat(1:length(monitor.opti_vol_data),i) = monitor.opti_vol_data;
                opti_base_mat(1:length(monitor.opti_base_data),i) = monitor.opti_base_data;
                waitbar(i/(size(file_cellstr,1)+2),h);                
            end
        end
         %% ������ѧ���׵�ѹ����
        now = fix(clock());
        now_str = sprintf('������������ѧ���׵�ѹ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(opti_vol_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+2),h);
          %% ������ѧ��������
        now_str = sprintf('������������ѧ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(opti_base_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+2)/(size(file_cellstr,1)+2),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_edit_hyd_press_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hyd_press (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            data_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %%
                data_mat(1:length(monitor.hydp_data),i) = monitor.hydp_data;
                waitbar(i/(size(file_cellstr,1)+1),h);                
            end
        end
         %% ����Һѹ����
        now = fix(clock());
        now_str = sprintf('����������Һѹ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_path = fullfile(option.filedir,now_str);
        data_cell = num2cell(data_mat);
        table_data = [sample_name_cell;data_cell];
        data = cell2table(table_data);
        writetable(data, out_path);
        waitbar((i+1)/(size(file_cellstr,1)+1),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end



function crp_start_pos_Callback(hObject, eventdata, handles)
% hObject    handle to crp_start_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_start_pos as text
%        str2double(get(hObject,'String')) returns contents of crp_start_pos as a double


% --- Executes during object creation, after setting all properties.
function crp_start_pos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_start_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function crp_end_pos_Callback(hObject, eventdata, handles)
% hObject    handle to crp_end_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_end_pos as text
%        str2double(get(hObject,'String')) returns contents of crp_end_pos as a double


% --- Executes during object creation, after setting all properties.
function crp_end_pos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_end_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function crp_seglen_Callback(hObject, eventdata, handles)
% hObject    handle to crp_seglen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_seglen as text
%        str2double(get(hObject,'String')) returns contents of crp_seglen as a double


% --- Executes during object creation, after setting all properties.
function crp_seglen_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_seglen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_refresh_crp_reaction.
function button_refresh_crp_reaction_Callback(hObject, eventdata, handles)
% hObject    handle to button_refresh_crp_reaction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in button_send2calibration.
function button_send2calibration_Callback(hObject, eventdata, handles)
% hObject    handle to button_send2calibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_edit_nps_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_nps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������NPS���ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %% rbc_nps
                  num = max(cell_info.rbc_time);
                  if num > 0
                      for j = 1:99
                          index = find(cell_info.rbc_time==j);
                          rbc_nps(j) = length(index);
                      end
                  else
                      rbc_nps(1:99) = 0;
                  end
                  %% plt_nps
                  num = max(cell_info.plt_time);
                  if num > 0
                      for j = 1:99
                          index = find(cell_info.plt_time==j);
                          plt_nps(j) = length(index);
                      end
                  else
                      plt_nps(1:99) = 0;
                  end
                  rbc_nps_mat(:,i) = rbc_nps;
                  plt_nps_mat(:,i) = plt_nps;
                  %% diff_nps
                  diff_info = cell_info.diff_info;
                  num = max(diff_info.time_stamp);
                  if num > 0
                      for j = 1:120
                          index = find(diff_info.time_stamp==j);
                          diff_nps(j) = length(index);
                      end
                  else
                      diff_nps(1:120) = 0;
                  end
                  %% baso_nps
                  baso_info = cell_info.baso_info;
                  num = max(baso_info.time_stamp);
                  if num > 0
                      for j = 1:120
                          index = find(baso_info.time_stamp==j);
                          baso_nps(j) = length(index);
                      end
                  else
                      baso_nps(1:120) = 0;
                  end
                  diff_nps_mat(:,i) = diff_nps;
                  baso_nps_mat(:,i) = baso_nps;
                  waitbar(i/(size(file_cellstr,1)+4),h);
            end
        end
        %% ����RBC_NPS����
        now = fix(clock());
        now_str = sprintf('����������RBC_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(rbc_nps_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+1)/(size(file_cellstr,1)+4),h);
         %% ����PLT_NPS����
        now_str = sprintf('����������PLT_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(plt_nps_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+2)/(size(file_cellstr,1)+4),h);
         %% ����DIFF_NPS����
        now_str = sprintf('����������DIFF_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(diff_nps_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+3)/(size(file_cellstr,1)+4),h);
         %% ����BASO_NPS����
        now_str = sprintf('����������BASO_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(baso_nps_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+4)/(size(file_cellstr,1)+4),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_edit_opti_hist_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_opti_hist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
option = handles.option;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������NPS���ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        h=waitbar(0,'���ڴ����У����Ժ�...');
        num = read_file_list_with_str(option.filedir,'*.inf', handles, 0);
        if num > 0
            sample_name_cell = cell(1,num);
            file_cellstr = cellstr(get(handles.listbox1, 'String'));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(option.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = 20;
                config.crp_end_pos = 230;
                config.crp_seglen = 5;
                [header,sample,re,cell_info,monitor] = vk_inf_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                  %% diff_hist
                  diff_ls_hist = get_hist_for_seg(256,cell_info.diff_info.ls_peak,4095);
                  diff_ms_hist = get_hist_for_seg(256,cell_info.diff_info.ms_peak,4095);
                  diff_hs_hist = get_hist_for_seg(256,cell_info.diff_info.hs_peak,4095);
                %% diff_hist
                  baso_ls_hist = get_hist_for_seg(256,cell_info.baso_info.ls_peak,4095);
                  baso_ms_hist = get_hist_for_seg(256,cell_info.baso_info.ms_peak,4095);
                  baso_hs_hist = get_hist_for_seg(256,cell_info.baso_info.hs_peak,4095);
                  %% matrix binding
                  diff_ls_hist_mat(:,i) = diff_ls_hist;
                  diff_ms_hist_mat(:,i) = diff_ms_hist;
                  diff_hs_hist_mat(:,i) = diff_hs_hist;
                  
                  baso_ls_hist_mat(:,i) = baso_ls_hist;
                  baso_ms_hist_mat(:,i) = baso_ms_hist;
                  baso_hs_hist_mat(:,i) = baso_hs_hist;
                
                  waitbar(i/(size(file_cellstr,1)+6),h);
            end
        end
        %% ����diff_ls_hist����
        now = fix(clock());
        now_str = sprintf('����������DIFF_LSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(diff_ls_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+1)/(size(file_cellstr,1)+6),h);
        %% ����diff_ms_hist����
        now_str = sprintf('����������DIFF_MSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(diff_ms_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+2)/(size(file_cellstr,1)+6),h);
        %% ����diff_hs_hist����
        now_str = sprintf('����������DIFF_HSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(diff_hs_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+3)/(size(file_cellstr,1)+6),h);
        %% ����baso_ls_hist����
        now_str = sprintf('����������BASO_LSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(baso_ls_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+4)/(size(file_cellstr,1)+6),h);
        %% ����baso_ms_hist����
        now_str = sprintf('����������BASO_MSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(baso_ms_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+5)/(size(file_cellstr,1)+6),h);
        %% ����baso_hs_hist����
        now_str = sprintf('����������BASO_HSֱ��ͼ_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(option.filedir,now_str);
        cell_data = [sample_name_cell;num2cell(baso_hs_hist_mat)];
        data = cell2table(cell_data);
        writetable(data, outfilepath);
        waitbar((i+6)/(size(file_cellstr,1)+6),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(option.filedir);
            case 'ȡ��'
        end
        
        
    case 'ȡ��'
        
end
