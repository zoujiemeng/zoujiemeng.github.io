function barycentre = cal_barycentre_of_hist(hist_data)

total = sum(hist_data);
barycentre = 0;
for i = 1 : length(hist_data)
    barycentre = barycentre + (i-0.5)*(hist_data(i)/total);
end