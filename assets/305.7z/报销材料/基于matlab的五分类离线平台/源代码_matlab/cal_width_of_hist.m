function width = cal_width_of_hist(hist_data,peak_data)

[max_value,max_index] = max(hist_data);
threshold = max_value/10;
for i = 1:max_index
    if hist_data(i) >= threshold
        index1 = i;
        break;
    end
end

for i = max_index:length(hist_data)
    if hist_data(i) <= threshold
        index2 = i;
        break;
    end
end

k1 = hist_data(index1) - hist_data(index1-1);
b1 = hist_data(index1) - k1*index1;
x1 = (threshold-b1)/k1;

k2 = hist_data(index2) - hist_data(index2-1);
b2 = hist_data(index2) - k2*index2;
x2 = (threshold-b2)/k2;

tmp_data = peak_data(peak_data > x1 & peak_data < x2);
width = std(tmp_data);