function evaluation_of_standard_particle(ls,ms,hs,h_uitable)

ls_title = {'lsͨ��' ' ' ' ' ' '};

tmp1 = sprintf('%4.1f',ls.barycentre);
tmp2 = sprintf('%4.1f',ls.peak_mean);
ls_bary = {'����' tmp1 '��ֵ' tmp2};
tmp = sprintf('%4.0f',ls.cellnum);
ls_num = {'����' tmp '����' tmp};
tmp1 = sprintf('%4.1f',ls.hist_width);
tmp2 = sprintf('%4.1f',ls.hist_sd);
ls_width = {'����' tmp1 'SD' tmp2};
tmp1 = sprintf('%4.1f%%',ls.hist_cv1);
tmp2 = sprintf('%4.1f%%',ls.hist_cv2);
ls_cv = {'CV' tmp1 'CV' tmp2};

ms_title = {'msͨ��' ' ' ' ' ' '};

tmp1 = sprintf('%4.1f',ms.barycentre);
tmp2 = sprintf('%4.1f',ms.peak_mean);
ms_bary = {'����' tmp1 '��ֵ' tmp2};
tmp = sprintf('%4.0f',ms.cellnum);
ms_num = {'����' tmp '����' tmp};
tmp1 = sprintf('%4.1f',ms.hist_width);
tmp2 = sprintf('%4.1f',ms.hist_sd);
ms_width = {'����' tmp1 'SD' tmp2};
tmp1 = sprintf('%4.1f%%',ms.hist_cv1);
tmp2 = sprintf('%4.1f%%',ms.hist_cv2);
ms_cv = {'CV' tmp1 'CV' tmp2};

hs_title = {'hsͨ��' ' ' ' ' ' '};

tmp1 = sprintf('%4.1f',hs.barycentre);
tmp2 = sprintf('%4.1f',hs.peak_mean);
hs_bary = {'����' tmp1 '��ֵ' tmp2};
tmp = sprintf('%4.0f',hs.cellnum);
hs_num = {'����' tmp '����' tmp};
tmp1 = sprintf('%4.1f',hs.hist_width);
tmp2 = sprintf('%4.1f',hs.hist_sd);
hs_width = {'����' tmp1 'SD' tmp2};
tmp1 = sprintf('%4.1f%%',hs.hist_cv1);
tmp2 = sprintf('%4.1f%%',hs.hist_cv2);
hs_cv = {'CV' tmp1 'CV' tmp2};

blank = {' ' ' ' ' ' ' ' };

data = [ls_title;ls_bary;ls_num;ls_width;ls_cv;blank;ms_title;ms_bary;...
    ms_num;ms_width;ms_cv;blank;hs_title;hs_bary;hs_num;hs_width;hs_cv];
set(h_uitable,'data',data);