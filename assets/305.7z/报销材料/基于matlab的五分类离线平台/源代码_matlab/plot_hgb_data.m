function h_hgb = plot_hgb_data(hgb_vol,hgb_pos,h_axes)

hgb_bk_pos = int32(hgb_pos.bk);
hgb_measure_pos = int32(hgb_pos.me);
x = 1:length(hgb_vol);
if hgb_measure_pos > length(hgb_vol)
    hgb_measure_pos = length(hgb_vol);
end
h_hgb = plot(h_axes,x,hgb_vol,'r');
hold(h_axes,'on');
plot(h_axes,hgb_bk_pos,hgb_vol(hgb_bk_pos),'s','MarkerSize',10,'MarkerEdgeColor','g','MarkerFaceColor','g');
plot(h_axes,hgb_measure_pos,hgb_vol(hgb_measure_pos),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
hold(h_axes,'off');
%set(handles.axes_hgb,'color',[0,0,0],'xlim',[1 vol_num+100],'XTick',[1:1000:4100],'XTickLabel',{'0' '10' '20' '30' '40'});
set(h_axes,'color',[0,0,0],'xlim',[1 length(hgb_vol)+100]);
%set(handles.text_hgb_bk,'string',num2str(hgb_vol(hgb_bk_pos)));
%set(handles.text_hgb_measure,'string',num2str(hgb_vol(hgb_measure_pos)));
%hgb_theoretical = log10(hgb_vol(hgb_bk_pos)/hgb_vol(hgb_measure_pos))*230;
%set(handles.text_hgb_re,'string',sprintf('%5.4f',hgb_theoretical));
%set(h_hgb,'ButtonDownFcn',{@hgb_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback