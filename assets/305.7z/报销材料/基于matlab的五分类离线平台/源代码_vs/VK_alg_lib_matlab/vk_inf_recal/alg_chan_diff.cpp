#include "alg_chan_diff.h"
#include "alg_resource.h"
#include "alg_watershed.h"
#include "vk_global.h"

#include <string.h>
#include <math.h>

/*******************************************************************
// �� �� ���� difmain
// ��    �ܣ� difͨ��������
********************************************************************/
bool difmain(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1 ��ʼ��
	flag = difinit(DifInput, DifOutput);
	if (!flag)
	{
		return false;
	}

	// 2 ��ȡDiffͨ�����ò���
	flag = difconfigpara(&DifInput->DifConfigPara);
	if (!flag)
	{
		return false;
	}

	// 3 Diffͨ���źŴ���
	flag = difsigprocess(DifInput, DifOutput);
	if (!flag)
	{
		return false;
	}

	// 4 Diffͨ�������㷨
	flag = difclassify(DifInput, DifOutput);
	if (!flag)
	{
		return false;
	}

	// 5 Diffͨ����������
	flag = difparacal(DifInput, DifOutput);

	return flag;
}

/*******************************************************************
// �� �� ���� difinit
// ��    �ܣ� difͨ����ʼ��
********************************************************************/
bool difinit(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	memset(DifOutput, 0, sizeof(stDifOutput));

	return true;
}

/*******************************************************************
// �� �� ���� getdifconfigpara
// ��    �ܣ� difͨ�����ò���
********************************************************************/
bool difconfigpara(stDifConfigPara *pConfigPara)
{
	if (pConfigPara == NULL)
	{
		return false;
	}

	// 1ά��(LS����)
	pConfigPara->Alg_D_Sig_LogTranConfig[0].Left  = 230 ;
	pConfigPara->Alg_D_Sig_LogTranConfig[0].Right = 4095;
	pConfigPara->Alg_D_Sig_LogTranConfig[0].Base  = 0.0 ;
	pConfigPara->Alg_D_Sig_LogTranConfig[0].Min   = 0   ;
	pConfigPara->Alg_D_Sig_LogTranConfig[0].Max   = 4095;

	// 2ά��(MS����)
	pConfigPara->Alg_D_Sig_LogTranConfig[1].Left  = 120 ;
	pConfigPara->Alg_D_Sig_LogTranConfig[1].Right = 4095;
	pConfigPara->Alg_D_Sig_LogTranConfig[1].Base  = 0.0 ;
	pConfigPara->Alg_D_Sig_LogTranConfig[1].Min   = 0   ;
	pConfigPara->Alg_D_Sig_LogTranConfig[1].Max   = 4095;

	// 3ά��(HS����)
	pConfigPara->Alg_D_Sig_LogTranConfig[2].Left  = 50  ;
	pConfigPara->Alg_D_Sig_LogTranConfig[2].Right = 4095;
	pConfigPara->Alg_D_Sig_LogTranConfig[2].Base  = 0.0 ;
	pConfigPara->Alg_D_Sig_LogTranConfig[2].Min   = 0   ;
	pConfigPara->Alg_D_Sig_LogTranConfig[2].Max   = 4095;

	return true;
}



/*******************************************************************
// �� �� ���� difsigprocess
// ��    �ܣ� difͨ���źŴ���
********************************************************************/
bool difsigprocess(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	// 1��DATA����ת��---------------------------------------
	stOptiCellList DifCellList;
	memset(&DifCellList, 0, sizeof(stOptiCellList));

	convert_inf_data(&DifCellList, DifInput->diff_cell_list, DifInput->diff_cell_num);

	// 2������任
	coorconvite_opti(DifInput->DifConfigPara.Alg_D_Sig_LogTranConfig, DifCellList);

	DifOutput->DifFeaturePara.OptiCellList = DifCellList;

	return true;
}

/*******************************************************************
// �� �� ���� difclassify
// ��    �ܣ� difͨ�������㷨
********************************************************************/
bool difclassify(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	//if (DifInput->WorkMode == WORKMODE_QUALC)
	//{
	//	difclassify_qualc(DifInput, DifOutput);
	//}
	//else
	//{
		difclassify_blood(DifInput, DifOutput);
	//}
	
	return true;
}

// Ѫ�������㷨
bool difclassify_blood(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	removeghost_blood(DifInput, DifOutput);

	classify_Eos_blood(DifInput, DifOutput);

	classify_LMN_blood(DifInput, DifOutput);

	return true;
}

// �ʿط����㷨
bool difclassify_qualc(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	return true;
}

// ȥѪӰ
bool removeghost_blood(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	bool flag = false;
	
	// ��������
	stOptiCellList OptiCellList = DifOutput->DifFeaturePara.OptiCellList;

	// �ڴ�����
	int *InptSct = new int[Sct_Len_64*Sct_Len_64];
	int *InptMap = new int[Sct_Len_64*Sct_Len_64];
	int *TypeSct = new int[Sct_Len_64*Sct_Len_64];

	memset(InptSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptMap, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(TypeSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);

	int SctType = LS_MS_ALG;

	// 1�����inputSct
	getinptsct(InptSct, Sct_Len_64, SctType, OptiCellList, CELLTYPE_BLANK, 4, 2, 0.4);
	memcpy(DifOutput->DifGraphPara.ls_ms_alg, InptSct, sizeof(int)*Sct_Len_64*Sct_Len_64);
	// 2����ȡUnicStp
	flag = readcsv("./config/map1.csv", InptMap, Sct_Len_64*Sct_Len_64);
	if (!flag)
	{
		POINTER_FREE(InptSct);
		POINTER_FREE(InptMap);
		POINTER_FREE(TypeSct);
		return false;
	}

	// 3����ˮ���㷨
	AlgWatershed(InptSct, InptMap, TypeSct, Sct_Len_64, Sct_Len_64);

	// 4��������������
	settypesct(OptiCellList, CELLTYPE_BLANK, TypeSct, Sct_Len_64, SctType);

	POINTER_FREE(InptSct);
	POINTER_FREE(InptMap);
	POINTER_FREE(TypeSct);

	return true;
}

// Neu/Eos����
bool classify_Eos_blood(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	// ��������
	stOptiCellList OptiCellList = DifOutput->DifFeaturePara.OptiCellList;

	// �ڴ�����
	int *InptSct = new int[Sct_Len_64*Sct_Len_64];
	int *ScatStp = new int[Sct_Len_64*Sct_Len_64];
	int *InptMap = new int[Sct_Len_64*Sct_Len_64];
	int *InptStp = new int[Sct_Len_64*Sct_Len_64];
	int *TypeSct = new int[Sct_Len_64*Sct_Len_64];

	memset(InptSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(ScatStp, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptStp, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptMap, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(TypeSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);

	// 1�����inputSct
	int SctType = LS_HS_ALG;
	getinptsct(InptSct, Sct_Len_64, SctType, OptiCellList, CELLTYPE_NEU, 4, 2, 0.4);
	memcpy(DifOutput->DifGraphPara.ls_hs_alg, InptSct, sizeof(int)*Sct_Len_64*Sct_Len_64);
	// 3�����InptStp
	double stepcol[4] = {0.7, 0.5, 0.3, 0.05};
	getinptstp(ScatStp, InptSct, Sct_Len_64, stepcol);

	// 5����ȡInptMap
	readcsv("./config/map2.csv", InptMap, Sct_Len_64*Sct_Len_64);

	// 6��ģ��ƥ��
	double Sco = 0.0;
	int    X_S = 0;
	int    Y_S = 0;

	readcsv("./config/stp2.csv", InptStp, Sct_Len_64*Sct_Len_64);

	TemplateMatch(InptMap, ScatStp, InptStp, Sct_Len_64, Sct_Len_64, &Sco, &X_S, &Y_S);

	// 7����ˮ���㷨
	AlgWatershed(InptSct, InptMap, TypeSct, Sct_Len_64, Sct_Len_64);

	// 8��������������
	settypesct(OptiCellList, CELLTYPE_NEU, TypeSct, Sct_Len_64, SctType);

	POINTER_FREE(InptSct);
	POINTER_FREE(ScatStp);
	POINTER_FREE(InptStp);
	POINTER_FREE(InptMap);
	POINTER_FREE(TypeSct);

	return true;
}

// Lym/Neu/Mon ����
bool classify_LMN_blood(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}
	// ��������
	stOptiCellList OptiCellList = DifOutput->DifFeaturePara.OptiCellList;

	// �ڴ�����
	int *InptSct = new int[Sct_Len_64*Sct_Len_64];
	int *ScatStp = new int[Sct_Len_64*Sct_Len_64];
	int *InptMap = new int[Sct_Len_64*Sct_Len_64];
	int *InptStp = new int[Sct_Len_64*Sct_Len_64];
	int *TypeSct = new int[Sct_Len_64*Sct_Len_64];

	memset(InptSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(ScatStp, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptStp, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptMap, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(TypeSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);

	// 1�����inputSct
	int SctType = LS_MS_ALG;
	getinptsct(InptSct, Sct_Len_64, SctType, OptiCellList, CELLTYPE_NEU, 4, 2, 0.4);

	// 3�����InptStp
	double stepcol[4] = {0.7, 0.5, 0.3, 0.05};
	getinptstp(ScatStp, InptSct, Sct_Len_64, stepcol);

	// 5����ȡInptMap
	readcsv("./config/map3.csv", InptMap, Sct_Len_64*Sct_Len_64);

	// 6��ģ��ƥ��
	double Sco = 0.0;
	int    X_S = 0;
	int    Y_S = 0;

	readcsv("./config/stp3.csv", InptStp, Sct_Len_64*Sct_Len_64);
	TemplateMatch(InptMap, ScatStp, InptStp, Sct_Len_64, Sct_Len_64, &Sco, &X_S, &Y_S);

	// 7����ˮ���㷨
	AlgWatershed(InptSct, InptMap, TypeSct, Sct_Len_64, Sct_Len_64);

	// 8��������������
	settypesct(OptiCellList, CELLTYPE_NEU, TypeSct, Sct_Len_64, SctType);

	POINTER_FREE(InptSct);
	POINTER_FREE(ScatStp);
	POINTER_FREE(InptStp);
	POINTER_FREE(InptMap);
	POINTER_FREE(TypeSct);

	return true;
}

/*******************************************************************
// �� �� ���� difcparacal
// ��    �ܣ� difͨ����������
********************************************************************/
bool difparacal(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	// �����������
	DifServiceParaCal(DifInput, DifOutput);

	// �����������
	DifReportParaCal(DifInput, DifOutput);

	// ������������
	DifFeatureParaCal(DifInput, DifOutput);

	// �о���������
	DifResearchParaCal(DifInput, DifOutput);

	return true;
}

// �����������
bool DifServiceParaCal(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	stOptiCellList OptiCellList = DifOutput->DifFeaturePara.OptiCellList;

	int GhostNum = 0;
	int WbcNum   = 0;
	int LymNum   = 0;
	int MonNum   = 0;
	int NeuNum   = 0;
	int EosNum   = 0;

	for (int i=0; i<OptiCellList.CellNum; i++)
	{
		switch (OptiCellList.pOptiPulse[i].CellType)
		{
		case CELLTYPE_GHOST:
			GhostNum ++;
			break;

		case CELLTYPE_LYM:
			LymNum ++;
			break;

		case CELLTYPE_MON:
			MonNum ++;
			break;

		case CELLTYPE_NEU:
			NeuNum ++;
			break;

		case CELLTYPE_EOS:
			EosNum ++;
			break;

		default:
			break;
		}
	}

	WbcNum = LymNum + MonNum + NeuNum + EosNum;

	DifOutput->DifServicePara.AllCellNum = WbcNum + GhostNum;
	DifOutput->DifServicePara.GhostNum   = GhostNum;
	DifOutput->DifServicePara.WbcCellNum = WbcNum;

	DifOutput->DifServicePara.LymCellNum = LymNum;
	DifOutput->DifServicePara.MonCellNum = MonNum;
	DifOutput->DifServicePara.NeuCellNum = NeuNum;
	DifOutput->DifServicePara.EosCellNum = EosNum;

	return true;
}

// �����������
bool DifReportParaCal(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput == NULL || DifOutput == NULL)
	{
		return false;
	}

	// 1 ��ϸ������ֵ����
	// 1.1 ��ȡ��ϸ������ֵ
	int WbcCellNum = DifOutput->DifServicePara.WbcCellNum;

	// 1.2 ����Wbc
	double Dilution = DifInput->Dilution;
	double Volume   = DifInput->MeasureTime*DifInput->MeasureFlow;

	Volume =(Volume < EPSINON) ? DifInput->Volume : Volume;

	DifOutput->DifReportPara.Wbc = (Volume > EPSINON) ? 1.0*WbcCellNum*Dilution/Volume/1000 : 0;

	// 2 �ٷֱȼ���
	// 2.1 ��ȡ����ϸ������ֵ
	int LymNum = DifOutput->DifServicePara.LymCellNum;
	int MonNum = DifOutput->DifServicePara.MonCellNum;
	int NeuNum = DifOutput->DifServicePara.NeuCellNum;
	int EosNum = DifOutput->DifServicePara.EosCellNum;

	// 2.2 ����ٷֱ�
	DifOutput->DifReportPara.LymPer = (WbcCellNum > 0) ? 100.0*LymNum/WbcCellNum : 0;
	DifOutput->DifReportPara.MonPer = (WbcCellNum > 0) ? 100.0*MonNum/WbcCellNum : 0;
	DifOutput->DifReportPara.NeuPer = (WbcCellNum > 0) ? 100.0*NeuNum/WbcCellNum : 0;
	DifOutput->DifReportPara.EosPer = (WbcCellNum > 0) ? 100.0*EosNum/WbcCellNum : 0;

	return true;
}

// ������������
bool DifFeatureParaCal(stDifInput *DifInput,	stDifOutput *DifOutput)
{
	if (DifInput  == NULL || DifOutput == NULL)
	{
		return false;
	}

	return true;
}

// �о���������
bool DifResearchParaCal(stDifInput *DifInput, stDifOutput *DifOutput)
{
	if (DifInput  == NULL || DifOutput == NULL)
	{
		return false;
	}

	return true;
}