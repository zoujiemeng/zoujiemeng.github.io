#include "alg_chan_wbc.h"
#include "alg_resource.h"
#include "alg_watershed.h"

#include <math.h>
#include <string.h>

/*******************************************************************
// �� �� ���� main
// ��    �ܣ� ������
********************************************************************/
bool wbcmain(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1����ʼ��
	flag = wbcinit(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 2����ȡ���ò���
	flag = wbcconfigpara(&(WbcInput->WbcConfigPara));
	if (!flag)
	{
		return false;
	}

	// 3���źŴ���
	flag = wbcsigprocess(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 4��ͨ������
	flag = wbcclassify(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 5����������
	flag = wbcparacal(WbcInput, WbcOutput);

	return flag;
}

/*******************************************************************
// �� �� ���� init
// ��    �ܣ� ��ʼ��
********************************************************************/
bool wbcinit(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	memset(WbcOutput, 0, sizeof(stWbcOutput));

	return true;
}

/*******************************************************************
// �� �� ���� configpara
// ��    �ܣ� ���ò���
********************************************************************/
bool wbcconfigpara(stWbcConfigPara *pConfigPara)
{
	if (pConfigPara == NULL)
	{
		return false;
	}

	// 1ά��(LS����)
	pConfigPara->Alg_W_Sig_LogTranConfig[0].Left  = 230 ;
	pConfigPara->Alg_W_Sig_LogTranConfig[0].Right = 4095;
	pConfigPara->Alg_W_Sig_LogTranConfig[0].Base  = 0.0 ;
	pConfigPara->Alg_W_Sig_LogTranConfig[0].Min   = 0   ;
	pConfigPara->Alg_W_Sig_LogTranConfig[0].Max   = 4095;

	// 2ά��(MS����)
	pConfigPara->Alg_W_Sig_LogTranConfig[1].Left  = 120 ;
	pConfigPara->Alg_W_Sig_LogTranConfig[1].Right = 4095;
	pConfigPara->Alg_W_Sig_LogTranConfig[1].Base  = 0.0 ;
	pConfigPara->Alg_W_Sig_LogTranConfig[1].Min   = 0   ;
	pConfigPara->Alg_W_Sig_LogTranConfig[1].Max   = 4095;

	// 3ά��(HS����)
	pConfigPara->Alg_W_Sig_LogTranConfig[2].Left  = 50  ;
	pConfigPara->Alg_W_Sig_LogTranConfig[2].Right = 4095;
	pConfigPara->Alg_W_Sig_LogTranConfig[2].Base  = 0.0 ;
	pConfigPara->Alg_W_Sig_LogTranConfig[2].Min   = 0   ;
	pConfigPara->Alg_W_Sig_LogTranConfig[2].Max   = 4095;

	pConfigPara->Alg_W_Cal_SubBackGround = 10;                   // WBC������������
	pConfigPara->Alg_W_Cal_dWbcExpCoff   = 1.2;                  // WBC���Ӳ���ϵ��

	return true;
}

/*******************************************************************
// �� �� ���� sigprocess
// ��    �ܣ� �źŴ���
********************************************************************/
bool wbcsigprocess(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// 1��DATA����ת��---------------------------------------
	stOptiCellList WbcCellList;
	memset(&WbcCellList, 0, sizeof(stOptiCellList));

	convert_inf_data(&WbcCellList, WbcInput->diff_cell_list, WbcInput->diff_cell_num);
	
	// 2������任
	coorconvite_opti(WbcInput->WbcConfigPara.Alg_W_Sig_LogTranConfig, WbcCellList);

	WbcOutput->WbcFeaturePara.OptiCellList = WbcCellList;

	return true;
}

/*******************************************************************
// �� �� ���� classify
// ��    �ܣ� �����㷨
********************************************************************/
bool wbcclassify(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}
	
	wbcclassify_blood(WbcInput, WbcOutput);

	return true;
}

// Ѫ�������㷨
bool wbcclassify_blood(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	int i = 0;
	int j = 0;

	// ��ȡCellList
	stOptiCellList OptiCellList = WbcOutput->WbcFeaturePara.OptiCellList;

	// �ڴ�����
	int *InptSct = new int[Sct_Len_64*Sct_Len_64];
	int *InptMap = new int[Sct_Len_64*Sct_Len_64];
	int *TypeSct = new int[Sct_Len_64*Sct_Len_64];

	memset(InptSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(InptMap, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);
	memset(TypeSct, 0, sizeof(int)*Sct_Len_64*Sct_Len_64);

	// 1�����inputSct
	int SctType = LS_MS_ALG;
	getinptsct(InptSct, Sct_Len_64, SctType, OptiCellList, CELLTYPE_BLANK, 4, 2, 0.4);

	// 2�����inputMap
	// 2.1��������������
	double Ls_P = 0;
	double Ms_P = 0;
	double Hs_P = 0;

	for (int i=0; i<OptiCellList.CellNum; i++)
	{
		Ls_P += 1.0*OptiCellList.pOptiPulse[i].Alg_LSC/OptiCellList.CellNum;
		Ms_P += 1.0*OptiCellList.pOptiPulse[i].Alg_MSC/OptiCellList.CellNum;
		Hs_P += 1.0*OptiCellList.pOptiPulse[i].Alg_HSC/OptiCellList.CellNum;
	}
	
	// 2.2������Map
	double a = 6.0;
	double b = 10.0;
	double x = Ms_P * Sct_Len_64 / Max_Pulse_Val + 18;
	double y = 38.0;
	double q = 00.0;
	double sinq = sin(q*PI/180.0);
	double cosq = cos(q*PI/180.0);

	for (i=0; i<Sct_Len_64; i++)
	{
		for (j=0; j<Sct_Len_64; j++)
		{
			double x1 = (j-x)*cosq + (i-y)*sinq;
			double y1 = (j-x)*sinq - (i-y)*cosq;

			double temp1 = y1*y1/a/a + x1*x1/b/b;

			if (temp1 > 2.0)
			{
				InptMap[i*Sct_Len_64+j] = CELLTYPE_NLME;
			}
			else if (temp1 < 0.8)
			{
				InptMap[i*Sct_Len_64+j] = CELLTYPE_BAS;
			}

			//if( j > x && i > y - 2*a && i< y + 2*a)
			//{
			//	OptiClsRes.UnicMap[i*Sct_Len_64+j] = CELLTYPE_BLANK;
			//}

			//if (j > x && i > y - a && i< y + a)
			//{
			//	OptiClsRes.UnicMap[i*Sct_Len_64+j] = CELLTYPE_BAS;
			//}
		}
	}

	// 7����ˮ���㷨
	AlgWatershed(InptSct, InptMap, TypeSct, Sct_Len_64, Sct_Len_64);

	// 8��������������
	settypesct(OptiCellList, CELLTYPE_BLANK, TypeSct, Sct_Len_64, SctType);

	POINTER_FREE(InptSct);
	POINTER_FREE(InptMap);
	POINTER_FREE(TypeSct);

	return true;
}

// �ʿط����㷨
bool wbcclassify_qualc(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	return true;
}

/*******************************************************************
// �� �� ���� paracal
// ��    �ܣ� ������
********************************************************************/
bool wbcparacal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ����ͼ�δ���
	WbcGraphParaCal(WbcInput, WbcOutput);

	// 1�������������
	WbcServiceParaCal(WbcInput, WbcOutput);

	// 2�������������
	WbcReportParaCal(WbcInput,  WbcOutput);

	// 3��������������
	WbcFeatureParaCal(WbcInput,  WbcOutput);

	return true;
}

// Wbcͼ�β�������
bool WbcGraphParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if ( WbcInput  == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// Wbcֱ��ͼ
	stHist WbcLsHist;
	memset(&WbcLsHist, 0, sizeof(stHist));

	WbcLsHist.datalen = 256;
	WbcLsHist.linelen = 0;

	stOptiCellList WbcCellList = WbcOutput->WbcFeaturePara.OptiCellList;

	for (int i=0; i<WbcCellList.CellNum; i++)
	{
		int x = WbcCellList.pOptiPulse[i].Org_LSC * WbcLsHist.datalen / Max_Pulse_Val;
		
		WbcLsHist.datas[x] ++;
	}

	curvesmooth_gauss<int, int>(WbcLsHist.datas, WbcLsHist.datas, WbcLsHist.datalen, 8, 4);
	curvesmooth_gauss<int, int>(WbcLsHist.datas, WbcLsHist.datas, WbcLsHist.datalen, 8, 4);
	curvesmooth_gauss<int, int>(WbcLsHist.datas, WbcLsHist.datas, WbcLsHist.datalen, 8, 4);

	WbcOutput->WbcGraphPara.WbcHist = WbcLsHist;

	return true;
}

// Wbc ���Ӳ���
int WbcCompensation(int fWbcTotal, double dExpCoff)
{
	// one
	double tmpdouble      = dExpCoff*fWbcTotal*0.000001;
	double ftmpRbcCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	double ftmpRbcTotal   = fWbcTotal/ftmpRbcCompFac;

	// two
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpRbcTotal    = fWbcTotal/ftmpRbcCompFac;

	// three
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpRbcTotal    = fWbcTotal/ftmpRbcCompFac;

	// four
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;

	int WbcTotalNum = (int)(fWbcTotal/ftmpRbcCompFac);

	return WbcTotalNum;
}

// Wbc�����������
bool WbcReportParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if ( WbcInput  == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ���ò���
	int    Alg_W_Cal_SubBackGround = WbcInput->WbcConfigPara.Alg_W_Cal_SubBackGround;
	double Alg_W_Cal_dWbcExpCoff   = WbcInput->WbcConfigPara.Alg_W_Cal_dWbcExpCoff;

	// ��������
	int    WbcCellNum = WbcOutput->WbcServicePara.WbcCellNum;
	int    BasCellNum = WbcOutput->WbcServicePara.BasCellNum;
	double Dilution   = WbcInput->Dilution;
	double Volume     = WbcInput->Volume;

	// 1��WBC����
	double dWbc     = 0.0;

	// 1.1�����Ӳ���
	WbcCellNum  = WbcCompensation(WbcCellNum, Alg_W_Cal_dWbcExpCoff);

	// 1.2��������
	WbcCellNum -= Alg_W_Cal_SubBackGround;

	// 1.3��fWbc����
	if (Volume > EPSINON)
	{
		dWbc = WbcCellNum*Dilution/Volume/1000;
	}

	WbcOutput->WbcReportPara.Wbc = (dWbc > EPSINON) ? dWbc : 0;

	// 2��Bas%����
	double dBasPer = 0.0;
	
	if (WbcCellNum > EPSINON)
	{
		dBasPer = 100.0*BasCellNum/WbcCellNum;
	}
	
	WbcOutput->WbcReportPara.BasPer = dBasPer;

	return true;
}

// Wbc������������
bool WbcFeatureParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	//int i=0;

	//// ��ȡͨ��������Ϣ
	//stOptiCellList OptiCellList = WbcOutput->WbcFeaturePara.OptiCellList;


	return true;
}

// Wbc�����������
bool WbcServiceParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// CellList��Ϣ
	stOptiCellList OptiCellList = WbcOutput->WbcFeaturePara.OptiCellList;
	
	// ��������ͳ��
	int BasNum  = 0;
	int NLMENum = 0;
	int WbcNum  = 0;
	for (int i=0; i<OptiCellList.CellNum; i++)
	{
		switch(OptiCellList.pOptiPulse[i].CellType)
		{
		case CELLTYPE_NLME: NLMENum++; break;
		case CELLTYPE_BAS:  BasNum ++; break;
		default: break;
		}
	}

	WbcNum = BasNum + NLMENum;

	// ��ֵ
	WbcOutput->WbcServicePara.WbcCellNum = WbcNum;
	WbcOutput->WbcServicePara.BasCellNum = BasNum;
	
	return true;
}
