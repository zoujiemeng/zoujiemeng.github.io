#include "alg_resource.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
/*******************************************************************
// ��������
********************************************************************/
// ��ȡ��˹ƽ����
void getgaussfactor(double *factor, int step, double delta)
{
	if (factor == 0)
	{
		return;
	}

	double dsum = 0.0;

	for(int i=0; i<step; i++)
	{
		*(factor + i) = exp(-1.0*(i-(step-1)/2)*(i-(step-1)/2)/(2*delta*delta));
		dsum          += *(factor + i);
	}

	// ��һ��
	for (int i = 0; i < step; i++)
	{
		*(factor + i) /= dsum;
	}
}

/*******************************************************************
// ֱ��ͼ
********************************************************************/
// ֱ��ͼ����
bool gethist(stHist *pHist, stImpdCellList CellList)
{
	if (pHist == 0)
	{
		return false;
	}

	// ֱ��ͼ��ʼ��
	memset(pHist->datas, 0, sizeof(pHist->datas));

	int factor  = Max_Pulse_Val/pHist->datalen; 

	int i = 0;

	//if (MeasureMode)
	//{
	//	CellNum = 0;

	//	for (i=0; i<PulseNum; i++)
	//	{
	//		if ( pstImpdPulse[i].TimeStamp > (int)(10*TraverseTime+0.5) )
	//		{
	//			break;
	//		}

	//		CellNum ++;
	//	}
	//}

	for (i=0; i<CellList.CellNum; i++)
	{
		int index = CellList.pImpdPulse[i].PeakValue/factor;

		if (index > pHist->datalen - 1)
		{
			index = pHist->datalen - 1;
		}

		pHist->datas[index] ++;
	}

	return true;
}

/*******************************************************************
// ɢ��ͼ
********************************************************************/
// ɢ��ͼ����
bool getdatasct(int *DataSct, int SctLen, int SctType, stOptiCellList CellList, int CellType)
{
	if (DataSct == 0)
	{
		return false;
	}

	memset(DataSct, 0, sizeof(int)*SctLen*SctLen);

	int x = 0;
	int y = 0;
	int z = 0;

	if (SctType == LS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;
			}
			else if (CellType == CellList.pOptiPulse[i].CellType)
			{
				x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}
	else if (SctType == LS_HS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;
			}
			else if (CellList.pOptiPulse[i].CellType == CellType)
			{
				x = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}
	else if (SctType == HS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;
			}
			else if (CellList.pOptiPulse[i].CellType == CellType)
			{
				x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}
	if (SctType == LS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;
			}
			else if (CellType == CellList.pOptiPulse[i].CellType)
			{
				x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}
	else if (SctType == LS_HS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;
			}
			else if (CellList.pOptiPulse[i].CellType == CellType)
			{
				x = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}
	else if (SctType == HS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellType == CELLTYPE_ALL)
			{
				x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;
			}
			else if (CellList.pOptiPulse[i].CellType == CellType)
			{
				x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
				y = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;
			}

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			DataSct[y*SctLen + x]++;
		}
	}

	return true;
}

// ������������
bool settypesct(stOptiCellList CellList, int CellType, int *TypeSct, int SctLen, int SctType)
{
	if (TypeSct == 0)
	{
		return false;
	}

	if (SctType == LS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Org_MSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Org_LSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}
	else if (SctType == LS_HS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Org_HSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Org_LSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}
	else if (SctType == HS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Org_MSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Org_HSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}
	else if (SctType == LS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Alg_MSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Alg_LSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}
	else if (SctType == LS_HS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Alg_HSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Alg_LSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}
	else if (SctType == HS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			if (CellList.pOptiPulse[i].CellType == CellType)
			{
				int x = CellList.pOptiPulse[i].Alg_MSC * SctLen/Max_Pulse_Val;
				int y = CellList.pOptiPulse[i].Alg_HSC * SctLen/Max_Pulse_Val;

				limit<int>(&x, 0, SctLen-1);
				limit<int>(&y, 0, SctLen-1);

				CellList.pOptiPulse[i].CellType = TypeSct[y*SctLen + x];
			}
		}
	}

	return true;
}

bool gettypesct(int *TypeSct, int SctLen, int SctType, stOptiCellList CellList)
{
	if (TypeSct == 0)
	{
		return false;
	}

	memset(TypeSct, 0, sizeof(int)*SctLen*SctLen);

	int x = 0;
	int y = 0;
	int z = 0;

	if (SctType == LS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}
	else if (SctType == LS_HS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Org_LSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}
	else if (SctType == HS_MS)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Org_MSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Org_HSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}
	if (SctType == LS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}
	else if (SctType == LS_HS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Alg_LSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}
	else if (SctType == HS_MS_ALG)
	{
		for (int i=0; i<CellList.CellNum; i++)
		{
			x = CellList.pOptiPulse[i].Alg_MSC *SctLen/Max_Pulse_Val;
			y = CellList.pOptiPulse[i].Alg_HSC *SctLen/Max_Pulse_Val;

			limit<int>(&x, 0, SctLen-1);
			limit<int>(&y, 0, SctLen-1);

			TypeSct[y*SctLen + x] = CellList.pOptiPulse[i].CellType;
		}
	}

	return true;
}

bool getinptsct(int *InptSct, int SctLen, int SctType, stOptiCellList CellList, int CellType,
	int step, double delta, double coel)
{
	if (InptSct == 0)
	{
		return false;
	}

	// ��ȡDataSct
	int *DataSct = new int[SctLen*SctLen];
	getdatasct(DataSct, SctLen, SctType, CellList, CellType);

	// ��ȡGaussSct
	double *GaussSct = new double[SctLen*SctLen];
	sctsmooth_gauss<double, int>(GaussSct, DataSct, SctLen, SctLen, step, delta);

	// ��ȡCfarSct
	int *CfarSct = new int[SctLen*SctLen];
	getcfarsct<int, int>(CfarSct, DataSct, SctLen, SctLen, step, delta);

	// ����InputSct
	for (int i=0; i<SctLen; i++)
	{
		for (int j=0; j<SctLen; j++)
		{
			int index = i*SctLen + j;

			InptSct[index] = (int)(coel*GaussSct[index] + (1-coel)*CfarSct[index]);
			//InptSct[index] = (int)(DataSct[index]);
		}
	}

	if (CfarSct)  delete[] CfarSct;
	if (GaussSct) delete[] GaussSct;
	if (DataSct)  delete[] DataSct;

	return true;
}

/*******************************************************************
// ����ת��
********************************************************************/
// HGBͨ��ת��------------------------------------------------------
void dataconvite_hgb(stHgbVolList * HgbVolList, unsigned char *DataAddr, int DataLen)
{
	if (HgbVolList == NULL || DataAddr == NULL)
	{
		return;
	}

	int i = 0;

	// �ڴ�����
	short *VolListVal = new short[DataLen];
	if (VolListVal == NULL)
	{
		return;
	}
	memset(VolListVal, 0, sizeof(short)*DataLen);

	// ����ת��
	for (i=0; i<DataLen; i++)
	{
		VolListVal[i] = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += sizeof(short);
	}

	// ��ֵ����
	HgbVolList->VolListVal = VolListVal;
	HgbVolList->VolListNum = DataLen;
}

// �迹ͨ��ת����DataLenΪpulse����
void dataconvite_impd(stImpdCellList *pCellList, unsigned char *DataAddr, int DataLen)
{
	if (pCellList == NULL || DataAddr == NULL)
	{
		return;
	}

	int i = 0;
	int j = 0;

	// �ڴ�����
	stImpdPulse *pPulseInfo = new stImpdPulse[DataLen];
	if (pPulseInfo == NULL)
	{
		return;
	}
	memset(pPulseInfo, 0, sizeof(stImpdPulse)*DataLen);

	// ��ȡ��Ϣ
	for (i=0; i<DataLen; i++)
	{
		// FAFB
		unsigned short HeadCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ��־λ
		DataAddr += 1;

		// ��ֵ
		pPulseInfo[j].PeakValue = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ǰ���
		pPulseInfo[j].PriWidth  = *((unsigned char *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].SubWidth  = *((unsigned char *)DataAddr);
		DataAddr += 1;

		// ȫ���
		pPulseInfo[j].FullWidth = *((unsigned char *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].BaseLine  = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ʱ���
		pPulseInfo[j].TimeStamp = *((unsigned char *)DataAddr);
		DataAddr += 1;

		// M����־
		pPulseInfo[j].MPulseFlag = (bool)(*((unsigned char *)DataAddr) & 0x01);
		DataAddr += 1;

		// ����λ
		DataAddr += 1;

		// У��λ
		DataAddr += 1;

		// FCFD
		unsigned short EndCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ͷβУ��
		if (HeadCheck == 0xFAFB && EndCheck == 0xFCFD && pPulseInfo[j].PeakValue > 0)
		{
			j += 1;
		}
	}

	// ��ֵ����
	pCellList->pImpdPulse = pPulseInfo;
	pCellList->CellNum    = j;
}

void getstamplist_impd(vector<int> &StampList, stImpdCellList CellList)
{
	if (CellList.CellNum <= 0)
	{
		return;
	}

	// ʱ�������
	int StampNum = CellList.pImpdPulse[CellList.CellNum-1].TimeStamp + 1;

	// ʱ�������
	// ��ʼ��
	for (int i=0; i<StampNum; i++)
	{
		StampList.push_back(0);
	}

	// ����
	for (int i=0; i<CellList.CellNum; i++)
	{
		int j = CellList.pImpdPulse[i].TimeStamp;

		StampList[j] ++ ;
	}
}

// ��ѧͨ��ת����DataLenΪpulse����
//void dataconvite_opti(stOptiCellList *pCellList, unsigned char *DataAddr, int DataLen)
//{
//	if (pCellList == NULL || DataAddr == NULL)
//	{
//		return;
//	}
//
//	int i = 0;
//	int j = 0;
//
//	// �ڴ�����
//	stOptiPulse *pPulseInfo = new stOptiPulse[DataLen];
//	if (pPulseInfo == NULL)
//	{
//		return;
//	}
//	memset(pPulseInfo, 0, sizeof(stOptiPulse)*DataLen);
//
//	// ��ȡ��Ϣ
//	for (i=0; i<DataLen; i++)
//	{
//		// FAFB
//		unsigned short HeadCheck = Swap16(*((unsigned short *)DataAddr));
//		DataAddr += 2;
//
//		// ��־λ
//		DataAddr += 1;
//
//		pPulseInfo[j].Org_LSC    = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
//		DataAddr += 2;
//
//		pPulseInfo[j].PulseWidth = *((unsigned char *)DataAddr);
//		DataAddr += 1;
//
//		pPulseInfo[j].Org_MSC    = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
//		DataAddr += 2;
//
//		pPulseInfo[j].Org_HSC    = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
//		DataAddr += 2;
//
//		pPulseInfo[j].TimeStamp  = *((unsigned char *)DataAddr);
//		DataAddr += 1;
//
//		// ����λ
//		DataAddr += 2;
//
//		// У��λ
//		DataAddr += 1;
//
//		// FCFD
//		unsigned short EndCheck = Swap16(*((unsigned short *)DataAddr));
//		DataAddr += 2;
//
//		// ͷβУ��
//		if (HeadCheck == 0xFAFB && EndCheck == 0xFCFD && pPulseInfo[j].Org_LSC > 128)
//		{
//			j += 1;
//		}
//	}
//
//	// ��ֵ����
//	pCellList->pOptiPulse  = pPulseInfo;
//	pCellList->CellNum = j;
//}

int convert_inf_data(stOptiCellList *opti_cell_list, OPTI_CELL_INFO *inf_cell_list,
	int inf_cell_num)
{
	if (opti_cell_list == NULL || inf_cell_list == NULL)
	{
		return -1;
	}

	int i = 0;
	int j = 0;

	// �ڴ�����
	stOptiPulse *pPulseInfo = new stOptiPulse[inf_cell_num];
	if (pPulseInfo == NULL)
	{
		return -2;
	}
	memset(pPulseInfo, 0, sizeof(stOptiPulse)*inf_cell_num);

	// ��ȡ��Ϣ
	for (i = 0; i < inf_cell_num; i++)
	{
		// ��Ч���ж�
		if (inf_cell_list[i].ls_peak == 0 &&
			inf_cell_list[i].ms_peak == 0 &&
			inf_cell_list[i].hs_peak == 0 )
		{
			continue;
		}
		else
		{
			pPulseInfo[j].Org_LSC = inf_cell_list[i].ls_peak;
			pPulseInfo[j].Org_MSC = inf_cell_list[i].ms_peak;
			pPulseInfo[j].Org_HSC = inf_cell_list[i].hs_peak;
			pPulseInfo[j].TimeStamp = inf_cell_list[i].time_stamp;
			pPulseInfo[j].PulseWidth = inf_cell_list[i].ls_width;
			j++;
		}
	}

	// ��ֵ����
	opti_cell_list->pOptiPulse = pPulseInfo;
	opti_cell_list->CellNum = j;
	return 0;
}

void dataconvite_opti(stOptiCellList *pCellList, unsigned char *DataAddr, int DataLen)
{
	if (pCellList == NULL || DataAddr == NULL)
	{
		return;
	}

	int i = 0;
	int j = 0;

	// �ڴ�����
	stOptiPulse *pPulseInfo = new stOptiPulse[DataLen];
	if (pPulseInfo == NULL)
	{
		return;
	}
	memset(pPulseInfo, 0, sizeof(stOptiPulse)*DataLen);

	// ��ȡ��Ϣ
	for (i=0; i<DataLen; i++)
	{
		// ʱ����
		unsigned int HeadCheck = *((unsigned int *)DataAddr);
		DataAddr += 4;

		short Org_LSC = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		short Org_MSC = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		short Org_HSC = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		unsigned short PulseNO = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ����λ
		DataAddr += 4;

		// ��Ч���ж�
		if (PulseNO > 0 && PulseNO <= j + 100)
		{
			pPulseInfo[j].Org_LSC   = Org_LSC;
			pPulseInfo[j].Org_MSC   = Org_MSC;
			pPulseInfo[j].Org_HSC   = Org_HSC;
			pPulseInfo[j].TimeStamp = PulseNO;

			j += 1;
		}
	}

	// ��ֵ����
	pCellList->pOptiPulse  = pPulseInfo;
	pCellList->CellNum = j;
}

void getstamplist_opti(vector<int> &StampList, stOptiCellList CellList)
{
	if (CellList.CellNum <= 0)
	{
		return;
	}

	// ʱ�������
	int StampNum = CellList.pOptiPulse[CellList.CellNum-1].TimeStamp + 1;

	// ʱ�������
	// ��ʼ��
	for (int i=0; i<StampNum; i++)
	{
		StampList.push_back(0);
	}

	// ����
	for (int i=0; i<CellList.CellNum; i++)
	{
		int j = CellList.pOptiPulse[i].TimeStamp;

		StampList[j] ++ ;
	}
}

// ����任
bool coorconvite_opti(stLogTranConfig *pLogTranConfig, stOptiCellList OptiCellList)
{
	if (pLogTranConfig == 0)
	{
		return false;
	}

	// ���ò���
	int    LS_L   = pLogTranConfig[0].Left ;
	int    LS_R   = pLogTranConfig[0].Right;
	double LS_B   = pLogTranConfig[0].Base ;
	int    LS_Min = pLogTranConfig[0].Min  ;
	int    LS_Max = pLogTranConfig[0].Max  ;

	int    MS_L   = pLogTranConfig[1].Left ;
	int    MS_R   = pLogTranConfig[1].Right;
	double MS_B   = pLogTranConfig[1].Base ;
	int    MS_Min = pLogTranConfig[1].Min  ;
	int    MS_Max = pLogTranConfig[1].Max  ;

	int    HS_L   = pLogTranConfig[2].Left ;
	int    HS_R   = pLogTranConfig[2].Right;
	double HS_B   = pLogTranConfig[2].Base ;
	int    HS_Min = pLogTranConfig[2].Min  ;
	int    HS_Max = pLogTranConfig[2].Max  ;

	// ����任
	for (int i=0; i<OptiCellList.CellNum; i++ )
	{
		int x = OptiCellList.pOptiPulse[i].Org_LSC;
		int y = OptiCellList.pOptiPulse[i].Org_MSC;
		int z = OptiCellList.pOptiPulse[i].Org_HSC;

		OptiCellList.pOptiPulse[i].Alg_LSC = LogConvert(x, LS_L, LS_R, LS_B, LS_Min, LS_Max);
		OptiCellList.pOptiPulse[i].Alg_MSC = LogConvert(y, MS_L, MS_R, MS_B, MS_Min, MS_Max);
		OptiCellList.pOptiPulse[i].Alg_HSC = LogConvert(z, HS_L, HS_R, HS_B, HS_Min, HS_Max);
	}

	return true;
}

// ������任
int LogConvert(int x, int Left, int Right, double Base, int Min, int Max)
{
	double factorA = 1.0*(Max - Min)/(log(Right + Base) - log(Left + Base));
	double factorC = factorA * log(Left + Base) - Min;

	if (x < 1)
	{
		x = 1;
	}

	int y = (int)(factorA * log(x + Base) - factorC);

	limit<int>(&y, Min, Max);
	return y;
}

// У׼ϵ������
bool CalirationCal(MODE_WORK workmode, MODE_SAMPLE samplemode, MODE_ANALYSIS analysmode, double *pDstCal, double *pSorCal)
{
	if (pSorCal == NULL || pDstCal == NULL)
	{
		return false;
	}

	// ����ģʽУ׼ϵ��
	if (workmode == WORKMODE_CB_FA)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			pDstCal[i] = 1.0;
		}
	}
	else if (workmode == WORKMODE_CB_US)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			pDstCal[i] = pSorCal[i*MAXCALIRATION+FAXCTORY];
		}
	}
	else
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			pDstCal[i] = pSorCal[i*MAXCALIRATION+FAXCTORY]*pSorCal[i*MAXCALIRATION+CUSTOM];
		}
	}

	// ����ģʽ�䴫��ϵ��
	if (samplemode != SAMPLEMODE_OPEN)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			pDstCal[i] *= pSorCal[i*MAXCALIRATION+SAMPLEFACTOR];
		}
	}

	// ����ģʽ�䴫��ϵ��
	if (  analysmode != ANALYSISMODE_CBC_DIFF)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			pDstCal[i] *= pSorCal[i*MAXCALIRATION+TESTFACTOR];
		}
	}

	return true;
}

/*******************************************************************
// ��ȡCSV�ļ�
********************************************************************/
bool readcsv(char *filename, int *filedata, int datalen)
{
	FILE *fp = fopen(filename, "r");
	if (fp == NULL)
	{
		return false;
	}

	fseek(fp,0,SEEK_END);
	int filelen = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	char* filebuffer = new char[filelen];
	fread(filebuffer, sizeof(char), filelen, fp);

	char *pBegin   = filebuffer;
	char *pRowEnd  = strchr(filebuffer, '\n');
	char *pCellEnd = strchr(filebuffer, ',');

	int index = 0;

	while (pRowEnd != NULL && index < datalen)
	{
		// �н���
		if (pRowEnd < pCellEnd || pCellEnd == NULL)
		{
			*(filedata + index) = atoi(pBegin);
			index += 1;

			pBegin   = pRowEnd + 1;
			pRowEnd = strchr(pRowEnd + 1, '\n');
		}
		else//��Ԫ����
		{
			*(filedata + index) = atoi(pBegin);
			index += 1;

			pBegin   = pCellEnd + 1;
			pCellEnd = strchr(pCellEnd + 1, ',');
		}
	}

	if (filebuffer != NULL)
	{
		delete[] filebuffer;
		filebuffer = NULL;
	}

	if (fp!= NULL)
	{
		fclose(fp);
		fp = NULL;
	}

	return true;
}