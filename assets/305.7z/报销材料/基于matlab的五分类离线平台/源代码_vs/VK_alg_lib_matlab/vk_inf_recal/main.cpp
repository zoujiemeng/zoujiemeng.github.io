#include <stdio.h>
#include <string.h>
#include "mex.h"
#include "alg_chan_diff.h"
#include "alg_chan_wbc.h"
#include "common_func.h"



void set_field_double_val(mxArray *pout, mxArray *ptmp, double val, int index)
{
	ptmp = mxCreateNumericMatrix(1, 1, mxDOUBLE_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &val, sizeof(double));
	mxSetFieldByNumber(pout, 0, index, ptmp);
	return;
}

void set_field_int_val(mxArray *pout, mxArray *ptmp, int val, int index)
{
	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &val, sizeof(int));
	mxSetFieldByNumber(pout, 0, index, ptmp);
	return;
}

mxArray *result2mxArray(VK_INF_RESULT *re,INF_CRP *crp)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "wbc","neun","lymn","monn","eosn","basn",
		"alyn","licn","neup","lymp","monp","eosp","basp","alyp","licp",
		"rbc","hgb","hct","mcv","mch","mchc","rdw_cv","rdw_sd","plt",
		"mpv","pdw","pct","plcc","plcr","wbc_hist","rbc_hist","plt_hist",
		"wbc_line","rbc_line","plt_line","baso_total_num","rbc_total_num",
		"plt_total_num","crp_reaction","crp_ori_val","crp_val","wbc_org_num",
		"rbc_org_num","plt_org_num","hgb_bk_volt","hgb_me_volt"};
	int field_num;
	int *line;

	field_num = 46;
	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = NULL;
	set_field_double_val(pout, ptmp, re->report_result.wbc, 0);
	set_field_double_val(pout, ptmp, re->report_result.neu_num, 1);
	set_field_double_val(pout, ptmp, re->report_result.lym_num, 2);
	set_field_double_val(pout, ptmp, re->report_result.mon_num, 3);
	set_field_double_val(pout, ptmp, re->report_result.eos_num, 4);
	set_field_double_val(pout, ptmp, re->report_result.bas_num, 5);
	set_field_double_val(pout, ptmp, re->report_result.aly_num, 6);
	set_field_double_val(pout, ptmp, re->report_result.lic_num, 7);
	set_field_double_val(pout, ptmp, re->report_result.neu_per, 8);
	set_field_double_val(pout, ptmp, re->report_result.lym_per, 9);
	set_field_double_val(pout, ptmp, re->report_result.mon_per, 10);
	set_field_double_val(pout, ptmp, re->report_result.eos_per, 11);
	set_field_double_val(pout, ptmp, re->report_result.bas_per, 12);
	set_field_double_val(pout, ptmp, re->report_result.aly_per, 13);
	set_field_double_val(pout, ptmp, re->report_result.lic_per, 14);

	set_field_double_val(pout, ptmp, re->report_result.rbc, 15);
	set_field_double_val(pout, ptmp, re->report_result.hgb, 16);
	set_field_double_val(pout, ptmp, re->report_result.hct, 17);
	set_field_double_val(pout, ptmp, re->report_result.mcv, 18);
	set_field_double_val(pout, ptmp, re->report_result.mch, 19);
	set_field_double_val(pout, ptmp, re->report_result.mchc, 20);
	set_field_double_val(pout, ptmp, re->report_result.rdw_cv, 21);
	set_field_double_val(pout, ptmp, re->report_result.rdw_sd, 22);
	set_field_double_val(pout, ptmp, re->report_result.plt, 23);
	set_field_double_val(pout, ptmp, re->report_result.mpv, 24);
	set_field_double_val(pout, ptmp, re->report_result.pdw, 25);
	set_field_double_val(pout, ptmp, re->report_result.pct, 26);
	set_field_double_val(pout, ptmp, re->report_result.plcc, 27);
	set_field_double_val(pout, ptmp, re->report_result.plcr, 28);
	

	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->wbc_hist.dsp_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 29, ptmp);

	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->rbc_hist.dsp_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 30, ptmp);

	ptmp = mxCreateNumericMatrix(128, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->plt_hist.dsp_hist.datas, sizeof(int) * 128);
	mxSetFieldByNumber(pout, 0, 31, ptmp);

	ptmp = mxCreateNumericMatrix(re->wbc_hist.dsp_hist.linelen, 1,
		mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->wbc_hist.dsp_hist.lines, sizeof(int) * 
		re->wbc_hist.dsp_hist.linelen);
	mxSetFieldByNumber(pout, 0, 32, ptmp);

	ptmp = mxCreateNumericMatrix(2, 1, mxINT32_CLASS, mxREAL);
	line = (int *)mxGetData(ptmp);
	line[0] = re->rbc_hist.dsp_hist.lines[0];
	line[1] = re->rbc_hist.dsp_hist.lines[1];
	mxSetFieldByNumber(pout, 0, 33, ptmp);

	ptmp = mxCreateNumericMatrix(2, 1, mxINT32_CLASS, mxREAL);
	line = (int *)mxGetData(ptmp);
	line[0] = re->plt_hist.dsp_hist.lines[0];
	line[1] = re->plt_hist.dsp_hist.lines[1];
	mxSetFieldByNumber(pout, 0, 34, ptmp);

	set_field_double_val(pout, ptmp, re->other_result.baso_wbc_filter_num, 35);
	set_field_double_val(pout, ptmp, re->other_result.rbc_filter_num, 36);
	set_field_double_val(pout, ptmp, re->other_result.plt_filter_num, 37);

	set_field_double_val(pout, ptmp, crp->reaction, 38);
	set_field_double_val(pout, ptmp, crp->crp_ori_val, 39);
	set_field_double_val(pout, ptmp, crp->crp_val, 40);

	set_field_double_val(pout, ptmp, re->other_result.baso_wbc_org_num, 41);
	set_field_double_val(pout, ptmp, re->other_result.rbc_org_num, 42);
	set_field_double_val(pout, ptmp, re->other_result.plt_org_num, 43);
	set_field_double_val(pout, ptmp, re->other_result.hgb_bk_volt, 44);
	set_field_double_val(pout, ptmp, re->other_result.hgb_me_volt, 45);

	return pout;
}


mxArray *opti_cell_info2mxArray(OPTI_CELL_INFO *cell_info, int cell_num)
{
	mxArray *pout, *ls_peak, *ms_peak, *hs_peak, *p_celltype, *p_width, *p_time;
	const char *field_name[] = { "ls_peak","ms_peak","hs_peak","celltype",
		"ls_width","time_stamp" };
	int field_num = 6;
	int i;
	short *lpeak, *mpeak, *hpeak, *ctype;
	byte *width, *time_stamp;

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);
	// wbc cell info
	ls_peak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	lpeak = (short *)mxGetData(ls_peak);
	ms_peak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mpeak = (short *)mxGetData(ms_peak);
	hs_peak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	hpeak = (short *)mxGetData(hs_peak);
	p_celltype = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	ctype = (short *)mxGetData(p_celltype);
	p_width = mxCreateNumericMatrix(cell_num, 1, mxUINT8_CLASS, mxREAL);
	width = (byte *)mxGetData(p_width);
	p_time = mxCreateNumericMatrix(cell_num, 1, mxUINT8_CLASS, mxREAL);
	time_stamp = (byte *)mxGetData(p_time);
	for (i = 0; i < cell_num; i++)
	{
		lpeak[i] = cell_info[i].ls_peak;
		mpeak[i] = cell_info[i].ms_peak;
		hpeak[i] = cell_info[i].hs_peak;
		width[i] = cell_info[i].ls_width;
		time_stamp[i] = cell_info[i].time_stamp;
		ctype[i] = cell_info[i].cell_type;
	}
	mxSetFieldByNumber(pout, 0, 0, ls_peak);
	mxSetFieldByNumber(pout, 0, 1, ms_peak);
	mxSetFieldByNumber(pout, 0, 2, hs_peak);
	mxSetFieldByNumber(pout, 0, 3, p_celltype);
	mxSetFieldByNumber(pout, 0, 4, p_width);
	mxSetFieldByNumber(pout, 0, 5, p_time);
	return pout;
}

mxArray *cell_info2mxArray(VK_INF_CELL_LIST *cell, stDifOutput *diff_output)
{
	mxArray *pout, *ppeak, *pfullwidth,*ptime,*pmflag,*ppriwidth,*psubwidth,*ptmp;
	const char *field_name[] = { "diff_info","baso_info","rbc_peak", 
		"rbc_fullwidth","rbc_time","rbc_mflag","plt_peak","plt_fullwidth",
		"plt_time", "plt_mflag","plt_priwidth","plt_subwidth","ls_ms_alg",
		"ls_hs_alg"};
	int field_num = 14;
	int cell_num,i;
	short *peak, *fullwidth,*time,*mflag,*priwidth,*subwidth;

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);
	// diff cell info
	mxSetFieldByNumber(pout, 0, 0, opti_cell_info2mxArray(cell->diff_cell_list,
		cell->diff_cell_num));
	// baso cell info
	mxSetFieldByNumber(pout, 0, 1, opti_cell_info2mxArray(cell->baso_cell_list,
		cell->baso_cell_num));
	// rbc cell info
	cell_num = cell->rbc_cell_num;
	ppeak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	peak = (short *)mxGetData(ppeak);
	pfullwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	fullwidth = (short *)mxGetData(pfullwidth);
	ptime = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	time = (short *)mxGetData(ptime);
	pmflag = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mflag = (short *)mxGetData(pmflag);
	for (i = 0; i < cell_num; i++)
	{
		peak[i] = cell->rbc_cell_info[i].peak_value;
		fullwidth[i] = cell->rbc_cell_info[i].full_width;
		time[i] = cell->rbc_cell_info[i].time_stamp;
		mflag[i] = cell->rbc_cell_info[i].mpulse_flag;
	}
	mxSetFieldByNumber(pout, 0, 2, ppeak);
	mxSetFieldByNumber(pout, 0, 3, pfullwidth);
	mxSetFieldByNumber(pout, 0, 4, ptime);
	mxSetFieldByNumber(pout, 0, 5, pmflag);
	// plt cell info
	cell_num = cell->plt_cell_num;
	ppeak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	peak = (short *)mxGetData(ppeak);
	pfullwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	fullwidth = (short *)mxGetData(pfullwidth);
	ptime = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	time = (short *)mxGetData(ptime);
	pmflag = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mflag = (short *)mxGetData(pmflag);
	ppriwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	priwidth = (short *)mxGetData(ppriwidth);
	psubwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	subwidth = (short *)mxGetData(psubwidth);
	for (i = 0; i < cell_num; i++)
	{
		peak[i] = cell->plt_cell_info[i].peak_value;
		fullwidth[i] = cell->plt_cell_info[i].full_width;
		time[i] = cell->plt_cell_info[i].time_stamp;
		mflag[i] = cell->plt_cell_info[i].mpulse_flag;
		priwidth[i] = cell->plt_cell_info[i].pri_width;
		subwidth[i] = cell->plt_cell_info[i].sub_width;
	}
	mxSetFieldByNumber(pout, 0, 6, ppeak);
	mxSetFieldByNumber(pout, 0, 7, pfullwidth);
	mxSetFieldByNumber(pout, 0, 8, ptime);
	mxSetFieldByNumber(pout, 0, 9, pmflag);
	mxSetFieldByNumber(pout, 0, 10, ppriwidth);
	mxSetFieldByNumber(pout, 0, 11, psubwidth);
	//
	ptmp = mxCreateNumericMatrix(64, 64, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), diff_output->DifGraphPara.ls_ms_alg, sizeof(int) * 64 * 64);
	mxSetFieldByNumber(pout, 0, 12, ptmp);
	ptmp = mxCreateNumericMatrix(64, 64, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), diff_output->DifGraphPara.ls_hs_alg, sizeof(int) * 64 * 64);
	mxSetFieldByNumber(pout, 0, 13, ptmp);
	return pout;
}

mxArray *monitor2mxArray(VK_INF_NEW_MONITOR *new_monitor, INF_CRP *crp,
	int exception_code)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "hgb_data","opti_vol_data","rhole_data",
		"opti_base_data","rbase_data","airp_data","crp_data","hydp_data",
		"wbc_block","rbc_block" };
	int field_num = 10;
	int data_num;
	
	pout = mxCreateStructMatrix(1, 1, field_num, field_name);
	ptmp = NULL;
	
	// hgb data
	data_num = new_monitor->hgb.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->hgb.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	// opti background vol data
	data_num = new_monitor->opti_background_vol.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->opti_background_vol.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	// rbc aperture data
	data_num = new_monitor->rbc_aperture_vol.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->rbc_aperture_vol.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	// opti base data
	data_num = new_monitor->opti_base.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->opti_base.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	// rbc aperture base data
	data_num = new_monitor->rbc_vol_base.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->rbc_vol_base.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	// air pressure data
	data_num = new_monitor->vacuum_pressure.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->vacuum_pressure.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	// crp data
	data_num = crp->data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), crp->data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	// hydaulic pressure data
	data_num = new_monitor->hydraulic_pressure.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->hydraulic_pressure.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 7, ptmp);

	// exception
	set_field_int_val(pout, ptmp, exception_code & 0x00000001, 8);
	set_field_int_val(pout, ptmp, exception_code & 0x00000002, 9);

	return pout;
}

mxArray *header2mxArray(INF_HEADER *header, INF_SYSTEM_VER *sys_ver, int error_code)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "error_code","inf_ver","system_ver","timeseq_ver",
		"main_ver","alg_ver","drivefpga_ver","mcu_ver"};
	int field_num = 8;
	//char *str_buff;
	

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &error_code, sizeof(int));
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &header->inf_ver, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	ptmp = mxCreateString(sys_ver->version_system);
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	ptmp = mxCreateString(sys_ver->version_timeseq);
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	ptmp = mxCreateString(sys_ver->version_main_fpga);
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	ptmp = mxCreateString(sys_ver->version_alg);
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	ptmp = mxCreateString(sys_ver->version_drive_fpga);
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	ptmp = mxCreateString(sys_ver->version_mcu);
	mxSetFieldByNumber(pout, 0, 7, ptmp);

	return pout;
}



mxArray *sample2mxArray_inf(VK_INF_SAMPLE *sample, VK_INF_CONFIG *config)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "analysis_mode","blood_mode","sample_type",
	"diff_gain","rbc_gain","hgb_gain","crp_gain","wbc_fcb","wbc_ucb","rbc_fcb",
	"rbc_ucb","plt_fcb","plt_ucb","hgb_fcb","hgb_ucb","mcv_fcb","mcv_ucb"};
	int field_num = 17;
	double d_tmp;
	

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->analysis_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->blood_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->sample_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->diff_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->rbc_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->hgb_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->crp_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	//
	d_tmp = config->cb_wbc.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 7);

	d_tmp = config->cb_wbc.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 8);
	//
	d_tmp = config->cb_rbc.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 9);

	d_tmp = config->cb_rbc.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 10);
	//
	d_tmp = config->cb_plt.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 11);

	d_tmp = config->cb_plt.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 12);
	//
	d_tmp = config->cb_hgb.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 13);

	d_tmp = config->cb_hgb.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 14);
	//
	d_tmp = config->cb_mcv.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 15);

	d_tmp = config->cb_mcv.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 16);

	return pout;
}

// �����ض�
bool Truncation_blood(VK_INF_RESULT *inf_re)
{
	if (inf_re == NULL)
	{
		return false;
	}

	// %�ض�
	int NeuPer = (int)(inf_re->report_result.neu_per * 10 + 0.5);
	int LymPer = (int)(inf_re->report_result.lym_per * 10 + 0.5);
	int MonPer = (int)(inf_re->report_result.mon_per * 10 + 0.5);
	int EosPer = (int)(inf_re->report_result.eos_per * 10 + 0.5);
	int BasPer = (int)(inf_re->report_result.bas_per * 10 + 0.5);

	if (1000 - LymPer - MonPer - EosPer - BasPer > 0)
	{
		NeuPer = 1000 - LymPer - MonPer - EosPer - BasPer;
	}
	else if (1000 - NeuPer - MonPer - EosPer - BasPer > 0)
	{
		LymPer = 1000 - NeuPer - MonPer - EosPer - BasPer;
	}
	else if (1000 - NeuPer - LymPer - EosPer - BasPer > 0)
	{
		MonPer = 1000 - NeuPer - LymPer - EosPer - BasPer;
	}
	else if (1000 - NeuPer - LymPer - MonPer - BasPer > 0)
	{
		EosPer = 1000 - NeuPer - LymPer - MonPer - BasPer;
	}
	else
	{
		BasPer = 1000 - NeuPer - LymPer - MonPer - EosPer;
	}

	inf_re->report_result.neu_per = (float)0.1*NeuPer;
	inf_re->report_result.lym_per = (float)0.1*LymPer;
	inf_re->report_result.mon_per = (float)0.1*MonPer;
	inf_re->report_result.eos_per = (float)0.1*EosPer;
	inf_re->report_result.bas_per = (float)0.1*BasPer;

	// #�ض�
	int Wbc = (int)(inf_re->report_result.wbc * 100 + 0.5);

	int NeuCount = (int)(1.0*NeuPer*Wbc / 1000 + 0.5);
	int LymCount = (int)(1.0*LymPer*Wbc / 1000 + 0.5);
	int MonCount = (int)(1.0*MonPer*Wbc / 1000 + 0.5);
	int EosCount = (int)(1.0*EosPer*Wbc / 1000 + 0.5);
	int BasCount = (int)(1.0*BasPer*Wbc / 1000 + 0.5);

	if (Wbc - LymCount - MonCount - EosCount - BasCount > 0)
	{
		NeuCount = Wbc - LymCount - MonCount - EosCount - BasCount;
	}
	else if (Wbc - NeuCount - MonCount - EosCount - BasCount > 0)
	{
		LymCount = Wbc - NeuCount - MonCount - EosCount - BasCount;
	}
	else if (Wbc - NeuCount - LymCount - EosCount - BasCount > 0)
	{
		MonCount = Wbc - NeuCount - LymCount - EosCount - BasCount;
	}
	else if (Wbc - NeuCount - LymCount - MonCount - BasCount > 0)
	{
		EosCount = Wbc - NeuCount - LymCount - MonCount - BasCount;
	}
	else
	{
		BasCount = Wbc - NeuCount - LymCount - MonCount - EosCount;
	}

	inf_re->report_result.wbc = (float)0.01*Wbc;
	inf_re->report_result.neu_num = (float)0.01*NeuCount;
	inf_re->report_result.lym_num = (float)0.01*LymCount;
	inf_re->report_result.mon_num = (float)0.01*MonCount;
	inf_re->report_result.eos_num = (float)0.01*EosCount;
	inf_re->report_result.bas_num = (float)0.01*BasCount;

	return true;
}

int vk_alg_main_offline(VK_INF_FILE *inf_in, stChannelAlgOutput *alg_output)
{
	int exception_code = 0;
	stDifInput diff_input;
	stWbcInput wbc_input;

	// input binding
	wbc_input.Dilution = 124.4;
	wbc_input.Volume = 8.5754*11.7;
	wbc_input.diff_cell_num = inf_in->cell_list.baso_cell_num;
	wbc_input.diff_cell_list = inf_in->cell_list.baso_cell_list;

	wbc_input.Dilution = 106.3;
	wbc_input.Volume = 8.5754*9.3;
	diff_input.diff_cell_num = inf_in->cell_list.diff_cell_num;
	diff_input.diff_cell_list = inf_in->cell_list.diff_cell_list;

	// api function call
	wbcmain(&wbc_input, &alg_output->WbcOutput);
	exception_code = difmain(&diff_input, &alg_output->DifOutPut);

	// output binding
	inf_in->result.report_result.wbc = (float)alg_output->WbcOutput.WbcReportPara.Wbc;
	inf_in->result.report_result.bas_per = (float)alg_output->WbcOutput.WbcReportPara.BasPer;
	inf_in->cell_list.baso_cell_num = alg_output->WbcOutput.WbcFeaturePara.OptiCellList.CellNum;
	for (int i = 0; i < inf_in->cell_list.baso_cell_num; i++)
	{
		inf_in->cell_list.baso_cell_list[i].ls_peak =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].Org_LSC;
		inf_in->cell_list.baso_cell_list[i].ms_peak =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].Org_MSC;
		inf_in->cell_list.baso_cell_list[i].hs_peak =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].Org_HSC;
		inf_in->cell_list.baso_cell_list[i].time_stamp =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].TimeStamp;
		inf_in->cell_list.baso_cell_list[i].cell_type =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].CellType;
		inf_in->cell_list.baso_cell_list[i].ls_width =
			alg_output->WbcOutput.WbcFeaturePara.OptiCellList.pOptiPulse[i].PulseWidth;
	}

	inf_in->result.report_result.neu_per = (float)alg_output->DifOutPut.DifReportPara.NeuPer;
	inf_in->result.report_result.lym_per = (float)alg_output->DifOutPut.DifReportPara.LymPer;
	inf_in->result.report_result.mon_per = (float)alg_output->DifOutPut.DifReportPara.MonPer;
	inf_in->result.report_result.eos_per = (float)alg_output->DifOutPut.DifReportPara.EosPer;
	inf_in->cell_list.diff_cell_num = alg_output->DifOutPut.DifFeaturePara.OptiCellList.CellNum;
	for (int i = 0; i < inf_in->cell_list.diff_cell_num; i++)
	{
		inf_in->cell_list.diff_cell_list[i].ls_peak =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].Org_LSC;
		inf_in->cell_list.diff_cell_list[i].ms_peak =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].Org_MSC;
		inf_in->cell_list.diff_cell_list[i].hs_peak =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].Org_HSC;
		inf_in->cell_list.diff_cell_list[i].time_stamp =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].TimeStamp;
		inf_in->cell_list.diff_cell_list[i].cell_type =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].CellType;
		inf_in->cell_list.diff_cell_list[i].ls_width =
			alg_output->DifOutPut.DifFeaturePara.OptiCellList.pOptiPulse[i].PulseWidth;
	}

	// �����ض�
	Truncation_blood(&inf_in->result);
	return exception_code;
	
}

mxArray *combine_result2mxArray(mxArray *old_re, mxArray *new_re)
{
	mxArray *pout;
	const char *field_name[] = { "old","new" };
	int field_num = 2;


	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	mxSetFieldByNumber(pout, 0, 0, old_re);
	mxSetFieldByNumber(pout, 0, 1, new_re);
	return pout;
}

// CRC check function
uint32 crc_check(byte *buff, int buff_len)
{
	unsigned int crc = 0;
	unsigned char i;
	unsigned char *ptr = buff;
	while (buff_len--) {
		for (i = 0x80; i != 0; i = i >> 1) {
			if ((crc & 0x8000) != 0) {
				crc = crc << 1;
				crc = crc ^ 0x1021;
			}
			else {
				crc = crc << 1;
			}
			if ((*ptr & i) != 0) {
				crc = crc ^ 0x1021;
			}
		}
		ptr++;
	}
	return crc;
}

int read_record_of_vk_inf(FILE *fp, VK_INF_FILE *inf)
{
	char record;
	byte *buff;
	uint32 crc;
	int record_len, record_num;
	int read_num;

	record = 0;
	read_num = (int)fread(&record, sizeof(char), 1, fp);
	if (!read_num)
		return 0;
	fread(&crc, sizeof(uint32), 1, fp);
	fread(&record_len, sizeof(int), 1, fp);
	buff = (byte *)calloc(record_len, sizeof(byte));
	fread(buff, sizeof(byte), record_len, fp);
	if (crc != crc_check(buff, record_len))
	{
		FREE_POINTER(buff);
		return 133;
	}

	switch (record)
	{
	case 1:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->header, sizeof(INF_HEADER), 1, fp);
		break;
	case 2:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->sample, sizeof(VK_INF_SAMPLE), 1, fp);
		break;
	case 3:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->system_ver, sizeof(INF_SYSTEM_VER), 1, fp);
		break;
	case 5:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->config, sizeof(VK_INF_CONFIG), 1, fp);
		break;
	case 11:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->result, sizeof(VK_INF_RESULT), 1, fp);
		break;
	case 20:
		if (record_len % sizeof(OPTI_CELL_INFO))
			return 134;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(OPTI_CELL_INFO);
		inf->cell_list.diff_cell_num = record_num;
		inf->cell_list.diff_cell_list = (OPTI_CELL_INFO *)calloc(record_num,
			sizeof(OPTI_CELL_INFO));
		fread(inf->cell_list.diff_cell_list, sizeof(OPTI_CELL_INFO), record_num, fp);
		break;

	case 21:
		if (record_len % sizeof(OPTI_CELL_INFO))
			return 134;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(OPTI_CELL_INFO);
		inf->cell_list.baso_cell_num = record_num;
		inf->cell_list.baso_cell_list = (OPTI_CELL_INFO *)calloc(record_num,
			sizeof(OPTI_CELL_INFO));
		fread(inf->cell_list.baso_cell_list, sizeof(OPTI_CELL_INFO), record_num, fp);
		break;
	case 22:
		if (record_len % sizeof(IMPE_CELL_INFO))
			return 135;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(IMPE_CELL_INFO);
		inf->cell_list.rbc_cell_num = record_num;
		inf->cell_list.rbc_cell_info = (IMPE_CELL_INFO *)calloc(record_num,
			sizeof(IMPE_CELL_INFO));
		fread(inf->cell_list.rbc_cell_info, sizeof(IMPE_CELL_INFO), record_num, fp);
		break;
	case 23:
		if (record_len % sizeof(IMPE_CELL_INFO))
			return 136;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(IMPE_CELL_INFO);
		inf->cell_list.plt_cell_num = record_num;
		inf->cell_list.plt_cell_info = (IMPE_CELL_INFO *)calloc(record_num,
			sizeof(IMPE_CELL_INFO));
		fread(inf->cell_list.plt_cell_info, sizeof(IMPE_CELL_INFO), record_num, fp);
		break;
	case 25:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->crp, sizeof(INF_CRP), 1, fp);
		break;

	case 27:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->new_monitor, sizeof(VK_INF_NEW_MONITOR), 1, fp);
		break;
	default:
		return 137;
		break;
	}
	return 0;
}

int read_vk_inf_file(const char *file_path, VK_INF_FILE *inf)
{
	FILE *fp;
	int error_code;
	if (!(fp = fopen(file_path, "rb")))
		return 132; //�ļ��򿪴���
	while (!feof(fp))
	{
		if (error_code = read_record_of_vk_inf(fp, inf))
		{
			fclose(fp);
			return error_code;
		}

	}
	fclose(fp);
	return 0;
}

void free_memory_for_vk_inf_file(VK_INF_FILE *inf)
{
	FREE_POINTER(inf->cell_list.diff_cell_list);
	FREE_POINTER(inf->cell_list.baso_cell_list);
	FREE_POINTER(inf->cell_list.rbc_cell_info);
	FREE_POINTER(inf->cell_list.plt_cell_info);
	return;
}

//**********************************************************************
// ��������: mexFunction     
// ����˵����matlab���Ե��ú���     
// �� �� ֵ: void	     
// ��    ��: 
//           [out] int nlhs			�����������
//           [out] mxArray * plhs[]	�������matlab��������
//           [in] int nrhs			�����������
//           [in] mxArray * prhs[]	�������matlab��������
//**********************************************************************
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
	char *inf_file_path;
	char *inf_id;
	VK_INF_FILE inf;
	VK_INF_RESULT re;
	int exception_code, error_code, crp_start_pos, crp_end_pos, crp_seglen;
	mxArray *old_re, *new_re;
		
	if (nlhs != 5) mexErrMsgTxt("5 outputs required");
	if (nrhs != 2) mexErrMsgTxt("2 inputs required");

	inf_file_path = mxArrayToString(prhs[0]);
	inf_id = mxArrayToString(mxGetField(prhs[1], 0, "sample_id"));
	crp_start_pos = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_start_pos"));
	crp_end_pos = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_end_pos"));
	crp_seglen = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_seglen"));
	memset(&inf, 0, sizeof(VK_INF_FILE));
	memset(&re, 0, sizeof(VK_INF_RESULT));
	error_code = read_vk_inf_file(inf_file_path, &inf);

	inf.header.inf_ver -= 127;
	inf.crp.start_pos = crp_start_pos;
	inf.crp.end_pos = crp_end_pos;
	inf.crp.candidate_len = crp_seglen;
	exception_code = 0;
	stChannelAlgOutput alg_output;
	switch (inf.header.inf_ver)
	{
	case 1:
		plhs[0] = header2mxArray(&inf.header, &inf.system_ver, error_code);

		plhs[1] = sample2mxArray_inf(&inf.sample,&inf.config);

		exception_code = vk_alg_main_offline(&inf,&alg_output);
		plhs[3] = cell_info2mxArray(&inf.cell_list,&alg_output.DifOutPut);

		old_re = result2mxArray(&inf.result, &inf.crp);
		new_re = result2mxArray(&re, &inf.crp);
		plhs[2] = combine_result2mxArray(old_re, new_re);

		plhs[4] = monitor2mxArray(&inf.new_monitor, &inf.crp, exception_code);
		break;
	default:
		break;
	}
	FREE_POINTER(inf.cell_list.baso_cell_list);
	FREE_POINTER(inf.cell_list.diff_cell_list);
	FREE_POINTER(inf.cell_list.rbc_cell_info);
	FREE_POINTER(inf.cell_list.plt_cell_info);
		
}