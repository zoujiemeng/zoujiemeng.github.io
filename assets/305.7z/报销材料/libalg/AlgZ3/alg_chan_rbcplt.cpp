#include "alg_chan_rbcplt.h"
#include "alg_chan_rbc.h"
#include "alg_chan_plt.h"
#include "alg_resource.h"

#include <string.h>
#include <stdlib.h>
#include <math.h>

/*******************************************************************
// �� �� ���� impdmain
// ��    �ܣ� �迹ͨ���㷨������
********************************************************************/
bool impdmain(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1 ��ʼ��
	flag = impdinit(ImpdOutput);
	if (!flag)
	{
		return false;
	}

	// 2 ��ȡ���ò���
	flag = impdconfigpara(&(ImpdInput->DivConfigPara),
		&(ImpdInput->RbcInput.RbcConfigPara),
		&(ImpdInput->PltInput.PltConfigPara));
	if (!flag)
	{
		return false;
	}

	// 3 �źŴ���
	flag = impdsigprocess(ImpdInput, ImpdOutput);
	if (!flag)
	{
		return false;
	}

	// 4 ֱ��ͼ�ֽ�ģ��
	flag = impdclassify(ImpdInput, ImpdOutput);
	if (!flag)
	{
		return false;
	}

	// 5 ��������
	flag = impdparacal(ImpdInput, ImpdOutput);

	return flag;
}

/*******************************************************************
// �� �� ���� impdinit
// ��    �ܣ� �迹ͨ����ʼ������
********************************************************************/
bool impdinit(stImpdOutput *ImpdOutput)
{
	if (ImpdOutput == NULL)
	{
		return false;
	}

	memset(ImpdOutput, 0, sizeof(stImpdOutput));

	return true;
}

/*******************************************************************
// �� �� ���� getimpdconfigpara
// ��    �ܣ� ��ȡ�迹ͨ�����ò���
********************************************************************/
bool impdconfigpara(stDivConfigPara *DivConfigPara, 
	stRbcConfigPara *RbcConfigPara, 
	stPltConfigPara *PltConfigPara)
{
	if (   DivConfigPara == NULL
		|| RbcConfigPara == NULL
		|| PltConfigPara == NULL)
	{
		return false;
	}

	// RBC��PLT�ֽ����
	DivConfigPara->Alg_I_Divide_DefaultDivideLine   = 48;              // Ĭ��RBC/PLT�ֽ���
	DivConfigPara->Alg_I_Divide_MinLine             = 32;              // �ֽ��������
	DivConfigPara->Alg_I_Divide_MaxLine             = 56;              // �ֽ��������
	DivConfigPara->Alg_I_Divide_GaussSmoothStep     = 6;               // ��˹ƽ������С
	DivConfigPara->Alg_I_Divide_GaussSmoothDelta    = 3;               // ��˹ƽ����׼��
	DivConfigPara->Alg_I_Divide_FirstPeakEndPos     = 48;              // ��һ����Ľ�ֹλ��
	DivConfigPara->Alg_I_Divide_FirstVolEndPos      = 64;              // ��һ���ȵĽ�ֹλ��
	DivConfigPara->Alg_I_Divide_NegParticleLinePer  = 0.3;             // ��Ч������Ⱥ�ٷֱ�
	DivConfigPara->Alg_I_Divide_DivideK             = 5;               // ͳ�Ʒ������ֽ��߽���
	DivConfigPara->Alg_I_Divide_FitCurveMeanMinth   = 6;               // �������Mean��Сֵ
	DivConfigPara->Alg_I_Divide_FitCurveMeanMaxth   = 7;               // �������Mean���ֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaMinth  = 8.0;             // �������Delta��Сֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaMaxth  = 15.0;            // �������Delta���ֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaStep   = 0.1 ;            // �������Delta����
	DivConfigPara->Alg_I_Divide_FitCurveFitErrorPer = 0.25;            // �������������ٷֱ�

	// RBCͨ�����ò���
	RbcConfigPara->Alg_R_Dsf_RbcPeakMinTh           = 256;             // Dsf����Rbc��ֵ��С�߶�
	RbcConfigPara->Alg_R_Dsf_PulseNumMinTh          = 1000;            // Dsf����Rbc�����������
	RbcConfigPara->Alg_R_Sig_DsfHistSmoothStep      = 6;               // RbcDsfֱ��ͼ��˹ƽ������
	RbcConfigPara->Alg_R_Sig_DsfHistSmoothDelta     = 3;               // RbcDsfֱ��ͼ��˹ƽ����׼��
	RbcConfigPara->Alg_R_Cal_SubBackGround          =  10;             // RBC������������
	RbcConfigPara->Alg_R_Cal_dRbcExpCoff            = 1.6;             // RBC���Ӳ���ϵ��
	RbcConfigPara->Alg_R_Cal_dMcvAdjustCoff         = 1.0;             // MCV����ϵ��
	RbcConfigPara->Alg_R_Cal_RdwBaseLinePer         = 0.20;            // Rdw���߸߶�
	RbcConfigPara->Alg_R_Cal_dRdwSdAdjustCoff       = 3.65;            // RdwSd����ϵ��
	RbcConfigPara->Alg_R_Cal_dRdwCvAdjustCoff       = 110.1;           // RdwCv����ϵ��
	RbcConfigPara->Alg_R_Cal_SkewnessBaseLinePer    = 0.20;            // ƫ�Ȼ��߰ٷֱ�
	RbcConfigPara->Alg_R_Cal_KurtosisBaseLinePer    = 0.20;            // �ͶȻ��߰ٷֱ�

	// PLTͨ�����ò���
	PltConfigPara->Alg_P_Cal_SubBackGround          =  75;             // PLT������������
	PltConfigPara->Alg_P_Cal_dPltExpCoff            = 1.6;             // PLT���Ӳ���ϵ��
	PltConfigPara->Alg_P_Cal_dMpvAdjustCoff         = 0.76;            // MPV����ϵ��
	PltConfigPara->Alg_P_Cal_dPdwBaseLinePer        = 0.20;            // Pdw���߸߶�
	PltConfigPara->Alg_P_Cal_dPdwAdjustCoff         = 9.85;            // Pdw����ϵ��
	PltConfigPara->Alg_P_Cal_LargePltTh             = 26;              // ��PLT��ֵ

	return true;
}

/*******************************************************************
// �� �� ���� impdsigprocess
// ��    �ܣ� �迹ͨ���źŴ���
********************************************************************/
bool impdsigprocess(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput  == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1��DATA����ת��---------------------------------------
	// 1.1 RBC����ת��
	stImpdCellList RbcCellList;
	memset(&RbcCellList,  0, sizeof(stImpdCellList));

	dataconvite_impd(&RbcCellList, ImpdInput->RbcInput.DataAddr, ImpdInput->RbcInput.DataLen);

	ImpdOutput->RbcOutput.FeaturePara.ImpdCellList = RbcCellList;
	
	// 1.2 PLT����ת��
	stImpdCellList PltCellList;
	memset(&PltCellList,  0, sizeof(stImpdCellList));

	dataconvite_impd(&PltCellList, ImpdInput->PltInput.DataAddr, ImpdInput->PltInput.DataLen);

	ImpdOutput->PltOutput.FeaturePara.ImpdCellList = PltCellList;

	// 1.3 �������ת��
	stVoltList VoltList;
	VoltList.VoltNum = ImpdInput->RbcInput.HoleVLen;
	VoltList.VoltVal = new unsigned short[VoltList.VoltNum];

	unsigned char *tempaddr = ImpdInput->RbcInput.HoleVAddr;

	for (int i=0; i<VoltList.VoltNum; i++)
	{
		VoltList.VoltVal[i] = *((unsigned short *)tempaddr);

		tempaddr += 2;
	}

	ImpdOutput->RbcOutput.FeaturePara.HoleVList = VoltList;

	// 2��ϵͳ�쳣�ж�
	impdsystemerrorjudge(ImpdInput, ImpdOutput);

	// 3��RBCͨ���źŴ���
	flag = RbcHistProcess(&(ImpdInput->RbcInput), &(ImpdOutput->RbcOutput));
	if (!flag)
	{
		return false;
	}

	// 4��PLTͨ���źŴ���
	flag = PltHistProcess(&(ImpdInput->PltInput), &(ImpdOutput->PltOutput));

	return flag;
}

// ϵͳ�쳣�ж�
bool impdsystemerrorjudge(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	// С�׵�ѹ�쳣�ж�
	impdsystemerrorjudge_HoleAbn(ImpdInput, ImpdOutput);

	// �¿��쳣�ж�
	impdsystemerrorjudge_Block(ImpdInput, ImpdOutput);

	return true;
}

// ϵͳ�쳣�ж�(С�׵�ѹ)
bool impdsystemerrorjudge_HoleAbn(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	// ��������
	stVoltList VoltList = ImpdOutput->RbcOutput.FeaturePara.HoleVList;

	// �м����
	double *datavol = NULL;
	int     datalen = 0;

	datalen = VoltList.VoltNum;

	if (datalen > 0)
	{
		datavol = new double[datalen];
	}

	for (int i=0; i<datalen; i++)
	{
		datavol[i] = VoltList.VoltVal[i];
	}

	// ��ֵ�˲�
	curvesmooth_median<double>(datavol, datavol, VoltList.VoltNum, 5);

	// �����Сֵ
	double maxval = 0;
	double minval = 4096;

	int test1p = 1610;
	int test2p = 2605;

	if (datalen > test2p)
	{
		for (int i=test1p; i<test2p; i++)
		{
			if (maxval < datavol[i])
			{
				maxval = datavol[i];
			}

			if (minval > datavol[i])
			{
				minval = datavol[i];
			}
		}
	}

	ImpdOutput->RbcOutput.FeaturePara.MaxHoleVol = maxval;
	ImpdOutput->RbcOutput.FeaturePara.MinHoleVol = minval;

	POINTER_FREE(datavol);

	return true;
}

// ϵͳ�쳣�ж�(�¿�)
bool impdsystemerrorjudge_Block(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	// ��ȡNPS
	int *Npsdata = NULL;
	int  Npslen  = 0;

	getstamplist_impd(Npsdata, Npslen, ImpdOutput->RbcOutput.FeaturePara.ImpdCellList);

	ImpdOutput->RbcOutput.FeaturePara.Npsdata = Npsdata;
	ImpdOutput->RbcOutput.FeaturePara.Npslen  = Npslen;

	// ƽ������
	int  templen   = Npslen > 1 ? Npslen - 1 : 1;
	int *ptempdata = new int[templen];
	memset(ptempdata, 0, sizeof(int)*templen);

	curvesmooth_mean<int, int>(ptempdata,   Npsdata, templen, 8);
	curvesmooth_mean<int, int>(ptempdata, ptempdata, templen, 8);
	curvesmooth_mean<int, int>(ptempdata, ptempdata, templen, 8);

	// ����ͳ��ֵ
	double  Av_Nps = getmean<int>(ptempdata, templen);
	double  Sd_Nps = getstde<int>(ptempdata, templen);
	double  Cv_Nps = getcova<int>(ptempdata, templen);

	ImpdOutput->RbcOutput.FeaturePara.Av_Nps  = Av_Nps;
	ImpdOutput->RbcOutput.FeaturePara.Sd_Nps  = Sd_Nps;
	ImpdOutput->RbcOutput.FeaturePara.Cv_Nps  = Cv_Nps;

	// һ�ײ��ֱ��ͼ
	int *pDecHist = new int[templen];
	memset(pDecHist, 0, sizeof(int)*templen);

	for (int i=0; i<templen; i++)
	{
		pDecHist[i] = ptempdata[i+1] - ptempdata[i];
	}

	// 2.2.2���������ֵ����������������ֵ��λ��
	int TepArea = 0;
	int TepPos  = 0;
	int TepPeak = 0;

	int PosArea = 0;
	int PosPos  = 0;
	int PosPeak = 0;

	for(int i=0; i<templen; i++)
	{
		if (pDecHist[i] > 0 && i < templen - 1)
		{
			TepArea += abs(pDecHist[i]);

			if (TepPeak < abs(pDecHist[i]))
			{
				TepPeak = abs(pDecHist[i]);
				TepPos = i;
			}
		}
		else
		{
			if (PosArea < TepArea)
			{
				PosArea  = TepArea;
				PosPos   = TepPos;
				PosPeak  = TepPeak;
			}

			TepArea  = 0;
			TepPos   = 0;
			TepPeak  = 0;
		}
	}

	// 2.2.3�������ֵ��������������ֵ��λ��
	TepArea = 0;
	TepPos  = 0;
	TepPeak = 0;

	int NegArea  = 0;
	int NegPos   = 0;
	int NegPeak  = 0;

	for(int i=0; i<templen; i++)
	{
		if (pDecHist[i] < 0 && i < templen - 1)
		{
			TepArea += abs(pDecHist[i]);

			if (TepPeak < abs(pDecHist[i]))
			{
				TepPeak = abs(pDecHist[i]);
				TepPos  = i;
			}
		}
		else
		{
			if (NegArea < TepArea)
			{
				NegArea  = TepArea;
				NegPos   = TepPos;
				NegPeak  = TepPeak;
			}

			TepArea  = 0;
			TepPos   = i;
			TepPeak  = 0;
		}
	}

	ImpdOutput->RbcOutput.FeaturePara.PosPeak    = PosPeak;
	ImpdOutput->RbcOutput.FeaturePara.PosArea    = PosArea;
	ImpdOutput->RbcOutput.FeaturePara.NegPeak    = NegPeak;
	ImpdOutput->RbcOutput.FeaturePara.NegArea    = NegArea;

	POINTER_FREE(ptempdata);
	POINTER_FREE(pDecHist);

	return true;
}

/*******************************************************************
// �� �� ���� impdclassify
// ��    �ܣ� �迹ͨ�����ദ��
// �� �� ֵ�� ��
********************************************************************/
bool impdclassify(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1��ͳ�Ʒ������ֽ���
	flag = RbcPltDivide_Statistics(ImpdInput, ImpdOutput);
	if (!flag)
	{
		return false;
	}

	//// 2��ֱ��ͼ��Ϸֽ��ߵ���
	//flag = RbcPltDivide_CurveFit(ImpdInput, ImpdOutput);

	return flag;
}

// ͳ�Ʒ������ֽ���
bool RbcPltDivide_Statistics(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	// �㷨���ò���
	int    Alg_I_Divide_DefaultDivideLine  = ImpdInput->DivConfigPara.Alg_I_Divide_DefaultDivideLine;     // Ĭ��RBC/PLT�ֽ���
	int    Alg_I_Divide_MinLine            = ImpdInput->DivConfigPara.Alg_I_Divide_MinLine;               // �ֽ��������
	int    Alg_I_Divide_MaxLine            = ImpdInput->DivConfigPara.Alg_I_Divide_MaxLine;               // �ֽ��������

	int    Alg_I_Divide_GaussSmoothStep    = ImpdInput->DivConfigPara.Alg_I_Divide_GaussSmoothStep;       // ��˹ƽ������С
	int    Alg_I_Divide_GaussSmoothDelta   = ImpdInput->DivConfigPara.Alg_I_Divide_GaussSmoothDelta;      // ��˹ƽ����׼�� 
	int    Alg_I_Divide_FirstPeakEndPos    = ImpdInput->DivConfigPara.Alg_I_Divide_FirstPeakEndPos;       // ��һ����Ľ�ֹλ��
	int    Alg_I_Divide_FirstVolEndPos     = ImpdInput->DivConfigPara.Alg_I_Divide_FirstVolEndPos;        // ��һ���ȵĽ�ֹλ��
	double Alg_I_Divide_NegParticleLinePer = ImpdInput->DivConfigPara.Alg_I_Divide_NegParticleLinePer;    // ��Ч������Ⱥ�ٷֱ�
	int    Alg_I_Divide_DivideK            = ImpdInput->DivConfigPara.Alg_I_Divide_DivideK;               // ͳ�Ʒ������ֽ��߽���

	int DivideLine = Alg_I_Divide_DefaultDivideLine;

	int i = 0;

	// 1 ͳ�Ʒ������ֽ���
	int *RbcPltHist = NULL;
	RbcPltHist = new int[Plt_Hist_DataLen];

	if ( RbcPltHist == NULL)
	{
		ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
		ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;
		return false;
	}

	memcpy(RbcPltHist, ImpdOutput->PltOutput.GraphPara.OrgHist.datas, sizeof(int)*Plt_Hist_DataLen);

	curvesmooth_gauss<int, int>(RbcPltHist, RbcPltHist, Plt_Hist_DataLen,
		Alg_I_Divide_GaussSmoothStep, Alg_I_Divide_GaussSmoothDelta);

	curvesmooth_gauss<int, int>(RbcPltHist, RbcPltHist, Plt_Hist_DataLen,
		Alg_I_Divide_GaussSmoothStep, Alg_I_Divide_GaussSmoothDelta);


	// 1.1 ��ǰ48ͨ�����ֵ
	int MaxAValue  = 0;
	int MaxAPos    = 0;

	for (i=0; i<Alg_I_Divide_FirstPeakEndPos; i++)
	{
		if (MaxAValue < RbcPltHist[i])
		{
			MaxAValue = RbcPltHist[i];
			MaxAPos   = i;
		}
	}

	// 1.2 �����ֵ��96ͨ����Сֵ
	int MinBValue  = MaxAValue;
	int MinBPos    = MaxAPos;

	for (i=MinBPos; i<Alg_I_Divide_FirstVolEndPos; i++)
	{
		if (MinBValue > RbcPltHist[i])
		{
			MinBValue = RbcPltHist[i];
			MinBPos   = i;
		}
	}

	// δ�ҵ���Сֵ���˳�
	if (MaxAValue <= MinBValue )
	{	
		POINTER_FREE(RbcPltHist);
		ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
		ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;
		return true;
	}

	// 1.3 ����Сֵ������ֵ
	int MaxCValue  = 0;
	int MaxCPos    = 0;

	for (i=MinBPos; i<Plt_Hist_DataLen; i++ )
	{
		if (MaxCValue < RbcPltHist[i])
		{
			MaxCValue = RbcPltHist[i];
			MaxCPos   = i;
		}
	}

	// δ�ҵ���С֮������ֵ���˳�
	if ( MaxCPos == 0)
	{	
		POINTER_FREE(RbcPltHist);
		ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
		ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;
		return true;
	}

	// 1.4 �����Ч������Ⱥ
	double NegParticleLine = 0;

	if (MaxAValue < MaxCValue)
	{
		NegParticleLine = Alg_I_Divide_NegParticleLinePer*(MaxAValue - MinBValue) + MinBValue;
	}
	else
	{
		NegParticleLine = Alg_I_Divide_NegParticleLinePer*(MaxCValue - MinBValue) + MinBValue;
	}	

	double NegParticleSwarm[Plt_Hist_DataLen];
	memset(NegParticleSwarm, 0, sizeof(double)*Plt_Hist_DataLen);

	for (i=MaxAPos; i<MaxCPos; i++)
	{
		NegParticleSwarm[i] = NegParticleLine - RbcPltHist[i];

		if (NegParticleSwarm[i] < 0)
		{
			NegParticleSwarm[i] = 0;
		}
	}

	double SumDen  = 0;
	double SumNum  = 0;

	for (i=0; i<Plt_Hist_DataLen; i++)
	{
		SumDen +=   pow(1.0*NegParticleSwarm[i],Alg_I_Divide_DivideK);
		SumNum += i*pow(1.0*NegParticleSwarm[i],Alg_I_Divide_DivideK);
	}

	if (SumDen > EPSINON)
	{
		DivideLine = (int)(SumNum/SumDen);
	}

	if (DivideLine > Alg_I_Divide_MaxLine)
	{
		DivideLine = Alg_I_Divide_MaxLine;
	}

	if (DivideLine < Alg_I_Divide_MinLine)
	{
		DivideLine = Alg_I_Divide_MinLine;
	}

	POINTER_FREE(RbcPltHist);

	ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
	ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;

	return true;
}

// ֱ��ͼ���΢���ֽ���
bool RbcPltDivide_CurveFit(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	// �㷨���ò���
	int    Alg_I_RbcPltDivide_MinLine = ImpdInput->DivConfigPara.Alg_I_Divide_MinLine;               // �ֽ��������
	int    Alg_I_RbcPltDivide_MaxLine = ImpdInput->DivConfigPara.Alg_I_Divide_MaxLine;               // �ֽ��������
	int    FitCurveMeanMinth          = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveMeanMinth;     // �������Mean��Сֵ
	int    FitCurveMeanMaxth          = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveMeanMaxth;     // �������Mean���ֵ
	double FitCurveDeltaMinth         = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaMinth;    // �������Delta��Сֵ
	double FitCurveDeltaMaxth         = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaMaxth;    // �������Delta���ֵ
	double FitCurveDeltaStep          = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaStep;     // �������Delta����
	double FitCurveFitErrorPer        = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveFitErrorPer;   // �������������ٷֱ�

	int DivideLine = ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine;

	int i = 0;

	// 1 ��ȡֱ��ͼ��Ϣ
	int *RbcHist = NULL;
	int *FitHist = NULL;
	RbcHist      = new int[Rbc_Hist_DataLen];
	FitHist      = new int[Rbc_Hist_DataLen];

	if (  RbcHist == NULL
		||FitHist == NULL)
	{
		POINTER_FREE(RbcHist);
		POINTER_FREE(FitHist);

		ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
		ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;

		return false;
	}

	memcpy(RbcHist, ImpdOutput->RbcOutput.GraphPara.DspHist.datas, sizeof(int)*Rbc_Hist_DataLen);
	memset(FitHist, 0, sizeof(int)*Rbc_Hist_DataLen);

	// 2 ��ȡֱ��ͼ��ϲ���
	int    MaxValue  = 0;
	int    MaxPos    = 0;
	int    Mean      = 0;
	double Delta     = 0.0;

	// 2.1 ��RBCֱ��ͼ���ֵ����λ��
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		if (MaxValue < RbcHist[i])
		{
			MaxValue = RbcHist[i];
			MaxPos   = i;
		}
	}

	if (MaxValue <= 0)
	{
		POINTER_FREE(RbcHist);
		POINTER_FREE(FitHist);

		ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
		ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;

		return true;
	}

	// 2.2 ��С������
	int MinFitError = 10000000;
	int FitError    = 0;

	int     TempMean  = 0;
	double  TempDelta = 0.0;

	int LeftMean  = MaxPos - FitCurveMeanMinth;
	int RightMean = MaxPos + FitCurveMeanMaxth;

	LeftMean  = LeftMean > 0                ? LeftMean : 0;
	LeftMean  = LeftMean < Rbc_Hist_DataLen ? LeftMean : Rbc_Hist_DataLen-1;

	RightMean = RightMean > 0                ? RightMean : 0;
	RightMean = RightMean < Rbc_Hist_DataLen ? RightMean : Rbc_Hist_DataLen-1;

	for (TempMean=LeftMean; TempMean<RightMean; TempMean++)
	{
		for (TempDelta=FitCurveDeltaMinth; TempDelta<FitCurveDeltaMaxth; TempDelta+=FitCurveDeltaStep)
		{
			// ���ֱ��ͼ����
			for (i=0; i<Rbc_Hist_DataLen; i++)
			{
				FitHist[i] = (int)(MaxValue*exp(-1.0*(i-TempMean)*(i-TempMean)/(2*TempDelta*TempDelta)) + 0.5);
			}

			FitError = 0;

			for (i=MaxPos; i<Rbc_Hist_DataLen; i++)
			{
				if (RbcHist[i] < FitCurveFitErrorPer*MaxValue )
				{
					break;
				}

				FitError += (RbcHist[i] - FitHist[i])*(RbcHist[i] - FitHist[i]);
			}

			if (MinFitError > FitError)
			{
				MinFitError = FitError;

				Mean  = TempMean;
				Delta = TempDelta;
			}
		}
	}

	// 2.3 ���ֱ��ͼ����
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		FitHist[i] = (int)(MaxValue*exp(-1.0*(i - Mean)*(i - Mean)/(2*Delta*Delta)) + 0.5);
	}

	// 3 �ֽ���΢��
	int DivideLine_PLT =  DivideLine;
	int DivideLine_Rbc =  DivideLine/2; 

	int TempCellNum1 = 0;
	int TempCellNum2 = 0;	

	for(i=0; i<DivideLine_Rbc; i++)
	{
		TempCellNum1 += FitHist[i];
	}

	for (i=DivideLine_PLT; i>0; i--)
	{
		TempCellNum2 += ImpdOutput->PltOutput.GraphPara.OrgHist.datas[i];

		if (TempCellNum2 > TempCellNum1)
		{
			DivideLine_PLT = i;

			break;
		}
	}

	// �ֽ���λ���޶�
	DivideLine = DivideLine_PLT;

	if (DivideLine < Alg_I_RbcPltDivide_MinLine)
	{
		DivideLine = Alg_I_RbcPltDivide_MinLine;
	}
	else if (DivideLine > Alg_I_RbcPltDivide_MaxLine)
	{
		DivideLine = Alg_I_RbcPltDivide_MaxLine;
	}

	POINTER_FREE(RbcHist);
	POINTER_FREE(FitHist);

	ImpdOutput->RbcOutput.ServicePara.RbcPltDivideLine = DivideLine/2;
	ImpdOutput->PltOutput.ServicePara.RbcPltDivideLine = DivideLine;

	return true;
}

/*******************************************************************
// �� �� ���� impdparacal
// ��    �ܣ� �迹ͨ����������
********************************************************************/
bool impdparacal(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	if (ImpdInput  == NULL || ImpdOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1��RBC��������
	flag = RbcParaCal(&(ImpdInput->RbcInput), &(ImpdOutput->RbcOutput));
	if (!flag)
	{
		return false;
	}

	// 2��PLT��������
	ImpdInput->PltInput.RbcTotalNum = ImpdOutput->RbcOutput.ServicePara.RbcTotalNum;

	flag = PltParaCal(&(ImpdInput->PltInput), &(ImpdOutput->PltOutput));

	return flag;
}
