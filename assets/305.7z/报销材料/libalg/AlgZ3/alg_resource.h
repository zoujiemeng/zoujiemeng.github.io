#ifndef ALGRESOURCE_H
#define ALGRESOURCE_H

#include "alg_type_basic.h"
#include "alg_type_config.h"

#include <math.h>
#include <iostream>
#include <string.h>
#include <vector>

using namespace std;

/*******************************************************************
// ��������
********************************************************************/
// ����ֵ����
#define  EPSINON    0.000001
#define  INVALID    -10000
#define  PI         3.1415926

#define  POINTER_FREE(p)    if (p != NULL)   \
							{                \
							delete[] p;  \
							p = NULL;    \
							}

// ���ֵ����Сֵ
#define max(a,b)  (((a) > (b)) ? (a) : (b))
#define min(a,b)  (((a) < (b)) ? (a) : (b))

// ��С������ת��(16λ)
#define Swap16(X)   ( (((unsigned short)(X)&0xff00)>>8) | (((unsigned short)(X)&0x00ff)<<8) )

// ��С������ת��(32λ)
#define Swap32(X)   ( (((unsigned int)(X)&0xff000000)>>24) | (((unsigned int)(X)&0x00ff0000)>>8)  \
	|(((unsigned int)(X)&0x0000ff00)<<8) | (((unsigned int)(X)&0x000000ff)<<24) )

// ��ֵ�޶�
template<class T>
void limit(T *x, T low, T up)
{
	*x = max(*x, low);
	*x = min(*x, up );
}

// ����
template<class T>
void sort(T *dst, T *src, int datalen)
{
	// ��ʼ��
	memcpy(dst, src, sizeof(T)*datalen);

	// ð������
	for (int i=0; i<datalen; i++)
	{  
		bool flag = true;

		for (int j=0; j<datalen-1; j++)
		{
			T temp = 0;
			if (dst[j] > dst[j+1])
			{
				temp     = dst[j];
				dst[j]   = dst[j+1];
				dst[j+1] = temp;

				flag      = false;
			}
		}

		if (flag)
		{
			break;
		}
	}
}

// �����ֵ
template<class T>
double getmean(T *data, int datalen)
{
	if (data == 0 || datalen <= 0)
	{
		return 0.0;
	}

	double mean = 0.0;

	for (int i=0; i<datalen; i++)
	{
		mean += data[i];
	}

	return (mean/datalen);
}

// ������ֵ
template<class T>
T getmedian(T *data, int datalen)
{
	if (data == 0 || datalen <= 0)
	{
		return 0;
	}

	sort<T>(data, data, datalen);

	return data[datalen/2];
}

// �������ƫ��
template<class T>
double getstde(T *data, int datalen)
{
	if (data == 0 || datalen <= 0)
	{
		return 0.0;
	}

	double mean = getmean<T>(data, datalen);

	double temp = 0.0;
	for (int i=0; i<datalen; i++)
	{
		temp += (data[i]-mean)*(data[i]-mean);
	}

	double stde = 0.0;

	if (datalen > 1)
	{
		stde = sqrt(temp/(datalen-1));
	}

	return stde;
}

// �������ƫ��
template<class T>
double getcova(T *data, int datalen)
{
	if (data == 0 || datalen <= 0)
	{
		return 0.0;
	}

	double mean = getmean<T>(data, datalen);
	double stde = getstde<T>(data, datalen);

	double cova = 0.0;

	if (mean > EPSINON)
	{
		cova = stde/mean;
	}

	return cova;
}

// ��ȡ��˹��
void getgaussfactor(double *factor, int step, double delta);

/*******************************************************************
// ֱ��ͼ
********************************************************************/
// ֱ��ͼ����
bool gethist(stHist *pHist, stImpdCellList CellList);

// ��ֵƽ��
template<class T1, class T2>
void curvesmooth_mean(T1 *dst, T2 *src, int datalen, int step)
{
	 if (dst == 0 || src == 0)
	 {
		 return;
	 }

	// ��ʼ��
	memcpy(dst, src, sizeof(T1)*datalen);
	 
	int imin = 0;
	int imax = datalen - 1;
	 
	for (int i=imin; i<=imax; i++)
	{
	 	double sum = 0;
	 
		int half = (step - 1) / 2;
		for (int j=0; j<step; j++)
		{
			int k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			sum += *(src + k);
		}

		*(dst + i) = (T1)(1.0*sum/step);
	}
 }

// ��ֵƽ��
template<class T>
void curvesmooth_median(T *dst, T *src, int datalen, int step)
{
	if (dst == 0 || src == 0)
	{
		return;
	}

	// ��ʼ��
	memcpy(dst, src, sizeof(T)*datalen);
	
	// �����ڴ�
	T *temp = new T[step];
	if (0 == temp)
	{
		return;
	}
	
	int imin = 0;
	int imax = datalen - 1;

	for (int i=imin; i<=imax; i++)
	{
		int half = (step - 1) / 2;
		for (int j = 0; j < step; j++)
		{
			int k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			*(temp + j) = *(src + k);
		}

		*(dst + i) = getmedian<T>(temp, step);
	}

	// �ͷ���ʱ������
	if (temp)
	{
		delete [] temp;
	}
}

// �������-������̬
template<class T>
void curvefit_lognorm(T *dst, T *src, int datalen, int left, int right)
{
	if (dst == 0 || src == 0)
	{
		return;
	}

	// ��ʼ��
	memcpy(dst, src, sizeof(T)*datalen);

	// ��ʱֱ��ͼ
	double *temp = new double[datalen];
	memset(temp, 0, sizeof(double)*datalen);	
	
	// ��ֵ�������
	double E = 0;
	double V = 0;
	double S = 0;
	for (int i=left; i<right; i++)
	{
		S += src[i];
		E += src[i]*i;
	}

	if (S <= EPSINON || E <= EPSINON)
	{
		return;
	}

	E = E/S;

	for (int i=left; i<right; i++)
	{
		V += src[i]*(i-E)*(i-E);
	}

	V = V/S;

	// ��ϲ�������
	double t = V/(E*E) + 1;

	double u = log(E/pow(t, 0.5));
	double q = pow(log(t), 0.5);

	// ���ֱ��ͼ
	t = 0;
	for (int i=0; i<datalen; i++)
	{
		i = i > 1 ? i : 1;

		temp[i] = 1.0/i*exp( -(log(1.0*i)-u)*(log(1.0*i)-u)/(2*q*q) );

		t += temp[i];
	}

	if ( t < EPSINON)
	{
		return;
	}

	// ��һ������
	double m =  S / t;
	for (int i=0; i<datalen; i++)
	{
		dst[i] = (T)(temp[i]*m); 
	}

	if (temp != NULL)
	{
		delete [] temp;
	}
}

// ��˹ƽ��
template<class T1, class T2>
void curvesmooth_gauss(T1* dst, T2* src, int datalen, int step, double delta)
{
	if (dst == 0 || src == 0)
	{
		return;
	}

	// ��ʼ��
	for (int i=0; i<datalen; i++)
	{
		*(dst+i) = (T1)(*(src+i));
	}

	// ��ȡgauss��
	double* factors = new double[step];
	if (factors == 0)
	{
		return;
	}

	getgaussfactor(factors, step, delta);

	// ����ÿ����
	int imin = 0;
	int imax = datalen - 1;

	for (int i=imin; i<=imax; i++)
	{
		double sum = 0;

		int half = (step - 1) / 2;
		for (int j = 0; j < step; j++)
		{
			int k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			sum += ( *(src+k) * *(factors+j) );
		}

		*(dst + i) = (T1)(sum);
	}

	// �ͷ���ʱ������
	if (factors)
	{
		delete [] factors;
	}
}

/*******************************************************************
// ɢ��ͼ
********************************************************************/
// ��˹ƽ��
template<class T1, class T2>
void sctsmooth_gauss(T1* dst, T2* src, int hei, int wid, int step, double delta)
{
	if (dst == 0 || src == 0)
	{
		return;
	}

	int i = 0;
	int j = 0;
	int m = 0;
	int n = 0;
	int half = (step - 1) / 2;

	// ��ʼ��
	memset(dst, 0, sizeof(T1)*hei*wid);

	// ��ȡgauss��
	double* factors = new double[step];
	if (factors == 0)
	{
		return;
	}

	getgaussfactor(factors, step, delta);

	// ��ʱ����
	double *dTempSct = new double[hei*wid];
	memset(dTempSct, 0, sizeof(double)*hei*wid);

	// x����ƽ��
	for (i=0; i<hei; i++)
	{
		for (j=0; j<wid; j++)
		{
			for (m=0; m<step; m++)
			{
				n = j + m - half;
				n = n > 0     ? n : 0;
				n = n < wid-1 ? n : wid-1;

				*(dTempSct + i*wid + j) += ( *(src + i*wid + n) * *(factors+m) );
			}
		}
	}

	// y����ƽ��
	for (i=0; i<hei; i++)
	{
		for (j=0; j<wid; j++)
		{
			double sum = 0;

			for (m=0; m<step; m++)
			{
				n = i + m - half;
				n = n > 0     ? n : 0;
				n = n < hei-1 ? n : hei-1;

				sum += ( *(dTempSct + n*wid + j) * *(factors+m) );
			}

			*(dst + i*wid + j) = (T1)(sum);
		}
	}

	// �ͷ���ʱ������
	if (factors)
	{
		delete [] factors;
	}

	if (dTempSct)
	{
		delete [] dTempSct;
	}
}

// ����ɢ��ͼ����
bool getdatasct(int *DataSct, int SctLen, int SctType, stOptiCellList CellList, int CellType = CELLTYPE_ALL);

// ������������
bool settypesct(stOptiCellList CellList, int CellType, int *TypeSct, int SctLen, int SctType);

bool gettypesct(int *TypeSct, int SctLen, int SctType, stOptiCellList CellList);

bool getinptsct(int *InptSct, int SctLen, int SctType, stOptiCellList CellList, int CellType,
	int step, double delta, double coel);

// cfarɢ��ͼ����
template<class T1, class T2>
bool getcfarsct(T1* dst, T2* src, int hei, int wid, int step, double delta)
{
	if (dst == 0 || src == 0)
	{
		return false;
	}

	int i = 0;
	int j = 0;
	int k = 0;

	double *temp = new double[hei*wid];
	sctsmooth_gauss<double, T2>(temp, src, hei, wid, step, delta);

	for (i=0; i<hei; i++)
	{
		for (j=0; j<wid; j++)
		{
			k = i*wid + j;
			
			*(dst + k) = (T1)(*(temp + k)>*(src + k)?*(temp + k):*(src + k));
		}
	}

	if (temp)
	{
		delete[] temp;
	}

	return true;
}

//************************************************************//
// �������߷���
//************************************************************//
// l4p---------------------------------------------------------
double l4p(double *a, int m, double x);

/*******************************************************************
// ����ת��
********************************************************************/
// HGBͨ��ת��------------------------------------------------------
void dataconvite_hgb(stVoltList * HgbVolList, unsigned char *DataAddr, int DataLen);

// �迹ͨ��ת����DataLenΪpulse����
void dataconvite_impd(stImpdCellList *pImpdCellList, unsigned char *DataAddr, int DataLen);

// �迹ͨ��ת����DataLenΪpulse����
void dataconvite_impd2(unsigned char *DstDataAddr, unsigned char *ScrDataAddr, int DataLen);

// ��ȡ�����ȶ�������
void getstamplist_impd(vector<int> &StampList, stImpdCellList CellList);
void getstamplist_impd(int* &Npsdata, int &Npslen, stImpdCellList CellList);

// ��ѧͨ��ת����DataLenΪpulse����
void dataconvite_opti(stOptiCellList *pOptiCellList, unsigned char *DataAddr, int DataLen);

// ��ȡ�����ȶ�������
void getstamplist_opti(vector<int> &StampList, stOptiCellList CellList);

// ����任
bool coorconvite_opti(stLogTranConfig *pLogTranConfig, stOptiCellList OptiCellList);

// �����任
int LogConvert(int x, int Left, int Right, double Base, int Min, int Max);

/*******************************************************************
// �㷨��������
********************************************************************/
// У׼ϵ������
bool CalirationCal(MODE_WORK workmode, MODE_SAMPLE samplemode, MODE_ANALYSIS analysmode, double *pDstCal, double *pSorCal);

/*******************************************************************
// ��ȡCSV�ļ�
********************************************************************/
bool readcsv(char *filename, int *filedata, int datalen);
bool readcsv(string filename, int *filedata, int datalen);

#endif