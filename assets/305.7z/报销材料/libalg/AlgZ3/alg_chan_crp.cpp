//#include "stdafx.h"
#include "alg_chan_crp.h"
#include "alg_resource.h"
#include <cmath>
#include <stdio.h>
#include <stdlib.h>


#include <float.h>

/*******************************************************************
// �� �� ���� crpmain
// ��    �ܣ� Crpͨ��������
********************************************************************/
bool crpmain(stCrpInput *CrpInput, stCrpOutput *CrpOutput)
{
	if ( CrpInput == NULL || CrpOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1 ��ʼ��
	flag = crpinit(CrpOutput);
	if (!flag)
	{
		return false;
	}

	// 2 ������ò���
	flag = crpconfigpara(&(CrpInput->ConfigPara));
	if (!flag)
	{
		return false;
	}

	// 3 �źŴ���
	flag = crpsigprocess(CrpInput, CrpOutput);
	if (!flag)
	{
		return false;
	}

	// 4 ��������
	flag = crpparacal(CrpInput, CrpOutput);

	return true;
}

/*******************************************************************
// �� �� ���� crpinit
// ��    �ܣ� Crpͨ����ʼ������
********************************************************************/
bool crpinit(stCrpOutput  *CrpOutput)
{
	if (CrpOutput == NULL)
	{
		return false;
	}

	memset(CrpOutput, 0, sizeof(stCrpOutput));

	return true;
}

/*******************************************************************
// �� �� ���� getcrpconfigpara
// ��    �ܣ� ���Crpͨ�����ò���
********************************************************************/
bool crpconfigpara(stCrpConfigPara *Configpara)
{
	if (Configpara == NULL)
	{
		return false;
	}

	return true;
}

/*******************************************************************
// �� �� ���� getvoltlist
// ��    �ܣ� Crp��ѹת��
********************************************************************/
void getvoltlist(stVoltList &Voltlist, unsigned char *DataAddr, int DataLen)
{
	if (DataLen <= 0)
	{
		return;
	}

	// ת��
	Voltlist.VoltNum = DataLen;	
	Voltlist.VoltVal = new unsigned short[DataLen];

	unsigned char *tempaddr = DataAddr;

	for (int i=0; i<DataLen; i++)
	{
		Voltlist.VoltVal[i] = *((unsigned short *)tempaddr);

		tempaddr += 2;
	}
}

void getvoltlist(stVoltList &Voltlist, unsigned short *DataAddr, int DataLen)
{
	if (DataLen <= 0)
	{
		return;
	}

	// ת��
	Voltlist.VoltNum = DataLen;	
	Voltlist.VoltVal = new unsigned short[DataLen];

	for (int i=0; i<DataLen; i++)
	{
		Voltlist.VoltVal[i] = DataAddr[i];
	}
}

// ���㷴Ӧ��
double getreation(stVoltList VoltList, int startpos, int endpos)
{
	// 1����Ӧʱ��
	int Time_Test  = endpos  - startpos;     // ����ʱ��

	// 2�����ʼ���
	double reation = 0;

	if (startpos > 0 && endpos > 0 && startpos < VoltList.VoltNum && endpos < VoltList.VoltNum)
	{
		reation = VoltList.VoltVal[endpos] - VoltList.VoltVal[startpos];
	}

	// 4�����㷴Ӧ��
	if (Time_Test > 0)
	{
		reation = 200.0*reation / Time_Test;
	}	

	return reation;
}

/*******************************************************************
// �� �� ���� crpsigprocess
// ��    �ܣ� Crp�źŴ���
********************************************************************/
bool crpsigprocess(stCrpInput *CrpInput, stCrpOutput *CrpOutput)
{
	if (CrpInput == NULL || CrpOutput == NULL)
	{
		return false;
	}

	// 1������ת��------------------------------------------
	stVoltList NmVoltList;
	NmVoltList.VoltNum = 0;
	NmVoltList.VoltVal =NULL;
	getvoltlist(NmVoltList, CrpInput->NmDataAddr, CrpInput->NmDataLen);

	stVoltList HsVoltList;
	HsVoltList.VoltNum = 0;
	HsVoltList.VoltVal =NULL;
	getvoltlist(HsVoltList, CrpInput->HsDataAddr, CrpInput->HsDataLen);

	// ��ֹʱ��
	int pos_bkstart = NmVoltList.VoltNum - 130;    
	int pos_mestart = NmVoltList.VoltNum -  10;

	double reation = getreation(NmVoltList, pos_bkstart, pos_mestart);

	// 3����ֵ����
	CrpOutput->FeaturePara.pos_bkstart   = pos_bkstart;
	CrpOutput->FeaturePara.pos_mestart   = pos_mestart;
	CrpOutput->FeaturePara.NmVoltList    = NmVoltList;
	CrpOutput->FeaturePara.HsVoltList    = HsVoltList;

	CrpOutput->ServicePara.Reaction      = reation;

	return true;
}

/*******************************************************************
// �� �� ���� crpparacal
// ��    �ܣ� Crp��������
********************************************************************/
bool crpparacal(stCrpInput *CrpInput, stCrpOutput *CrpOutput)
{
	if (CrpInput == NULL || CrpOutput == NULL)
	{
		return false;
	}

	// 1����ȡ��Ӧ��
	double Reaction = CrpOutput->ServicePara.Reaction;

	// 2������CRP
	double dCrp = 0.0;

	//// 2.1 ��������
	//if (CrpInput->ScaleMode == SCALEMODE_TPLINE)
	//{
	//	crpparacal_TPline(&dCrp, Reaction, CrpInput->ScalePara);
	//}

	//// 2.2 spline
	//if (CrpInput->ScaleMode == SCALEMODE_SPLINE)
	//{
	//	crpparacal_SPline(&dCrp, Reaction, CrpInput->ScalePara);
	//}

	printf("CrpInput->ScaleMod 0:line 1:spline 2:l4p\n");
	printf("CrpInput->ScaleMod%d\n",CrpInput->ScaleMode);

	printf("scalepraadatas1:%f\n", CrpInput->ScalePara.paradata[0]);
	printf("scaleparadatas2:%f\n", CrpInput->ScalePara.paradata[1]);
	printf("scaleparadatas3:%f\n", CrpInput->ScalePara.paradata[2]);
	printf("scaleparadatas4:%f\n", CrpInput->ScalePara.paradata[3]);

	if (CrpInput->ScaleMode == SCALEMODE_L4LINE)
	{
		printf("mode right!\n");

		crpparacal_l4pline(&dCrp, Reaction, CrpInput->ScalePara.paradata, CrpInput->ScalePara.datalens);
	}
	else
	{
		printf("mode wrong!\n");
	}

	dCrp = (dCrp < EPSINON)? 0 : dCrp;

	CrpOutput->ReportPara.Crp = dCrp;

	printf("crpparacal:Reaction%f\n",Reaction);
	printf("crpparacal:crp%f\n",dCrp);

	return true;
}

//  �ⷽ��
void SolveEquation(double (*fun)(double *, int, double), double *a, int m, double *x, double y, double x0, double x1)
{
	// ������ʾ��Χ������
	if (y > fun(a, m, x1))
	{
		return;
	}

	// ��ʼֵ
	double x2 = (x0 + x1)/2;
	double y2 = fun(a, m, x2);

	int l = 0;

	while(abs(y - y2) > EPSINON)
	{
		// ���±߽�
		if (y - y2 > EPSINON)
		{
			x0 = x2;
		}
		else if (y - y2 < -EPSINON)
		{
			x1 = x2;
		}
		else  // �˳�����1
		{
			break;
		}

		x2 = (x0 + x1)/2;
		y2 = fun(a, m, x2);

		// �˳�����2
		if (abs(x0 - x1) < EPSINON)
		{
			break;
		}

		// �˳�����3
		if (l++ > 300)
		{
			break;
		}
	}

	*x = x2;
}

//********************************************************************
// �� �� ���� crpparacal_l4pline
// ��    �ܣ� Crpͨ����������(l4p)
//********************************************************************
bool crpparacal_l4pline(double *pCrp, double Reaction, double *data, int datalen)
{
	if (pCrp == NULL)
	{
		return false;
	}
	
	// 2�����ַ����
	*pCrp = 2000.0;

	if (Reaction < EPSINON)
	{
		*pCrp = 0;
	}
	else
	{
		SolveEquation(l4p, data, datalen, pCrp, Reaction, 0.0, 2000.0);
	}
	
	return true;
}

