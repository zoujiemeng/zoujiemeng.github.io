#include "alg_chan_hgb.h"
#include "alg_resource.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

/*******************************************************************
// �� �� ���� HgbMain
// ��    �ܣ� Hgbͨ��������
********************************************************************/
bool hgbmain(stHgbInput *HgbInput, stHgbOutput *HgbOutput)
{
	if (HgbInput == NULL || HgbOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1 ��ʼ��
	flag = hgbinit(HgbInput, HgbOutput);
	if (!flag)
	{
		return false;
	}

	// 2 ������ò���
	flag = hgbconfigpara( &(HgbInput->HgbConfigPara) );
	if (!flag)
	{
		return false;
	}

	// 3 �źŴ���
	flag = hgbsigprocess(HgbInput, HgbOutput);
	if (!flag)
	{
		return false;
	}

	// 3 ��������
	flag = hgbparacal(HgbInput, HgbOutput);

	return flag;
}

/*******************************************************************
// �� �� ���� HgbInit
// ��    �ܣ� Hgbͨ����ʼ������
********************************************************************/
bool hgbinit(stHgbInput *HgbInput, stHgbOutput *HgbOutput)
{
	if (HgbInput == NULL || HgbOutput == NULL)
	{
		return false;
	}

	memset(HgbOutput, 0, sizeof(stHgbOutput));

	return true;
}

/*******************************************************************
// �� �� ���� gethgbconfigpara
// ��    �ܣ� ���Hgbͨ�����ò���
********************************************************************/
bool hgbconfigpara(stHgbConfigPara *HgbConfigPara)
{
	if (HgbConfigPara == NULL)
	{
		return false;
	}

	HgbConfigPara->Alg_H_Cal_HgbAdjustfactor  = 0.88;
	HgbConfigPara->Alg_H_Cal_HgbSubBackGround = 2.0;

	return true;
}

/*******************************************************************
// �� �� ���� getvolvalue
// ��    �ܣ� ��ȡHgb��ѹֵ(���ס�����)
********************************************************************/
double getvolvalue(unsigned short* volarray, int volallnum, int voloutnum)
{
	if (volarray == NULL || volallnum < voloutnum )
	{
		return INVALID;
	}

	int    index    = 0;

	double volvalue = 0.0;

	for (int i=0; i<voloutnum; i++)
	{
		double dmaxbia = 0.0;

		volvalue = getmean<unsigned short>(volarray, volallnum - i);

		for (int j=0; j<volallnum-i; j++)
		{
			if (dmaxbia < abs(volarray[j] - volvalue) )
			{
				dmaxbia = abs(volarray[j] - volvalue);
				index   = j;
			}
		}

		double dtemp            = volarray[index];
		volarray[index]         = volarray[volallnum-1-i];
		volarray[volallnum-1-i] = (int)(dtemp);
	}

	volvalue = getmean<unsigned short>(volarray, volallnum - voloutnum);

	return volvalue;
}

/*******************************************************************
// �� �� ���� getblankvol
// ��    �ܣ� ��ȡHgb���׵�ѹ
********************************************************************/
double getblankvol(unsigned short *volarray, int volnum)
{
	return (getvolvalue(volarray, volnum, 4));
}

/*******************************************************************
// �� �� ���� getmeasurevol
// ��    �ܣ� ��ȡHgb������ѹֵ
********************************************************************/
double getmeasurevol(unsigned short *volarray, int volnum)
{
	return (getvolvalue(volarray, volnum, 4));
}

/*******************************************************************
// �� �� ���� hgbsigprocess
// ��    �ܣ� Hgb�źŴ���
********************************************************************/
bool hgbsigprocess(stHgbInput *HgbInput, stHgbOutput *HgbOutput)
{
	if (HgbInput == NULL || HgbOutput == NULL)
	{
		return false;
	}

	int pos_bkstart = 0;
	int pos_mestart = 0;

	switch (HgbInput->AnalyMode)
	{
	case ANALYSISMODE_CBC:
		pos_bkstart = 5;
		pos_mestart = 3520;
		break;
	case ANALYSISMODE_CBC_CRP:
		pos_bkstart = 5;
		pos_mestart = 4330;
		break;
	default:
		pos_bkstart = 5;
		pos_mestart = 3520;
		break;
	}

	// 1������ת��------------------------------------------
	if (HgbInput->DataLen <= 0)
	{
		return true;
	}

	stVoltList VoltList;
	VoltList.VoltNum = HgbInput->DataLen;
	VoltList.VoltVal = new unsigned short[VoltList.VoltNum];

	unsigned char *tempaddr = HgbInput->DataAddr;

	for (int i=0; i<VoltList.VoltNum; i++)
	{
		VoltList.VoltVal[i] = *((unsigned short *)tempaddr);

		tempaddr += 2;
	}

	// 2����ѹ����------------------------------------------
	const int Alg_HgbVolt_Len = 20;
	double BlankVol   = getblankvol(VoltList.VoltVal + pos_bkstart, Alg_HgbVolt_Len);
	double MeasureVol = getblankvol(VoltList.VoltVal + pos_mestart, Alg_HgbVolt_Len);

	// 3����ֵ����
	HgbOutput->FeaturePara.pos_bkstart   = pos_bkstart;
	HgbOutput->FeaturePara.pos_mestart   = pos_mestart;

	HgbOutput->FeaturePara.VoltList      = VoltList;
	HgbOutput->FeaturePara.BlankVol      = BlankVol;
	HgbOutput->FeaturePara.MeasureVol    = MeasureVol;

	return true;
}

/*******************************************************************
// �� �� ���� hgbparacal
// ��    �ܣ� Hgb��������
********************************************************************/
bool hgbparacal(stHgbInput *HgbInput, stHgbOutput *HgbOutput)
{
	if (HgbInput == NULL || HgbOutput == NULL)
	{
		return false;
	}

	// ��ȡ���ò���
	double HgbAdjustfactor  = HgbInput->HgbConfigPara.Alg_H_Cal_HgbAdjustfactor;
	double HgbSubBackGround = HgbInput->HgbConfigPara.Alg_H_Cal_HgbSubBackGround;

	// ��ȡ��������
	double HgbBlankVol   = HgbOutput->FeaturePara.BlankVol;
	double HgbMeasureVol = HgbOutput->FeaturePara.MeasureVol;

	// ���ϡ�ͱ�
	double Dilution = HgbInput->Dilution;

	// HGB��������
	double dHgb = 0.0;

	if (HgbMeasureVol > EPSINON && HgbBlankVol > EPSINON)
	{
		dHgb = HgbAdjustfactor*Dilution*log(1.0*HgbBlankVol/HgbMeasureVol) - HgbSubBackGround;
	}

	HgbOutput->ReportPara.Hgb = (dHgb > EPSINON)? dHgb : 0;

	return true;
}