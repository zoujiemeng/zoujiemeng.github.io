//#include "stdafx.h"
#include "alg_flow_main.h"
#include "alg_flow_channel.h"
#include "alg_flow_sample.h"
#include "alg_flow_display.h"
#include "alg_resource.h"

#include <string.h>

bool AlgorithmMain(stAlgInput *AlgInput, stAlgOutput *AlgOutput)
{
	if (AlgInput == NULL ||AlgOutput == NULL)
	{
		return false; 
	}
	// ģʽ����
	AlgInput->WbcInput.BloodMode  = AlgInput->BloodMode;
	AlgInput->WbcInput.AnalyMode  = AlgInput->AnalyMode;
	AlgInput->WbcInput.WorkMode   = AlgInput->WorkMode;
	AlgInput->WbcInput.SampleMode = AlgInput->SampleMode;

	AlgInput->ImpdInput.RbcInput.BloodMode  = AlgInput->BloodMode;
	AlgInput->ImpdInput.RbcInput.AnalyMode  = AlgInput->AnalyMode;
	AlgInput->ImpdInput.RbcInput.WorkMode   = AlgInput->WorkMode;
	AlgInput->ImpdInput.RbcInput.SampleMode = AlgInput->SampleMode;

	AlgInput->ImpdInput.PltInput.BloodMode  = AlgInput->BloodMode;
	AlgInput->ImpdInput.PltInput.AnalyMode  = AlgInput->AnalyMode;
	AlgInput->ImpdInput.PltInput.WorkMode   = AlgInput->WorkMode;
	AlgInput->ImpdInput.PltInput.SampleMode = AlgInput->SampleMode;

	AlgInput->HgbInput.BloodMode  = AlgInput->BloodMode;
	AlgInput->HgbInput.AnalyMode  = AlgInput->AnalyMode;
	AlgInput->HgbInput.WorkMode   = AlgInput->WorkMode;
	AlgInput->HgbInput.SampleMode = AlgInput->SampleMode;

	AlgInput->CrpInput.BloodMode  = AlgInput->BloodMode;
	AlgInput->CrpInput.AnalyMode  = AlgInput->AnalyMode;
	AlgInput->CrpInput.WorkMode   = AlgInput->WorkMode;
	AlgInput->CrpInput.SampleMode = AlgInput->SampleMode;
	AlgInput->CrpInput.ScaleMode  = AlgInput->ScaleMode;

	// 1 �������ģ��----------------------------------------------------
	stChannelAlgInput  ChannelInput;
	stChannelAlgOutput ChannelOutput;

	memset(&ChannelOutput, 0, sizeof(stChannelAlgOutput));

	ChannelInput.WbcInput    = AlgInput->WbcInput;
	ChannelInput.HgbInput    = AlgInput->HgbInput;
	ChannelInput.ImpdInput   = AlgInput->ImpdInput;
	ChannelInput.CrpInput    = AlgInput->CrpInput;

	ChannelAlg(&ChannelInput, &ChannelOutput);

	// ����������
	AlgOutput->ReportPara.WbcReportPara      = ChannelOutput.WbcOutput.ReportPara;
	AlgOutput->ReportPara.RbcReportPara      = ChannelOutput.ImpdOutput.RbcOutput.ReportPara;
	AlgOutput->ReportPara.PltReportPara      = ChannelOutput.ImpdOutput.PltOutput.ReportPara;
	AlgOutput->ReportPara.HgbReportPara      = ChannelOutput.HgbOutput.ReportPara;
	AlgOutput->ReportPara.CrpReportPara      = ChannelOutput.CrpOutput.ReportPara;

	// �о��������
	AlgOutput->ResearchPara.WbcResearchPara  = ChannelOutput.WbcOutput.ResearchPara;
	AlgOutput->ResearchPara.RbcResearchPara  = ChannelOutput.ImpdOutput.RbcOutput.ResearchPara;
	AlgOutput->ResearchPara.PltResearchPara  = ChannelOutput.ImpdOutput.PltOutput.ResearchPara;
	AlgOutput->ResearchPara.HgbResearchPara  = ChannelOutput.HgbOutput.ResearchPara;
	AlgOutput->ResearchPara.CrpResearchPara  = ChannelOutput.CrpOutput.ResearchPara;

	// �����������
	AlgOutput->FeaturePara.WbcFeaturePara    = ChannelOutput.WbcOutput.FeaturePara;
	AlgOutput->FeaturePara.RbcFeaturePara    = ChannelOutput.ImpdOutput.RbcOutput.FeaturePara;
	AlgOutput->FeaturePara.PltFeaturePara    = ChannelOutput.ImpdOutput.PltOutput.FeaturePara;
	AlgOutput->FeaturePara.HgbFeaturePara    = ChannelOutput.HgbOutput.FeaturePara;
	AlgOutput->FeaturePara.CrpFeaturePara    = ChannelOutput.CrpOutput.FeaturePara;

	// ����������
	AlgOutput->ServicePara.WbcServicePara    = ChannelOutput.WbcOutput.ServicePara;
	AlgOutput->ServicePara.RbcServicePara    = ChannelOutput.ImpdOutput.RbcOutput.ServicePara;
	AlgOutput->ServicePara.PltServicePara    = ChannelOutput.ImpdOutput.PltOutput.ServicePara;
	AlgOutput->ServicePara.HgbServicePara    = ChannelOutput.HgbOutput.ServicePara;
	AlgOutput->ServicePara.CrpServicePara    = ChannelOutput.CrpOutput.ServicePara;

	// 2 �����б�ģ��--------------------------------------------------------------------------------
	stSampleAlgInOutput SampleAlgInOutput;

	memset(&SampleAlgInOutput,  0, sizeof(stSampleAlgInOutput));

	// ������Ϣ
	SampleAlgInOutput.BloodMode  = AlgInput->BloodMode;
	SampleAlgInOutput.WorkMode   = AlgInput->WorkMode;
	SampleAlgInOutput.AnalyMode  = AlgInput->AnalyMode;
	SampleAlgInOutput.SampleMode = AlgInput->SampleMode;

	// ������Ϣ(�û�����)
	memcpy(SampleAlgInOutput.Caliration, AlgInput->Caliration, sizeof(double)*MAXPARA*CALIRATION_MAX);

	// ͼ����Ϣ
	SampleAlgInOutput.GraphPara.WbcGraphPara        = ChannelOutput.WbcOutput.GraphPara;
	SampleAlgInOutput.GraphPara.RbcGraphPara        = ChannelOutput.ImpdOutput.RbcOutput.GraphPara;
	SampleAlgInOutput.GraphPara.PltGraphPara        = ChannelOutput.ImpdOutput.PltOutput.GraphPara;
	SampleAlgInOutput.GraphPara.HgbGraphPara        = ChannelOutput.HgbOutput.GraphPara;
	SampleAlgInOutput.GraphPara.CrpGraphPara        = ChannelOutput.CrpOutput.GraphPara;

	// ������Ϣ
	SampleAlgInOutput.ReportPara.WbcReportPara      = ChannelOutput.WbcOutput.ReportPara;
	SampleAlgInOutput.ReportPara.RbcReportPara      = ChannelOutput.ImpdOutput.RbcOutput.ReportPara;
	SampleAlgInOutput.ReportPara.PltReportPara      = ChannelOutput.ImpdOutput.PltOutput.ReportPara;
	SampleAlgInOutput.ReportPara.HgbReportPara      = ChannelOutput.HgbOutput.ReportPara;
	SampleAlgInOutput.ReportPara.CrpReportPara      = ChannelOutput.CrpOutput.ReportPara;

	// �о���Ϣ
	SampleAlgInOutput.ResearchPara.WbcResearchPara  = ChannelOutput.WbcOutput.ResearchPara;
	SampleAlgInOutput.ResearchPara.RbcResearchPara  = ChannelOutput.ImpdOutput.RbcOutput.ResearchPara;
	SampleAlgInOutput.ResearchPara.PltResearchPara  = ChannelOutput.ImpdOutput.PltOutput.ResearchPara;
	SampleAlgInOutput.ResearchPara.HgbResearchPara  = ChannelOutput.HgbOutput.ResearchPara;
	SampleAlgInOutput.ResearchPara.CrpResearchPara  = ChannelOutput.CrpOutput.ResearchPara;

	// ������Ϣ
	SampleAlgInOutput.FeaturePara.WbcFeaturePara    = ChannelOutput.WbcOutput.FeaturePara;
	SampleAlgInOutput.FeaturePara.RbcFeaturePara    = ChannelOutput.ImpdOutput.RbcOutput.FeaturePara;
	SampleAlgInOutput.FeaturePara.PltFeaturePara    = ChannelOutput.ImpdOutput.PltOutput.FeaturePara;
	SampleAlgInOutput.FeaturePara.HgbFeaturePara    = ChannelOutput.HgbOutput.FeaturePara;
	SampleAlgInOutput.FeaturePara.CrpFeaturePara    = ChannelOutput.CrpOutput.FeaturePara;

	// �������
	SampleAlgInOutput.ServicePara.WbcServicePara    = ChannelOutput.WbcOutput.ServicePara;
	SampleAlgInOutput.ServicePara.RbcServicePara    = ChannelOutput.ImpdOutput.RbcOutput.ServicePara;
	SampleAlgInOutput.ServicePara.PltServicePara    = ChannelOutput.ImpdOutput.PltOutput.ServicePara;
	SampleAlgInOutput.ServicePara.HgbServicePara    = ChannelOutput.HgbOutput.ServicePara;
	SampleAlgInOutput.ServicePara.CrpServicePara    = ChannelOutput.CrpOutput.ServicePara;

	SampleAlg(&SampleAlgInOutput);

	// ͼ����Ϣ���
	AlgOutput->GraphPara.WbcGraphPara = SampleAlgInOutput.GraphPara.WbcGraphPara;
	AlgOutput->GraphPara.RbcGraphPara = SampleAlgInOutput.GraphPara.RbcGraphPara;
	AlgOutput->GraphPara.PltGraphPara = SampleAlgInOutput.GraphPara.PltGraphPara;
	AlgOutput->GraphPara.HgbGraphPara = SampleAlgInOutput.GraphPara.HgbGraphPara;
	AlgOutput->GraphPara.CrpGraphPara = SampleAlgInOutput.GraphPara.CrpGraphPara;

	// 3 ��ʾģ��--------------------------------------------------------------------------------
	stDisplayAlgInOutput DisplayAlgInOutput;

	memset(&DisplayAlgInOutput, 0, sizeof(stDisplayAlgInOutput));

	// ������Ϣ
	DisplayAlgInOutput.BloodMode  = AlgInput->BloodMode;
	DisplayAlgInOutput.WorkMode   = AlgInput->WorkMode;
	DisplayAlgInOutput.AnalyMode  = AlgInput->AnalyMode;
	DisplayAlgInOutput.SampleMode = AlgInput->SampleMode;

	// ��������
	memcpy(DisplayAlgInOutput.Para,  SampleAlgInOutput.Para,  sizeof(PARA)*MAXPARA);
	memcpy(DisplayAlgInOutput.Alarm, SampleAlgInOutput.Alarm, sizeof(ALARM)*MAXALARM);

	DisplayAlg(&DisplayAlgInOutput);

	// ��������
	memcpy(AlgOutput->Para,  DisplayAlgInOutput.Para,  sizeof(PARA)*MAXPARA);
	memcpy(AlgOutput->Alarm, DisplayAlgInOutput.Alarm, sizeof(ALARM)*MAXALARM);

	POINTER_FREE(AlgOutput->FeaturePara.WbcFeaturePara.Npsdata);
	POINTER_FREE(AlgOutput->FeaturePara.RbcFeaturePara.Npsdata);

	return true;
}

char *GetAlgVersion(void)
{
	char *pVersion = (char *)("2.1.6.4515");
	return pVersion;
}