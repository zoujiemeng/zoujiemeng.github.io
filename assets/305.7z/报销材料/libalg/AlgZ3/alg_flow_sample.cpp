//#include "stdafx.h"
#include "alg_flow_sample.h"
#include "alg_resource.h"

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#include <direct.h>
#else
#include <unistd.h>
#endif

// ----------------------------------------------------------------------------------------
// �����б�
// ----------------------------------------------------------------------------------------
bool SampleAlg(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ���������б���ֵ����
	SetPosLine(SampleAlgInOutput);

	// ��ȡ���ò���
	GetSampleConfig(&(SampleAlgInOutput->SampleConfig));

	//��������
	Sample_Msg1(SampleAlgInOutput);

	//��������
	ParaCal(SampleAlgInOutput);

	//��������
	Sample_Msg2(SampleAlgInOutput);

	//��Ϣ�ۺ�
	Integration(SampleAlgInOutput);

	return true;
}

// ����������ֵ
bool SetPosLine(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	for (int i=0; i<MAXALARM; i++)
	{
		SampleAlgInOutput->Alarm[i].PosLine = 40;
	}
	
	return true;
}

// ��ȡ���ò���
void GetSampleConfig(stSampleConfig *SampleConfig)
{
	if (SampleConfig == NULL)
	{
		return;
	}

	SampleConfig->Alg_S_Msg_WbcSystemErrorBlockUN_HoleHighTh = 2.05 ;  // WBC�¿�С�׵�ѹ�쳣����

	SampleConfig->Alg_S_Msg_RbcSystemErrorBlockUN_HoleHighTh = 2.25 ;  // RBC�¿�С�׵�ѹ�쳣����

	SampleConfig->Alg_S_Msg_WbcSystemErrorHoleAbn_HoleLowTh  = 1.2  ;  // WBCС�׵�ѹ�쳣����

	SampleConfig->Alg_S_Msg_RbcSystemErrorHoleAbn_HoleLowTh  = 1.4  ;  // RBCС�׵�ѹ�쳣����

	SampleConfig->Alg_S_Msg_HgbSystemError_HgbBlankLowTh   = 4.2  ;  // HGB���׵�ѹ�쳣����
	SampleConfig->Alg_S_Msg_HgbSystemError_HgbBlankHighTh  = 4.8  ;  // HGB���׵�ѹ�쳣����

	SampleConfig->Alg_S_Msg_BackGroundAbsorbAbn_WbcTh      = 0.5  ;  // ���׻������쳣Wbc��ֵ
	SampleConfig->Alg_S_Msg_BackGroundAbsorbAbn_RbcTh      = 0.2  ;  // ���׻������쳣Rbc��ֵ
	SampleConfig->Alg_S_Msg_BackGroundAbsorbAbn_PltTh      =   5  ;  // ���׻������쳣Plt��ֵ
	SampleConfig->Alg_S_Msg_BackGroundAbsorbAbn_HgbTh      =   1  ;  // ���׻������쳣Hgb��ֵ

	SampleConfig->Alg_S_Msg_WbcAbn_Low_WbcTh               = 0.5  ;  // ��ϸ���쳣--��ֵ��ϸ��Wbc��ֵ

	SampleConfig->Alg_S_Msg_RbcHistAbn_SkewnessLowTh       = 0.04 ;  // ��ϸ���ֲ��쳣Skewness����
	SampleConfig->Alg_S_Msg_RbcHistAbn_SkewnessHighTh      = 0.39 ;  // ��ϸ���ֲ��쳣Skewness����
	SampleConfig->Alg_S_Msg_RbcHistAbn_KurtosisLowTh       = -0.8 ;  // ��ϸ���ֲ��쳣Kurtosis����
	SampleConfig->Alg_S_Msg_RbcHistAbn_KurtosisHighTh      = -0.55;  // ��ϸ���ֲ��쳣Kurtosis����

	SampleConfig->Alg_S_Msg_Bimodality_Rdw_cvLowTh         = 23.5 ;  // ˫����Rdw_cv����
	SampleConfig->Alg_S_Msg_Bimodality_KurtosisLowTh       = 0.85 ;  // ˫����Rdw_sd����

	SampleConfig->Alg_S_Msg_Agglutination_RbcNumLowTh      = 400  ;  // ��ϸ���������Ӿ���ֵ����
	SampleConfig->Alg_S_Msg_Agglutination_RbcPerLowTh      = 2.3  ;  // ��ϸ���������Ӱٷֱ�����
	SampleConfig->Alg_S_Msg_Agglutination_Slope            = 0.004;  // ��ϸ������б��
	SampleConfig->Alg_S_Msg_Agglutination_Intercept        = -0.9 ;  // ��ϸ�������ؾ�(�ٷֱ�)

	SampleConfig->Alg_S_Msg_Iron_MchcLowTh                 = 310  ;  // ȱ����Mchc����
	SampleConfig->Alg_S_Msg_Iron_McvLowTh                  = 75.0 ;  // ȱ����Mcv����
	SampleConfig->Alg_S_Msg_Iron_RdwcvHighTh               = 15.0 ;  // ȱ����Rdwcv����

	SampleConfig->Alg_S_Msg_HgbMchcAbn_MchcTh              = 380.0;  // MCHC�쳣

	SampleConfig->Alg_S_Msg_PltHistAbn_PltUpTh             = 25.0 ;  // ѪС��ֲ��쳣PLTUP��ֵ
	SampleConfig->Alg_S_Msg_PltClumps_PltTh                = 200  ;  // ѪС��ۼ�PLT��ֵ
	SampleConfig->Alg_S_Msg_PltClumps_MpvTh                = 11.0 ;  // ѪС��ۼ�MPV��ֵ
	SampleConfig->Alg_S_Msg_PltClumps_PltUpTh              = 75.0 ;  // ѪС��ۼ�PLTUP��ֵ
}

// ���ñ���Flag
void SetAlarmFlag(ALARM *Alarm, int QFlag)
{
	Alarm->Degree = QFlag;

	if (Alarm->Degree > Alarm->PosLine)
	{
		Alarm->Flag = true;
	}
}

// ----------------------------------------------------------------------------------------
// ����ģ��1
// ----------------------------------------------------------------------------------------
// ���ɱ���1
void Suspect_Msg1(stSampleAlgInOutput *SampleAlgInOutput)
{

}

// ϵͳ����1
void System_Msg1(stSampleAlgInOutput *SampleAlgInOutput)
{
	// WBCͨ��ϵͳ�쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[WBCSYSTEMERROR_HOLEABN],  Wbc_SystemErrorHoleAbn(SampleAlgInOutput));
	SetAlarmFlag(&SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK_UN], Wbc_SystemErrorBlockUN(SampleAlgInOutput));
	SetAlarmFlag(&SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK_AC], Wbc_SystemErrorBlockAC(SampleAlgInOutput));

	// RBCͨ��ϵͳ�쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[RBCSYSTEMERROR_HOLEABN],  Rbc_SystemErrorHoleAbn(SampleAlgInOutput));
	SetAlarmFlag(&SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK_UN], Rbc_SystemErrorBlockUN(SampleAlgInOutput));
	SetAlarmFlag(&SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK_AC], Rbc_SystemErrorBlockAC(SampleAlgInOutput));

	// HGBͨ��ϵͳ�쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[HGBSYSTEMERROR], Hgb_SystemError(SampleAlgInOutput));
}

// ״̬����1
void Status_Msg1()
{

}

// ����ģ��1
bool Sample_Msg1(stSampleAlgInOutput *SampleAlgInOutput)
{	
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ���ɱ���1
	Suspect_Msg1(SampleAlgInOutput);

	// ϵͳ����1
	System_Msg1(SampleAlgInOutput);

	// ״̬����1
	Status_Msg1();

	return true;
}

// ----------------------------------------------------------------------------------------
// ��������
// ----------------------------------------------------------------------------------------
// ��������׼��
bool PreParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ����ģʽУ׼ϵ��
	if (SampleAlgInOutput->WorkMode == WORKMODE_CB_FA)
	{
		for (int i=0; i<MAXPARA; i++)
		{
			SampleAlgInOutput->Caliration_C[i] = 1.0;
		}
	}
	else if (SampleAlgInOutput->WorkMode == WORKMODE_CB_US)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			SampleAlgInOutput->Caliration_C[i] = SampleAlgInOutput->Caliration[i][CALIRATION_FA];
		}
	}
	else
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			SampleAlgInOutput->Caliration_C[i] = SampleAlgInOutput->Caliration[i][CALIRATION_FA]*SampleAlgInOutput->Caliration[i][CALIRATION_US];
		}
	}

	// ����ģʽ�䴫��ϵ��
	if (SampleAlgInOutput->SampleMode != SAMPLEMODE_OPEN)
	{
		for (int i=0; i<MAXPARA; i++)
		{
			SampleAlgInOutput->Caliration_C[i] *= SampleAlgInOutput->Caliration[i][CALIRATION_SA];
		}
	}

	// ����ģʽ�䴫��ϵ��
	if (SampleAlgInOutput->AnalyMode != ANALYSISMODE_CBC)
	{
		for (int i=WBC; i<MAXPARA; i++)
		{
			SampleAlgInOutput->Caliration_C[i] *= SampleAlgInOutput->Caliration[i][CALIRATION_AN];
		}
	}

	return true;
}

// WBC��������
bool WbcParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// 1��ͨ������
	double dWbc     = SampleAlgInOutput->ReportPara.WbcReportPara.Wbc;
	double dLymPer  = SampleAlgInOutput->ReportPara.WbcReportPara.LymPer;
	double dMidPer  = SampleAlgInOutput->ReportPara.WbcReportPara.MidPer;
	double dGranPer = SampleAlgInOutput->ReportPara.WbcReportPara.GranPer;

	// 2����������

	// 3��ֱ�Ӳ���
	// 3.1���������
	SampleAlgInOutput->Para[WBC].Value         = dWbc     * SampleAlgInOutput->Caliration_C[WBC];
	SampleAlgInOutput->Para[LYMPERCENT].Value  = dLymPer  * SampleAlgInOutput->Caliration_C[LYMPERCENT];
	SampleAlgInOutput->Para[MIDPERCENT].Value  = dMidPer  * SampleAlgInOutput->Caliration_C[MIDPERCENT];
	SampleAlgInOutput->Para[GRANPERCENT].Value = dGranPer * SampleAlgInOutput->Caliration_C[GRANPERCENT];

	// 4����Ӳ���
	// 4.1���������
	SampleAlgInOutput->Para[LYMCOUNT].Value    = SampleAlgInOutput->Para[WBC].Value*SampleAlgInOutput->Para[LYMPERCENT].Value/100.0;
	SampleAlgInOutput->Para[MIDCOUNT].Value    = SampleAlgInOutput->Para[WBC].Value*SampleAlgInOutput->Para[MIDPERCENT].Value/100.0;
	SampleAlgInOutput->Para[GRANCOUNT].Value   = SampleAlgInOutput->Para[WBC].Value*SampleAlgInOutput->Para[GRANPERCENT].Value/100.0;

	return true;
}

// RBC��������
bool RbcParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if ( SampleAlgInOutput == NULL)
	{
		return false;
	}

	// 1��ͨ������
	double dRbc   = SampleAlgInOutput->ReportPara.RbcReportPara.Rbc;
	double dMcv   = SampleAlgInOutput->ReportPara.RbcReportPara.Mcv;
	double dHgb   = SampleAlgInOutput->ReportPara.HgbReportPara.Hgb;
	double Rdw_cv = SampleAlgInOutput->ReportPara.RbcReportPara.Rdw_cv;
	double Rdw_sd = SampleAlgInOutput->ReportPara.RbcReportPara.Rdw_sd;

	// 2��ֱ�Ӳ�������
	// 2.1��ֱ�Ӳ���
	SampleAlgInOutput->Para[RBC].Value    = dRbc  * SampleAlgInOutput->Caliration_C[RBC];
	SampleAlgInOutput->Para[HGB].Value    = dHgb  * SampleAlgInOutput->Caliration_C[HGB];
	SampleAlgInOutput->Para[MCV].Value    = dMcv  * SampleAlgInOutput->Caliration_C[MCV];
	SampleAlgInOutput->Para[RDW_CV].Value = Rdw_cv* SampleAlgInOutput->Caliration_C[RDW_CV];
	SampleAlgInOutput->Para[RDW_SD].Value = Rdw_sd* SampleAlgInOutput->Caliration_C[MCV]*SampleAlgInOutput->Caliration_C[RDW_SD];

	// 3����Ӳ���
	SampleAlgInOutput->Para[HCT].Value  = SampleAlgInOutput->Para[RBC].Value*SampleAlgInOutput->Para[MCV].Value/10
		*SampleAlgInOutput->Caliration_C[HCT];

	if (SampleAlgInOutput->Para[RBC].Value > EPSINON)
	{
		SampleAlgInOutput->Para[MCH].Value  = SampleAlgInOutput->Para[HGB].Value / SampleAlgInOutput->Para[RBC].Value
			*SampleAlgInOutput->Caliration_C[MCH];
	}
	else
	{
		SampleAlgInOutput->Para[MCH].Value  = 0;
	}

	if ( SampleAlgInOutput->Para[MCV].Value > EPSINON )
	{
		SampleAlgInOutput->Para[MCHC].Value = SampleAlgInOutput->Para[MCH].Value*1000/SampleAlgInOutput->Para[MCV].Value
			*SampleAlgInOutput->Caliration_C[MCHC];
	}
	else
	{
		SampleAlgInOutput->Para[MCHC].Value = 0;
	}

	return true;
}

// PLT��������
bool PltParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ͨ������
	double dPlt   = SampleAlgInOutput->ReportPara.PltReportPara.Plt;
	double dMpv   = SampleAlgInOutput->ReportPara.PltReportPara.Mpv;
	double dPdw   = SampleAlgInOutput->ReportPara.PltReportPara.Pdw;
	double dPlcr  = SampleAlgInOutput->ReportPara.PltReportPara.Plcr;

	// ��������
	dPlt = 1.31*dPlt;

	// ֱ�Ӳ���
	SampleAlgInOutput->Para[PLT].Value    = dPlt*SampleAlgInOutput->Caliration_C[PLT];
	SampleAlgInOutput->Para[MPV].Value    = dMpv*SampleAlgInOutput->Caliration_C[MPV];
	SampleAlgInOutput->Para[PDW].Value    = dPdw*SampleAlgInOutput->Caliration_C[PDW];
	SampleAlgInOutput->Para[PLCR].Value   = dPlcr*100*SampleAlgInOutput->Caliration_C[PLCR];

	// ��Ӳ���
	SampleAlgInOutput->Para[PCT].Value    = SampleAlgInOutput->Para[PLT].Value*SampleAlgInOutput->Para[MPV].Value/10000
		*SampleAlgInOutput->Caliration_C[PCT];

	SampleAlgInOutput->Para[PLCC].Value   = SampleAlgInOutput->Para[PLT].Value*SampleAlgInOutput->Para[PLCR].Value/100
		*SampleAlgInOutput->Caliration_C[PLCC];

	return true;
}

// CRP��������
bool CrpParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ͨ������
	double dCrp = SampleAlgInOutput->ReportPara.CrpReportPara.Crp;

	// HCT����
	if (100 - SampleAlgInOutput->Para[HCT].Value > EPSINON)
	{
		dCrp = dCrp * 100 / (100 - SampleAlgInOutput->Para[HCT].Value);
	}
 
	// ֱ�Ӳ���
	SampleAlgInOutput->Para[CRP_NM].Value = dCrp*SampleAlgInOutput->Caliration_C[CRP_NM];
	SampleAlgInOutput->Para[CRP_HS].Value = dCrp*SampleAlgInOutput->Caliration_C[CRP_HS];

	return true;
}

// ��������
bool ParaCal(stSampleAlgInOutput *SampleAlgInOutput)
{
	if ( SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ����׼��
	PreParaCal(SampleAlgInOutput);

	// WBC��������
	WbcParaCal(SampleAlgInOutput);

	// RBC��������
	RbcParaCal(SampleAlgInOutput);

	// PLT��������
	PltParaCal(SampleAlgInOutput);

	// CRP��������
	CrpParaCal(SampleAlgInOutput);

	return true;
}

// ----------------------------------------------------------------------------------------
// ����ģ��2
// ----------------------------------------------------------------------------------------
// ���ɱ���2
void Suspect_Msg2(stSampleAlgInOutput *SampleAlgInOutput)
{
	if (SampleAlgInOutput == NULL)
	{
		return;
	}

	// ���׻������쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[BLANKORABSORBABN], Blank_AbsorbAbn(SampleAlgInOutput));

	// WBC���ɱ���--------------------------------------------------------------
	// ��ϸ���쳣
	// ��ϸ���쳣--��ֵ��ϸ��
	SetAlarmFlag(&SampleAlgInOutput->Alarm[WBCABN_LOW], WbcAbn_Low(SampleAlgInOutput));

	// ��ϸ���쳣--�ٷֱ�Ϊ��
	SetAlarmFlag(&SampleAlgInOutput->Alarm[WBCABN_DIFERROE], WbcAbn_FivePerNeg(SampleAlgInOutput) );

	// RBC���ɱ���--------------------------------------------------------------
	// RBC�ֲ��쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[RBCHISTABN],    RbcHistAbn(SampleAlgInOutput) );

	// RBC����
	SetAlarmFlag(&SampleAlgInOutput->Alarm[AGGLUTINATION], RbcAgglutination(SampleAlgInOutput) );

	// RBC˫��
	SetAlarmFlag(&SampleAlgInOutput->Alarm[BIMODALITY],    RbcBimodality(SampleAlgInOutput) );

	// ȱ����
	SetAlarmFlag(&SampleAlgInOutput->Alarm[IRON],          RbcIron(SampleAlgInOutput) );

	// Ѫ�쵰���쳣/����_��������������
	SetAlarmFlag(&SampleAlgInOutput->Alarm[HGBINTERF_HHCHECK], HgbInterf_HHCheck(SampleAlgInOutput) );

	// Ѫ�쵰���쳣/����_MCHC�쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[HGBINTERF_MCHCABN], HgbInterf_MchcAbn(SampleAlgInOutput));

	// PLT���ɱ���--------------------------------------------------------------
	// ѪС��ֲ��쳣
	SetAlarmFlag(&SampleAlgInOutput->Alarm[PLTHISTABN],     PltHistAbn(SampleAlgInOutput) );

	// ѪС��ۼ�
	SetAlarmFlag(&SampleAlgInOutput->Alarm[PLTCLUMPS], PltClumps(SampleAlgInOutput) );
}

// ϵͳ����2
void System_Msg2(stSampleAlgInOutput *SampleAlgInOutput)
{
}

// ״̬����2
void Status_Msg2()
{

}

// ����ģ��2
bool Sample_Msg2(stSampleAlgInOutput *SampleAlgInOutput)
{	
	if (SampleAlgInOutput == NULL)
	{
		return false;
	}

	// ���ɱ���2
	Suspect_Msg2(SampleAlgInOutput);

	// ϵͳ����2
	System_Msg2(SampleAlgInOutput);

	// ״̬����2
	Status_Msg2();

	return true;
}

// ----------------------------------------------------------------------------------------
// �ۺ�ģ��
// ----------------------------------------------------------------------------------------
// �����ۺ�
bool MsgIntegration(stSampleAlgInOutput  *SampleAlgInOutput)
{
	if ( SampleAlgInOutput == NULL)
	{
		return false;
	}

	int i = 0;

	// 1����������
	// 1.1 ����ģʽ�Ա�������
	if (SampleAlgInOutput->AnalyMode == ANALYSISMODE_CRP)
	{
		// WBC��HGBͨ�����б���
		for (i=WBCSYSTEMERROR_BLOCK; i<CRPINCREASE; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}
	}
	else if (SampleAlgInOutput->AnalyMode == ANALYSISMODE_CBC)
	{
		SampleAlgInOutput->Alarm[CRPINCREASE].Degree = 0;
		SampleAlgInOutput->Alarm[CRPINCREASE].Flag   = false;
	}

	// 1.2 ����ģʽ�Ա�������(����/�ʿ��������������쳣����)
	if (  SampleAlgInOutput->WorkMode == WORKMODE_QUALC
		||SampleAlgInOutput->WorkMode == WORKMODE_BLANK
		||SampleAlgInOutput->WorkMode == WORKMODE_CB_FA
		||SampleAlgInOutput->WorkMode == WORKMODE_CB_US
		||SampleAlgInOutput->Alarm[BLANKORABSORBABN].Flag)
	{
		// ���ΰ�ϸ���쳣����
		for (i=WBCABN; i<HGBSYSTEMERROR; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}

		// ���κ�ϸ����ѪС���쳣����
		for (i=RBCHISTABN; i<MAXALARM; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}
	}

	// 1.3 ����ģʽ���α��׻������쳣����
	if (SampleAlgInOutput->WorkMode == WORKMODE_BLANK)
	{
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Degree = 0;
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Flag   = false;
	}

	// 2�������ۺ�
	// 2.1����ϸ���쳣
	int MaxDegree = 0;
	for (i=WBCABN; i<=WBCABN_DIFERROE; i++)
	{
		if (MaxDegree < SampleAlgInOutput->Alarm[i].Degree)
		{
			MaxDegree = SampleAlgInOutput->Alarm[i].Degree;
		}
	}

	SampleAlgInOutput->Alarm[WBCABN].Degree = MaxDegree;
	if ( SampleAlgInOutput->Alarm[WBCABN].Degree > SampleAlgInOutput->Alarm[WBCABN].PosLine)
	{
		SampleAlgInOutput->Alarm[WBCABN].Flag = true;
	}

	// 2.3��Ѫ�쵰���쳣/�����ۺ�
	MaxDegree = 0;
	for (i=HGBINTERF_HHCHECK; i<=HGBINTERF_MCHCABN; i++)
	{
		if (MaxDegree < SampleAlgInOutput->Alarm[i].Degree)
		{
			MaxDegree = SampleAlgInOutput->Alarm[i].Degree;
		}
	}

	SampleAlgInOutput->Alarm[HGBINTERF].Degree = MaxDegree;
	if ( SampleAlgInOutput->Alarm[HGBINTERF].Degree > SampleAlgInOutput->Alarm[HGBINTERF].PosLine)
	{
		SampleAlgInOutput->Alarm[HGBINTERF].Flag = true;
	}

	// 2.4��WBCͨ���¿�
	MaxDegree = 0;
	for (i=WBCSYSTEMERROR_BLOCK_UN; i<=WBCSYSTEMERROR_BLOCK_AC; i++)
	{
		if (MaxDegree < SampleAlgInOutput->Alarm[i].Degree)
		{
			MaxDegree = SampleAlgInOutput->Alarm[i].Degree;
		}
	}

	SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK].Degree = MaxDegree;
	if ( SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK].Degree > SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK].PosLine)
	{
		SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK].Flag = true;
	}

	// 2.5��RBCͨ���¿�
	MaxDegree = 0;
	for (i=RBCSYSTEMERROR_BLOCK_UN; i<=RBCSYSTEMERROR_BLOCK_AC; i++)
	{
		if (MaxDegree < SampleAlgInOutput->Alarm[i].Degree)
		{
			MaxDegree = SampleAlgInOutput->Alarm[i].Degree;
		}
	}

	SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK].Degree = MaxDegree;
	if ( SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK].Degree > SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK].PosLine)
	{
		SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK].Flag = true;
	}

	// 3 ϵͳ�쳣������������
	if (SampleAlgInOutput->Alarm[WBCSYSTEMERROR_BLOCK].Flag || SampleAlgInOutput->Alarm[WBCSYSTEMERROR_HOLEABN].Flag)
	{
		// ���׻������쳣
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Degree = 0;
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Flag   = false;

		// ���ΰ�ϸ���쳣����
		for (i=WBCABN; i<HGBSYSTEMERROR; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}
	}

	if (SampleAlgInOutput->Alarm[RBCSYSTEMERROR_BLOCK].Flag || SampleAlgInOutput->Alarm[RBCSYSTEMERROR_HOLEABN].Flag)
	{
		// ���׻������쳣
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Degree = 0;
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Flag   = false;

		// ���κ�ϸ����ѪС���쳣����
		for (i=RBCHISTABN; i<CRPINCREASE; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}
	}

	if (SampleAlgInOutput->Alarm[HGBSYSTEMERROR].Flag)
	{
		// ���׻������쳣
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Degree = 0;
		SampleAlgInOutput->Alarm[BLANKORABSORBABN].Flag   = false;
		
		// ȱ����
		SampleAlgInOutput->Alarm[IRON].Degree = 0;
		SampleAlgInOutput->Alarm[IRON].Flag   = false;

		// Ѫ�쵰���쳣
		SampleAlgInOutput->Alarm[HGBINTERF].Degree = 0;
		SampleAlgInOutput->Alarm[HGBINTERF].Flag   = false;
		SampleAlgInOutput->Alarm[HGBINTERF_HHCHECK].Degree = 0;
		SampleAlgInOutput->Alarm[HGBINTERF_HHCHECK].Flag   = false;
		SampleAlgInOutput->Alarm[HGBINTERF_MCHCABN].Degree = 0;
		SampleAlgInOutput->Alarm[HGBINTERF_MCHCABN].Flag   = false;
	}

	return true;
}

// ��Ϣ�ۺ�
bool InfoIntegration(stSampleAlgInOutput  *SampleAlgInOutput)
{
	if ( SampleAlgInOutput == NULL)
	{
		return false;
	}

	int i = 0;
	int j = 0;

	// ��ȡ������Ϣ
	static int Alarm2Para[MAXALARM][MAXPARA] = {0};

	static bool flag = false;
	flag = readcsv((char *)"./config/alarm2para.csv", (int*)(Alarm2Para), MAXALARM*MAXPARA);

//	if (!flag) { AfxMessageBox("alarm2para�ļ���ȡʧ�ܣ�"); return false;}

	// 1�����Բ�������
	for (i=0; i<MAXPARA; i++)
	{
		int max = 0;

		for (j=0; j<MAXALARM; j++)
		{
			if ( SampleAlgInOutput->Alarm[j].Flag && Alarm2Para[j][i] > max )
			{
				max = Alarm2Para[j][i];
			}
		}

		if (max == 2)
		{
			SampleAlgInOutput->Para[i].Mark = STAR;
		}
		else if (max == 1)
		{
			SampleAlgInOutput->Para[i].Mark = DOUBT;
		}
		else
		{
			SampleAlgInOutput->Para[i].Mark = NORMAL;
		}
	}

	// 2 �����������
	SampleAlgInOutput->GraphPara = SampleAlgInOutput->GraphPara;

	// 2.1 ��ϸ�������������
	if (SampleAlgInOutput->Para[WBC].Value < 0.5)
	{
		// ��������
		for (i=LYMPERCENT; i<=GRANCOUNT; i++)
		{
			SampleAlgInOutput->Para[i].Mark = STAR;
		}

		// ��������
		for (int i=WBCHISTABN; i<=MIDINCREASE; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}

		// ֱ��ͼ����
		memset(SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist.datas, 0, sizeof(int)*256);

		// �ֽ���
		SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist.lines[0] = 12;
		SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist.lines[1] = 50;
		SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist.lines[2] = 70;
		SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist.lines[3] = 220;
	}

	// 2.2 ��ϸ�������������
	if (SampleAlgInOutput->Para[RBC].Value < 0.2)
	{
		// ��������
		for (i=MCV; i<=RDW_SD; i++)
		{
			SampleAlgInOutput->Para[i].Mark = STAR;
		}

		// ��������
		for (int i=RBCHISTABN; i<=HYPOCHROMIA; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}

		// ֱ��ͼ����
		memset(SampleAlgInOutput->GraphPara.RbcGraphPara.DspHist.datas, 0, sizeof(int)*256);

		// �ֽ��ߴ���
		SampleAlgInOutput->GraphPara.RbcGraphPara.DspHist.lines[0] = 40;
		SampleAlgInOutput->GraphPara.RbcGraphPara.DspHist.lines[1] = 220;
	}

	// 2.3 ѪС�������������
	if (SampleAlgInOutput->Para[PLT].Value < 5)
	{
		// ��������
		for (i=MPV; i<=PLCC; i++)
		{
			SampleAlgInOutput->Para[i].Mark = STAR;
		}

		// ��������
		for (int i=PLTHISTABN; i<=PLTCLUMPS; i++)
		{
			SampleAlgInOutput->Alarm[i].Degree = 0;
			SampleAlgInOutput->Alarm[i].Flag   = false;
		}

		// ֱ��ͼ����
		if (SampleAlgInOutput->Para[PLT].Value < 1)
		{
			memset(SampleAlgInOutput->GraphPara.PltGraphPara.DspHist.datas, 0, sizeof(int)*128);
		}

		// �ֽ��ߴ���
		SampleAlgInOutput->GraphPara.PltGraphPara.DspHist.lines[0] = 2;
		SampleAlgInOutput->GraphPara.PltGraphPara.DspHist.lines[1] = 52;
	}

	// 3 ģʽ�Բ�������
	if (SampleAlgInOutput->AnalyMode == ANALYSISMODE_CRP)
	{
		// ����
		for (int i=WBC; i<=PLCC; i++)
		{
			SampleAlgInOutput->Para[i].Mark = BLANK;
		}

		// ͼ��
		memset(&SampleAlgInOutput->GraphPara.WbcGraphPara.DspHist, 0, sizeof(stHist));
		memset(&SampleAlgInOutput->GraphPara.RbcGraphPara.DspHist, 0, sizeof(stHist));
		memset(&SampleAlgInOutput->GraphPara.PltGraphPara.DspHist, 0, sizeof(stHist));
	}
	else if (SampleAlgInOutput->AnalyMode == ANALYSISMODE_CBC)
	{
		// ����
		for (int i=CRP_NM; i<=CRP_HS; i++)
		{
			SampleAlgInOutput->Para[i].Mark = BLANK;
		}
	}

	// 4 ��ʾ��Χ�Բ�������
	if (SampleAlgInOutput->AnalyMode & ANALYSISMODE_CBC)
	{
		if (SampleAlgInOutput->Para[WBC].Value < 0.0 || SampleAlgInOutput->Para[WBC].Value > 999.99)
		{
			SampleAlgInOutput->Para[WBC].Mark         = HIGH;
			SampleAlgInOutput->Para[GRANCOUNT].Mark   = HIGH;
			SampleAlgInOutput->Para[LYMCOUNT ].Mark   = HIGH;
			SampleAlgInOutput->Para[MIDCOUNT ].Mark   = HIGH;
			SampleAlgInOutput->Para[GRANPERCENT].Mark = HIGH;
			SampleAlgInOutput->Para[LYMPERCENT ].Mark = HIGH;
			SampleAlgInOutput->Para[MIDPERCENT ].Mark = HIGH;
		}

		if (  SampleAlgInOutput->Para[RBC].Value < 0.0 || SampleAlgInOutput->Para[RBC].Value > 9.99
			||SampleAlgInOutput->Para[HCT].Value < 0.0 || SampleAlgInOutput->Para[HCT].Value > 99.9
			)
		{
			SampleAlgInOutput->Para[RBC].Mark    = HIGH;
			SampleAlgInOutput->Para[HCT].Mark    = HIGH;
			SampleAlgInOutput->Para[MCV].Mark    = HIGH;
			SampleAlgInOutput->Para[MCH].Mark    = HIGH;
			SampleAlgInOutput->Para[MCHC].Mark   = HIGH;
			SampleAlgInOutput->Para[RDW_CV].Mark = HIGH;
			SampleAlgInOutput->Para[RDW_SD].Mark = HIGH;
		}

		if (SampleAlgInOutput->Para[HGB].Value < 0.0 || SampleAlgInOutput->Para[HGB].Value > 300.0)
		{
			SampleAlgInOutput->Para[HGB].Mark    = HIGH;
			SampleAlgInOutput->Para[MCH].Mark    = HIGH;
			SampleAlgInOutput->Para[MCHC].Mark   = HIGH;
		}

		if (SampleAlgInOutput->Para[PLT].Value < 0.0 || SampleAlgInOutput->Para[PLT].Value > 9999)
		{
			SampleAlgInOutput->Para[PLT ].Mark = HIGH;
			SampleAlgInOutput->Para[MPV ].Mark = HIGH;
			SampleAlgInOutput->Para[PDW ].Mark = HIGH;
			SampleAlgInOutput->Para[PCT ].Mark = HIGH;
			SampleAlgInOutput->Para[PLCR].Mark = HIGH;
			SampleAlgInOutput->Para[PLCC].Mark = HIGH;
		}
	}
	
	if (SampleAlgInOutput->AnalyMode & ANALYSISMODE_CRP)
	{
		if (SampleAlgInOutput->Para[CRP_NM].Value < 0.0 || SampleAlgInOutput->Para[CRP_NM].Value > 999.9)
		{
			SampleAlgInOutput->Para[CRP_NM].Mark  = HIGH;
			SampleAlgInOutput->Para[CRP_HS].Mark  = HIGH;
		}
	}
	
	return true;
}

// �ۺ�ģ��
bool Integration(stSampleAlgInOutput *SampleAlgInOutput)
{
	if ( SampleAlgInOutput == NULL)
	{
		return false;
	}

	// �����ۺ�
	MsgIntegration(SampleAlgInOutput);

	// ��Ϣ�ۺ�
	InfoIntegration(SampleAlgInOutput);

	// ��չģ��
	ExtendAlgo();

	return true;
}

// ��չ�㷨
bool ExtendAlgo()
{
	return true;
}

// ----------------------------------------------------------------------------------------
// ϵͳ�쳣��ģ��
// ----------------------------------------------------------------------------------------
// WBCϵͳ�쳣С�׵�ѹ�쳣
int Wbc_SystemErrorHoleAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double HoleLowTh  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_WbcSystemErrorHoleAbn_HoleLowTh;

	// ��������
	double HoleVol    = SampleAlgInOutput->FeaturePara.WbcFeaturePara.MinHoleVol * 5.0 / 4096;

	// QFlag����
	int QFlag = (HoleVol < HoleLowTh) ? 100 : 0;

	return QFlag;
}

// WBC�¿�(���ɽ���)
int Wbc_SystemErrorBlockUN(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ͨ��С�׵�ѹ����--------------------------------------------------------------------
	// ���ò���
	double HoleHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_WbcSystemErrorBlockUN_HoleHighTh;

	// ��������
	double HoleVol    = SampleAlgInOutput->FeaturePara.WbcFeaturePara.MaxHoleVol * 5.0 / 4096;

	// QFlag����
	int QFlag = (HoleVol > HoleHighTh) ? 100 : 0;

	// ͨ�����������ȶ��Ա���--------------------------------------------------------------
	// ���ò���
	double NegAreaTh = 90; 
	double NegPeakTh = 10;

	double NegAreaTh1 = 10; 
	double NegAreaTh2 = 60; 
	double NpsCVTh_N  = 0.25;

	double PosAreaTh = 90; 
	double PosPeakTh = 10;

	double PosAreaTh1 = 10; 
	double PosAreaTh2 = 60; 
	double NpsCVTh_P  = 0.25;

	// ��������
	double NpsCV = SampleAlgInOutput->FeaturePara.WbcFeaturePara.Cv_Nps;
	int NegArea  = SampleAlgInOutput->FeaturePara.WbcFeaturePara.NegArea;
	int NegPeak  = SampleAlgInOutput->FeaturePara.WbcFeaturePara.NegPeak;
	int PosArea  = SampleAlgInOutput->FeaturePara.WbcFeaturePara.PosArea;
	int PosPeak  = SampleAlgInOutput->FeaturePara.WbcFeaturePara.PosPeak;

	// ��������С
	double dQFlag1 = NegPeak + NegArea*NegPeakTh/NegAreaTh - NegPeakTh;

	double dQFlag2 = NpsCV + NegArea*NpsCVTh_N/NegAreaTh2 - NpsCVTh_N;
	if (NegArea < NegAreaTh1)
	{
		dQFlag2 = 0;
	}

	dQFlag1 = dQFlag1 > dQFlag2 ? dQFlag1 : dQFlag2;

	// ���������
	double dQFlag3 = PosPeak + PosArea*PosPeakTh/PosAreaTh - PosPeakTh;
	double dQFlag4 = NpsCV + PosArea*NpsCVTh_P/PosAreaTh2 - NpsCVTh_P;
	if (NegArea < PosAreaTh1)
	{
		dQFlag4 = 0;
	}

	dQFlag3 = dQFlag3 > dQFlag4 ? dQFlag3 : dQFlag4;

	double dQFlag = dQFlag1 > dQFlag3 ? dQFlag1 : dQFlag3;

	QFlag = dQFlag > 0 ? 100 : 0;

	return QFlag;
}

// WBC�¿�(�ɽ���)
int Wbc_SystemErrorBlockAC(stSampleAlgInOutput *SampleAlgInOutput)
{
	int QFlag = 0;

	return QFlag;
}

// RBCϵͳ�쳣С�׵�ѹ�쳣
int Rbc_SystemErrorHoleAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double HoleLowTh  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcSystemErrorHoleAbn_HoleLowTh;

	// ��������
	double HoleVol    = SampleAlgInOutput->FeaturePara.WbcFeaturePara.MinHoleVol * 5.0 / 4096;

	// QFlag����
	int QFlag = (HoleVol < HoleLowTh) ? 100 : 0;

	return QFlag;
}

// RBC�¿�(���ɽ���)
int Rbc_SystemErrorBlockUN(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ͨ��С�׵�ѹ����--------------------------------------------------------------------
	// ���ò���
	double HoleHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcSystemErrorBlockUN_HoleHighTh;

	// ��������
	double HoleVol    = SampleAlgInOutput->FeaturePara.RbcFeaturePara.MaxHoleVol * 5.0 / 4096;

	// QFlag����
	int QFlag = (HoleVol > HoleHighTh) ? 100 : 0;

	// ͨ�����������ȶ��Ա���--------------------------------------------------------------
	// ���ò���
	double NegAreaTh = 110; 
	double NegPeakTh = 12;

	// ��������
	int NegArea = SampleAlgInOutput->FeaturePara.RbcFeaturePara.NegArea;
	int NegPeak = SampleAlgInOutput->FeaturePara.RbcFeaturePara.NegPeak;

	double dQFlag = NegPeak + NegArea*NegPeakTh/NegAreaTh - NegPeakTh;

	QFlag = dQFlag > 0 ? 100 : 0;

	return QFlag;
}

// RBC�¿�(�ɽ���)
int Rbc_SystemErrorBlockAC(stSampleAlgInOutput *SampleAlgInOutput)
{
	int QFlag = 0;

	return QFlag;
}

// HGBϵͳ�쳣
int Hgb_SystemError(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double HgbBlankLowTh  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_HgbSystemError_HgbBlankLowTh;
	double HgbBlankHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_HgbSystemError_HgbBlankHighTh;

	// ��������
	double HgbBlankVol    = SampleAlgInOutput->FeaturePara.HgbFeaturePara.BlankVol * 5.0 / 4096;

	// QFlag����
	int QFlag = 0;

	if (HgbBlankVol < HgbBlankLowTh || HgbBlankVol > HgbBlankHighTh)
	{
		QFlag = 100;
	}

	return QFlag;
}

// ----------------------------------------------------------------------------------------
// �����б��ӱ���ģ��
// ----------------------------------------------------------------------------------------
// ���׻������쳣
int Blank_AbsorbAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double WbcTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_BackGroundAbsorbAbn_WbcTh;
	double RbcTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_BackGroundAbsorbAbn_RbcTh;
	double PltTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_BackGroundAbsorbAbn_PltTh;
	double HgbTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_BackGroundAbsorbAbn_HgbTh;

	// ��������
	double dWbc = SampleAlgInOutput->Para[WBC].Value;
	double dRbc = SampleAlgInOutput->Para[RBC].Value;
	double dPlt = SampleAlgInOutput->Para[PLT].Value;
	double dHgb = SampleAlgInOutput->Para[HGB].Value;

	int QFlag = (dWbc <= WbcTh && dRbc <= RbcTh && dPlt <= PltTh && dHgb <= HgbTh) ? 100 : 0;

	return QFlag;
}

// ��ϸ���쳣--��ֵ��ϸ��
int WbcAbn_Low(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double WbcTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_WbcAbn_Low_WbcTh;

	// ��������
	double dWbc = SampleAlgInOutput->Para[WBC].Value;

	// QFlag����
	int QFlag = (dWbc<WbcTh) ? 100 : 0;

	return QFlag;
}

// ��ϸ���쳣--����%Ϊ��
int WbcAbn_FivePerNeg(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���

	// ��������
	double GranPer = SampleAlgInOutput->Para[GRANPERCENT].Value;
	double LymPer  = SampleAlgInOutput->Para[LYMPERCENT ].Value;
	double MidPer  = SampleAlgInOutput->Para[MIDPERCENT ].Value;

	// QFlag����
	int QFlag = 0;
	
	if (GranPer<0 || LymPer<0 || MidPer<0)
	{
		QFlag = 100;
	}

	return QFlag;
}

// ��ϸ��ֱ��ͼ�쳣
int RbcHistAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double SkewnessLowTh  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcHistAbn_SkewnessLowTh;
	double SkewnessHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcHistAbn_SkewnessHighTh;
	double KurtosisLowTh  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcHistAbn_KurtosisLowTh;
	double KurtosisHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_RbcHistAbn_KurtosisHighTh;

	// ��������
	double Skewness   = SampleAlgInOutput->FeaturePara.RbcFeaturePara.Skewness;
	double Kurtosis   = SampleAlgInOutput->FeaturePara.RbcFeaturePara.Kurtosis;

	// QFlag����
	int QFlag = 0;

	if (  Skewness > SkewnessHighTh || Skewness < SkewnessLowTh
		||Kurtosis > KurtosisHighTh || Kurtosis < KurtosisLowTh
		)
	{
		 QFlag = 100;
	}

	return QFlag;
}

// ˫���Ա���
int RbcBimodality(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double dRDW_CVLowTh   = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Bimodality_Rdw_cvLowTh;
	double dKurtosisLowTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Bimodality_KurtosisLowTh;

	// ��������
	double dRDW_CV   = SampleAlgInOutput->Para[RDW_CV].Value;
	double dKurtosis = SampleAlgInOutput->FeaturePara.RbcFeaturePara.Kurtosis;

	// QFlag����
	double dQFlag1 = pow(40.0, dRDW_CV  /dRDW_CVLowTh  ) / 40;
	double dQFlag2 = pow(40.0, -dKurtosis/dKurtosisLowTh) / 40;

	dQFlag1 = min(dQFlag1, dQFlag2);

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// ��ϸ����������
int RbcAgglutination(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	int    RbcNumLowTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Agglutination_RbcNumLowTh;
	double RbcPerLowTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Agglutination_RbcPerLowTh;
	double Line_Slope  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Agglutination_Slope      ;
	double Line_Inter  = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Agglutination_Intercept  ;

	// ��������
	int    RbcAggNum = SampleAlgInOutput->FeaturePara.RbcFeaturePara.RbcAggNum;
	double RbcAggPer = SampleAlgInOutput->FeaturePara.RbcFeaturePara.RbcAggPer;

	// QFlag����
	double dQFlag1 = (RbcNumLowTh>EPSINON) ? 1.0*RbcAggNum/RbcNumLowTh : 0.0;
	double dQFlag2 = (RbcPerLowTh>EPSINON) ? 1.0*RbcAggPer/RbcPerLowTh : 0.0;
	double dQFlag3 = (Line_Slope*RbcAggNum+Line_Inter<RbcAggPer) ? 0.0 : 100.0;

	dQFlag1 = min(min(dQFlag1, dQFlag2), dQFlag3);

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// ȱ���Ա���
int RbcIron(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double MchcLowTh   = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Iron_MchcLowTh;  
	double McvLowTh    = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Iron_McvLowTh;   
	double RdwcvHighTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_Iron_RdwcvHighTh;

	// ��������
	double Mchc  = SampleAlgInOutput->Para[MCHC].Value;
	double Mcv   = SampleAlgInOutput->Para[MCV].Value;
	double Rdwcv = SampleAlgInOutput->Para[RDW_CV].Value;

	// QFlag����
	double dQFlag1 = (Mchc>EPSINON)      ? 1.0*MchcLowTh/Mchc : 0.0;
	double dQFlag2 = (Mcv >EPSINON)      ? 1.0*McvLowTh /Mcv  : 0.0;
	double dQFlag3 = RdwcvHighTh>EPSINON ? 1.0*Rdwcv/RdwcvHighTh:0.0;

	dQFlag1 = min(min(dQFlag1, dQFlag2), dQFlag3);

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// Ѫ�쵰���쳣���š���MCHC�쳣
int HgbInterf_MchcAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double MchcTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_HgbMchcAbn_MchcTh;
	
	// ��������
	double Mchc   = SampleAlgInOutput->Para[MCHC].Value;

	// QFlag����
	double dQFlag1 = (MchcTh>EPSINON) ? 1.0*Mchc/MchcTh : 0.0;

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// Ѫ�쵰���쳣���š�����������������
int HgbInterf_HHCheck(stSampleAlgInOutput *SampleAlgInOutput)
{
	int QFlag = 0;

	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// ѪС��ֱ��ͼ�쳣
int PltHistAbn(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	double PltUpTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_PltHistAbn_PltUpTh;

	// ��������
	double PltUp   = SampleAlgInOutput->FeaturePara.PltFeaturePara.I_Plt_UP;

	// QFlag����
	double dQFlag1  = (PltUpTh>EPSINON) ? 1.0*PltUp/PltUpTh : 0.0;

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}

// ѪС��ۼ�����
int PltClumps(stSampleAlgInOutput *SampleAlgInOutput)
{
	// ���ò���
	int    PltTh   = SampleAlgInOutput->SampleConfig.Alg_S_Msg_PltClumps_PltTh;
	double MpvTh   = SampleAlgInOutput->SampleConfig.Alg_S_Msg_PltClumps_MpvTh;
	double PltUpTh = SampleAlgInOutput->SampleConfig.Alg_S_Msg_PltClumps_PltUpTh;	

	// ��������
	double dPlt    = SampleAlgInOutput->Para[PLT].Value;
	double Mpv     = SampleAlgInOutput->Para[MPV].Value;
	double PltUp   = SampleAlgInOutput->FeaturePara.PltFeaturePara.I_Plt_UP;

	// QFlag����
	double dQFlag1 = (dPlt>EPSINON)    ? 1.0*PltTh/dPlt    : 0.0;
	double dQFlag2 = (MpvTh>EPSINON)   ? 1.0*Mpv/MpvTh     : 0.0;
	double dQFlag3 = (PltUpTh>EPSINON) ? 1.0*PltUp/PltUpTh : 0.0;

	dQFlag1 = min(min(dQFlag1, dQFlag2), dQFlag3);

	int QFlag =(int)(40*dQFlag1 + 0.5);
	limit<int>(&QFlag, 0, 100);
	return QFlag;
}