#include "alg_chan_rbc.h"
#include "alg_resource.h"

#include <string.h>
#include <math.h>

/*******************************************************************
// RBCͨ���źŴ���
********************************************************************/
// Rbcֱ��ͼ�źŴ���
bool RbcHistProcess(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcInput == NULL || RbcOutput == NULL)
	{
		return false;
	}

	// ���ò���
	int Alg_R_Sig_DsfHistSmoothStep  = RbcInput->RbcConfigPara.Alg_R_Sig_DsfHistSmoothStep;
	int Alg_R_Sig_DsfHistSmoothDelta = RbcInput->RbcConfigPara.Alg_R_Sig_DsfHistSmoothDelta;

	// 1��RBC������������
	RbcOutput->GraphPara.DspHist.datalen = 256;
	RbcOutput->GraphPara.DspHist.linelen = 2;

	RbcDSF(RbcInput->RbcConfigPara, &(RbcOutput->GraphPara.DspHist), RbcOutput->FeaturePara.ImpdCellList);

	// 2��RBC����ֱ��ͼƽ��
	curvesmooth_gauss<int, int>(RbcOutput->GraphPara.DspHist.datas,  
		RbcOutput->GraphPara.DspHist.datas,
		Rbc_Hist_DataLen,
		Alg_R_Sig_DsfHistSmoothStep,
		Alg_R_Sig_DsfHistSmoothDelta);

	// 3��RBCԭʼֱ��ͼ����
	RbcOutput->GraphPara.OrgHist.datalen = 256;
	RbcOutput->GraphPara.OrgHist.linelen = 2;

	gethist(&(RbcOutput->GraphPara.OrgHist), RbcOutput->FeaturePara.ImpdCellList);

	return true;
}

// RbcDsf����
bool RbcDSF(stRbcConfigPara RbcConfigPara, stHist *pHist, stImpdCellList CellList)
{
	if (pHist == NULL)
	{
		return false;
	}

	memset(pHist->datas, 0, sizeof(pHist->datas));

	const int    Dsf_Wide_len  = 60;
	const double Dsf_Pulse_per = 0.66;

	int  Alg_R_Dsf_RbcPeakMinTh  = RbcConfigPara.Alg_R_Dsf_RbcPeakMinTh;
	int  Alg_R_Dsf_PulseNumMinTh = RbcConfigPara.Alg_R_Dsf_PulseNumMinTh;

	int i = 0;
	int j = 0;

	int    rfreq[Dsf_Wide_len][Rbc_Hist_DataLen];
	memset(rfreq, 0, sizeof(int)*Dsf_Wide_len*Rbc_Hist_DataLen);

	int    rpct [Dsf_Wide_len] = {0};
	double rpcts[Dsf_Wide_len] = {0};

	int ValidNum  = 0;

	// ������ȡ��߶ȷֲ�ֱ��ͼ
	for (i=0; i<CellList.CellNum; i++)
	{
		if (CellList.pImpdPulse[i].PeakValue > Alg_R_Dsf_RbcPeakMinTh)
		{
			int index = CellList.pImpdPulse[i].PeakValue/16;
			int width = CellList.pImpdPulse[i].PriWidth+CellList.pImpdPulse[i].SubWidth;
			bool flag = false;

			if (CellList.pImpdPulse[i].MPulseFlag >= 1)
			{
				flag = true;
			}

			if (width >= 0 && width < Dsf_Wide_len && !flag)
			{
				rfreq[width][index]++;

				ValidNum++;
			}
		}
	}

	// ͳ����������ֱ�Ӽ���
	if (ValidNum < Alg_R_Dsf_PulseNumMinTh)
	{
		for (i=0; i<Rbc_Hist_DataLen; i++)
		{
			for (j=0; j<Dsf_Wide_len; j++)
			{
				pHist->datas[i] += rfreq[j][i];
			}
		}

		return true;
	}

	// dsf����������vline
	for (i=0; i<Dsf_Wide_len; i++)
	{
		for (j=0; j<Rbc_Hist_DataLen; j++)
		{
			rpct[i] += rfreq[i][j];
		}
	}

	rpcts[0] = rpct[0]/ValidNum;
	for (i=1; i<Dsf_Wide_len; i++)
	{
		rpcts[i] = 1.0*rpct[i]/ValidNum; 
	}

	int    sline = 0;
	int    vline = 0;
	double EqLen = 1.0*Dsf_Wide_len;
	double templ = 0.0;
	double dtemp = 0.0;

	int    maxpos =0;

	for (i=0; i<Dsf_Wide_len; i++)
	{
		if (dtemp < rpcts[i])
		{
			dtemp = rpcts[i];
			maxpos = i;
		}
	}

	for (i=0; i<maxpos+2; i++)
	{
		dtemp = 0.0;

		for (j=i; j<Dsf_Wide_len; j++)
		{
			if (dtemp + rpcts[j] > Dsf_Pulse_per)
			{
				templ = (j-i-1) + (Dsf_Pulse_per - dtemp)/rpcts[j];
				break;
			}
			else
			{
				dtemp += rpcts[j];
			}
		}

		if (EqLen > templ)
		{
			EqLen = templ;

			sline = i;
		}
	}

	vline = sline + (int)floor(EqLen);

	// dsfֱ��ͼ����
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		for (j=sline; j<=vline; j++)
		{
			pHist->datas[i] += rfreq[j][i];
		}
	}

	// dsfֱ��ͼ����
	double sumper = 0.0;

	for (j=sline; j<=vline; j++)
	{
		sumper += rpcts[j];
	}

	if (sumper + rpcts[vline+1] < Dsf_Pulse_per)
	{
		return true;
	}

	double rp = 1.0*(Dsf_Pulse_per-sumper)/(rpcts[vline+1]);

	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		pHist->datas[i] += (int)(rp*rfreq[vline+1][i]);
	}

	return true;
}

// RbcDsf����
bool RbcDSF1(stRbcConfigPara RbcConfigPara, stHist *pHist, stImpdCellList CellList)
{
	if (pHist == NULL)
	{
		return false;
	}

	memset(pHist->datas, 0, sizeof(pHist->datas));

	const int    Dsf_Wide_len  = 60;
	const double Dsf_Pulse_per = 0.4;

	int  Alg_R_Dsf_RbcPeakMinTh  = RbcConfigPara.Alg_R_Dsf_RbcPeakMinTh;
	int  Alg_R_Dsf_PulseNumMinTh = RbcConfigPara.Alg_R_Dsf_PulseNumMinTh;

	int i = 0;
	int j = 0;

	int    rfreq[Dsf_Wide_len][Rbc_Hist_DataLen];
	memset(rfreq, 0, sizeof(int)*Dsf_Wide_len*Rbc_Hist_DataLen);

	int    rpct [Dsf_Wide_len] = {0};
	double rpcts[Dsf_Wide_len] = {0};

	int ValidNum  = 0;

	// ������ȡ��߶ȷֲ�ֱ��ͼ
	for (i=0; i<CellList.CellNum; i++)
	{
		if (CellList.pImpdPulse[i].PeakValue > Alg_R_Dsf_RbcPeakMinTh)
		{
			int index = CellList.pImpdPulse[i].PeakValue/16;
			//int width = CellList.pImpdPulse[i].FullWidth;
			int width = CellList.pImpdPulse[i].PriWidth+CellList.pImpdPulse[i].SubWidth;
			bool flag = false;

			if (CellList.pImpdPulse[i].MPulseFlag >= 1)
			{
				flag = true;
			}

			if (width >= 0 && width < Dsf_Wide_len && !flag)
			{
				rfreq[width][index]++;

				ValidNum++;
			}
		}
	}

	// ͳ����������ֱ�Ӽ���
	if (ValidNum < Alg_R_Dsf_PulseNumMinTh)
	{
		for (i=0; i<Rbc_Hist_DataLen; i++)
		{
			for (j=0; j<Dsf_Wide_len; j++)
			{
				pHist->datas[i] += rfreq[j][i];
			}
		}

		return true;
	}

	// dsf����������vline
	for (i=0; i<Dsf_Wide_len; i++)
	{
		for (j=0; j<Rbc_Hist_DataLen; j++)
		{
			rpct[i] += rfreq[i][j];
		}
	}

	rpcts[0] = rpct[0]/ValidNum;
	for (i=1; i<Dsf_Wide_len; i++)
	{
		rpcts[i] += rpcts[i-1]+1.0*rpct[i]/ValidNum; 
	}

	if (rpcts[Dsf_Wide_len-1] < Dsf_Pulse_per)
	{
		for (i=0; i<Rbc_Hist_DataLen; i++)
		{
			for (j=0; j<Dsf_Wide_len; j++)
			{
				pHist->datas[i] += rfreq[j][i];
			}
		}

		return true;
	}

	int vline = 0;
	for (i=0; i<Dsf_Wide_len; i++)
	{
		if (rpcts[i] >= Dsf_Pulse_per)
		{
			vline = i-1;
			break;
		}
	}

	// dsfֱ��ͼ����
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		for (j=0; j<=vline; j++)
		{
			pHist->datas[i] += rfreq[j][i];
		}
	}

	// dsfֱ��ͼ����
	double rp = 1.0*(Dsf_Pulse_per-rpcts[vline])/(rpcts[vline+1]-rpcts[vline]);

	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		pHist->datas[i] += (int)(rp*rfreq[vline+1][i]);
	}

	return true;
}

/*******************************************************************
// Rbcͨ����������
********************************************************************/
bool RbcParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcInput  == NULL || RbcOutput == NULL)
	{
		return false;
	}

	// 1 ֱ��ͼ�ֽ�������
	BuildRbcHist(RbcInput, RbcOutput);

	// 2 �����������
	{
		// 2.1 ����̬��������
		RbcNoShapeParaCal(RbcInput, RbcOutput);

		// 2.2 ��̬��������
		RbcShapeParaCal(RbcInput, RbcOutput);
	}

	// 3 ������������
	RbcFeatureParaCal(RbcInput, RbcOutput);

	return true;
}

// RBCֱ��ͼ����
bool BuildRbcHist(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcOutput == NULL)
	{
		return false;
	}

	// 1 ��ʾֱ��ͼ����

	// 2 ��һ�ֽ�������
	int firstline = RbcOutput->ServicePara.RbcPltDivideLine;

	// 3 �ڶ��ֽ�������
	int secondline = 220;

	for(int i=secondline; i>1; i--)
	{
		if (   RbcOutput->GraphPara.DspHist.datas[i]> 0
			&& RbcOutput->GraphPara.DspHist.datas[i]<=RbcOutput->GraphPara.DspHist.datas[i-1] )
		{
			secondline = i;
			break;
		}
	}

	if (secondline < 230)
	{
		secondline = 230;
	}

	RbcOutput->GraphPara.OrgHist.lines[0] = firstline; 
	RbcOutput->GraphPara.DspHist.lines[0] = firstline; 

	RbcOutput->GraphPara.OrgHist.lines[1] = secondline;
	RbcOutput->GraphPara.DspHist.lines[1] = secondline;

	return true;
}

// RBC���Ӳ���
int RbcCompensation(int RbcTotal ,double dExpCoff)
{
	// one
	double tmpdouble     = dExpCoff*RbcTotal*0.000001;
	double tmpRbcCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	double tmpRbcTotal   = RbcTotal/tmpRbcCompFac;

	// two
	tmpdouble      = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	tmpRbcTotal    = RbcTotal/tmpRbcCompFac;

	// three
	tmpdouble      = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	tmpRbcTotal    = RbcTotal/tmpRbcCompFac;

	// four
	tmpdouble      = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;

	int RbcTotalNum   = (int)(RbcTotal/tmpRbcCompFac);

	return RbcTotalNum;
}

// RBC����̬�������㣨RBC��
bool RbcNoShapeParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcInput == NULL || RbcOutput == NULL)
	{
		return false;
	}

	int     SubBackGround = RbcInput->RbcConfigPara.Alg_R_Cal_SubBackGround;
	double  fRbcExpCoff   = RbcInput->RbcConfigPara.Alg_R_Cal_dRbcExpCoff;

	int    i = 0;

	// 1������RBC������
	// 1.1������RBCʶ��������
	int  RbcTotal = 0;

	for (i=RbcOutput->GraphPara.OrgHist.lines[0]; i<=RbcOutput->GraphPara.OrgHist.lines[1]; i++)
	{
		RbcTotal += RbcOutput->GraphPara.OrgHist.datas[i];
	}

	// 1.2�����Ӳ���
	// ʱ�����Ӳ�������
	double MeasureTime   = RbcInput->MeasureTime;
	double TraverseTime  = RbcOutput->FeaturePara.TraverseTime;

	if (TraverseTime > EPSINON)
	{
		RbcTotal = (int)(1.0*RbcTotal/TraverseTime*MeasureTime +0.5);
	}

	// ���Ӳ���
	RbcTotal  = RbcCompensation(RbcTotal, fRbcExpCoff);

	// ������
	RbcTotal -= SubBackGround;

	RbcOutput->ServicePara.RbcTotalNum = RbcTotal;

	// 1.3��Rbcֵ����
	double dRbc     = 0.0;
	double Dilution = RbcInput->Dilution;
	double Volume   = RbcInput->Volume;

	if (Volume > EPSINON)
	{
		dRbc = RbcTotal * Dilution / Volume / 1000000;
	}

	if (dRbc < EPSINON)
	{
		dRbc = 0.0;
	}

	RbcOutput->ReportPara.Rbc = dRbc;

	return true;
}

// RBC��̬�������㣨MCV/RDW_SD/RDW_CV��
bool RbcShapeParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcInput == NULL || RbcOutput == NULL)
	{
		return false;
	}

	double dMcvAdjustCoff   = RbcInput->RbcConfigPara.Alg_R_Cal_dMcvAdjustCoff;
	double dRdwBaseLinePer  = RbcInput->RbcConfigPara.Alg_R_Cal_RdwBaseLinePer;
	double dRdwsdAdjustCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRdwSdAdjustCoff;
	double dRdwCvAdjustCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRdwCvAdjustCoff;

	int i = 0;

	int FirstLine  = RbcOutput->GraphPara.DspHist.lines[0];
	int SecondLine = RbcOutput->GraphPara.DspHist.lines[1];

	// MCV����
	double dMcv = 0;

	double dSumDen = 0.0;
	double dSumNum = 0.0;
	for (i=FirstLine; i<=SecondLine; i++)
	{
		dSumDen +=   RbcOutput->GraphPara.DspHist.datas[i];
		dSumNum += i*RbcOutput->GraphPara.DspHist.datas[i];
	}

	if (dSumDen > EPSINON)
	{
		dMcv = dMcvAdjustCoff*dSumNum/dSumDen*320/Rbc_Hist_DataLen;
	}

	RbcOutput->ReportPara.Mcv = dMcv;

	// RDW_CV/RDW_SD����
	double dRdw_sd = 0.0;
	double dRdw_cv = 0.0;
	double dmean   = 0.0;
	double dSD     = 0.0;

	// 1 ����ֱ��ͼ����ȡ5%��ֵ���²��֣�
	int RbcTmpHist[Rbc_Hist_DataLen] = {0};

	int  Peaky = 0;
	for (i=FirstLine; i<=SecondLine; i++)
	{	
		if (Peaky < RbcOutput->GraphPara.DspHist.datas[i])
		{
			Peaky = RbcOutput->GraphPara.DspHist.datas[i];
		}
	}

	for (i=FirstLine; i<=SecondLine; i++)
	{
		if (RbcOutput->GraphPara.DspHist.datas[i] > dRdwBaseLinePer*Peaky)
		{
			RbcTmpHist[i] = RbcOutput->GraphPara.DspHist.datas[i];
		}
	}

	// 2 ���ֵ
	dSumDen = 0;
	dSumNum = 0;

	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		dSumDen  +=   RbcTmpHist[i];
		dSumNum  += i*RbcTmpHist[i];
	}

	if (dSumDen > 0)
	{
		dmean = dSumNum/dSumDen;
	}

	// 3 �󷽲�
	dSumNum = 0;
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		dSumNum += (i-dmean)*(i-dmean)*RbcTmpHist[i];
	}

	if (dSumDen > 0)
	{
		dSD = dSumNum/dSumDen;
	}

	// Rdw_Sd/Rdw_Cv����
	dRdw_sd = dRdwsdAdjustCoff*sqrt(dSD)*320/256;

	if (dmean > 0)
	{
		dRdw_cv = dRdwCvAdjustCoff*sqrt(dSD)/dmean;
	}

	RbcOutput->ReportPara.Rdw_sd = dRdw_sd;
	RbcOutput->ReportPara.Rdw_cv = dRdw_cv;

	return true;
}

// ƫ�ȼ��㣨Skewness��
double SkewnessCal(stHist DspHist, double RdwBaseLinePer)
{
	double Skewness = 0.0; 

	int FirstLine  = DspHist.lines[0];
	int SecondLine = DspHist.lines[1];

	int    i        = 0;
	double fSumDen  = 0.0;
	double fSumNum  = 0.0;
	double fmean    = 0.0;
	double fSD      = 0.0;

	// 1 ����ֱ��ͼ����ȡ5%��ֵ���²��֣�
	int RbcTmpHist[Rbc_Hist_DataLen] = {0};

	int   Peaky = 0;
	for (i=FirstLine; i<=SecondLine; i++)
	{
		if (Peaky < DspHist.datas[i])
		{
			Peaky = DspHist.datas[i];
		}
	}

	for (i=FirstLine; i<=SecondLine; i++)
	{
		if (DspHist.datas[i] > RdwBaseLinePer*Peaky)
		{
			RbcTmpHist[i] =DspHist.datas[i];
		}
	}

	// 2 ���ֵ
	fSumDen = 0;
	fSumNum = 0;

	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumDen  +=   RbcTmpHist[i];
		fSumNum  += i*RbcTmpHist[i];
	}

	if (fSumDen > 0)
	{
		fmean = fSumNum/fSumDen;
	}

	// 3 ���׼��
	fSumNum = 0;
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumNum += (i-fmean)*(i-fmean)*RbcTmpHist[i];
	}

	if (fSumDen > EPSINON)
	{
		fSD = sqrt(fSumNum/fSumDen);
	}

	// 4 ��Skewness
	fSumNum = 0.0;
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumNum += pow((i-fmean),3)*RbcTmpHist[i];
	}

	if (  fSD     > EPSINON
		&&fSumDen > EPSINON)
	{
		Skewness = fSumNum/pow(fSD,3)/fSumDen;
	}

	return Skewness;
}

// �Ͷȼ��㣨Kurtosis��
double KurtosisCal(stHist DspHist, double fRdwBaseLinePer)
{
	double Kurtosis = 0.0; 

	int FirstLine  = DspHist.lines[0];
	int SecondLine = DspHist.lines[1];

	int    i        = 0;
	double fSumDen  = 0.0;
	double fSumNum  = 0.0;
	double fmean    = 0.0;
	double fSD      = 0.0;

	// 1 ����ֱ��ͼ����ȡ20%��ֵ���²��֣�
	int RbcTmpHist[Rbc_Hist_DataLen] = {0};

	int Peaky = 0;
	for (i=FirstLine; i<=SecondLine; i++)
	{		
		if (Peaky < DspHist.datas[i])	
		{		
			Peaky = DspHist.datas[i];	
		}
	}

	for (i=FirstLine; i<=SecondLine; i++)
	{
		if (DspHist.datas[i] > fRdwBaseLinePer*Peaky)
		{
			RbcTmpHist[i] =DspHist.datas[i];
		}
	}

	// 2 ���ֵ
	fSumDen = 0;
	fSumNum = 0;

	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumDen  +=   RbcTmpHist[i];
		fSumNum  += i*RbcTmpHist[i];
	}

	if (fSumDen > 0)
	{
		fmean = fSumNum/fSumDen;
	}

	// 3 ���׼��
	fSumNum = 0;
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumNum += (i-fmean)*(i-fmean)*RbcTmpHist[i];
	}

	if (fSumDen > EPSINON)
	{
		fSD = sqrt(fSumNum/fSumDen);
	}

	// 4 ��Kurtosis
	fSumNum = 0.0;
	for (i=0; i<Rbc_Hist_DataLen; i++)
	{
		fSumNum += pow((i-fmean),4)*RbcTmpHist[i];
	}

	if (  fSD     > EPSINON
		&&fSumDen > EPSINON)
	{
		Kurtosis = fSumNum/pow(fSD,4)/fSumDen - 3;
	}

	return Kurtosis;
}

// ��ϸ��������������
bool AgglutinationParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (  RbcInput  == NULL
		||RbcOutput == NULL)
	{
		return false;
	}

	// ���ò���
	double fRbcExpCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRbcExpCoff*1.0E-6;

	int i       = 0;
	int j       = 0;
	int HistLen = Rbc_Hist_DataLen;

	// 1���౶��ֱ��ͼ����
	int *RbcOneLoidHist = NULL;        // һ����ֱ��ͼ
	int *RbcTwoLoidHist = NULL;        // ������ֱ��ͼ
	int *RbcThrLoidHist = NULL;        // ������ֱ��ͼ
	int *RbcMulLoidHist = NULL;        // �౶��ֱ��ͼ

	RbcOneLoidHist      = new int[HistLen];
	RbcTwoLoidHist      = new int[HistLen*2];
	RbcThrLoidHist      = new int[HistLen*3];
	RbcMulLoidHist      = new int[HistLen];

	if (  RbcOneLoidHist == NULL
		||RbcTwoLoidHist == NULL
		||RbcThrLoidHist == NULL
		||RbcMulLoidHist == NULL)
	{
		POINTER_FREE(RbcOneLoidHist);
		POINTER_FREE(RbcTwoLoidHist);
		POINTER_FREE(RbcThrLoidHist);
		POINTER_FREE(RbcMulLoidHist);
		//	AfxMessageBox("AgglutinationParaCal�ڴ�����ʧ�ܣ�");

		return false;
	}

	memset(RbcOneLoidHist, 0, sizeof(int)*HistLen);
	memset(RbcTwoLoidHist, 0, sizeof(int)*HistLen*2);
	memset(RbcThrLoidHist, 0, sizeof(int)*HistLen*3);
	memset(RbcMulLoidHist, 0, sizeof(int)*HistLen);

	// 1.1 һ����ֱ��ͼ����
	int FirstLine  = RbcOutput->GraphPara.DspHist.lines[0];
	int SecondLine = RbcOutput->GraphPara.DspHist.lines[1];

	for (i=FirstLine; i<=SecondLine; i++)
	{
		RbcOneLoidHist[i] = RbcOutput->GraphPara.DspHist.datas[i];
	}

	// 1.2 ������ֱ��ͼ����
	for (i=0; i<HistLen*2; i++)
	{
		double dTemp = 0.0;

		for (j=max(0, i-(HistLen-1)); j<min(i, HistLen-1); j++)
		{
			dTemp += RbcOneLoidHist[j] * RbcOneLoidHist[i-j];
		}

		RbcTwoLoidHist[i] = (int)(dTemp*fRbcExpCoff+0.5);
	}

	// 1.3 ������ֱ��ͼ����
	for (i=0; i<HistLen*3; i++)
	{
		double dTemp = 0.0;

		for (j=max(0, i-(2*HistLen-1)); j<min(i, HistLen-1); j++)
		{
			dTemp += RbcOneLoidHist[j] * RbcTwoLoidHist[i-j];
		}

		RbcThrLoidHist[i] = (int)(dTemp*fRbcExpCoff+0.5);
	}

	// 1.4 �౶��ֱ��ͼ
	for (i=0; i<HistLen; i++)
	{
		RbcMulLoidHist[i] = RbcTwoLoidHist[i] + RbcThrLoidHist[i];
	}

	for (i=HistLen; i<2*HistLen; i++)
	{
		RbcMulLoidHist[HistLen-1] += RbcTwoLoidHist[i] + RbcThrLoidHist[i];
	}

	for (i=2*HistLen; i<3*HistLen; i++)
	{
		RbcMulLoidHist[HistLen-1] += RbcThrLoidHist[i];
	}

	// 2��������������
	int    RbcCellNum = 0;
	int    RbcAggNum  = 0;
	double RbcAggPer  = 0.0;

	// 2.1 �Ҷ౶��ֱ��ͼ���ֵ
	int PeakPos   = 0;
	int PeakValue = 0;

	for(i=0; i<HistLen-1; i++)
	{
		if(PeakValue <= RbcMulLoidHist[i])
		{
			PeakValue = RbcMulLoidHist[i];
			PeakPos   = i;
		}
	}

	// 2.2 ������������
	for (i=0; i<HistLen; i++)
	{
		RbcCellNum += RbcOneLoidHist[i];

		if (i>=PeakPos)
		{
			RbcAggNum  += RbcOneLoidHist[i] - RbcMulLoidHist[i];
		}
	}

	if(RbcCellNum > 0)
	{
		RbcAggPer = 100.0*RbcAggNum/RbcCellNum;
	}

	RbcOutput->FeaturePara.RbcAggNum = RbcAggNum;
	RbcOutput->FeaturePara.RbcAggPer = RbcAggPer;

	POINTER_FREE(RbcOneLoidHist);
	POINTER_FREE(RbcTwoLoidHist);
	POINTER_FREE(RbcThrLoidHist);
	POINTER_FREE(RbcMulLoidHist);

	return true;
}

// RBC�����������㣨Skewness/Kurtosis��
bool RbcFeatureParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (  RbcInput  == NULL
		||RbcOutput == NULL)
	{
		return false;
	}

	double Alg_R_Cal_SkewnessBaseLinePer = RbcInput->RbcConfigPara.Alg_R_Cal_SkewnessBaseLinePer;
	double Alg_R_Cal_KurtosisBaseLinePer = RbcInput->RbcConfigPara.Alg_R_Cal_KurtosisBaseLinePer;

	// ƫ���Ͷȼ���
	double Skewness = SkewnessCal(RbcOutput->GraphPara.DspHist, Alg_R_Cal_SkewnessBaseLinePer);
	double Kurtosis = KurtosisCal(RbcOutput->GraphPara.DspHist, Alg_R_Cal_KurtosisBaseLinePer);

	RbcOutput->FeaturePara.Skewness = Skewness;
	RbcOutput->FeaturePara.Kurtosis = Kurtosis;

	// ��ϸ��������������
	AgglutinationParaCal(RbcInput, RbcOutput);

	return true;
}