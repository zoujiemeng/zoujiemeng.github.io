#ifndef ALG_CHAN_CRP_H
#define ALG_CHAN_CRP_H

#include "alg_type_inout.h"

// ������
bool crpmain(stCrpInput *CrpInput, stCrpOutput  *CrpOutput);

// ��ʼ��
bool crpinit(stCrpOutput  *CrpOutput);

// ���ò���
bool crpconfigpara(stCrpConfigPara *Configpara);

// �źŴ���
bool crpsigprocess(stCrpInput *CrpInput, stCrpOutput *CrpOutput);

// ��������
bool crpparacal(stCrpInput *CrpInput, stCrpOutput *CrpOutput);

//bool CrpParaCal_TPLine(double *pCrp, double Reaction, double *ScaleVal, int ScaleNum);
//bool CrpParaCal_SPLine(double *pCrp, double Reaction, double *ScaleVal, int ScaleNum);
//bool CrpParaCal_L5Line(double *pCrp, double Reaction, double *ScaleVal, int ScaleNum);
bool crpparacal_l4pline(double *pCrp, double Reaction, double *ScaleVal, int ScaleNum);

#endif