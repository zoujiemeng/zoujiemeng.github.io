#include "alg_chan_wbc.h"
#include "alg_chan_rbcplt.h"
#include "alg_chan_hgb.h"
#include "alg_chan_crp.h"

#include <string.h>

bool ChannelAlg(stChannelAlgInput *ChannelAlgInput, stChannelAlgOutput *ChannelAlgOutput)
{
	if (ChannelAlgInput  == NULL || ChannelAlgOutput == NULL)
	{
		return false;
	}

	wbcmain(&(ChannelAlgInput->WbcInput  ), &(ChannelAlgOutput->WbcOutput));
	impdmain(&(ChannelAlgInput->ImpdInput), &(ChannelAlgOutput->ImpdOutput));
	hgbmain(&(ChannelAlgInput->HgbInput  ), &(ChannelAlgOutput->HgbOutput));
	crpmain(&(ChannelAlgInput->CrpInput  ), &(ChannelAlgOutput->CrpOutput));

	return true;
}