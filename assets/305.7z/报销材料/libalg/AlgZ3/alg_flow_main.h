#ifndef ALGMAIN_H
#define ALGMAIN_H

#include "alg_type_inout.h"

bool AlgorithmMain(stAlgInput *AlgInput, stAlgOutput *AlgOutPut);

char *GetAlgVersion(void);

#endif