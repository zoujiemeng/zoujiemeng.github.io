#include "alg_chan_plt.h"
#include "alg_resource.h"

#include <string.h>
#include <math.h>
/*******************************************************************
// PLTͨ���źŴ���
********************************************************************/
// Pltֱ��ͼ�źŴ���
bool PltHistProcess(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	// ԭʼֱ��ͼ����
	PltOutput->GraphPara.OrgHist.datalen = 128;
	PltOutput->GraphPara.OrgHist.linelen = 2;

	gethist(&(PltOutput->GraphPara.OrgHist), PltOutput->FeaturePara.ImpdCellList);

	return true;
}

/*******************************************************************
// PLTͨ����������
********************************************************************/
// PLTֱ��ͼ����
bool BuildPltHist(stPltInput *PltInput,	stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	int i = 0;

	// 1 ֱ��ͼ����
	PltOutput->GraphPara.DspHist = PltOutput->GraphPara.OrgHist;
	//PltOutput->GraphPara.DspHist.datalen = 128;

	//curvefit_lognorm(PltOutput->GraphPara.OrgHist.datas, 
	//	PltOutput->GraphPara.DspHist.datas,  Plt_Hist_DataLen, 0, 
	//	PltOutput->ServicePara.RbcPltDivideLine);

	curvesmooth_gauss<int, int>(PltOutput->GraphPara.DspHist.datas, PltOutput->GraphPara.DspHist.datas,  Plt_Hist_DataLen, 6, 3);
	curvesmooth_gauss<int, int>(PltOutput->GraphPara.DspHist.datas, PltOutput->GraphPara.DspHist.datas,  Plt_Hist_DataLen, 6, 3);
	//curvesmooth_gauss<int, int>(PltOutput->GraphPara.DspHist.datas, PltOutput->GraphPara.DspHist.datas,  Plt_Hist_DataLen, 6, 3);

	// 2 ��һ�ֽ���
	int firstline  = 2;
	for(i=2; i<Plt_Hist_DataLen;i++)
	{
		if (PltOutput->GraphPara.DspHist.datas[i] > 0)
		{
			firstline = i;
			break;
		}
	}

	// 3 �ڶ��ֽ���
	int secondline = PltOutput->ServicePara.RbcPltDivideLine;

	PltOutput->GraphPara.OrgHist.lines[0] = firstline;
	PltOutput->GraphPara.DspHist.lines[0] = firstline;

	PltOutput->GraphPara.OrgHist.lines[1] = secondline;
	PltOutput->GraphPara.DspHist.lines[1] = secondline;

	return true;
}

// PLT���Ӳ���
int PltCompensation(int fRbcTotal, int fPltTotal, double fExpCoff)
{
	// Rbc��Plt����
	double fPltTotal2     = fPltTotal /(1-(1-exp(-0.1*fExpCoff*fRbcTotal*0.000001))*2);

	// Plt�Բ���
	// one
	double tmpdouble      = fExpCoff*fPltTotal*0.000001;
	double ftmpPltCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	double ftmpPltTotal   = fPltTotal2/ftmpPltCompFac;

	// two
	tmpdouble      = fExpCoff*ftmpPltTotal*0.000001;
	ftmpPltCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpPltTotal   = fPltTotal2/ftmpPltCompFac;

	// three
	tmpdouble      = fExpCoff*ftmpPltTotal*0.000001;
	ftmpPltCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpPltTotal   = fPltTotal2/ftmpPltCompFac;

	// four
	tmpdouble      = fExpCoff*ftmpPltTotal*0.000001;
	ftmpPltCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;

	int PltTotalNum = (int)(fPltTotal2/ftmpPltCompFac);

	return PltTotalNum;
}

// PLT����̬�������㣨PLT��
bool PltNoShapeParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	int     SubBackGround = PltInput->PltConfigPara.Alg_P_Cal_SubBackGround;
	double  fPltExpCoff   = PltInput->PltConfigPara.Alg_P_Cal_dPltExpCoff;

	int i = 0;

	// 1��PLTֵ����
	// 1.1������PLTʶ��������
	int PltTotal = 0;
	for (i=PltOutput->GraphPara.OrgHist.lines[0]; i<=PltOutput->GraphPara.OrgHist.lines[1]; i++)
	{
		PltTotal += PltOutput->GraphPara.OrgHist.datas[i];
	}

	// 1.2�����Ӳ���
	// ʱ�����Ӳ�������
	double MeasureTime   = PltInput->MeasureTime;
	double TraverseTime  = PltOutput->FeaturePara.TraverseTime;

	if (TraverseTime > EPSINON)
	{
		PltTotal = (int)(1.0*PltTotal/TraverseTime*MeasureTime +0.5);
	}

	// ������
	PltTotal -= SubBackGround;

	// ���Ӳ���
	int RbcTotal = PltInput->RbcTotalNum;
	PltTotal     = PltCompensation(RbcTotal, PltTotal, fPltExpCoff);

	PltOutput->ServicePara.PltTotalNum = PltTotal;

	// 1.3��Pltֵ����
	double  dPlt      = 0.0;
	double  Volume    = PltInput->Volume  ;
	double  Dilution  = PltInput->Dilution;

	if (Volume > EPSINON)
	{
		dPlt = PltTotal * Dilution / Volume / 1000;
	}

	if (dPlt < EPSINON)
	{
		dPlt = 0;
	}

	PltOutput->ReportPara.Plt = dPlt;

	return true;
}

// PLT��̬�������㣨MPV/PDW/PLCR/PLCC��
bool PltShapeParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	double Alg_P_Cal_dMpvAdjustCoff  = PltInput->PltConfigPara.Alg_P_Cal_dMpvAdjustCoff;
	//double Alg_P_Cal_dPdwBaseLinePer = PltInput->PltConfigPara.Alg_P_Cal_dPdwBaseLinePer;
	double Alg_P_Cal_dPdwAdjustCoff  = PltInput->PltConfigPara.Alg_P_Cal_dPdwAdjustCoff;
	int    Alg_P_Cal_LargePltTh      = PltInput->PltConfigPara.Alg_P_Cal_LargePltTh;

	int i = 0;

	// 1 MPV����
	double dMpv = 0;

	double dSumDen = 0.0;
	double dSumNum = 0.0;

	for (i=PltOutput->GraphPara.DspHist.lines[0]; i<PltOutput->GraphPara.DspHist.lines[1]; i++)
	{
		dSumDen +=   PltOutput->GraphPara.DspHist.datas[i];
		dSumNum += i*PltOutput->GraphPara.DspHist.datas[i];
	}

	if (dSumDen > EPSINON)
	{
		dMpv = Alg_P_Cal_dMpvAdjustCoff*dSumNum/dSumDen*40/64;
	}

	PltOutput->ReportPara.Mpv = dMpv;

	// 2 PDW����
	double dPdw  = 0.0;

	double dSum1 = 0.0;
	double dSum2 = 0.0;
	double dSum3 = 0.0;

	for (i=PltOutput->GraphPara.DspHist.lines[0]; i<PltOutput->GraphPara.DspHist.lines[1]; i++)
	{
		dSum1 += PltOutput->GraphPara.DspHist.datas[i]*log(i+0.1)*log(i+0.1);
		dSum2 += PltOutput->GraphPara.DspHist.datas[i]*log(i+0.1);
		dSum3 += PltOutput->GraphPara.DspHist.datas[i];
	}

	if (dSum3 > EPSINON)
	{
		dPdw = Alg_P_Cal_dPdwAdjustCoff*exp(sqrt((dSum1 - dSum2*dSum2/dSum3)/dSum3));
	}

	PltOutput->ReportPara.Pdw = dPdw;

	// 3 PLCR����
	double dPltTotal = 0.0;
	double dPlcr     = 0.0;

	for(i=0; i<PltOutput->GraphPara.OrgHist.lines[1]; i++)
	{
		dPltTotal += PltOutput->GraphPara.DspHist.datas[i];
	}

	for(i=Alg_P_Cal_LargePltTh; i<PltOutput->GraphPara.OrgHist.lines[1]; i++)
	{
		dPlcr += PltOutput->GraphPara.DspHist.datas[i];
	}

	if (dPltTotal > EPSINON)
	{
		dPlcr = dPlcr/dPltTotal;
	}

	PltOutput->ReportPara.Plcr = dPlcr;

	return true;
}

// PLT�����������㣨I_PLT_LP,I_PLT_UP��
bool PltFeatureParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	// ������ʼ��
	double I_Plt_LP = 0.0;
	double I_Plt_UP = 0.0;

	// ��ȡֱ��ͼ����Ϣ
	stHist DspHist = PltOutput->GraphPara.DspHist;
	int    PLT_LD  = DspHist.lines[0];
	int    PLT_UD  = DspHist.lines[1];

	int     i           = 0;
	int     PeakVal     = 0;
	double  dTmpVal     = 0.0;

	// ��ֱ��ͼ��߷�ֵ
	for (i=PLT_LD; i<PLT_UD; i++)
	{
		if (PeakVal < DspHist.datas[i])
		{
			PeakVal = DspHist.datas[i];
		}
	}

	// ����I_PLT_LP��I_PLT_UP
	if (PeakVal > 0)
	{
		//����I_PLT_LP
		dTmpVal  = DspHist.datas[PLT_LD];

		I_Plt_LP = 100.0*dTmpVal/PeakVal;

		//����I_PLT_UP
		dTmpVal = 0.0;

		for (i=PLT_UD-3; i<=PLT_UD+3; i++)
		{
			dTmpVal += DspHist.datas[i];
		}

		dTmpVal /= 7.0;

		I_Plt_UP = 100.0*dTmpVal/PeakVal;
	}

	PltOutput->FeaturePara.I_Plt_LP = I_Plt_LP;
	PltOutput->FeaturePara.I_Plt_UP = I_Plt_UP;

	return true;
}

// PLTͨ����������
bool PltParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (PltInput == NULL || PltOutput == NULL)
	{
		return false;
	}

	// 1 ͼ����Ϣ����
	BuildPltHist(PltInput, PltOutput);

	// 2 �����������
	{
		// 2.1 ����̬��������
		PltNoShapeParaCal(PltInput, PltOutput);

		// 2.2 ��̬��������
		PltShapeParaCal(PltInput, PltOutput);
	}

	// 3 ������������
	PltFeatureParaCal(PltInput, PltOutput);

	return true;
}