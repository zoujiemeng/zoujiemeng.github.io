//#include "stdafx.h"
#include "alg_pulse_impd.h"

// ��С������ת��(16λ)
#define Swap16(X)   ( (((unsigned short)(X)&0xff00)>>8) | (((unsigned short)(X)&0x00ff)<<8) )

// ��С������ת��(32λ)
#define Swap32(X)   ( (((UINT32)(X)&0xff000000)>>24) | (((UINT32)(X)&0x00ff0000)>>8)  \
	|(((UINT32)(X)&0x0000ff00)<<8) | (((UINT32)(X)&0x000000ff)<<24) )

// �迹ͨ����������-------------------------------------------------
bool SetPulseIdConfig_Ipmd(stPulseIdConfig_Impd *PulseIdConfig, PULSETYPE ChanType)
{
	switch (ChanType)
	{
	case PULSETYPE_WBC:
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh1   =   12;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh2   =   18;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh3   =   24;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh4   =   40;

		PulseIdConfig->Alg_PulseIdentify_IdentifyLength     =  100;

		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh1    =   20;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh2    =   16;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh3    =   12;

		PulseIdConfig->Alg_PulseIdentify_ValEndPerTh        =    6;
		PulseIdConfig->Alg_PulseIdentify_ValEndValueTh      =  600;

		PulseIdConfig->Alg_PulseIdentify_EndPosValueTh      =   40;

		PulseIdConfig->Alg_PulseIdentify_MPulsePerTh        =    8;

		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMaxTh =   80;
		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMinTh =   10;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMaxTh =   20;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMinTh =    3;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMaxTh =   20;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMinTh =    3;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMaxTh=   30;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMinTh=   10;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMaxTh     = 3856;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMinTh     =  100;

		break;

	case PULSETYPE_RBC:
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh1   =  6  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh2   =  8  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh3   = 10  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh4   = 30  ;

		PulseIdConfig->Alg_PulseIdentify_IdentifyLength     = 100 ;

		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh1    = 28  ;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh2    = 22  ;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh3    = 16  ;

		PulseIdConfig->Alg_PulseIdentify_ValEndPerTh        = 6   ;
		PulseIdConfig->Alg_PulseIdentify_ValEndValueTh      = 400 ;

		PulseIdConfig->Alg_PulseIdentify_EndPosValueTh      = 40  ;

		PulseIdConfig->Alg_PulseIdentify_MPulsePerTh        = 8   ;

		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMaxTh = 80  ;
		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMinTh = 10  ;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMaxTh = 100 ;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMinTh = 2   ;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMaxTh = 100 ;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMinTh = 2   ;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMaxTh= 50  ;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMinTh= 8   ;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMaxTh     = 4095;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMinTh     = 50 ;

		break;

	case PULSETYPE_PLT:
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh1   = 10  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh2   = 12  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh3   = 16  ;
		PulseIdConfig->Alg_PulseIdentify_StartPosValueTh4   = 40  ;

		PulseIdConfig->Alg_PulseIdentify_IdentifyLength     = 100 ;

		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh1    = 22  ;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh2    = 16  ;
		PulseIdConfig->Alg_PulseIdentify_FastEndValueTh3    = 10  ;

		PulseIdConfig->Alg_PulseIdentify_ValEndPerTh        = 6   ;
		PulseIdConfig->Alg_PulseIdentify_ValEndValueTh      = 400 ;

		PulseIdConfig->Alg_PulseIdentify_EndPosValueTh      = 40  ;

		PulseIdConfig->Alg_PulseIdentify_MPulsePerTh        = 8   ;

		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMaxTh =  46 ;
		PulseIdConfig->Alg_PulseIdentify_PulseFulWidthMinTh = 11  ;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMaxTh = 100 ;
		PulseIdConfig->Alg_PulseIdentify_PulsePriWidthMinTh = 2   ;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMaxTh = 100 ;
		PulseIdConfig->Alg_PulseIdentify_PulseSubWidthMinTh = 2   ;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMaxTh= 26  ;
		PulseIdConfig->Alg_PulseIdentify_PulseHalfWidthMinTh= 8   ;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMaxTh     = 4095;
		PulseIdConfig->Alg_PulseIdentify_PulsePeakMinTh     = 220 ;
		break;

	default:
		break;
	}

	return true;
}

// �迹ͨ�����ߴ���-------------------------------------------------
void detectbase_impd(UINT16 *PulseArray, UINT16 *BaseArray, int ArrayLen, int Window)
{
	if (PulseArray == NULL || BaseArray  == NULL)
	{
		return;
	}

	int i     = 0;
	int j     = 0;
	int index = 0;

	int AccumHistLen = MaxPulseVal;

	int *AccumHist = new int[AccumHistLen];
	if (AccumHist == NULL)
	{
		return;
	}
	memset(AccumHist,  0,  sizeof(int)*AccumHistLen);

	// ����ʼ��
	AccumHist[0] = Window;

	for (i=0; i<ArrayLen ;i++)
	{
		int PriPos = i - Window;
		int SubPos = i;

		if (PriPos < 0)
		{
			AccumHist[0]-- ;
		}
		else
		{
			AccumHist[PulseArray[PriPos]]-- ;
		}

		AccumHist[PulseArray[SubPos]]++ ;

		int sum = 0;
		for (j=0; j<AccumHistLen; j++)
		{
			sum += AccumHist[j];

			if ( sum >= (Window+1)/2 )
			{
				BaseArray[i] = j;
				break;
			}
		}
	}

	for (i=0; i<ArrayLen - (Window/2) ;i++)
	{
		BaseArray[i] = BaseArray[i+(Window/2)];
	}

	if (AccumHist)
	{
		delete[] AccumHist;
		AccumHist = 0;
	}
}

// �迹ͨ������ʶ��-------------------------------------------------
bool detectcell_impd(stPulseIdConfig_Impd PulseConfigure, stPulseIdList_Impd *PulseCellList, UINT16 *PulseArray, int ArrayLen)
{
	if (PulseArray == NULL)
	{
		return false;
	}

	int Alg_PulseIdentify_StartPosValueTh1    = PulseConfigure.Alg_PulseIdentify_StartPosValueTh1;
	int Alg_PulseIdentify_StartPosValueTh2    = PulseConfigure.Alg_PulseIdentify_StartPosValueTh2;
	int Alg_PulseIdentify_StartPosValueTh3    = PulseConfigure.Alg_PulseIdentify_StartPosValueTh3;
	int Alg_PulseIdentify_StartPosValueTh4    = PulseConfigure.Alg_PulseIdentify_StartPosValueTh4;
	
	int Alg_PulseIdentify_IdentifyLength      = PulseConfigure.Alg_PulseIdentify_IdentifyLength;

	int Alg_PulseIdentify_FastEndValueTh1     = PulseConfigure.Alg_PulseIdentify_FastEndValueTh1;
	int Alg_PulseIdentify_FastEndValueTh2     = PulseConfigure.Alg_PulseIdentify_FastEndValueTh2;
	int Alg_PulseIdentify_FastEndValueTh3     = PulseConfigure.Alg_PulseIdentify_FastEndValueTh3;

	int Alg_PulseIdentify_ValEndPerTh         = PulseConfigure.Alg_PulseIdentify_ValEndPerTh  ;
	int Alg_PulseIdentify_ValEndValueTh       = PulseConfigure.Alg_PulseIdentify_ValEndValueTh;

	int Alg_PulseIdentify_EndPosValueTh       = PulseConfigure.Alg_PulseIdentify_EndPosValueTh;

	int Alg_PulseIdentify_MPulsePerTh         = PulseConfigure.Alg_PulseIdentify_MPulsePerTh  ;

	int Alg_PulseIdentify_PulseFulWidthMaxTh  = PulseConfigure.Alg_PulseIdentify_PulseFulWidthMaxTh;
	int Alg_PulseIdentify_PulseFulWidthMinTh  = PulseConfigure.Alg_PulseIdentify_PulseFulWidthMinTh;
	int Alg_PulseIdentify_PulsePriWidthMaxTh  = PulseConfigure.Alg_PulseIdentify_PulsePriWidthMaxTh;
	int Alg_PulseIdentify_PulsePriWidthMinTh  = PulseConfigure.Alg_PulseIdentify_PulsePriWidthMinTh;
	int Alg_PulseIdentify_PulseSubWidthMaxTh  = PulseConfigure.Alg_PulseIdentify_PulseSubWidthMaxTh;
	int Alg_PulseIdentify_PulseSubWidthMinTh  = PulseConfigure.Alg_PulseIdentify_PulseSubWidthMinTh;
	int Alg_PulseIdentify_PulseHalfWidthMaxTh = PulseConfigure.Alg_PulseIdentify_PulseHalfWidthMaxTh;
	int Alg_PulseIdentify_PulseHalfWidthMinTh = PulseConfigure.Alg_PulseIdentify_PulseHalfWidthMinTh;
	int Alg_PulseIdentify_PulsePeakMaxTh      = PulseConfigure.Alg_PulseIdentify_PulsePeakMaxTh;
	int Alg_PulseIdentify_PulsePeakMinTh      = PulseConfigure.Alg_PulseIdentify_PulsePeakMinTh;

	bool startflag      = false;
	int  startpos       = 0;
	int  startvalue     = 0;

	bool peakflag       = false;
	int  peakpos        = 0;
	int  peakvalue      = 0;

	bool fastendflag    = false;
	bool endflag        = false;
	int  endpos         = 0;
	int  endvalue       = 0;

	bool valflag        = false;
	int  valvalue       = 0;
	int  valpos         = 0;

	bool mflag          = false;

	for (int i=2; i<ArrayLen-1; i++)
	{
		int ppdata = PulseArray[i-2];
		int pdata  = PulseArray[i-1];
		int cdata  = PulseArray[i]  ;
		int ndata  = PulseArray[i+1];

		// �����
		if (  !startflag
			&& pdata > ppdata + Alg_PulseIdentify_StartPosValueTh1
			&& cdata > pdata  + Alg_PulseIdentify_StartPosValueTh2
			&& cdata < ndata  - Alg_PulseIdentify_StartPosValueTh3
			&& cdata >          Alg_PulseIdentify_StartPosValueTh4
			)
		{
			startflag  = true  ;
			startpos   = i - 2 ;
			startvalue = ppdata;
		}

		// �����
		if (!startflag)
		{
			continue;
		}

		// ����ʶ�𳤶�����
		if (i > startpos + Alg_PulseIdentify_IdentifyLength)
		{
			endflag  = true;
			endpos   = i;
			endvalue = cdata;
		}

		// ��ֵ����
		if ( peakvalue < cdata )
		{
			peakflag  = true;
			peakvalue = cdata;
			peakpos   = i;
		}

		// ��ֵ����
		if (  cdata <  pdata
			&&cdata <= ndata)
		{
			if (  ( fastendflag && cdata*10 < Alg_PulseIdentify_ValEndPerTh*peakvalue)
			    ||( fastendflag && cdata    < peakvalue - Alg_PulseIdentify_ValEndValueTh)
			   )
			{
				endflag  = true;
				endpos   = i;
				endvalue = cdata;
			}
			else
			{
				valflag  = true;
				valpos   = i;
				valvalue = cdata;
			} 
		}

		// ���ٽ�����־
		if (  pdata < ppdata - Alg_PulseIdentify_FastEndValueTh1
			&&cdata < pdata  - Alg_PulseIdentify_FastEndValueTh2
			&&cdata > ndata  - Alg_PulseIdentify_FastEndValueTh3)
		{
			fastendflag = true;
		}

		// ��������
		if ( cdata < Alg_PulseIdentify_EndPosValueTh)
		{
			endflag  = true;
			endpos   = i;
			endvalue = cdata;
		}

		// ������Ϣ��¼
		if (endflag)
		{
			// m����־
			if (valflag&&valvalue*10 > Alg_PulseIdentify_MPulsePerTh*peakvalue)
			{
				peakpos    = valpos;
				peakvalue  = valvalue;
				mflag      = true;
			}
			
			int submidpos = endpos;
			for (int j=peakpos; j<endpos; j++)
			{
				if (PulseArray[j] < peakvalue/2)
				{
					submidpos = j;
					break;
				}
			}

			int primidpos = startpos;
			for (int j=peakpos; j>primidpos; j--)
			{
				if (PulseArray[j] < peakvalue/2)
				{
					primidpos = j;
					break;
				}
			}
			
			// ������Ϣ��ֵ����
			stPulseIdCell_Impd  PulseCellPacket;
			memset(&PulseCellPacket,   0, sizeof(stPulseIdCell_Impd));

			PulseCellPacket.FulWidth   = endpos    - startpos;
			PulseCellPacket.SubWidth   = submidpos - peakpos;
			PulseCellPacket.PriWidth   = peakpos   - primidpos;

			PulseCellPacket.StartPos   = startpos;
			PulseCellPacket.StartValue = startvalue;

			PulseCellPacket.EndPos     = endpos;
			PulseCellPacket.EndValue   = endvalue;

			PulseCellPacket.PeakPos    = peakpos;

			PulseCellPacket.PeakValue  = peakvalue;

			PulseCellPacket.MPulseFlag = mflag;

			// ������Ч���ж�
			if (   PulseCellPacket.FulWidth   < Alg_PulseIdentify_PulseFulWidthMaxTh
				&& PulseCellPacket.FulWidth   > Alg_PulseIdentify_PulseFulWidthMinTh
				&& PulseCellPacket.PriWidth   < Alg_PulseIdentify_PulsePriWidthMaxTh
				&& PulseCellPacket.PriWidth   > Alg_PulseIdentify_PulsePriWidthMinTh
				&& PulseCellPacket.SubWidth   < Alg_PulseIdentify_PulseSubWidthMaxTh
				&& PulseCellPacket.SubWidth   > Alg_PulseIdentify_PulseSubWidthMinTh
				&& PulseCellPacket.PriWidth + PulseCellPacket.SubWidth < Alg_PulseIdentify_PulseHalfWidthMaxTh
				&& PulseCellPacket.PriWidth + PulseCellPacket.SubWidth > Alg_PulseIdentify_PulseHalfWidthMinTh
				&& PulseCellPacket.PeakValue  < Alg_PulseIdentify_PulsePeakMaxTh
				&& PulseCellPacket.PeakValue  > Alg_PulseIdentify_PulsePeakMinTh
				)
			{
				PulseCellList->CellNum++;
				PulseCellList->CellPacket.push_back(PulseCellPacket);
			}
	
			startflag  = false;
			startpos   = 0;
			startvalue = 0;

			peakflag   = false;
			peakpos    = 0;
			peakvalue  = 0;

			valflag    = false;

			endflag    = false;
			endpos     = 0;
			endvalue   = 0;

			fastendflag= false;
			mflag      = false;
		}
	}

	return true;
}

// ��ͨ������ʶ��---------------------------------------------------
void pulseid_impd(stPulseIdList_Impd *PulseCellList, PULSETYPE ChanType, bool m_BaseProcessFlag,
	UINT16 *PulseArray, UINT16 *BaseArray, UINT16 *NoBaseArray, int ArrayLen)
{
	// ������ʼ��
	PulseCellList->CellNum = 0;

	// ���ߴ���
	memset(BaseArray, 0, sizeof(UINT16)*ArrayLen);

	if (m_BaseProcessFlag)
	{
		detectbase_impd(PulseArray, BaseArray, ArrayLen, 512);
	}

	// �����ߴ���
	for(int i=0; i<ArrayLen; i++)
	{
		NoBaseArray[i] = (PulseArray[i]-BaseArray[i]) > 0 ? (PulseArray[i]-BaseArray[i]) : 0;
	}

	// ���ò���
	stPulseIdConfig_Impd PulseIdConfig;
	SetPulseIdConfig_Ipmd(&PulseIdConfig, ChanType);

	// ����ʶ��
	detectcell_impd(PulseIdConfig, PulseCellList, NoBaseArray, ArrayLen);
}

// ���ӷ�װ(FPGA)���-----------------------------------------------
bool DataConvite_Pulse(unsigned char* &DataAddr, int &DataLen, stPulseIdList_Impd PulseIdList)
{
	// ��ȡ����
	DataLen = PulseIdList.CellNum;

	// �ڴ�����
	int BufLen = DataLen*16;
	DataAddr   = new unsigned char[BufLen];
	if (DataAddr == NULL)
	{
		return false;
	}

	memset(DataAddr, 0, BufLen*sizeof(char));

	unsigned char *CurAddr = DataAddr;
	// ����ת��
	for (int i=0; i<DataLen; i++)
	{
		// FAFB
		*(unsigned short *)CurAddr = Swap16((unsigned short)0xFAFB);
		CurAddr += 2;

		// ��־λ
		CurAddr += 1;

		// ��ֵ
		*(unsigned short *)CurAddr = Swap16((unsigned short)PulseIdList.CellPacket[i].PeakValue);
		CurAddr += 2;

		// ǰ���
		*(unsigned char *)CurAddr = (unsigned char)(PulseIdList.CellPacket[i].PriWidth);
		CurAddr += 1;

		// ����
		*(unsigned char *)CurAddr = (unsigned char)(PulseIdList.CellPacket[i].SubWidth);
		CurAddr += 1;

		// ȫ���
		*(unsigned char *)CurAddr = (unsigned char)(PulseIdList.CellPacket[i].FulWidth);
		CurAddr += 1;

		// ����
		*(unsigned short *)CurAddr = Swap16((unsigned short)PulseIdList.CellPacket[i].BaseLine);
		CurAddr += 2;

		// ʱ���
		*(unsigned char *)CurAddr = (unsigned char)(0x1);
		CurAddr += 1;

		// M����־
		*(unsigned char *)CurAddr = (unsigned char)(PulseIdList.CellPacket[i].MPulseFlag);
		CurAddr += 1;

		// ����λ
		CurAddr += 1;

		// У��λ
		CurAddr += 1;

		// FCFD
		*(unsigned short *)CurAddr = Swap16((unsigned short)0xFCFD);
		CurAddr += 2;
	}

	return true;
}