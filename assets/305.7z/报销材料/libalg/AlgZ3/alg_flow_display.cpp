//#include "stdafx.h"
#include "alg_flow_display.h"
#include "alg_resource.h"

// ��ʾ�����㷨
bool DisplayAlg(stDisplayAlgInOutput *DisplayAlgInOutput)
{
	if (DisplayAlgInOutput == 0)
	{
		return false;
	}

	bool flag = false;

	//--------------------------------------------------------------------------
	// ��������
	//--------------------------------------------------------------------------
	// ��ȡ������Ϣ
	static int Truncation[MAXPARA][2] = {0};

	flag = readcsv((char *)"./config/truncation.csv", (int*)(Truncation), MAXPARA*2);
	//if (!flag) { AfxMessageBox("truncation�ļ���ȡʧ�ܣ�"); return false;}

	// ���ò�����λ������
	for (int i=0; i<MAXPARA; i++)
	{
		DisplayAlgInOutput->Para[i].UnitNO    = Truncation[i][0];
		DisplayAlgInOutput->Para[i].Precision = Truncation[i][1];
	}

	// �����������
	//if ( 
	//	DisplayAlgInOutput->Para[WBC].Mark           != STAR
	//	&&DisplayAlgInOutput->Para[LYMPERCENT].Mark  != STAR
	//	&&DisplayAlgInOutput->Para[LYMPERCENT].Mark  != BLANK
	//	&&DisplayAlgInOutput->Para[MIDPERCENT].Mark  != STAR
	//	&&DisplayAlgInOutput->Para[MIDPERCENT].Mark  != BLANK
	//	&&DisplayAlgInOutput->Para[GRANPERCENT].Mark != STAR
	//	&&DisplayAlgInOutput->Para[GRANPERCENT].Mark != BLANK
	//	)
	{
		flag = TruncationPara(DisplayAlgInOutput);
		// if (!flag) {	printf("TruncationPara Fail");	return false;}
	}

	//--------------------------------------------------------------------------
	// ȷ���Ա���
	//--------------------------------------------------------------------------
	DefinitiveMsg(DisplayAlgInOutput);

	return true;
}

// �����ض�
bool TruncationPara(stDisplayAlgInOutput *DisplayAlgInOutput)
{
	if (DisplayAlgInOutput == 0)
	{
		return false;
	}
	
	// %�ض�
	int LymPer  = (int)(DisplayAlgInOutput->Para[LYMPERCENT ].Value*10 + 0.5);
	int MidPer  = (int)(DisplayAlgInOutput->Para[MIDPERCENT ].Value*10 + 0.5);
	int GranPer = (int)(DisplayAlgInOutput->Para[GRANPERCENT].Value*10 + 0.5);

	if (1000 - LymPer - MidPer > 0)
	{
		GranPer = 1000 - LymPer - MidPer;
	}
	else if (1000 - MidPer - GranPer > 0)
	{
		LymPer = 1000 - MidPer - GranPer;
	}
	else if (1000 - LymPer - GranPer > 0)
	{
		MidPer = 1000 - GranPer - LymPer;
	}

	DisplayAlgInOutput->Para[LYMPERCENT ].Value = 0.1*LymPer;
	DisplayAlgInOutput->Para[MIDPERCENT ].Value = 0.1*MidPer;
	DisplayAlgInOutput->Para[GRANPERCENT].Value = 0.1*GranPer;

	// #�ض�
	int Wbc = (int)(DisplayAlgInOutput->Para[WBC].Value*100 + 0.5);

	int LymCount  = (int)(1.0*LymPer*Wbc/1000 + 0.5);
	int MidCount  = (int)(1.0*MidPer*Wbc/1000 + 0.5);
	int GranCount = (int)(1.0*GranPer*Wbc/1000 + 0.5);

	if (Wbc - LymCount - MidCount > 0)
	{
		GranCount = Wbc - LymCount - MidCount;
	}
	else if (Wbc - GranCount - MidCount > 0)
	{
		LymCount = Wbc - GranCount - MidCount;
	}
	else if (Wbc - GranCount - LymCount > 0)
	{
		MidCount = Wbc - GranCount - LymCount;
	}

	DisplayAlgInOutput->Para[WBC].Value       = 0.01*Wbc;
	DisplayAlgInOutput->Para[GRANCOUNT].Value = 0.01*GranCount;
	DisplayAlgInOutput->Para[LYMCOUNT ].Value = 0.01*LymCount;
	DisplayAlgInOutput->Para[MIDCOUNT ].Value = 0.01*MidCount;

	return true;
}

// ȷ���Ա���
bool DefinitiveMsg(stDisplayAlgInOutput *DisplayAlgInOutput)
{
	if (DisplayAlgInOutput == 0)
	{
		return false;
	}

	// ���ò���
	double Alg_W_Msg_WbcIncrease_WbcTh     = 18.0 ;
	double Alg_W_Msg_WbcDecrease_WbcTh     = 2.5  ;
	double Alg_W_Msg_GranIncrease_GranTh   = 11.0 ;
	double Alg_W_Msg_GranDecrease_GranTh   = 1.0  ;
	double Alg_W_Msg_LymIncrease_LymTh     = 4.0  ;
	double Alg_W_Msg_LymDecrease_LymTh     = 0.8  ;
	double Alg_W_Msg_MidIncrease_MidTh     = 1.5  ;

	double Alg_R_Msg_Anisocytosis_RdwcvTh  = 22.0 ;
	double Alg_R_Msg_Anisocytosis_RdwsdTh  = 64.0 ;
	double Alg_R_Msg_Macrocytosis_McvTh    = 113.0;
	double Alg_R_Msg_Microcytosis_McvTh    = 70.0 ;
	double Alg_R_Msg_Anemia_HgbTh          = 90   ;
	double Alg_R_Msg_Hypochromia_MchcTh    = 290.0;
	double Alg_R_Msg_RbcIncrease_RbcTh     = 6.5  ;

	int Alg_P_Msg_PltDecrease_PltTh        = 60   ;
	int Alg_P_Msg_PltIncrease_PltTh        = 600  ;

	double Alg_P_Msg_CrpIncrease_CrpTh     = 50.0 ;

	if (DisplayAlgInOutput->WorkMode == WORKMODE_BLOOD)
	{
		// ��ϵȷ���Ա���----------------------------------------------------------------
		// ��ϸ������
		if (  DisplayAlgInOutput->Para[WBC].Mark != STAR
			&&DisplayAlgInOutput->Para[WBC].Mark != BLANK
			&&DisplayAlgInOutput->Para[WBC].Mark != HIGH
			&&DisplayAlgInOutput->Para[WBC].Value > Alg_W_Msg_WbcIncrease_WbcTh
			)
		{
			DisplayAlgInOutput->Alarm[WBCINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[WBCINCREASE].Flag   = true;
		}

		// ��ϸ������
		if (  DisplayAlgInOutput->Para[WBC].Mark != STAR
			&&DisplayAlgInOutput->Para[WBC].Mark != BLANK
			&&DisplayAlgInOutput->Para[WBC].Mark != HIGH
			&&DisplayAlgInOutput->Para[WBC].Value > 0.5
			&&DisplayAlgInOutput->Para[WBC].Value < Alg_W_Msg_WbcDecrease_WbcTh
			)
		{
			DisplayAlgInOutput->Alarm[WBCDECREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[WBCDECREASE].Flag   = true;
		}

		// ������ϸ������
		if (  DisplayAlgInOutput->Para[GRANCOUNT].Mark != STAR
			&&DisplayAlgInOutput->Para[GRANCOUNT].Mark != BLANK
			&&DisplayAlgInOutput->Para[GRANCOUNT].Mark != HIGH
			&&DisplayAlgInOutput->Para[GRANCOUNT].Value > Alg_W_Msg_GranIncrease_GranTh
			)
		{
			DisplayAlgInOutput->Alarm[GRANINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[GRANINCREASE].Flag   = true;
		}

		// ������ϸ������
		if (  DisplayAlgInOutput->Para[GRANCOUNT].Mark != STAR
			&&DisplayAlgInOutput->Para[GRANCOUNT].Mark != BLANK
			&&DisplayAlgInOutput->Para[GRANCOUNT].Mark != HIGH
			&&DisplayAlgInOutput->Para[GRANCOUNT].Value < Alg_W_Msg_GranDecrease_GranTh
			)
		{
			DisplayAlgInOutput->Alarm[GRANDECREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[GRANDECREASE].Flag   = true;
		}

		// �ܰ�ϸ������
		if (  DisplayAlgInOutput->Para[LYMCOUNT].Mark != STAR
			&&DisplayAlgInOutput->Para[LYMCOUNT].Mark != BLANK
			&&DisplayAlgInOutput->Para[LYMCOUNT].Mark != HIGH
			&&DisplayAlgInOutput->Para[LYMCOUNT].Value > Alg_W_Msg_LymIncrease_LymTh
			)
		{
			DisplayAlgInOutput->Alarm[LYMINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[LYMINCREASE].Flag   = true;
		}

		// �ܰ�ϸ������
		if (  DisplayAlgInOutput->Para[LYMCOUNT].Mark != STAR
			&&DisplayAlgInOutput->Para[LYMCOUNT].Mark != BLANK
			&&DisplayAlgInOutput->Para[LYMCOUNT].Mark != HIGH
			&&DisplayAlgInOutput->Para[LYMCOUNT].Value < Alg_W_Msg_LymDecrease_LymTh
			)
		{
			DisplayAlgInOutput->Alarm[LYMDECREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[LYMDECREASE].Flag   = true;
		}

		// ����ϸ������
		if (  DisplayAlgInOutput->Para[MIDCOUNT].Mark != STAR
			&&DisplayAlgInOutput->Para[MIDCOUNT].Mark != BLANK
			&&DisplayAlgInOutput->Para[MIDCOUNT].Mark != HIGH
			&&DisplayAlgInOutput->Para[MIDCOUNT].Value > Alg_W_Msg_MidIncrease_MidTh
			)
		{
			DisplayAlgInOutput->Alarm[MIDINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[MIDINCREASE].Flag   = true;
		}

		// RBCϵȷ���Ա���----------------------------------------------------------------
		// ��ϸ������
		if (  DisplayAlgInOutput->Para[RBC].Mark != STAR
			&&DisplayAlgInOutput->Para[RBC].Mark != BLANK
			&&DisplayAlgInOutput->Para[RBC].Mark != HIGH
			&&DisplayAlgInOutput->Para[RBC].Value > Alg_R_Msg_RbcIncrease_RbcTh
			)
		{
			DisplayAlgInOutput->Alarm[RBCINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[RBCINCREASE].Flag   = true;
		}

		// ��ϸ����С����
		if (  DisplayAlgInOutput->Para[RDW_SD].Mark != STAR
			&&DisplayAlgInOutput->Para[RDW_SD].Mark != BLANK
			&&DisplayAlgInOutput->Para[RDW_SD].Mark != HIGH
			&&DisplayAlgInOutput->Para[RDW_CV].Mark != STAR
			&&DisplayAlgInOutput->Para[RDW_CV].Mark != BLANK
			&&DisplayAlgInOutput->Para[RDW_CV].Mark != HIGH
			&&DisplayAlgInOutput->Para[RDW_SD].Value > Alg_R_Msg_Anisocytosis_RdwsdTh
			&&DisplayAlgInOutput->Para[RDW_CV].Value > Alg_R_Msg_Anisocytosis_RdwcvTh
			)
		{
			DisplayAlgInOutput->Alarm[ANISOCYTOSIS].Degree = 100;
			DisplayAlgInOutput->Alarm[ANISOCYTOSIS].Flag   = true;
		}

		// ��ɫ����
		if (  DisplayAlgInOutput->Para[MCHC].Mark != STAR
			&&DisplayAlgInOutput->Para[MCHC].Mark != BLANK
			&&DisplayAlgInOutput->Para[MCHC].Mark != HIGH
			&&DisplayAlgInOutput->Para[MCHC].Value < Alg_R_Msg_Hypochromia_MchcTh
			)
		{
			DisplayAlgInOutput->Alarm[HYPOCHROMIA].Degree = 100;
			DisplayAlgInOutput->Alarm[HYPOCHROMIA].Flag   = true;
		}

		// ��ϸ���Ժ�ϸ��
		if (  DisplayAlgInOutput->Para[MCV].Mark != STAR
			&&DisplayAlgInOutput->Para[MCV].Mark != BLANK
			&&DisplayAlgInOutput->Para[MCV].Mark != HIGH
			&&DisplayAlgInOutput->Para[MCV].Value > Alg_R_Msg_Macrocytosis_McvTh
			)
		{
			DisplayAlgInOutput->Alarm[MACROCYTHEMIA].Degree = 100;
			DisplayAlgInOutput->Alarm[MACROCYTHEMIA].Flag   = true;
		}

		// Сϸ���Ժ�ϸ��
		if (  DisplayAlgInOutput->Para[MCV].Mark != STAR
			&&DisplayAlgInOutput->Para[MCV].Mark != BLANK
			&&DisplayAlgInOutput->Para[MCV].Mark != HIGH
			&&DisplayAlgInOutput->Para[MCV].Value < Alg_R_Msg_Microcytosis_McvTh
			)
		{
			DisplayAlgInOutput->Alarm[MICROCYTHEMIA].Degree = 100;
			DisplayAlgInOutput->Alarm[MICROCYTHEMIA].Flag   = true;
		}

		// ƶѪ
		if (  DisplayAlgInOutput->Para[RBC].Value > 0.2
			&&DisplayAlgInOutput->Para[HGB].Mark != STAR
			&&DisplayAlgInOutput->Para[HGB].Mark != BLANK
			&&DisplayAlgInOutput->Para[HGB].Mark != HIGH
			&&DisplayAlgInOutput->Para[HGB].Value < Alg_R_Msg_Anemia_HgbTh
			)
		{
			DisplayAlgInOutput->Alarm[ANEMIA].Degree = 100;
			DisplayAlgInOutput->Alarm[ANEMIA].Flag   = true;
		}

		// PLTϵȷ���Ա���
		// ѪС������
		if (  DisplayAlgInOutput->Para[PLT].Mark != STAR
			&&DisplayAlgInOutput->Para[PLT].Mark != BLANK
			&&DisplayAlgInOutput->Para[PLT].Mark != HIGH
			&&DisplayAlgInOutput->Para[PLT].Value > Alg_P_Msg_PltIncrease_PltTh
			)
		{
			DisplayAlgInOutput->Alarm[PLTINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[PLTINCREASE].Flag   = true;
		}

		// ѪС�����
		if (  DisplayAlgInOutput->Para[PLT].Mark != STAR
			&&DisplayAlgInOutput->Para[PLT].Mark != BLANK
			&&DisplayAlgInOutput->Para[PLT].Mark != HIGH
			&&DisplayAlgInOutput->Para[PLT].Value > 10
			&&DisplayAlgInOutput->Para[PLT].Value < Alg_P_Msg_PltDecrease_PltTh
			)
		{
			DisplayAlgInOutput->Alarm[PLTDECREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[PLTDECREASE].Flag   = true;
		}

		// C��Ӧ��������
		if (  DisplayAlgInOutput->Para[CRP_NM].Mark != STAR
			&&DisplayAlgInOutput->Para[CRP_NM].Mark != BLANK
			&&DisplayAlgInOutput->Para[CRP_NM].Mark != HIGH
			&&DisplayAlgInOutput->Para[CRP_NM].Value > Alg_P_Msg_CrpIncrease_CrpTh
			)
		{
			DisplayAlgInOutput->Alarm[CRPINCREASE].Degree = 100;
			DisplayAlgInOutput->Alarm[CRPINCREASE].Flag   = true;
		}
	}

	return true;
}