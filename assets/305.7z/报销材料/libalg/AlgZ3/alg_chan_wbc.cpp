#include "alg_chan_wbc.h"
#include "alg_resource.h"
#include "alg_watershed.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

/*******************************************************************
// �� �� ���� main
// ��    �ܣ� ������
********************************************************************/
bool wbcmain(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1����ʼ��
	flag = wbcinit(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 2����ȡ���ò���
	flag = wbcconfigpara(&(WbcInput->WbcConfigPara));
	if (!flag)
	{
		return false;
	}

	// 3���źŴ���
	flag = wbcsigprocess(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 4��ͨ������
	flag = wbcclassify(WbcInput, WbcOutput);
	if (!flag)
	{
		return false;
	}

	// 5����������
	flag = wbcparacal(WbcInput, WbcOutput);

	return flag;
}

/*******************************************************************
// �� �� ���� init
// ��    �ܣ� ��ʼ��
********************************************************************/
bool wbcinit(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	memset(WbcOutput, 0, sizeof(stWbcOutput));

	return true;
}

/*******************************************************************
// �� �� ���� configpara
// ��    �ܣ� ���ò���
********************************************************************/
bool wbcconfigpara(stWbcConfigPara *pConfigPara)
{
	if (pConfigPara == NULL)
	{
		return false;
	}

	pConfigPara->Alg_W_Cal_SubBackGround = 10;                   // WBC������������
	pConfigPara->Alg_W_Cal_dWbcExpCoff   = 1.89;                  // WBC���Ӳ���ϵ��
	//pConfigPara->Alg_W_Cal_dWbcExpCoff   = 1.2;                  // WBC���Ӳ���ϵ��
	return true;
}

/*******************************************************************
// �� �� ���� sigprocess
// ��    �ܣ� �źŴ���
********************************************************************/
bool wbcsigprocess(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	bool flag = false;

	// 1������ת��
	// 1.1��DATA����ת��---------------------------------------
	stImpdCellList WbcCellList;
	memset(&WbcCellList, 0, sizeof(stOptiCellList));

	dataconvite_impd(&WbcCellList, WbcInput->DataAddr, WbcInput->DataLen);

	WbcOutput->FeaturePara.ImpdCellList = WbcCellList;

	// 1.2��HoleV����ת��---------------------------------------
	stVoltList VoltList;
	VoltList.VoltNum = WbcInput->HoleVLen;
	VoltList.VoltVal = new unsigned short[VoltList.VoltNum];

	unsigned char *tempaddr = WbcInput->HoleVAddr;

	for (int i=0; i<VoltList.VoltNum; i++)
	{
		VoltList.VoltVal[i] = *((unsigned short *)tempaddr);

		tempaddr += 2;
	}

	WbcOutput->FeaturePara.HoleVList = VoltList;

	// 2��ϵͳ�쳣�ж�
	wbcsystemerrorjudge(WbcInput, WbcOutput);

	// ԭʼֱ��ͼ����
	WbcOutput->GraphPara.OrgHist.datalen = 256;
	WbcOutput->GraphPara.OrgHist.linelen = 4;

	gethist(&(WbcOutput->GraphPara.OrgHist), WbcOutput->FeaturePara.ImpdCellList);

	WbcOutput->GraphPara.DspHist = WbcOutput->GraphPara.OrgHist;

	curvesmooth_gauss<int, int>(WbcOutput->GraphPara.DspHist.datas, WbcOutput->GraphPara.DspHist.datas, 256, 6, 3);
	curvesmooth_gauss<int, int>(WbcOutput->GraphPara.DspHist.datas, WbcOutput->GraphPara.DspHist.datas, 256, 6, 3);

	return true;
}

// ϵͳ�쳣�ж�
bool wbcsystemerrorjudge(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// С�׵�ѹ�쳣�ж�
	wbcsystemerrorjudge_HoleAbn(WbcInput, WbcOutput);

	// �¿��쳣�ж�
	wbcsystemerrorjudge_Block(WbcInput, WbcOutput);

	return true;
}

// ϵͳ�쳣�ж�(С�׵�ѹ)
bool wbcsystemerrorjudge_HoleAbn(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ��������
	stVoltList VoltList = WbcOutput->FeaturePara.HoleVList;

	// �м����
	double *datavol = NULL;
	int     datalen = 0;

	datalen = VoltList.VoltNum;

	if (datalen > 0)
	{
		datavol = new double[datalen];
	}
		
	for (int i=0; i<datalen; i++)
	{
		datavol[i] = VoltList.VoltVal[i];
	}

	// ��ֵ�˲�
	curvesmooth_median<double>(datavol, datavol, VoltList.VoltNum, 5);
	
	// �����Сֵ
	double maxval = 0;
	double minval = 4096;

	int test1p = 1610;
	int test2p = 2605;

	//if (WbcInput->AnalyMode & ANALYSISMODE_CRP)
	//{
	//	test1p = 1600;
	//	test2p = 2600;
	//}

	if (datalen > test2p)
	{
		for (int i=test1p; i<test2p; i++)
		{
			if (maxval < datavol[i])
			{
				maxval = datavol[i];
			}

			if (minval > datavol[i])
			{
				minval = datavol[i];
			}
		}
	}
	
	WbcOutput->FeaturePara.MaxHoleVol = maxval;
	WbcOutput->FeaturePara.MinHoleVol = minval;

	POINTER_FREE(datavol);

	return true;
}

// ϵͳ�쳣�ж�(�¿�)
bool wbcsystemerrorjudge_Block(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ��ȡNPS
	int *Npsdata = NULL;
	int  Npslen  = 0;

	getstamplist_impd(Npsdata, Npslen, WbcOutput->FeaturePara.ImpdCellList);

	WbcOutput->FeaturePara.Npsdata = Npsdata;
	WbcOutput->FeaturePara.Npslen  = Npslen;

	// ƽ������
	int  templen   = Npslen > 1 ? Npslen - 1 : 1;
	int *ptempdata = new int[templen];
	memset(ptempdata, 0, sizeof(int)*templen);

	curvesmooth_mean<int, int>(ptempdata,   Npsdata, templen, 8);
	curvesmooth_mean<int, int>(ptempdata, ptempdata, templen, 8);
	curvesmooth_mean<int, int>(ptempdata, ptempdata, templen, 8);

	// ����ͳ��ֵ
	double  Av_Nps = getmean<int>(Npsdata, templen);
	double  Sd_Nps = getstde<int>(Npsdata, templen);
	double  Cv_Nps = getcova<int>(Npsdata, templen);

	WbcOutput->FeaturePara.Av_Nps  = Av_Nps;
	WbcOutput->FeaturePara.Sd_Nps  = Sd_Nps;
	WbcOutput->FeaturePara.Cv_Nps  = Cv_Nps;

	// һ�ײ��ֱ��ͼ
	int *pDecHist = new int[templen];
	memset(pDecHist, 0, sizeof(int)*templen);

	for (int i=0; i<templen; i++)
	{
		pDecHist[i] = ptempdata[i+1] - ptempdata[i];
	}

	// 2.2.2���������ֵ����������������ֵ��λ��
	int TepArea  = 0;
	int TepPos   = 0;
	int TepPeak  = 0;

	int PosArea  = 0;
	int PosPos   = 0;
	int PosPeak  = 0;

	for(int i=0; i<templen; i++)
	{
		if (pDecHist[i] > 0 && i < templen - 1)
		{
			TepArea += abs(pDecHist[i]);

			if (TepPeak < abs(pDecHist[i]))
			{
				TepPeak = abs(pDecHist[i]);
				TepPos  = i;
			}
		}
		else
		{
			if (PosArea < TepArea)
			{
				PosArea  = TepArea;
				PosPos   = TepPos;
				PosPeak  = TepPeak;
			}

			TepArea  = 0;
			TepPos   = 0;
			TepPeak  = 0;
		}
	}

	// 2.2.3�������ֵ��������������ֵ��λ��
	TepArea  = 0;
	TepPos   = 0;
	TepPeak  = 0;

	int NegArea  = 0;
	int NegPos   = 0;
	int NegPeak  = 0;

	for(int i=0; i<templen; i++)
	{
		if (pDecHist[i] < 0 && i < templen - 1)
		{
			TepArea += abs(pDecHist[i]);

			if (TepPeak < abs(pDecHist[i]))
			{
				TepPeak = abs(pDecHist[i]);
				TepPos = i;
			}
		}
		else
		{
			if (NegArea < TepArea)
			{
				NegArea  = TepArea;
				NegPos   = TepPos;
				NegPeak  = TepPeak;
			}

			TepArea  = 0;
			TepPos   = i;
			TepPeak  = 0;
		}
	}

	WbcOutput->FeaturePara.PosPeak   = PosPeak;
	WbcOutput->FeaturePara.PosArea   = PosArea;
	WbcOutput->FeaturePara.NegPeak   = NegPeak;
	WbcOutput->FeaturePara.NegArea   = NegArea;

	POINTER_FREE(ptempdata);
	POINTER_FREE(pDecHist);

	return true;
}

int get_peak_index_of_int_array_within_range(int *array, int left, int right,
	int *max_val)
{
	int i, peak_pos;
	int tmp = 0;
	int offset = 2;

	peak_pos = 0;
	if (left + offset + offset >= right - offset)
	{
		return 0;
	}
	for (i = left + offset; i < right - offset; i++)
	{
		if (array[i - offset] < array[i] && array[i] > array[i + offset])
		{
			if (tmp < array[i])
			{
				tmp = array[i];
				peak_pos = i;
			}
		}
	}

	if (peak_pos == 0)
	{
		tmp = 0;
		for (i = left + 1; i < right - 1; i++)
		{
			if (array[i - 1] <= array[i] && array[i] >= array[i + 1])
			{
				if (tmp < array[i])
				{
					tmp = array[i];
					peak_pos = i;
				}
			}
		}
	}
	*max_val = tmp;
	return peak_pos;
}

int get_max_index_of_int_array_within_range(int *array, int left, int right,
	int *max_val)
{
	int i, peak_pos;
	int tmp = *max_val;

	peak_pos = 0;
	if (left >= right)
	{
		return 0;
	}
	for (i = left; i < right; i++)
	{
		if (tmp < array[i])
		{
			tmp = array[i];
			peak_pos = i;
		}
	}
	*max_val = tmp;
	return peak_pos;
}

int get_trough_index_of_int_array_within_range(int *array, int left, int right,
	int *min_val)
{
	int i, min_pos;
	int tmp = *min_val;
	int offset = 2;

	min_pos = 0;
	if (left + offset + offset >= right - offset)
	{
		return 0;
	}
	for (i = left + offset; i < right - offset; i++)
	{
		if (array[i - offset] >= array[i] && array[i] < array[i + offset])
		{
			if (tmp >= array[i])
			{
				tmp = array[i];
				min_pos = i;
			}
		}
	}

	if (!min_pos)
	{
		tmp = *min_val;
		for (i = left + 1; i < right - 1; i++)
		{
			if (array[i - 1] >= array[i] && array[i] <= array[i + 1])
			{
				if (tmp > array[i])
				{
					tmp = array[i];
					min_pos = i;
				}
			}
		}
	}
	*min_val = tmp;
	return min_pos;
}

static void wbc_classification_for_int_array(stWbcOutput *s_output, int *hist_data)
{

	int ghost_peak_pos1, lym_start_pos, lym_peak_pos, lym_end_pos, gran_end_pos,
		gran_peak_pos, gran_start_pos, tmp_pos, ghost_peak_pos2;
	int i, ghost_redge, lym_redge, gran_redge;
	int ghost_peak_val, lym_peak_val, lym_start_val, total_max_val,
		l2_l3_gap;
	int tmp;
	double atan1, atan2, multi, sub;

	int wbc_hist_datalen = s_output->GraphPara.OrgHist.datalen;
	ghost_redge = 12;
	lym_redge = 50;
	gran_redge = 210;

	// ��ȡȫ�����ֵ����С��10����Ĭ�Ϸ��ദ��
	total_max_val = 0;
	for (i = 0; i < wbc_hist_datalen; i++)
	{
		if (total_max_val < hist_data[i])
		{
			total_max_val = hist_data[i];
		}
	}
	if (total_max_val < 10)
		return;


	// ��ȡѪӰ��ֵ
	ghost_peak_val = 0;
	ghost_peak_pos1 = get_peak_index_of_int_array_within_range(hist_data, 0,
		ghost_redge, &ghost_peak_val);
	

	// ��ȡlym��ֵ
	lym_peak_val = 0;
	lym_peak_pos = get_peak_index_of_int_array_within_range(hist_data, ghost_redge,
		lym_redge, &lym_peak_val);
	if (!lym_peak_pos)
	{
		s_output->GraphPara.DspHist.lines[4] = (s_output->GraphPara.DspHist.
			lines[1] + s_output->GraphPara.DspHist.lines[2]) / 2;
		tmp = 0;
		s_output->GraphPara.DspHist.lines[5] = 
			get_max_index_of_int_array_within_range(hist_data, s_output->GraphPara.DspHist.
				lines[1], s_output->GraphPara.DspHist.lines[3], &tmp);
		return;
	}
	else
		s_output->GraphPara.DspHist.lines[4] = lym_peak_pos;
		

	// ��ȡlym��ʼ�㣬��L1
	lym_start_val = total_max_val + 1;
	lym_start_pos = get_trough_index_of_int_array_within_range(hist_data,
		ghost_peak_pos1, lym_peak_pos, &lym_start_val);
	if (lym_start_pos)
	{
		s_output->GraphPara.DspHist.lines[0] = lym_start_pos;
	}

	// ��ȡlym��ֹ�㣬��L2
	bool lym_end_flag = true;
	tmp_pos = 0;
	for (i = lym_peak_pos + 2; i < wbc_hist_datalen - 2; ++i)
	{
		atan1 = atan((hist_data[i + 2] - hist_data[i]) / 2.0);
		atan2 = atan((hist_data[i] - hist_data[i - 2]) / 2.0);

		multi = atan1*atan2;
		if (multi < 0.00001 && i - lym_peak_pos > 8 &&
			hist_data[i] * 100 < 63 * lym_peak_val)
		{
			tmp_pos = i;
			break;
		}
	}
	if (tmp_pos - lym_peak_pos < 35)
	{
		lym_end_pos = tmp_pos;
	} 
	else
	{
		tmp_pos = 0;
		tmp = total_max_val + 1;
		for (i = lym_peak_pos + 2; i < lym_peak_pos + 26; ++i)
		{
			atan1 = atan((hist_data[i + 2] - hist_data[i]) / 2.0);
			atan2 = atan((hist_data[i] - hist_data[i - 2]) / 2.0);

			sub = fabs(atan1 - atan2);
			if (sub > 1.1 && i - lym_peak_pos > 11 &&
				fabs(atan1) < fabs(atan2) && tmp > hist_data[i])
			{
				tmp_pos = i;
				tmp = hist_data[i];
			}
		}
		if (tmp_pos)
			lym_end_pos = tmp_pos; 
		else
		{
			lym_end_flag = false;
			lym_end_pos = 50;
		}


	}
	
	
	if (lym_end_flag && hist_data[lym_end_pos]*10 > hist_data[lym_peak_pos]*15)
	{
		int adjust_coef = (int)(35 - (hist_data[lym_end_pos]*10/hist_data[lym_peak_pos])*0.5);
		if(adjust_coef < 0)
			adjust_coef = 0;
		lym_end_pos = s_output->GraphPara.DspHist.lines[0] + adjust_coef;
	}
		
	if(lym_end_pos)
		s_output->GraphPara.DspHist.lines[1] = lym_end_pos;

	// ��ȡgran��ֹ�㣬��L4
	ghost_peak_val = 0;
	ghost_peak_pos2 = wbc_hist_datalen;
	for (i = wbc_hist_datalen - 2; i > gran_redge + 2; i--)
	{
		if (hist_data[i - 2] < hist_data[i] && hist_data[i] > hist_data[i + 2])
		{
			ghost_peak_pos2 = i;
			break;
		}
	}
	gran_end_pos = wbc_hist_datalen - 1;
	for (i = ghost_peak_pos2 - 1; i > gran_redge + 1; i--)
	{
		if (hist_data[i - 1] >= hist_data[i] && hist_data[i] <= hist_data[i + 1])
		{
			gran_end_pos = i;
			break;
		}
	}
	s_output->GraphPara.DspHist.lines[3] = gran_end_pos;

	//// ��˹��ϻ�ȡgran�ķ�ֵλ��
	//gran_peak_pos = (int)gsl_gauss_fit_for_int_array(hist_data, lym_end_pos,
	//	gran_end_pos);
	// ͳ�Ʒ���ȡgran��ֵ��λ��
	int tempval1  = 0;
	int tempval2 = 0;
	for (i=lym_peak_pos+20; i<250; i++)
	{
		tempval1 += hist_data[i];
		tempval2 += hist_data[i]*i;
	}

	int templine = 0;
	if (tempval1 != 0)
	{
		templine = tempval2/tempval1;
	} 
	
	int maxval = 0;
	for (i=templine; i<250; i++)
	{
		if (maxval < hist_data[i])
		{
			maxval = hist_data[i];
			gran_peak_pos = i;
		}
	}

	// ����������ȡL2-L3�ľ���
	l2_l3_gap = (int)(0.23*(gran_peak_pos - lym_end_pos) + 4.99);
	//l2_l3_gap = (int)(0.23*(gran_peak_pos - lym_peak_pos) + 3.99);
	if (l2_l3_gap < 10)
	{
		l2_l3_gap = 10;
		gran_peak_pos = lym_end_pos + l2_l3_gap;
	}
	// �������L3��λ�ã��ж�L2-L3�ľ����Ƿ���Ҫ΢��	
	gran_start_pos = lym_end_pos + l2_l3_gap;
	if (hist_data[gran_start_pos]*10 > hist_data[gran_peak_pos]*11)
	{
		l2_l3_gap = 15;
	}
	/*int avg_gran_start = (hist_data[gran_start_pos-1] + hist_data[gran_start_pos] + 
		hist_data[gran_start_pos+1])/3;
	int avg_gran_peak = (hist_data[gran_peak_pos-1] + hist_data[gran_peak_pos] + 
		hist_data[gran_peak_pos+1])/3;
	if (avg_gran_start*10 > avg_gran_peak*11)
	{
		l2_l3_gap = 10;
	}*/
	/*else if (avg_gran_start*100 > avg_gran_peak*70)
	{
		l2_l3_gap -= 7;
	}*/
	// ȷ��L3��λ�ã�����ֵ������ṹ��
	gran_start_pos = lym_end_pos + l2_l3_gap;
	s_output->GraphPara.DspHist.lines[5] = gran_peak_pos;
	s_output->GraphPara.DspHist.lines[2] = gran_start_pos;

}

/*******************************************************************
// �� �� ���� classify
// ��    �ܣ� �����㷨
********************************************************************/
bool wbcclassify(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	stHist DspHist = WbcOutput->GraphPara.DspHist;

	int i =0;
	int j = 0;
	int minval = 0;
	int maxval = 0;

	// ��һ��������(��Сֵ)
	int firstline = 10;
	minval = DspHist.datas[10];
	for (i=10; i<20; i++)
	{
		if (minval > DspHist.datas[i])
		{
			minval = DspHist.datas[i];
			firstline = i;
		}
	}

	WbcOutput->GraphPara.OrgHist.lines[0] = firstline;
	WbcOutput->GraphPara.DspHist.lines[0] = firstline;

	/*WbcOutput->GraphPara.OrgHist.lines[0] = 20;
	WbcOutput->GraphPara.DspHist.lines[0] = 20;*/

	WbcOutput->GraphPara.OrgHist.lines[1] = 50;
	WbcOutput->GraphPara.DspHist.lines[1] = 50;

	WbcOutput->GraphPara.OrgHist.lines[2] = 70;
	WbcOutput->GraphPara.DspHist.lines[2] = 70;

	WbcOutput->GraphPara.OrgHist.lines[3] = 252;
	WbcOutput->GraphPara.DspHist.lines[3] = 252;

	
	//// �ܰͷ�ֵ
	//int lympeakline = firstline;
	//for (i=lympeakline; i<40; i++)
	//{
	//	if (maxval < DspHist.datas[i])
	//	{
	//		maxval = DspHist.datas[i];
	//		lympeakline = i;
	//	}
	//}

	//WbcOutput->GraphPara.OrgHist.lines[1] = lympeakline + 20;
	//WbcOutput->GraphPara.DspHist.lines[1] = lympeakline + 20;
	//
	//// ��ϸ����ֵ
	//int tempval1  = 0;
	//int tempval2 = 0;
	//for (i=lympeakline+20; i<250; i++)
	//{
	//	tempval1 += DspHist.datas[i];
	//	tempval2 += DspHist.datas[i]*i;
	//}

	//int templine = tempval2/tempval1;

	//int granpeakline = templine;
	//maxval = 0;
	//for (i=granpeakline; i<250; i++)
	//{
	//	if (maxval < DspHist.datas[i])
	//	{
	//		maxval = DspHist.datas[i];
	//		granpeakline = i;
	//	}
	//}

	// 

	//WbcOutput->GraphPara.DspHist.lines[4] = granpeakline;
	//WbcOutput->GraphPara.OrgHist.lines[4] = granpeakline;

	//WbcOutput->GraphPara.OrgHist.lines[4] = lympeakline;
	//WbcOutput->GraphPara.DspHist.lines[4] = lympeakline;

	//WbcOutput->GraphPara.DspHist.lines[5] = granpeakline;
	//WbcOutput->GraphPara.OrgHist.lines[5] = granpeakline;
	wbc_classification_for_int_array(WbcOutput,WbcOutput->GraphPara.DspHist.datas);
	WbcOutput->GraphPara.OrgHist.linelen = 4;
	WbcOutput->GraphPara.DspHist.linelen = 4;
	memcpy(WbcOutput->GraphPara.OrgHist.lines,WbcOutput->GraphPara.DspHist.lines,
		sizeof(int)*WbcOutput->GraphPara.DspHist.linelen);

	return true;
}

/*******************************************************************
// �� �� ���� paracal
// ��    �ܣ� ������
********************************************************************/
bool wbcparacal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ����ͼ�δ���
	GraphParaCal(WbcInput, WbcOutput);

	// 1�������������
	WbcServiceParaCal(WbcInput, WbcOutput);

	// 2�������������
	WbcReportParaCal(WbcInput,  WbcOutput);

	// 3��������������
	WbcFeatureParaCal(WbcInput,  WbcOutput);

	return true;
}

// Wbcͼ�β�������
bool GraphParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if ( WbcInput  == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// Wbc��ʾֱ��ͼ
	//WbcOutput->GraphPara.DspHist.lines = WbcOutput->GraphPara.OrgHist;

	return true;
}

// Wbc ���Ӳ���
int WbcCompensation(int fWbcTotal, double dExpCoff)
{
	// one
	double tmpdouble      = dExpCoff*fWbcTotal*0.000001;
	double ftmpRbcCompFac = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	double ftmpRbcTotal   = fWbcTotal/ftmpRbcCompFac;

	// two
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpRbcTotal    = fWbcTotal/ftmpRbcCompFac;

	// three
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;
	ftmpRbcTotal    = fWbcTotal/ftmpRbcCompFac;

	// four
	tmpdouble       = dExpCoff*ftmpRbcTotal*0.000001;
	ftmpRbcCompFac  = (exp(-1*tmpdouble) + exp(-2*tmpdouble) + 1)/3;

	int WbcTotalNum = (int)(fWbcTotal/ftmpRbcCompFac);

	return WbcTotalNum;
}

// Wbc�����������
bool WbcReportParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if ( WbcInput  == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// ���ò���
	int    Alg_W_Cal_SubBackGround = WbcInput->WbcConfigPara.Alg_W_Cal_SubBackGround;
	double Alg_W_Cal_dWbcExpCoff   = WbcInput->WbcConfigPara.Alg_W_Cal_dWbcExpCoff;

	// ��������
	int    WbcCellNum  = WbcOutput->ServicePara.WbcCellNum;
	int    LymCellNum  = WbcOutput->ServicePara.LymCellNum;
	int    MidCellNum  = WbcOutput->ServicePara.MidCellNum;
	int    GranCellNum = WbcOutput->ServicePara.GranCellNum;

	double Dilution    = WbcInput->Dilution;
	double Volume      = WbcInput->Volume;

	// 1��WBC����
	double dWbc     = 0.0;

	// 1.1�����Ӳ���
	WbcCellNum  = WbcCompensation(WbcCellNum, Alg_W_Cal_dWbcExpCoff);

	// 1.2��������
	WbcCellNum -= Alg_W_Cal_SubBackGround;

	// 1.3��fWbc����
	if (Volume > EPSINON)
	{
		dWbc = WbcCellNum*Dilution/Volume/1000;
	}
	// 1.4����ֵ��������
	if (dWbc > 121.99679)
	{
		dWbc = 0.0000134*dWbc*dWbc*dWbc - 0.00464*dWbc*dWbc + 1.36663*dWbc;
	}
	WbcOutput->ReportPara.Wbc = (dWbc > EPSINON) ? dWbc : 0;

	// 2��Lym%����
	double dLymPer  = 0.0;
	double dMidPer  = 0.0;
	double dGranPer = 0.0;
	
	if (WbcCellNum > EPSINON)
	{
		dLymPer  = 100.0*LymCellNum/WbcCellNum;
		dMidPer  = 100.0*MidCellNum/WbcCellNum;
		dGranPer = 100.0*GranCellNum/WbcCellNum;
	}
	
	WbcOutput->ReportPara.LymPer  = dLymPer;
	WbcOutput->ReportPara.MidPer  = dMidPer;
	WbcOutput->ReportPara.GranPer = dGranPer;

	return true;
}

// Wbc������������
bool WbcFeatureParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}


	return true;
}

// Wbc�����������
bool WbcServiceParaCal(stWbcInput *WbcInput, stWbcOutput *WbcOutput)
{
	if (WbcInput == NULL || WbcOutput == NULL)
	{
		return false;
	}

	// CellList��Ϣ
	stHist OrgHist = WbcOutput->GraphPara.OrgHist;
	
	// ��������ͳ��
	int WbcNum  = 0;
	int LymNum  = 0;
	int MidNum  = 0;
	int GranNum = 0;

	for (int i=OrgHist.lines[0]; i<OrgHist.lines[1]; i++)
	{
		LymNum += OrgHist.datas[i];
	}

	for (int i=OrgHist.lines[1]; i<OrgHist.lines[2]; i++)
	{
		MidNum += OrgHist.datas[i];
	}

	for (int i=OrgHist.lines[2]; i<OrgHist.lines[3]; i++)
	{
		GranNum += OrgHist.datas[i];
	}

	WbcNum = LymNum + MidNum + GranNum;

	// W-MCV
	double NumDec = 0;
	double NumSum = 0;

	for (int i=OrgHist.lines[0]; i<OrgHist.lines[3]; i++)
	{
		NumDec += OrgHist.datas[i];
		NumSum += OrgHist.datas[i]*i;
	}

	double mcv = 0.0;
	
	if (NumDec > 0)
	{
		mcv = 1.0 * NumSum / NumDec;
	}
	
	// ��ֵ
	WbcOutput->ServicePara.WbcCellNum  = WbcNum;
	WbcOutput->ServicePara.LymCellNum  = LymNum;
	WbcOutput->ServicePara.MidCellNum  = MidNum;
	WbcOutput->ServicePara.GranCellNum = GranNum;
	WbcOutput->ServicePara.W_MCV       = mcv;
	return true;
}
