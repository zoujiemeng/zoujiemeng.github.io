#ifndef _ALG_H__
#define _ALG_H__

#include "protocolalg.h"


#ifdef __cplusplus  
extern "C" {       
#endif  


// ͨ������
typedef enum _COLLECT_CHANNEL_TYPE
{
	COLLECT_CHANNEL_WBC_PULSE = 0, //WBC����
	COLLECT_CHANNEL_RBC_PULSE, // RBC����
	COLLECT_CHANNEL_PLT_PULSE,
	COLLECT_CHANNEL_WBC_APERTURE_VOL,// WBCС�׵�ѹ
	COLLECT_CHANNEL_RBC_APERTURE_VOL, // RBCС�׵�ѹ
	COLLECT_CHANNEL_WBC_BASE, //WBC����
	COLLECT_CHANNEL_RBC_BASE, // RBC����
	COLLECT_CHANNEL_HGB, //HGB��ѹ
	COLLECT_CHANNEL_DIFF_PULSE,
	COLLECT_CHANNEL_DIFF_L,
	COLLECT_CHANNEL_DIFF_M,
	COLLECT_CHANNEL_DIFF_H,
	COLLECT_CHANNEL_BASO_PULSE,
	COLLECT_CHANNEL_BASO_L,
	COLLECT_CHANNEL_BASO_M,
	COLLECT_CHANNEL_BASO_H,
	COLLECT_CHANNEL_DB_APERTURE,
	COLLECT_CHANNEL_DB_BASE,
	COLLECT_CHANNEL_CRP,
	COLLECT_CHANNEL_RBC_OD,
	COLLECT_CHANNEL_WBC_OD,
	COLLECT_CHANNEL_PLT_OD,
	COLLECT_CHANNEL_MAX
} COLLECT_CHANNEL_TYPE;

// �ɼ�״̬
typedef enum _COLLECT_STATE
{
	COLLECT_STATE_IDLE = 0,
	COLLECT_STATE_READY,
	COLLECT_STATE_RUNNING,
	COLLECT_STATE_STOP
} COLLECT_STATE;

//�ɼ�ͨ��
typedef struct _CollectChannel
{
	unsigned long ulAddr;        //��ʼ��ַ 
	unsigned long ulCount;       //�Ѳɼ�������(Byte)
	int lState;                  // 1 ���ڲɼ�  0 ֹͣ
}CollectChannel;

//�ɼ����
typedef struct _DataCollectHandle
{
	unsigned int ulMagic;         // Ĭ��0x12345678
	COLLECT_STATE eCollectState;    
	CollectChannel astChannels[COLLECT_CHANNEL_MAX]; //�ɼ�ͨ��
}DataCollectHandle;


//��ѹ�ɼ�ͨ��
typedef struct _NegPressCollectChannel
{
    unsigned int ulCount;       //�Ѳɼ�����
    int lState;                  // 1 ���ڲɼ�  0 ֹͣ
	unsigned short *punAddr;        //��ʼ��ַ 
}NegPressCollectChannel;

//CRP���ݲɼ�ͨ��
typedef struct _CRPCollectChannel
{
    unsigned int ulCount;       //�Ѳɼ�����
    int lState;                  // 1 ���ڲɼ�  0 ֹͣ
	unsigned short *punAddr;        //��ʼ��ַ 
}CRPCollectChannel;

//Һ��ѹ���ɼ�ͨ��
typedef struct _LiquidPressCollectChannel
{
    unsigned int ulCount;       //�Ѳɼ�����
    int lState;                  // 1 ���ڲɼ�  0 ֹͣ
    unsigned short *punAddr;        //��ʼ��ַ 
}LiquidPressCollectChannel;


#define FPGA_PACK_SIZE (16)


char *AlgGetVersion(void);
int BK_alg_main(unsigned char *buff, DataCollectHandle *data_handle, 
	const sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result, alg_output_info *outInfo);
int bk_generate_new_inf_file(unsigned char *buff, DataCollectHandle *data_handle,
	sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result);


void AlgSetDilutionRatio(int lRatioWbWBC, int lRatioWbPLT, int lRatioPreWBC, int lRatioPrePLT);
void AlgSetCalFactor(const item_cal_factor_t *pstCalFactor);
void AlgSetCrpParaInfo(const crp_para_info *pstPara);
int AlgAddCrpData(const CRPCollectChannel *pstLowHandle, const CRPCollectChannel *pstHighHandle);
int AlgAddNegPressData(const NegPressCollectChannel *pstHandle);


#ifdef __cplusplus  
}  
#endif


#endif



