#ifdef __cplusplus  
extern "C" {       
#endif  

int BK_alg_main(unsigned char *buff, DataCollectHandle *data_handle, 
	const sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result, alg_output_info *outInfo);


#ifdef __cplusplus  
}  
#endif