#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "alg.h"
#include "protocolalg.h"
#include "../alg_flow_main.h"

#define  POINTER_FREE_BKALG(p)    if (p != NULL)   \
							{                \
							delete[] p;  \
							p = NULL;    \
							}


#define ALG_VERSION "1.1.4220"
//#define BK_LINUX_TEST
#ifndef MAX_PATH
#define MAX_PATH          260
#endif

//extern item_cal_factor_t g_calFactor;
//extern crp_para_info g_stCrpParaInfo;
//extern const CRPCollectChannel *g_crpCollectHandle;
//extern const CRPCollectChannel *g_highCrpCollectHandle;
//extern const NegPressCollectChannel *g_negCollectHandle;
//
//
//extern double g_fRatioWbWBC;
//extern double g_fRatioWbPLT;
//extern double g_fRatioPreWBC;
//extern double g_fRatioPrePLT;


double g_fRatioWbWBC  = 305.1f;
double g_fRatioWbPLT  = 16498.5f;
double g_fRatioPreWBC = 502;
double g_fRatioPrePLT = 16449.4f;
void AlgSetDilutionRatio(int lRatioWbWBC, int lRatioWbPLT, int lRatioPreWBC, int lRatioPrePLT)
{
	g_fRatioWbWBC  = 1.0*lRatioWbWBC / 10;
	g_fRatioWbPLT  = 1.0*lRatioWbPLT / 10;	
	g_fRatioPreWBC = 1.0*lRatioPreWBC / 10;		
	g_fRatioPrePLT = 1.0*lRatioPrePLT / 10;			
}

item_cal_factor_t g_calFactor;
// �����㷨У׼ϵ��
void AlgSetCalFactor(const item_cal_factor_t *pstCalFactor)
{	
	printf("SetAlgCalFactor alg\n");	
	memcpy(&g_calFactor, pstCalFactor, sizeof(g_calFactor));	
	return;
}

crp_para_info g_stCrpParaInfo;
// ����CRPУ׼����
void AlgSetCrpParaInfo(const crp_para_info *pstPara)
{    
	memcpy(&g_stCrpParaInfo, pstPara, sizeof(crp_para_info));
}


const CRPCollectChannel *g_crpCollectHandle = NULL;
const CRPCollectChannel *g_highCrpCollectHandle = NULL;
// �ⲿ���ݸ��㷨ģ��CRP����
int AlgAddCrpData(const CRPCollectChannel *pstLowHandle, const CRPCollectChannel *pstHighHandle)
{	
	printf("AlgAddCrpData alg. ulCount = %ld.  punAddr = %ld, ulCount = %ld.  punAddr = %ld\n", pstLowHandle->ulCount, (int)(pstLowHandle->punAddr), pstHighHandle->ulCount, (int)(pstHighHandle->punAddr));	
	g_crpCollectHandle = pstLowHandle;	
	g_highCrpCollectHandle = pstHighHandle;	
	return 0;
}

const NegPressCollectChannel *g_negCollectHandle = NULL;
// �ⲿ���ݸ��㷨ģ�鸺ѹ����
int AlgAddNegPressData(const NegPressCollectChannel *pstHandle)
{	
	printf("AlgAddNegPressData alg\n");	
	g_negCollectHandle = pstHandle;	
	return 0;
}


char *AlgGetVersion(void)
{
	char *pcVersion = GetAlgVersion(); 
	return pcVersion;
}	

int getmark(PARA para)
{
	int mark = 0;

	switch(para.Mark)
	{
	case NORMAL: mark = ParaMarkNormal;break;
	case BLANK : mark = ParaMarkBlank;break;
	case STAR  : mark = ParaMarkStar;break;
	case DOUBT : mark = ParaMarkDoubt;break;
	case HIGH  : mark = ParaMarkHigh;break;
	default:     mark = ParaMarkNormal;break;
	}

	return mark;
}

void getitem_graph_t(item_graph_t &reshist, stHist &orghist)
{
	reshist.len = orghist.datalen;

	for (int i=0; i<reshist.len; i++)
	{
		reshist.data[i] = orghist.datas[i];
	}
}

int getHintFlag(stAlgOutput AlgOutput)
{
	int HintFlag = 0;

	//tempval   = AlgOutput.Alarm[WBCDECREASE].Flag ? HintFlagWbcLess : 0;
	//HintFlag += tempval;

	//tempval   = AlgOutput.Alarm[WBCINCREASE].Flag ? HintFlagWbcMore : 0;
	//HintFlag += tempval;

	//tempval   = AlgOutput.Alarm[WBCINCREASE].Flag ? HintFlagWbcMore : 0;
	//HintFlag += tempval;

	HintFlag += AlgOutput.Alarm[WBCDECREASE].Flag  ? HintFlagWbcLess  : 0;
	HintFlag += AlgOutput.Alarm[WBCINCREASE].Flag  ? HintFlagWbcMore  : 0;
	HintFlag += AlgOutput.Alarm[GRANDECREASE].Flag ? HintFlagGranLess : 0;
	HintFlag += AlgOutput.Alarm[GRANINCREASE].Flag ? HintFlagGranMore : 0;
	HintFlag += AlgOutput.Alarm[WBCABN].Flag       ? HintFlagWbcAbnormal : 0;
	HintFlag += AlgOutput.Alarm[LYMDECREASE].Flag  ? HintFlagLymphLess : 0;
	HintFlag += AlgOutput.Alarm[LYMINCREASE].Flag  ? HintFlagLymphMore : 0;
	HintFlag += AlgOutput.Alarm[MIDINCREASE].Flag  ? HintFlagMidMore   : 0;

	// ��ϵ����	// HintFlag3SerialLess

	HintFlag += AlgOutput.Alarm[RBCINCREASE].Flag   ? HintFlagRbcMore   : 0;
	HintFlag += AlgOutput.Alarm[ANISOCYTOSIS].Flag  ? HintFlagRbcInequality : 0;
	HintFlag += AlgOutput.Alarm[MACROCYTHEMIA].Flag ? HintFlagRbcOversized : 0;
	HintFlag += AlgOutput.Alarm[MICROCYTHEMIA].Flag ? HintFlagRbcSmallsize : 0;
	HintFlag += AlgOutput.Alarm[ANEMIA].Flag ? HintFlagRbcAnemia : 0;
	HintFlag += AlgOutput.Alarm[HYPOCHROMIA].Flag ? HintFlagRbcHypochromic : 0;
	HintFlag += AlgOutput.Alarm[RBCHISTABN].Flag ? HintFlagRbcAbnormal : 0;
	HintFlag += AlgOutput.Alarm[BIMODALITY].Flag ? HintFlagRbcBimodality : 0;
	HintFlag += AlgOutput.Alarm[AGGLUTINATION].Flag ? HintFlagRbcAggregation : 0;
	HintFlag += AlgOutput.Alarm[IRON].Flag ? HintFlagRbcIDA : 0;
	HintFlag += AlgOutput.Alarm[HGBINTERF].Flag ? HintFlagRbcHgbAbnormal : 0;

	HintFlag += AlgOutput.Alarm[PLTDECREASE].Flag ? HintFlagPltLess : 0;
	HintFlag += AlgOutput.Alarm[PLTINCREASE].Flag ? HintFlagPltMore : 0;
	HintFlag += AlgOutput.Alarm[PLTHISTABN].Flag ? HintFlagPltAbnormal : 0;
	HintFlag += AlgOutput.Alarm[PLTCLUMPS].Flag ? HintFlagPltAggregation : 0;

	HintFlag += AlgOutput.Alarm[CRPINCREASE].Flag ? HintFlagCrpExcess : 0;

	// ��ϸ���ֲ��쳣
	HintFlag += AlgOutput.Alarm[WBCHISTABN].Flag ? HintFlagWbcDistributeAbnormal : 0;

	// ���׻������쳣
	HintFlag += AlgOutput.Alarm[BLANKORABSORBABN].Flag ? HintFlagBlankOrAbsorbAbnormal : 0;

	return HintFlag;
}

int getErrorFlag(stAlgOutput AlgOutput)
{
	int ErrorFlag = 0;

	// ��ϸ���¿�
	ErrorFlag += AlgOutput.Alarm[WBCSYSTEMERROR_BLOCK].Flag ? ErrorFlagWbcBlock : 0;
	
	// ��ϸ���¿�
	ErrorFlag += AlgOutput.Alarm[RBCSYSTEMERROR_BLOCK].Flag ? ErrorFlagRbcBlock : 0;

	// ��ϸ��С�׵�ѹ�쳣
	ErrorFlag += AlgOutput.Alarm[WBCSYSTEMERROR_HOLEABN].Flag ? ErrorFlagWbcHoleVAbnormal : 0;

	// ��ϸ��С�׵�ѹ�쳣
	ErrorFlag += AlgOutput.Alarm[RBCSYSTEMERROR_HOLEABN].Flag ? ErrorFlagRbcHoleVAbnormal : 0;

	return ErrorFlag;
}

int BK_alg_main(unsigned char *buff, DataCollectHandle *data_handle, const sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result, alg_output_info *outInfo)
{
	if (buff == NULL || data_handle == NULL || s_sample_info == NULL || bk_result == NULL || outInfo == NULL)
	{
		return 0;
	}

	stAlgInput  AlgInput;
	stAlgOutput AlgOutput;

	 printf("bk_alg_main_start!\n");
	 printf("whole_blood_wbc_dilution:%f\n",g_fRatioWbWBC);
	 printf("whole_blood_rbc_dilution:%f\n",g_fRatioWbPLT);
	 printf("prediluted_wbc_dilution:%f\n",g_fRatioPreWBC);
	 printf("prediluted_rbc_dilution:%f\n",g_fRatioPrePLT);

	/****************************************************************/
	// ����ת��-------------------------------------------------------
	/****************************************************************/
	// ģʽ��Ϣ-------------------------------------------------------
	switch(s_sample_info->bm)
	{
	case 0: AlgInput.BloodMode = BLOODMODE_WHOLEBLOOD; break;
	case 1: AlgInput.BloodMode = BLOODMODE_PREDILUENT; break;
	default:AlgInput.BloodMode = BLOODMODE_WHOLEBLOOD; break;		
	}

	switch(s_sample_info->am)
	{
	case 0: AlgInput.AnalyMode = ANALYSISMODE_CBC; break;
	case 1: AlgInput.AnalyMode = ANALYSISMODE_CRP; break;
	case 2: AlgInput.AnalyMode = ANALYSISMODE_CBC_CRP; break;
	default:AlgInput.AnalyMode = ANALYSISMODE_CBC_CRP; break;		
	}

	switch(s_sample_info->wm)
	{
	case 0: AlgInput.WorkMode = WORKMODE_BLOOD; break;
	case 1: AlgInput.WorkMode = WORKMODE_QUALC; break;
	case 2: AlgInput.WorkMode = WORKMODE_CB_US; break;
	case 3: AlgInput.WorkMode = WORKMODE_CB_FA; break;
	case 4: AlgInput.WorkMode = WORKMODE_CRPSC; break;
	default:AlgInput.WorkMode = WORKMODE_BLOOD; break;		
	}

	// ����ģʽ-------------------------------------------------------
	//switch((g_stCrpParaInfo.calMethod))
	//{
	//case CRP_METHOD_LOG4P    : AlgInput.CrpInput.ScaleMode = SCALEMODE_L4LINE; break;
	//case CRP_METHOD_SPLINE   :
	//case CRP_METHOD_TWO_POINT:
	//case CRP_METHOD_LOGISTICS:
	//default: AlgInput.CrpInput.ScaleMode = SCALEMODE_L4LINE;
	//}

	AlgInput.ScaleMode = SCALEMODE_L4LINE;
	
	// ���ϡ�ͱ�-----------------------------------------------------
	if (AlgInput.BloodMode == BLOODMODE_WHOLEBLOOD)
	{
		AlgInput.WbcInput.Dilution           = g_fRatioWbWBC;
		AlgInput.HgbInput.Dilution           = g_fRatioWbWBC;
		AlgInput.ImpdInput.RbcInput.Dilution = g_fRatioWbPLT;
		AlgInput.ImpdInput.PltInput.Dilution = g_fRatioWbPLT;
	}
	else
	{
		AlgInput.WbcInput.Dilution           = g_fRatioPreWBC;
		AlgInput.HgbInput.Dilution           = g_fRatioPreWBC;
		AlgInput.ImpdInput.RbcInput.Dilution = g_fRatioPrePLT;
		AlgInput.ImpdInput.PltInput.Dilution = g_fRatioPrePLT;
	}

	// if (AlgInput.BloodMode == BLOODMODE_WHOLEBLOOD)
	// {
	// 	AlgInput.WbcInput.Dilution           = 305.1;
	// 	AlgInput.HgbInput.Dilution           = 305.1;
	// 	AlgInput.ImpdInput.RbcInput.Dilution = 16498.5;
	// 	AlgInput.ImpdInput.PltInput.Dilution = 16498.5;
	// }
	// else
	// {
	// 	AlgInput.WbcInput.Dilution           = 502.0;
	// 	AlgInput.HgbInput.Dilution           = 502.0;
	// 	AlgInput.ImpdInput.RbcInput.Dilution = 16449.4;
	// 	AlgInput.ImpdInput.PltInput.Dilution = 16449.4;
	// }

	AlgInput.WbcInput.Volume = 402.8;
	AlgInput.HgbInput.Volume = 402.8;
	AlgInput.ImpdInput.RbcInput.Volume = 197.372;
	AlgInput.ImpdInput.PltInput.Volume = 197.372;

	// �������-------------------------------------------------------
	if (AlgInput.BloodMode == BLOODMODE_WHOLEBLOOD)
	{
		int datalens = g_stCrpParaInfo.stWbPara.lParaNum;
		AlgInput.CrpInput.ScalePara.datalens = datalens;

		for (int i=0; i<datalens; i++)
		{
			AlgInput.CrpInput.ScalePara.paradata[i] = g_stCrpParaInfo.stWbPara.afPara[i];
		}
	}
	else
	{
		int datalens = g_stCrpParaInfo.stPrePara.lParaNum;
		AlgInput.CrpInput.ScalePara.datalens = datalens;

		for (int i=0; i<datalens; i++)
		{
			AlgInput.CrpInput.ScalePara.paradata[i] = g_stCrpParaInfo.stPrePara.afPara[i];
		}
	}

	printf("scaleparalens:%d\n",AlgInput.CrpInput.ScalePara.datalens);

	if (AlgInput.CrpInput.ScalePara.datalens >= 4)
	{
		printf("scalepraadatas1:%f\n",AlgInput.CrpInput.ScalePara.paradata[0]);
		printf("scaleparadatas2:%f\n",AlgInput.CrpInput.ScalePara.paradata[1]);
		printf("scaleparadatas3:%f\n",AlgInput.CrpInput.ScalePara.paradata[2]);
		printf("scaleparadatas4:%f\n",AlgInput.CrpInput.ScalePara.paradata[3]);
	}

	// У׼ϵ��-------------------------------------------------------
	// ��ʼ��
	for (int i=0; i<MAXPARA; i++)
	{
		for(int j=0; j<CALIRATION_MAX; j++)
		{
			AlgInput.Caliration[i][j] = 1.0;
		}
	}

	if (AlgInput.BloodMode == BLOODMODE_WHOLEBLOOD)
	{
		AlgInput.Caliration[WBC][CALIRATION_US] = g_calFactor.wbCalFactor.fWbc/100;
		AlgInput.Caliration[RBC][CALIRATION_US] = g_calFactor.wbCalFactor.fRbc/100;
		AlgInput.Caliration[PLT][CALIRATION_US] = g_calFactor.wbCalFactor.fPlt/100;
		AlgInput.Caliration[MCV][CALIRATION_US] = g_calFactor.wbCalFactor.fMcv/100;
		AlgInput.Caliration[HGB][CALIRATION_US] = g_calFactor.wbCalFactor.fHgb/100;
		AlgInput.Caliration[CRP_NM][CALIRATION_US] = g_calFactor.wbCalFactor.fCrp/100;
		AlgInput.Caliration[CRP_HS][CALIRATION_US] = g_calFactor.wbCalFactor.fCrp/100;

		AlgInput.Caliration[WBC][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fWbc/100;
		AlgInput.Caliration[RBC][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fRbc/100;
		AlgInput.Caliration[PLT][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fPlt/100;
		AlgInput.Caliration[MCV][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fMcv/100;
		AlgInput.Caliration[HGB][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fHgb/100;
		AlgInput.Caliration[CRP_NM][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fCrp/100;
		AlgInput.Caliration[CRP_HS][CALIRATION_FA] = g_calFactor.wbFactoryCalFactor.fCrp/100;
	}
	else
	{
		AlgInput.Caliration[WBC][CALIRATION_US] = g_calFactor.pdCalFactor.fWbc/100;
		AlgInput.Caliration[RBC][CALIRATION_US] = g_calFactor.pdCalFactor.fRbc/100;
		AlgInput.Caliration[PLT][CALIRATION_US] = g_calFactor.pdCalFactor.fPlt/100;
		AlgInput.Caliration[MCV][CALIRATION_US] = g_calFactor.pdCalFactor.fMcv/100;
		AlgInput.Caliration[HGB][CALIRATION_US] = g_calFactor.pdCalFactor.fHgb/100;
		AlgInput.Caliration[CRP_NM][CALIRATION_US] = g_calFactor.pdCalFactor.fCrp/100;
		AlgInput.Caliration[CRP_HS][CALIRATION_US] = g_calFactor.pdCalFactor.fCrp/100;

		AlgInput.Caliration[WBC][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fWbc/100;
		AlgInput.Caliration[RBC][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fRbc/100;
		AlgInput.Caliration[PLT][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fPlt/100;
		AlgInput.Caliration[MCV][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fMcv/100;
		AlgInput.Caliration[HGB][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fHgb/100;
		AlgInput.Caliration[CRP_NM][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fCrp/100;
		AlgInput.Caliration[CRP_HS][CALIRATION_FA] = g_calFactor.pdFactoryCalFactor.fCrp/100;
	}
	
	// ͨ����Ϣ-------------------------------------------------------
	// WBCͨ��
	AlgInput.WbcInput.DataAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulAddr;
	AlgInput.WbcInput.DataLen  = data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulCount / FPGA_PACK_SIZE;
	printf("wbc_cell_num:%d\n",AlgInput.WbcInput.DataLen);

	// RBCͨ��
	AlgInput.ImpdInput.RbcInput.DataAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulAddr;
	AlgInput.ImpdInput.RbcInput.DataLen  = data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulCount / FPGA_PACK_SIZE;

	// PLTͨ��
	AlgInput.ImpdInput.PltInput.DataAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulAddr;
	AlgInput.ImpdInput.PltInput.DataLen  = data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulCount / FPGA_PACK_SIZE;
	printf("plt_cell_num:%d\n",AlgInput.ImpdInput.PltInput.DataLen);

	// HGBͨ��
	AlgInput.HgbInput.DataAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	AlgInput.HgbInput.DataLen  = data_handle->astChannels[COLLECT_CHANNEL_HGB].ulCount / sizeof(short);

	//// CRPͨ��
	//AlgInput.CrpInput.DataAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_CRP].ulAddr;
	//AlgInput.CrpInput.DataLen  = data_handle->astChannels[COLLECT_CHANNEL_CRP].ulCount / sizeof(short);
	if (g_crpCollectHandle != NULL)
	{
		AlgInput.CrpInput.NmDataAddr = g_crpCollectHandle->punAddr;
		AlgInput.CrpInput.NmDataLen  = g_crpCollectHandle->ulCount;
	}

	printf("g_crpCollectHandle->ulCount:%d\n",g_crpCollectHandle->ulCount);

	if (g_highCrpCollectHandle != NULL)
	{
		AlgInput.CrpInput.HsDataAddr = g_highCrpCollectHandle->punAddr;
		AlgInput.CrpInput.HsDataLen  = g_highCrpCollectHandle->ulCount;
	}

	// �����Ϣ-------------------------------------------------------
	// WBCͨ��
	AlgInput.WbcInput.HoleVAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr;
	AlgInput.WbcInput.HoleVLen  = data_handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);
	printf("wbc_holev_num:%d\n",AlgInput.WbcInput.HoleVLen);	

	// WBCͨ��
	AlgInput.ImpdInput.RbcInput.HoleVAddr = buff +	data_handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr;
	AlgInput.ImpdInput.RbcInput.HoleVLen  = data_handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);
	printf("rbc_holev_num:%d\n",AlgInput.WbcInput.DataLen);	

	/****************************************************************/
	// �㷨����-------------------------------------------------------
	/****************************************************************/
	// �㷨����
	AlgorithmMain(&AlgInput, &AlgOutput);

	/****************************************************************/
	// ����ת��-------------------------------------------------------
	/****************************************************************/
	// ������Ϣ-------------------------------------------------------
	bk_result->wbc.val    = (float)(AlgOutput.Para[WBC].Value);
	bk_result->lymphn.val = (float)(AlgOutput.Para[LYMCOUNT].Value);
	bk_result->midn.val   = (float)(AlgOutput.Para[MIDCOUNT].Value);
	bk_result->grann.val  = (float)(AlgOutput.Para[GRANCOUNT].Value);
	bk_result->lymphp.val = (float)(AlgOutput.Para[LYMPERCENT].Value);
	bk_result->midp.val   = (float)(AlgOutput.Para[MIDPERCENT].Value);
	bk_result->granp.val  = (float)(AlgOutput.Para[GRANPERCENT].Value);

	bk_result->rbc.val    = (float)(AlgOutput.Para[RBC].Value);
	bk_result->hgb.val    = (float)(AlgOutput.Para[HGB].Value);
	bk_result->hct.val    = (float)(AlgOutput.Para[HCT].Value);
	bk_result->mcv.val    = (float)(AlgOutput.Para[MCV].Value);
	bk_result->mch.val    = (float)(AlgOutput.Para[MCH].Value);
	bk_result->mchc.val   = (float)(AlgOutput.Para[MCHC].Value);
	bk_result->rdw_cv.val = (float)(AlgOutput.Para[RDW_CV].Value);
	bk_result->rdw_sd.val = (float)(AlgOutput.Para[RDW_SD].Value);

	bk_result->plt.val    = (float)(AlgOutput.Para[PLT].Value);
	bk_result->mpv.val    = (float)(AlgOutput.Para[MPV].Value);
	bk_result->pct.val    = (float)(AlgOutput.Para[PCT].Value);
	bk_result->pdw.val    = (float)(AlgOutput.Para[PDW].Value);
	bk_result->plcc.val   = (float)(AlgOutput.Para[PLCC].Value);
	bk_result->plcr.val   = (float)(AlgOutput.Para[PLCR].Value);
	
	bk_result->crp.val    = (float)(AlgOutput.Para[CRP_NM].Value);

	printf("crp.val1:%f\n", bk_result->crp.val);

	if (AlgInput.WorkMode == WORKMODE_CRPSC)
	{
		bk_result->crp.val = (float)AlgOutput.ServicePara.CrpServicePara.Reaction;
	}

	printf("crp.val2:%f\n", bk_result->crp.val);
	
	// ��־λ
	bk_result->wbc.mark    = getmark(AlgOutput.Para[WBC]);
	bk_result->lymphn.mark = getmark(AlgOutput.Para[LYMCOUNT]);
	bk_result->midn.mark   = getmark(AlgOutput.Para[MIDCOUNT]);
	bk_result->grann.mark  = getmark(AlgOutput.Para[GRANCOUNT]);
	bk_result->lymphp.mark = getmark(AlgOutput.Para[LYMPERCENT]);
	bk_result->midp.mark   = getmark(AlgOutput.Para[MIDPERCENT]);
	bk_result->granp.mark  = getmark(AlgOutput.Para[GRANPERCENT]);

	bk_result->rbc.mark    = getmark(AlgOutput.Para[RBC]);
	bk_result->hgb.mark    = getmark(AlgOutput.Para[HGB]);
	bk_result->hct.mark    = getmark(AlgOutput.Para[HCT]);
	bk_result->mcv.mark    = getmark(AlgOutput.Para[MCV]);
	bk_result->mch.mark    = getmark(AlgOutput.Para[MCH]);
	bk_result->mchc.mark   = getmark(AlgOutput.Para[MCHC]);
	bk_result->rdw_cv.mark = getmark(AlgOutput.Para[RDW_CV]);
	bk_result->rdw_sd.mark = getmark(AlgOutput.Para[RDW_SD]);

	bk_result->plt.mark    = getmark(AlgOutput.Para[PLT]);
	bk_result->mpv.mark    = getmark(AlgOutput.Para[MPV]);
	bk_result->pct.mark    = getmark(AlgOutput.Para[PCT]);
	bk_result->pdw.mark    = getmark(AlgOutput.Para[PDW]);
	bk_result->plcc.mark   = getmark(AlgOutput.Para[PLCC]);
	bk_result->plcr.mark   = getmark(AlgOutput.Para[PLCR]);

	bk_result->crp.mark    = getmark(AlgOutput.Para[CRP_NM]);

	// ͼ����Ϣ-------------------------------------------------------
	getitem_graph_t(bk_result->whistodata, AlgOutput.GraphPara.WbcGraphPara.DspHist);
	getitem_graph_t(bk_result->rhistodata, AlgOutput.GraphPara.RbcGraphPara.DspHist);
	getitem_graph_t(bk_result->phistodata, AlgOutput.GraphPara.PltGraphPara.DspHist);

	bk_result->otherresult.wbcline1 = AlgOutput.GraphPara.WbcGraphPara.DspHist.lines[0];
	bk_result->otherresult.wbcline2 = AlgOutput.GraphPara.WbcGraphPara.DspHist.lines[1];
	bk_result->otherresult.wbcline3 = AlgOutput.GraphPara.WbcGraphPara.DspHist.lines[2];
	bk_result->otherresult.wbcline4 = AlgOutput.GraphPara.WbcGraphPara.DspHist.lines[3];

	bk_result->otherresult.rbclinel = AlgOutput.GraphPara.RbcGraphPara.DspHist.lines[0];
	bk_result->otherresult.rbcliner = AlgOutput.GraphPara.RbcGraphPara.DspHist.lines[1];

	bk_result->otherresult.pltlinel = AlgOutput.GraphPara.PltGraphPara.DspHist.lines[0];
	bk_result->otherresult.pltliner = AlgOutput.GraphPara.PltGraphPara.DspHist.lines[1];

	bk_result->otherresult.wmcv     = (float)(AlgOutput.ServicePara.WbcServicePara.W_MCV);

	// ������Ϣ-------------------------------------------------------
	int HintFlag = getHintFlag(AlgOutput);

	bk_result->otherresult.wbcHint = HintFlag & 0x060001FF;
	bk_result->otherresult.rbcHint = HintFlag & 0x000FFE00;
	bk_result->otherresult.pltHint = HintFlag & 0x00F00000;

	// ������Ϣ
	int ErrorFlag = getErrorFlag(AlgOutput);

	outInfo->errorFlag = ErrorFlag;

	printf("bk_alg_main_end!\n");

	// �ͷ��ڴ�
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.WbcFeaturePara.ImpdCellList.pImpdPulse);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.RbcFeaturePara.ImpdCellList.pImpdPulse);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.PltFeaturePara.ImpdCellList.pImpdPulse);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.HgbFeaturePara.VoltList.VoltVal);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.CrpFeaturePara.NmVoltList.VoltVal);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.CrpFeaturePara.HsVoltList.VoltVal);

	POINTER_FREE_BKALG(AlgOutput.FeaturePara.WbcFeaturePara.HoleVList.VoltVal);
	POINTER_FREE_BKALG(AlgOutput.FeaturePara.RbcFeaturePara.HoleVList.VoltVal);

	return 0;
}