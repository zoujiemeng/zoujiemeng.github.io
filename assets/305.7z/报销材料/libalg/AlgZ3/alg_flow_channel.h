#ifndef CHANNELALG_H
#define CHANNELALG_H

#include "alg_type_inout.h"

bool ChannelAlg(stChannelAlgInput *ChannelAlgInput, stChannelAlgOutput *ChannelAlgOutput);

#endif