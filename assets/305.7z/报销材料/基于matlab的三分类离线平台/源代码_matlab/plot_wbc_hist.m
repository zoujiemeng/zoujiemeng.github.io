function plot_wbc_hist(wbc_dsp_hist,line,h_axes)
%% WBCֱ��ͼ��ʾ
wbc_dsp_hist = [wbc_dsp_hist;0];
%wbc_dsp_hist = smooth(double(wbc_dsp_hist));
max_x = 400;
line = double(line)*max_x/length(wbc_dsp_hist);
step = max_x/length(wbc_dsp_hist);
x = step:step:max_x;
% x = 1:length(wbc_dsp_hist);
fill(h_axes,x,wbc_dsp_hist,'w');
ylim_max = max(wbc_dsp_hist)*1.5;
if ylim_max <= 0
    ylim_max = 1;
end
set(h_axes,'color',[0,0,0],'xlim',[1 max_x],'ylim',...
    [0 ylim_max],'XTick',(step:100:max_x),'XTickLabel',{'0' '100' '200' '300' '400'});
hold(h_axes,'on');
for i = 1:length(line)
    plot(h_axes,[line(i)+1 line(i)+1],[0 max(wbc_dsp_hist)*1.5],'w--');
end
hold(h_axes,'off');