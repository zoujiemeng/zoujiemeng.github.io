% ��ȡĿ���ļ����·���Ҫ����ļ�������ʾ��listbox��
function file_number = read_file_list(FolderName, handles, initial_flag)

set(handles.listbox1,'Value',1);
set(handles.listbox1,'String',[]);
set(handles.edit_path,'string',FolderName);
file_list = dir(fullfile(FolderName,'*.inf'));
if initial_flag == 0
%     if isempty(file_list)
%         errordlg('Please choose correct folder contains .inf file!','Error');  
%         return;
%     end
end
for i = 1:length(file_list);
    if ~file_list(i).isdir
        file_name = file_list(i).name;
        new_line = file_name;
        initial_name = cellstr(get(handles.listbox1,'String'));
        if isempty(initial_name{1});
            set(handles.listbox1,'String',new_line);
        else
            new_name = [initial_name;{new_line}];
            set(handles.listbox1,'String',new_name);
        end;
    end;
end;
file_list = dir(fullfile(FolderName,'*.int'));
if initial_flag == 0
    if isempty(file_list)
        errordlg('Please choose correct folder contains .inf file!','Error');  
        return;
    end
end
for i = 1:length(file_list);
    if ~file_list(i).isdir
        file_name = file_list(i).name;
        new_line = file_name;
        initial_name = cellstr(get(handles.listbox1,'String'));
        if isempty(initial_name{1});
            set(handles.listbox1,'String',new_line);
        else
            new_name = [initial_name;{new_line}];
            set(handles.listbox1,'String',new_name);
        end;
    end;
end;
file_cellstr = get(handles.listbox1, 'String');
[file_number,~] = size(file_cellstr);