% ���������ļ���Ϣ
function refresh_config()

global BK_offline_ini;
fid = fopen('BK_offline_platform_config.ini','wt');
fprintf(fid,'%s\n',BK_offline_ini.filedir);
fprintf(fid,'%s\n',BK_offline_ini.inf_file_name);
fprintf(fid,'%s\n',BK_offline_ini.wbcfilename);
fclose(fid);