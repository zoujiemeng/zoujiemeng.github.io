function nps_data_out = change_sec_gap_for_nps(nps_data,sec_gap)

index_max = floor(length(nps_data)/sec_gap);

for i = 1:index_max
    nps_data_out(i) = sum(nps_data((i-1)*sec_gap+1:i*sec_gap));
end