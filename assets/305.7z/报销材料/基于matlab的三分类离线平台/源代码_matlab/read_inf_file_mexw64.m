function [header,sample,re,cell,monitor] = read_inf_file_mexw64(filepath)

fid = fopen(filepath,'rb');
inf_ver = fread(fid,10,'int8');
fclose(fid);
switch inf_ver(10)
    case 1
        [header,sample,re,cell,monitor] = BK_read_inf_file(filepath);
    case 2
        [header,sample,re,cell,monitor] = BK_read_inf_file_2(filepath);
    case 3
        [header,sample,re,cell,monitor] = BK_read_inf_file_3(filepath);
    case 4
        [header,sample,re,cell,monitor] = BK_read_inf_file_4(filepath);
    otherwise
end