function plot_plt_hist(plt_org_hist,line,h_axes)

%% PLTֱ��ͼ��ʾ
plt_org_hist = [0;plt_org_hist;0];
plt_org_hist = smooth(double(plt_org_hist),5);
plt_y_max = max(plt_org_hist(1:64))*1.5;
max_x = 80;
line = double(line)*max_x/length(plt_org_hist);
step = max_x/length(plt_org_hist);
x = step:step:max_x;
fill(h_axes,x,plt_org_hist,'g');
if plt_y_max == 0
    plt_y_max = 10;
end
set(h_axes, 'XLim',[1 max_x/2],'ylim',[0 plt_y_max],'color',[0,0,0],'XTick',(step:10:max_x),'XTickLabel',{'0' '10' '20' '30' '40'});
hold(h_axes,'on');
plot(h_axes,[line(1) line(1)],[0 max(plt_org_hist)*1.5],'w--');
plot(h_axes,[line(2) line(2)],[0 max(plt_org_hist)*1.5],'w--');
hold(h_axes,'off');