function h_plot = nps_monitor_alone(nps_data,sec_gap,h_axes,color,ylim)

x = 1:length(nps_data);
h_plot = plot(h_axes,x,nps_data,color);
xtick_seg = 1:200/sec_gap:length(nps_data);
xtick_label = cell(length(xtick_seg),1);
for i = 1:length(xtick_seg)
    xtick_label{i} = num2str((i-1)*2); 
end
set(h_axes,'color',[0,0,0],'xlim',[1 length(nps_data)*1.1],'ylim',ylim,...
    'XTick',(1:200/sec_gap:length(nps_data)),'XTickLabel',xtick_label);