function varargout = BK_offline_platform(varargin)
%{
    
    HOW TO CREATE A NEW TAB

    1. Create or copy PANEL and TEXT objects in GUI



    2. Rename tag of PANEL to "tabNPanel" and TEXT for "tabNtext", where N
    - is a sequential number. 
    Example: tab3Panel, tab3text, tab4Panel, tab4text etc.
    
    3. Add to Tab Code - Settings in m-file of GUI a name of the tab to
    TabNames variable

   
%}

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BK_offline_platform_OpeningFcn, ...
                   'gui_OutputFcn',  @BK_offline_platform_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BK_offline_platform is made visible.
function BK_offline_platform_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BK_offline_platform (see VARARGIN)

% Choose default command line output for BK_offline_platform
handles.output = hObject;
global BK_offline_ini;
% Choose default command line output for BK_rbc_plt_module
handles.output = hObject;
set(0,'Units','normalized') %��ò�����ʾ����ʾ����Ϊ[0,0,1,1]�ĸ�ʽ�������������ڶ��ķֱ�������ʾ��������GUI�����ȶ��Ὣ��ʾ������Ϊ[0,0,1,1]
f=gcf;%���GUI���
set(f,'units','norm','position',[.1 .1 .5 .5]) % Set units to norm, and re-size.%��GUI����ʾҲ����Ϊnormalized����ʱGUI�����пؼ��ĵ�λ����normalized��ͬʱ������ʼλ��.



%% Tabs Code
% Settings
TabFontSize = 10;
TabNames = {'��ģ��','WBCģ��','RBC/PLTģ��','���ģ��','CRPģ��','����Ա�ģ��','CRP����ģ��'};
FigWidth = 0.265;

% Figure resize
set(handles.SimpleOptimizedTab,'Units','normalized')
pos = get(handles. SimpleOptimizedTab, 'Position');
set(handles. SimpleOptimizedTab, 'Position', [pos(1) pos(2) FigWidth pos(4)])

% Tabs Execution
handles = TabsFun(handles,TabFontSize,TabNames);

% Update handles structure
guidata(hObject, handles);

%% ��ȡ������Ϣ
read_bk_offline_plat_config();
%% ��ȡָ��Ŀ¼���ļ�
num = read_file_list(BK_offline_ini.filedir, handles, 1);
%% ��ʼ����������ؿؼ�
initial_crp_cali_settings(handles);
uibuttongroup_wbc_manual_SelectionChangedFcn(hObject, eventdata, handles);
%% ��ѡ���λ����Ч���ϴ��ļ�λ��
if num > 0
    file_cellstr = get(handles.listbox1, 'String');
    if ~isempty(file_cellstr)
        for i = 1:num
            if iscell(file_cellstr)
                filename = char(file_cellstr(i));
            else
                filename = file_cellstr;
            end
            if strcmp(filename,BK_offline_ini.inf_file_name);
                set(handles.listbox1,'value',i);
                %% �������㷨
                filepath = fullfile(BK_offline_ini.filedir,BK_offline_ini.inf_file_name);
                inf_present_main(hObject,eventdata,handles,filepath,filename);
                
                break;
            end
        end
    end
end

movegui(gcf,'center');

% UIWAIT makes BK_offline_platform wait for user response (see UIRESUME)
% uiwait(handles.SimpleOptimizedTab);

% --- TabsFun creates axes and text objects for tabs
function handles = TabsFun(handles,TabFontSize,TabNames)

% Set the colors indicating a selected/unselected tab
handles.selectedTabColor=get(handles.tab1Panel,'BackgroundColor');
handles.unselectedTabColor=handles.selectedTabColor-0.1;

% Create Tabs
TabsNumber = length(TabNames);
handles.TabsNumber = TabsNumber;
TabColor = handles.selectedTabColor;
for i = 1:TabsNumber
    n = num2str(i);
    
    % Get text objects position
    set(handles.(['tab',n,'text']),'Units','normalized')
    pos=get(handles.(['tab',n,'text']),'Position');

    % Create axes with callback function
    handles.(['a',n]) = axes('Units','normalized',...
                    'Box','on',...
                    'XTick',[],...
                    'YTick',[],...
                    'Color',TabColor,...
                    'Position',[pos(1) pos(2) pos(3) pos(4)+0.01],...
                    'Tag',n,...
                    'ButtonDownFcn',[mfilename,'(''ClickOnTab'',gcbo,[],guidata(gcbo))']);
                    
    % Create text with callback function
    handles.(['t',n]) = text('String',TabNames{i},...
                    'Units','normalized',...
                    'Position',[pos(3),pos(2)/2+pos(4)],...
                    'HorizontalAlignment','left',...
                    'VerticalAlignment','middle',...
                    'Margin',0.001,...
                    'FontSize',TabFontSize,...
                    'Backgroundcolor',TabColor,...
                    'Tag',n,...
                    'ButtonDownFcn',[mfilename,'(''ClickOnTab'',gcbo,[],guidata(gcbo))']);

    TabColor = handles.unselectedTabColor;
end
            
% Manage panels (place them in the correct position and manage visibilities)
set(handles.tab1Panel,'Units','normalized')
pan1pos=get(handles.tab1Panel,'Position');
set(handles.tab1text,'Visible','off')
for i = 2:TabsNumber
    n = num2str(i);
    set(handles.(['tab',n,'Panel']),'Units','normalized')
    set(handles.(['tab',n,'Panel']),'Position',pan1pos)
    set(handles.(['tab',n,'Panel']),'Visible','off')
    set(handles.(['tab',n,'text']),'Visible','off')
end

% --- Callback function for clicking on tab
function ClickOnTab(hObject,~,handles)
m = str2double(get(hObject,'Tag'));

for i = 1:handles.TabsNumber;
    n = num2str(i);
    if i == m
        set(handles.(['a',n]),'Color',handles.selectedTabColor)
        set(handles.(['t',n]),'BackgroundColor',handles.selectedTabColor)
        set(handles.(['tab',n,'Panel']),'Visible','on')
    else
        set(handles.(['a',n]),'Color',handles.unselectedTabColor)
        set(handles.(['t',n]),'BackgroundColor',handles.unselectedTabColor)
        set(handles.(['tab',n,'Panel']),'Visible','off')
    end
end

% --- Outputs from this function are returned to the command line.
function varargout = BK_offline_platform_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
javaFrame = get(gcf,'JavaFrame');  
set(javaFrame,'Maximized',1); 

function initial_crp_cali_settings(handles)

target_val = {0;5;20;40;80;160;200;320};
tmp = cell(8,1);
data = [target_val tmp];
set(handles.uitable_crp_cali_settings,'data',data);

function read_bk_offline_plat_config()

global BK_offline_ini;
if ~exist('BK_offline_platform_config.ini','file');
    fid = fopen('BK_offline_platform_config.ini','wt');
    fprintf(fid,'%s\n','C:\');
    fprintf(fid,'%s\n','None');
    fprintf(fid,'%s\n','None');
    fclose(fid);
end;
fid = fopen('BK_offline_platform_config.ini','rt');
BK_offline_ini.filedir = fgetl(fid);
BK_offline_ini.inf_file_name = fgetl(fid);
BK_offline_ini.wbcfilename = fgetl(fid);
fclose(fid);

function [header,sample,re,cell_info,monitor] = bk_inf_or_int_recal(filepath,config)

suffix = filepath(length(filepath)-3:length(filepath));
if strcmp(suffix,'.int')
    [header,sample,re,cell_info,monitor] = bk_int_recal(filepath,config);
else if strcmp(suffix, '.inf')
        [header,sample,re,cell_info,monitor] = bk_inf_recal(filepath,config);
    else
        header.error_code = -100;
    end
end
    

function inf_present_main(hObject,eventdata,handles,filepath,filename)

global bk_config;
config.sample_id = filename(1:length(filename)-4);
config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
%% ����C���Կ�
[header,sample,re,cell_info,monitor] = bk_inf_or_int_recal(filepath,config);

if header.error_code
    str = sprintf('��֧�ֵ�inf�ļ����ͻ���inf�ļ����𻵣�������Ϊ%d��',header.error_code);
    msgbox(str,'����');
    return;
end

bk_config.sample = sample;
bk_config.re = re;
bk_config.header = header;
bk_config.cell_info = cell_info;
%% ��ȡ���ñ�
[hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample);
%% չʾ��ǰ�����ļ���
set(handles.text_filename,'string',filename);
%% ���½�������Ϣչʾ
present_sample_info(sample,header,handles.uitable_sampleinfo);
%% gauss_fit test
% x = 1:240;
% intensity = double(re.new.rbc_hist(x));
% 
% [y_max,index] = max(intensity);
% tmp_x = 58;
% c = (tmp_x-index)/(sqrt(-log(intensity(tmp_x)/y_max)));
% %[errorcode,param] = gauss_fit(x,intensity,length(x));
% yy = y_max*exp(-((x-index)/c).^2); 
% %yy = param.A*exp(-((x-param.B)/param.C).^2); 

%% ��ģ��
% ���������ʾ
para_present_main(re.new,sample,handles.uitable_main_re);
% ֱ��ͼ��ʾ
plot_wbc_hist(re.new.wbc_hist,re.new.wbc_line,handles.axes_main_wbc);
% ��˹���rbcֱ��ͼ������ʾ
% plot(handles.axes_main_rbc,1:256,re.new.rbc_org_hist,'bo');
% hold(handles.axes_main_rbc,'on');
% plot(handles.axes_main_rbc,1:256,re.new.rbc_hist,'b-');
% hold(handles.axes_main_rbc,'off');
plot_rbc_hist(re.new.rbc_hist,re.new.rbc_line,handles.axes_main_rbc);
plot_plt_hist(re.new.plt_hist,re.new.plt_line,handles.axes_main_plt);


% ���漰У׼ϵ����ʾ
if header.inf_ver > 3
    config_present(sample,handles);
else
    set(handles.uitable_main_gain,'data',[]);
    set(handles.uitable_main_cb,'data',[]);
end

% %% ��ʱ��������
% index = find(cell.rbc_time == 1);
% tmp_data = cell.rbc_peak(index);
% save('1017_rbc_abnormal_peak_data','tmp_data');
% %% ��ʱrbc_pltֱ��ͼ����
% hist_str = sprintf('%d_rbc_hist.mat',value);
% hist_tmp = re.rbc_hist;
% save(hist_str,'hist_tmp');
% hist_str = sprintf('%d_plt_hist.mat',value);
% hist_tmp = re.plt_hist;
% save(hist_str,'hist_tmp');
% %% ��ʱm������,�������
% peak = cell.wbc_peak;
% peak_index = find(peak < 50/256*4095 & peak > 15/256*4095);
% mflag = cell.wbc_mflag(peak_index);
% index = find(mflag == 1);
% m_ratio = length(index)/length(mflag);
% width = cell.wbc_fullwidth(peak_index);
% index = find(width < 20);
% width_ratio = length(index)/length(width);

%% WBCģ��
% ���������ʾ
re.new.wbc_mnum = length(find(cell_info.wbc_mflag == 1));
para_present_wbc(re.new,header,handles);
% ֱ��ͼ��ʾ
handles.wbc_dsp_hist = re.new.wbc_hist;
handles.wbc_org_hist = re.new.wbc_org_hist;
bk_config.wbc_line = re.new.wbc_line;
guidata(hObject, handles);
wbc_hist_with_callback(re.new.wbc_org_hist,re.new.wbc_line,handles);
if isempty(cell_info.wbc_fullwidth)
    cla(handles.axes_wbc_nps);
    cla(handles.axes_wbc_width);
    cla(handles.axes_wbc_vol);
else
    % �ֶ�ֱ��ͼ�洢����ʾ
    handles.wbc_width_data = cell_info.wbc_fullwidth;
    handles.wbc_peak_data = cell_info.wbc_peak;
    handles.wbc_time = cell_info.wbc_time;
    guidata(hObject, handles);
    popup_wbc_seg_Callback(hObject, eventdata, handles);
    % NPSģ��Ĵ洢����ʾ
    num = max(cell_info.wbc_time);
    if num > 0
        for i = 1:num
            index = find(cell_info.wbc_time==i);
            wbc_nps(i) = length(index);
        end
        handles.wbc_nps = wbc_nps;
        guidata(hObject, handles);
        popup_wbc_nps_sec_Callback(hObject, eventdata, handles);
    end
end
%% hgbģ��
if ~isempty(monitor.hgb_data)
    hgb_vol = double(monitor.hgb_data);
    re.new.hgb_recal = plot_hgb_curve(hgb_vol,hgb_pos,handles);
    bk_config.hgb_data = hgb_vol;
    bk_config.hgb_pos = hgb_pos;
    % HGB���׵�ѹ�������ѹ������HGB���ߣ�
    re.new.hgb_bk_vol = mean(hgb_vol(hgb_pos.bk+1:hgb_pos.bk+10))/4096*5;
    re.new.hgb_me_vol = mean(hgb_vol(hgb_pos.me+1:hgb_pos.me+10))/4096*5;
    para_present_wbc(re.new,header,handles);
else
    cla(handles.axes_hgb);
    re.new.hgb_bk_vol = 0;
    re.new.hgb_me_vol = 0;
end

%% RBCģ��
% PLTʶ������������
re.new.plt_org_num = length(find(cell_info.plt_peak < 2048));
% RBC��PLTͨ��m������ͳ��
re.new.rbc_mnum = length(find(cell_info.rbc_mflag == 1));
re.new.plt_mnum = length(find(cell_info.plt_mflag == 1));
re.new.plt_base_avg = mean(cell_info.plt_base);
% ���������ʾ
para_present_rbc(re.new,header,handles);
% ֱ��ͼ��ʾ
plot_rbc_hist(re.new.rbc_hist,re.new.rbc_line,handles.axes_rbc_hist);
plot_plt_hist(re.new.plt_hist,re.new.plt_line,handles.axes_plt_hist);
% RBC�ֶ�ֱ��ͼ�洢����ʾ
width_data = cell_info.rbc_fullwidth;
%width_data = cell.plt_subwidth;
if isempty(width_data)
    cla(handles.axes_rbc_width);
    cla(handles.axes_rbc_vol);
    cla(handles.axes_rbc_nps);
else
    %eqwidth_data = area_data./double(peak_data);
    %handles.eqwidth_data = eqwidth_data;
    handles.rbc_width_data = width_data;
    handles.rbc_peak_data = cell_info.rbc_peak;
    handles.rbc_time = cell_info.rbc_time;
    guidata(hObject, handles);
    popup_rbc_seg_Callback(hObject, eventdata, handles);
end

% PLT�ֶ�ֱ��ͼ�洢����ʾ
width_data = cell_info.plt_fullwidth;
if isempty(width_data)
    cla(handles.axes_plt_width);
    cla(handles.axes_plt_vol);
    cla(handles.axes_plt_nps);
else
    handles.plt_width_data = width_data;
    handles.plt_peak_data = cell_info.plt_peak;
    handles.plt_time = cell_info.plt_time;
    guidata(hObject, handles);
    popup_plt_seg_Callback(hObject, eventdata, handles);
    % NPSģ�����ݴ洢����ʾ
    num = max(cell_info.rbc_time);
    for i = 1:num
        index = find(cell_info.rbc_time==i);
        rbc_nps(i) = length(index);
    end
    handles.rbc_nps = rbc_nps;
    guidata(hObject, handles);
    popup_rbc_nps_sec_Callback(hObject, eventdata, handles);
    %plot_nps_manual_line(handles.axes_rbc_nps,BK_rbc_config.nps_start,BK_rbc_config.nps_end,'g');
    
    num = max(cell_info.plt_time);
    if num > 0
        for i = 1:num
            index = find(cell_info.plt_time==i);
            plt_nps(i) = length(index);
        end
        
        handles.plt_nps = plt_nps;
        guidata(hObject, handles);
        
        popup_plt_nps_sec_Callback(hObject, eventdata, handles);
        %plot_nps_manual_line(handles.axes_plt_nps,BK_rbc_config.nps_start,BK_rbc_config.nps_end,'w');
    end
end
%% monitorģ��
% WBCС�׵�ѹ
alarm_msg = [];
if ~isempty(monitor.whole_data)
    if wbc_pos.start < length(monitor.whole_data) && wbc_pos.end < length(monitor.whole_data)
        plot_aperture_vol(monitor.whole_data,handles.axes_whole,wbc_pos);
        whole_data = medfilt1(double(monitor.whole_data),15);
        wbc_bool = if_abnormal_voltage(whole_data(wbc_pos.start-200:wbc_pos.end),3);
        if wbc_bool
            alarm_msg = [alarm_msg;{'WBCͨ��' '�¿�' ''}];
        end            
        %     alarm_msg = identify_abnormal_voltage(monitor.whole_data(wbc_pos.start-290:wbc_pos.end),...
        %         handles.uitable_main_alarm,'WBCͨ��',alarm_msg);
    else
        tmp = {'WBCͨ��' 'С�׵�ѹ���ݹ���' 'Һ·�����㲻�ڲɼ����ݷ�Χ��'};
        alarm_msg = [alarm_msg;tmp];
    end
else
    cla(handles.axes_whole);
end
% RBCС�׵�ѹ
if ~isempty(monitor.rhole_data)
    if rbc_pos.start < length(monitor.rhole_data) && rbc_pos.end < length(monitor.rhole_data)
        plot_aperture_vol(monitor.rhole_data,handles.axes_rhole,rbc_pos);
        rhole_data = medfilt1(double(monitor.rhole_data),15);
        rbc_bool = if_abnormal_voltage(rhole_data(rbc_pos.start-150:rbc_pos.end),4);
        if rbc_bool
            alarm_msg = [alarm_msg;{'RBCͨ��' '�¿�' ''}];
        end
        %     alarm_msg = identify_abnormal_voltage(monitor.rhole_data(rbc_pos.start-290:rbc_pos.end),...
        %         handles.uitable_main_alarm,'RBCͨ��',alarm_msg);
    else
        tmp = {'RBCͨ��' 'С�׵�ѹ���ݹ���' 'Һ·�����㲻�ڲɼ����ݷ�Χ��'};
        alarm_msg = [alarm_msg;tmp];
        
    end
else
    cla(handles.axes_rhole);
end
% WBCС�׻���
if isfield(monitor,'wbase_data')
    if ~isempty(monitor.wbase_data)
        if wbc_pos.start < length(monitor.wbase_data) && wbc_pos.end < length(monitor.wbase_data)
            plot_aperture_vol(monitor.wbase_data,handles.axes_wbase,wbc_pos);
            alarm_msg = identify_abnormal_base(monitor.wbase_data(wbc_pos.start:wbc_pos.end),...
                handles.uitable_main_alarm,'WBCͨ��',alarm_msg);
        else
            tmp = {'WBCͨ��' 'С�׻������ݹ���' 'Һ·�����㲻�ڲɼ����ݷ�Χ��'};
            alarm_msg = [alarm_msg;tmp];
        end
    else
        cla(handles.axes_wbase);
    end
end
% RBCС�׻���
if isfield(monitor,'rbase_data')
    if ~isempty(monitor.rbase_data)
        if wbc_pos.start < length(monitor.rbase_data) && wbc_pos.end < length(monitor.rbase_data)
            plot_aperture_vol(monitor.rbase_data,handles.axes_rbase,rbc_pos);
            alarm_msg = identify_abnormal_base(monitor.rbase_data(rbc_pos.start:rbc_pos.end),...
                handles.uitable_main_alarm,'RBCͨ��',alarm_msg);
        else
            tmp = {'RBCͨ��' 'С�׻������ݹ���' 'Һ·�����㲻�ڲɼ����ݷ�Χ��'};
            alarm_msg = [alarm_msg;tmp];
        end
    else
        cla(handles.axes_rbase);
    end
end
% ���ѹ��
if isfield(monitor,'air_pressure_data')
    if ~isempty(monitor.air_pressure_data)
        ap_data = -(bitand(monitor.air_pressure_data,32767,'int16'));
        ap_data = double(ap_data)/10;
        plot(handles.axes_air_pressure,1:length(ap_data),ap_data,'r');
        if length(ap_data) < 2000
            kpa_pos.start = kpa_pos.start/5;
            kpa_pos.end = kpa_pos.end/5;
        end
        if kpa_pos.start < length(ap_data) && kpa_pos.end < length(ap_data)
            hold(handles.axes_air_pressure,'on');
            plot(handles.axes_air_pressure,kpa_pos.start,ap_data(kpa_pos.start),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
            plot(handles.axes_air_pressure,kpa_pos.end,ap_data(kpa_pos.end),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
            hold(handles.axes_air_pressure,'off');
        else
            tmp = {' ' '���ѹ�����ݹ���' 'Һ·�����㲻�ڲɼ����ݷ�Χ��'};
            alarm_msg = [alarm_msg;tmp];
        end
        set(handles.axes_air_pressure,'color',[0,0,0],'xlim',[1 length(ap_data)+100],...
            'XTick',(1:1000:length(ap_data)+100),'XTickLabel',{'0' '10' '20' '30' '40'});
    else
        cla(handles.axes_air_pressure);
    end
end
set(handles.uitable_main_alarm,'data',alarm_msg);
%% CRPģ��
if sample.analysis_mode == 2 || sample.analysis_mode == 1
    if ~isempty(monitor.crp_data)
        crp_data = monitor.crp_data;
        handles.crp_data = crp_data;
        guidata(hObject,handles);
        set(handles.uitable_crp_data,'data',crp_data);
        reaction_config.start_pos = str2double(get(handles.crp_start_pos,'string'));
        reaction_config.end_pos = str2double(get(handles.crp_end_pos,'string'));
        reaction_config.seglen = str2double(get(handles.crp_seglen,'string'));
        plot_crp(crp_data,handles.axes_crp,reaction_config);
    else
        set(handles.uitable_crp_data,'data',[]);
        cla(handles.axes_crp);
    end
else
    set(handles.uitable_crp_data,'data',[]);
    cla(handles.axes_crp);
end
if header.inf_ver > 3
    crp_result_present(re.new,handles);
end
%% ����Ա�ģ��
para_present_main(re.old,sample,handles.uitable_comp_oldre);
para_present_main(re.new,sample,handles.uitable_comp_newre);

function hgb_val = plot_hgb_curve(hgb_vol,hgb_pos,handles)

global bk_config;
sample = bk_config.sample;
hgb_bk_pos = int32(hgb_pos.bk);
hgb_measure_pos = int32(hgb_pos.me);
%hgb_measure_pos = 4375;
x = 1:length(hgb_vol);
if hgb_measure_pos > length(hgb_vol)
    hgb_measure_pos = length(hgb_vol);
end
h_hgb = plot(handles.axes_hgb,x,hgb_vol,'r');
hold(handles.axes_hgb,'on');
plot(handles.axes_hgb,hgb_bk_pos,hgb_vol(hgb_bk_pos),'s','MarkerSize',10,'MarkerEdgeColor','g','MarkerFaceColor','g');
plot(handles.axes_hgb,hgb_measure_pos,hgb_vol(hgb_measure_pos),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
hold(handles.axes_hgb,'off');
%set(handles.axes_hgb,'color',[0,0,0],'xlim',[1 vol_num+100],'XTick',[1:1000:4100],'XTickLabel',{'0' '10' '20' '30' '40'});
set(handles.axes_hgb,'color',[0,0,0]);
switch sample.blood_mode
    case 0 %ȫѪ
        dilution = 305.1;
    case 1 %Ԥϡ��
        dilution = 501.9;
    otherwise
        dilution = 305.1;
end
hgb_theoretical = log10(hgb_vol(hgb_bk_pos)/hgb_vol(hgb_measure_pos))*dilution*1.95;
if hgb_theoretical < 115 || hgb_theoretical > 150
    hgb_theoretical = 1.018*hgb_theoretical - 3.384;
end
if hgb_theoretical < 60
    hgb_theoretical = hgb_theoretical + 2.1;
end
hgb_val = hgb_theoretical*sample.hgb_fcb*sample.hgb_ucb;
%set(handles.text_hgb_bk,'string',num2str(hgb_vol(hgb_bk_pos)));
%set(handles.text_hgb_measure,'string',num2str(hgb_vol(hgb_measure_pos)));
%hgb_theoretical = log10(hgb_vol(hgb_bk_pos)/hgb_vol(hgb_measure_pos))*230;
%set(handles.text_hgb_re,'string',sprintf('%5.4f',hgb_theoretical));
set(h_hgb,'ButtonDownFcn',{@bk_hgb_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback

function bk_hgb_buttondown_Callback(hObject, eventdata, handles)

global bk_config;
hgb_data = bk_config.hgb_data;

if strcmp(get(gcf,'SelectionType'),'normal') % ����������
    ClickPoint = get(gca,'currentpoint');
    col_coordinate = round(ClickPoint(1,1));
    if col_coordinate > length(hgb_data) || col_coordinate < 1
        msgbox('��������ѡ��Χ��','����');
        return;
    end
    bk_config.hgb_pos.bk = col_coordinate;
    
else if strcmp(get(gcf,'SelectionType'),'alt') % ����Ҽ�����
        ClickPoint = get(gca,'currentpoint');
        col_coordinate = round(ClickPoint(1,1));
        if col_coordinate < bk_config.hgb_pos.bk || col_coordinate > length(hgb_data)
            msgbox('��������ѡ��Χ��','����');
            return;
        end
        bk_config.hgb_pos.me = col_coordinate;
    end;
end;
bk_config.re.new.hgb_recal = plot_hgb_curve(hgb_data,bk_config.hgb_pos,handles);
para_present_wbc(bk_config.re.new,bk_config.header,handles);




function [hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample)

config = readtable('configure_table.csv');
switch sample.analysis_mode
    case 0 %CBC
        hgb_pos.bk = int32(str2double(cell2mat(config.cbc_hgb_bk_pos(3)))*100);
        hgb_pos.me = int32(str2double(cell2mat(config.cbc_hgb_me_pos(3)))*100);
        whole_pos_start = str2double(cell2mat(config.cbc_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_wbc_end_pos(3)))*100 - ap_start);
    case 2 %CBC+CRP
        hgb_pos.bk = int32(str2double(cell2mat(config.cbc_crp_hgb_bk_pos(3)))*100);
        hgb_pos.me = int32(str2double(cell2mat(config.cbc_crp_hgb_me_pos(3)))*100);
        whole_pos_start = str2double(cell2mat(config.cbc_crp_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_crp_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_crp_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - ap_start);
    otherwise
        hgb_pos.bk = int32(str2double(cell2mat(config.cbc_crp_hgb_bk_pos(3)))*100);
        hgb_pos.me = int32(str2double(cell2mat(config.cbc_crp_hgb_me_pos(3)))*100);
        whole_pos_start = str2double(cell2mat(config.cbc_crp_whole_start_pos(3)))*100;
        wbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - whole_pos_start);
        wbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - whole_pos_start);
        rhole_pos_start = str2double(cell2mat(config.cbc_crp_rhole_start_pos(3)))*100;
        rbc_pos.start = int32(str2double(cell2mat(config.cbc_crp_rbc_start_pos(3)))*100 - rhole_pos_start);
        rbc_pos.end = int32(str2double(cell2mat(config.cbc_crp_rbc_end_pos(3)))*100 - rhole_pos_start);
        ap_start = str2double(cell2mat(config.cbc_crp_kpa_start_pos(3)))*100;
        kpa_pos.start = int32(str2double(cell2mat(config.cbc_crp_wbc_start_pos(3)))*100 - ap_start);
        kpa_pos.end = int32(str2double(cell2mat(config.cbc_crp_wbc_end_pos(3)))*100 - ap_start);
end

function msg_out = identify_abnormal_base(data,h_table,module,alarm_msg)

overflow_num = 0;
for i = 1:length(data)
    if data(i) == 4095
        overflow_num = overflow_num + 1;
    end
end
if overflow_num > 100
    tmp = {module '���������쳣' '�������'};
    msg_out = [alarm_msg;tmp];
else
    msg_out = alarm_msg;
end


function msg_out = identify_abnormal_voltage(data,h_table,module,alarm_msg)

step = 9;
for i = 1:length(data)/step-1
    df(i) = data(step*(i+1))-data(step*i);
end
tmp = [];
thresh = 4;
for i = 1:length(df)-3
    if df(i) > thresh && df(i+1) > thresh  && df(i+2) > thresh-1 && df(i+3) > thresh-2
        tmp = {module 'С�׵�ѹ�쳣' '�쳣����'};
    else if df(i) < -1*thresh && df(i+1) < -1*thresh+1 && df(i+2) < -1*thresh+1 && df(i+3) < -1*thresh+2
            tmp = {module 'С�׵�ѹ�쳣' '�쳣�½�'};
        end
    end
end
if ~isempty(tmp)
    if isempty(alarm_msg)
        msg_out = tmp;
    else
        msg_out = [alarm_msg;tmp];
    end
else
    msg_out = alarm_msg;
end

function bool = if_abnormal_voltage(data,thresh)

step = 12;
for i = 1:length(data)-step
    df(i) = data(i+step)-data(i);
end
bool = 0;
% thresh = 3;
for i = 1:length(df)-3
    if df(i) >= thresh && df(i+1) >= thresh && df(i+2) >= thresh && df(i+3) >= thresh
        bool = 1;
    else if df(i) < -1*thresh && df(i+1) < -1*thresh && df(i+2) < -1*thresh && df(i+3) < -1*thresh
            bool = 1;
        end
    end
end


% set(h_table,'data',msg_out);

function plot_aperture_vol(data,h_axes,pos)

if ~isempty(data)
    plot(h_axes,1:length(data),data,'r');
    set(h_axes,'color',[0,0,0],'xlim',[1 length(data)+100],...
        'XTick',(1:1000:length(data)+100),'XTickLabel',{'10' '20' '30' '40'});
    hold(h_axes,'on');
%     plot(h_axes,1:length(data),medfilt1(double(data),15),'w');
    plot(h_axes,pos.start,data(pos.start),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
    plot(h_axes,pos.end,data(pos.end),'s','MarkerSize',10,'MarkerEdgeColor','m','MarkerFaceColor','m');
    hold(h_axes,'off');
else
    cla(h_axes);
end

function edit_path_Callback(hObject, eventdata, handles)
% hObject    handle to edit_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_path as text
%        str2double(get(hObject,'String')) returns contents of edit_path as a double


% --- Executes during object creation, after setting all properties.
function edit_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_browse.
function button_browse_Callback(hObject, eventdata, handles)
% hObject    handle to button_browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
FileInPath = get(handles.edit_path,'String');
filter = {'*.int;*.inf','inf/int file'};
[~,folder_name]= uigetfile(filter,'��inf�ļ�',FileInPath);
% folder_name = uigetdir(char(FileInPath),'��inf�ļ�');
if folder_name == 0
    folder_name = BK_offline_ini.filedir;
end
num = read_file_list(folder_name, handles, 0);
if num > 0
    BK_offline_ini.filedir = folder_name;
end

% --- Executes on button press in button_analyse.
function button_analyse_Callback(hObject, eventdata, handles)
% hObject    handle to button_analyse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;

tempstr = get(handles.listbox1,'String');
value = get(handles.listbox1,'Value');
if iscell(tempstr)
    filename = char(tempstr(value));
else
    filename = tempstr;
end
filepath = fullfile(BK_offline_ini.filedir,filename);
set(handles.radio_without_cb,'value',0);
inf_present_main(hObject,eventdata,handles,filepath,filename);

%% ������ر���
BK_offline_ini.inf_file_name = filename;


%% WBCֱ��ͼ�ֶ�����ģ��
function wbc_hist_with_callback(wbc_dsp_hist,line,handles)

%% WBCֱ��ͼ��ʾ
%line = [15;44;68];
wbc_dsp_hist = bk_gauss_smooth(wbc_dsp_hist,length(wbc_dsp_hist),4,2);
wbc_dsp_hist = bk_gauss_smooth(wbc_dsp_hist,length(wbc_dsp_hist),4,2);
wbc_dsp_hist = [double(wbc_dsp_hist);0];
% wbc_dsp_hist = smooth(double(wbc_dsp_hist));
% wbc_dsp_hist = smooth(double(wbc_dsp_hist));
h_wbc_hist = fill(handles.axes_wbc,1:length(wbc_dsp_hist),wbc_dsp_hist,'w');
ylim_max = max(wbc_dsp_hist)*1.5;
if ylim_max <= 0
    ylim_max = 1;
end
% set(handles.axes_wbc,'color',[0,0,0],'xlim',[0 length(wbc_dsp_hist)],...
%     'ylim',[0 ylim_max]);
set(handles.axes_wbc,'color',[0,0,0],'xlim',[1 length(wbc_dsp_hist)],'ylim',...
    [0 ylim_max],'XTick',(1:length(wbc_dsp_hist)/4:length(wbc_dsp_hist)),'XTickLabel',{'0' '100' '200' '300' '400'});
hold(handles.axes_wbc,'on');
for i = 1:length(line)
    plot(handles.axes_wbc,[line(i) line(i)],[0 max(wbc_dsp_hist)*1.5],'w--');
end
% log_data = log(wbc_dsp_hist);
% plot(handles.axes_wbc,1:length(log_data),log_data*wbc_dsp_hist(88)/log_data(88),'m');
hold(handles.axes_wbc,'off');
set(h_wbc_hist,'ButtonDownFcn',{@wbc_hist_buttondown_Callback,handles});


function wbc_hist_buttondown_Callback(hObject,eventdata, handles) %�Զ����callback����

global bk_config;

if strcmp(get(gcf,'SelectionType'),'normal') % ����������
    ClickPoint = get(gca,'currentpoint');
    col_coordinate = round(ClickPoint(1,1));
    if col_coordinate < 2 || col_coordinate > 255
        msgbox('��������ѡ��Χ��','����');
        return;
    end
    bk_config.wbc_line(bk_config.line_index) = col_coordinate;
    wbc_hist_with_callback(handles.wbc_org_hist,bk_config.wbc_line,handles);
    
    
else if strcmp(get(gcf,'SelectionType'),'alt') % ����Ҽ�����
        
    end;
        
end;

function crp_result_present(re,handles)

tmp = sprintf('%4.1f',re.crp_val);
crp = {'CRP' tmp};
tmp = sprintf('%4.1f',re.crp_ori_val);
crp_ori = {'CRP_ori' tmp};
tmp = sprintf('%4.2f',re.crp_reaction);
reaction = {'reaction' tmp};


data = [crp;crp_ori;reaction];
set(handles.uitable_crp_re,'data',data);


function config_present(re,handles)

tmp = sprintf('%4.0f',re.wbc_gain);
wbc = {'WBC' tmp};
tmp = sprintf('%4.0f',re.rbc_gain);
rbc = {'RBC' tmp};
tmp = sprintf('%4.0f',re.hgb_gain);
hgb = {'HGB' tmp};
tmp = sprintf('%4.0f',re.crp_gain);
crp = {'CRP' tmp};

data = [wbc;rbc;hgb;crp];
set(handles.uitable_main_gain,'data',data);

tmp1 = sprintf('%5.2f',re.wbc_fcb*100);
tmp2 = sprintf('%5.2f',re.wbc_ucb*100);
wbc = {'WBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.rbc_fcb*100);
tmp2 = sprintf('%5.2f',re.rbc_ucb*100);
rbc = {'RBC' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.plt_fcb*100);
tmp2 = sprintf('%5.2f',re.plt_ucb*100);
plt = {'PLT' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.hgb_fcb*100);
tmp2 = sprintf('%5.2f',re.hgb_ucb*100);
hgb = {'HGB' tmp1 tmp2};
tmp1 = sprintf('%5.2f',re.mcv_fcb*100);
tmp2 = sprintf('%5.2f',re.mcv_ucb*100);
mcv = {'MCV' tmp1 tmp2};
data = [wbc;rbc;hgb;mcv;plt];
set(handles.uitable_main_cb,'data',data);

function para_present_rbc(re,header,handles)

%%21�������ʾ
tmp = sprintf('%4.2f',re.rbc);
rbc = {'RBC' tmp ' ' '10^12/L'};
tmp = sprintf('%5.2f',re.hgb);
hgb = {'HGB' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.hct);
hct = {'HCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.mcv);
mcv = {'MCV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.mch);
mch = {'MCH' tmp ' ' 'pg'};
tmp = sprintf('%4.0f',re.mchc);
mchc = {'MCHC' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.rdw_cv);
rdw_cv = {'RDW_CV' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.rdw_sd);
rdw_sd = {'RDW_SD' tmp ' ' 'fL'};
tmp = sprintf('%5.1f',re.plt);
plt = {'PLT' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.mpv);
mpv = {'MPV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.pdw);
pdw = {'PDW' tmp ' ' 'fL'};
tmp = sprintf('%4.3f',re.pct);
pct = {'PCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.plcc);
plcc = {'PLCC' tmp ' ' '10^9/L'};
tmp = sprintf('%5.1f',re.plcr);
plcr = {'PLCR' tmp ' ' '%'};

blank = {' ' ' ' ' ' ' ' };

tmp = sprintf('%9.0f',re.rbc_total_num);
rbc_total_num = {'RBC��Ч������' tmp ' ' '��'};
tmp = sprintf('%9.0f',re.plt_total_num);
plt_total_num = {'PLT��Ч������' tmp ' ' '��'};
if header.inf_ver >= 5
    tmp = sprintf('%9.0f',re.rbc_org_num);
    rbc_org_num = {'RBCʶ��������' tmp ' ' '��'};
    tmp = sprintf('%4.2f',re.rbc_total_num/re.rbc_org_num*100);
    rbc_num_ratio = {'RBC��Ч���ӱ�' tmp ' ' '%'};
    tmp = sprintf('%9.0f',re.plt_org_num);
    plt_org_num = {'PLTʶ��������' tmp ' ' '��'};
    tmp = sprintf('%4.2f',re.plt_total_num/re.plt_org_num*100);
    plt_num_ratio = {'PLT��Ч���ӱ�' tmp ' ' '%'};
    tmp = sprintf('%9.0f',re.rbc_mnum);
    rbc_mnum = {'RBC_m������' tmp ' ' '��'};
    tmp = sprintf('%4.2f',re.rbc_mnum/re.rbc_org_num*100);
    rbc_mnum_ratio = {'RBC_m��/����' tmp ' ' '%'};
    tmp = sprintf('%9.0f',re.plt_mnum);
    plt_mnum = {'PLT_m������' tmp ' ' '��'};
    tmp = sprintf('%4.2f',re.plt_mnum/re.plt_org_num*100);
    plt_mnum_ratio = {'PLT_m��/����' tmp ' ' '%'};
    tmp = sprintf('%4.2f',re.hgb_bk_volt);
    hgb_bk_volt = {'HGB���׵�ѹֵ���������룩' tmp ' ' 'V'};
    tmp = sprintf('%4.2f',re.hgb_me_volt);
    hgb_me_volt = {'HGB������ѹֵ���������룩' tmp ' ' 'V'};
    tmp = sprintf('%4.2f',re.hgb_bk_vol);
    hgb_bk_vol = {'HGB���׵�ѹֵ��FPGA��' tmp ' ' 'V'};
    tmp = sprintf('%4.2f',re.hgb_me_vol);
    hgb_me_vol = {'HGB������ѹֵ��FPGA��' tmp ' ' 'V'};
    tmp = sprintf('%6.2f',re.plt_base_avg);
    plt_base_avg = {'PLT����ƽ��ֵ' tmp ' ' ''};
else
    rbc_org_num = {'RBCʶ��������' 'δ��¼' ' ' ''};
    plt_org_num = {'PLTʶ��������' 'δ��¼' ' ' ''};
    rbc_num_ratio = {'RBC��Ч���ӱ�' 'ȱ�������Ϣ' ' ' '%'};
    plt_num_ratio = {'PLT��Ч���ӱ�' 'ȱ�������Ϣ' ' ' '%'};
    rbc_mnum = {'RBC_m������' 'δ��¼' ' ' '��'};
    plt_mnum = {'PLT_m������' 'δ��¼' ' ' '��'};
    rbc_mnum_ratio = {'RBC_m��/����' 'ȱ�������Ϣ' ' ' '%'};
    plt_mnum_ratio = {'PLT_m��/����' 'ȱ�������Ϣ' ' ' '%'};
    hgb_bk_volt = {'HGB���׵�ѹֵ���������룩' 'δ��¼' ' ' 'V'};
    hgb_me_volt = {'HGB������ѹֵ���������룩' 'δ��¼' ' ' 'V'};
    hgb_bk_vol = {'HGB���׵�ѹֵ��FPGA��' 'δ��¼ ' '' 'V'};
    hgb_me_vol = {'HGB������ѹֵ��FPGA��' 'δ��¼ ' '' 'V'};
    plt_base_avg = {'PLT����ƽ��ֵ' 'δ��¼' ' ' ''};
end

data = [rbc;hgb;hct;mcv;mch;mchc;rdw_cv;rdw_sd;blank;plt;mpv;pdw;pct;plcr;...
    plcc;blank;rbc_total_num;rbc_org_num;rbc_num_ratio;plt_total_num;plt_org_num;...
    plt_num_ratio;rbc_mnum;rbc_mnum_ratio;plt_mnum;plt_mnum_ratio;blank;...
    hgb_bk_volt;hgb_me_volt;hgb_bk_vol;hgb_me_vol;plt_base_avg];
set(handles.uitable_rbc_re,'data',data);

function para_present_wbc(re,header,handles)

%%21�������ʾ
tmp = sprintf('%4.2f',re.wbc);
wbc = {'WBC' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.lymn);
lymn = {'LYM#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.midn);
midn = {'MID#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.2f',re.grann);
grann = {'GRAN#' tmp ' ' '10^9/L'};
tmp = sprintf('%4.1f',re.lymp);
lymp = {'LYM%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.midp);
midp = {'MID%' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.granp);
granp = {'GRAN%' tmp ' ' '%'};

blank = {' ' ' ' ' ' ' ' };

tmp = sprintf('%9.0f',re.wbc_total_num);
wbc_total_num = {'WBC��Ч������' tmp ' ' '��'};

if header.inf_ver >= 5
    tmp = sprintf('%9.0f',re.wbc_org_num);
    wbc_org_num = {'WBCʶ��������' tmp ' ' '��'};
    tmp = sprintf('%3.1f',re.wbc_total_num/re.wbc_org_num*100);
    wbc_num_ratio = {'WBC��Ч���ӱ�' tmp ' ' '%'};
%     tmp = sprintf('%7.0f',re.wbc_mnum);
%     wbc_mnum = {'WBC_m������' tmp ' ' '��'};
    tmp = sprintf('%4.1f',re.wbc_mcv);
    wbc_mcv = {'WBC_MCV' tmp ' ' 'fL'};
    tmp = sprintf('%4.1f',re.lym_mcv);
    lym_mcv = {'LYM_MCV' tmp ' ' 'fL'};
else
    wbc_org_num = {'WBCʶ��������' 'δ��¼' ' ' '��'};
    wbc_num_ratio = {'WBC��Ч���ӱ�' 'δ��¼' ' ' '%'};
%     wbc_mnum = {'WBC_m������' 'δ��¼' ' ' '��'};
    wbc_mcv = {'WBC_MCV' 'δ��¼' ' ' 'fL'};
    lym_mcv = {'LYM_MCV' 'δ��¼' ' ' 'fL'};
end

tmp = sprintf('%4.1f',re.hgb);
hgb_org = {'ԭʼHGBֵ' tmp ' ' 'g/L'};
if isfield(re,'hgb_recal')
    tmp = sprintf('%4.1f',re.hgb_recal);
    hgb_recal = {'����HGBֵ' tmp ' ' 'g/L'};
else
    hgb_recal = {'����HGBֵ' 'δ��¼' ' ' 'g/L'};
end

data = [wbc;lymn;midn;grann;lymp;midp;granp;blank;wbc_total_num;...
    wbc_org_num;wbc_num_ratio;wbc_mcv;lym_mcv;blank;hgb_org;hgb_recal];
set(handles.uitable_wbc_re,'data',data);

function present_sample_info(sample,header,h_uitable)

switch sample.analysis_mode
    case 0 %CBC
        am_str = 'CBC';
    case 1 %CRP
        am_str = 'CRP';
    case 2 %CBC+CRP
        am_str = 'CBC+CRP';
    otherwise
        am_str = 'Unknown';
end
am_str = {'����ģʽ' am_str};
switch sample.blood_mode
    case 0 %ȫѪ
        bm_str = 'ȫѪ';
    case 1 %Ԥϡ��
        bm_str = 'Ԥϡ��';
    otherwise
        bm_str = 'Unknown';
end
bm_str = {'Ѫ��ģʽ' bm_str};
switch sample.sample_type
    case 0 %����Ѫ
        st_str = '����Ѫ';
    otherwise
        st_str = 'Unknown';
end
st_str = {'��������' st_str};
blank = {' ' ' '};

system_ver = {'ϵͳ�汾��' header.system_ver};
timeseq_ver = {'Һ·�汾��' header.timeseq_ver};
mainfpga_ver = {'���ذ�FPGA�汾��' header.main_ver};
alg_ver = {'�㷨�汾��' header.alg_ver};
inf_ver = {'INF�汾��' sprintf('%d',header.inf_ver)};
if header.inf_ver < 5
    driverfpga_ver = {'������FPGA�汾��' 'δ��¼'};
    drivermcu_ver = {'������MCU�汾��' 'δ��¼'};
    machine_info = {'������Ϣ' 'δ��¼'};
    oem_info = {'OEM��Ϣ' 'δ��¼'};
    alg_type = {'�㷨����' '����'};
else
    driverfpga_ver = {'������FPGA�汾��' header.drivefpga_ver};
    drivermcu_ver = {'������MCU�汾��' header.mcu_ver};
    machine_info = {'������Ϣ' 'δ��¼'};
    oem_info = {'OEM��Ϣ' 'δ��¼'};
    alg_type = {'�㷨����' '����'};
end

data = [am_str;bm_str;st_str;system_ver;timeseq_ver;alg_ver;...
    mainfpga_ver;driverfpga_ver;drivermcu_ver;machine_info;oem_info;alg_type;inf_ver];
set(h_uitable,'data',data,'columnwidth',{150 100});


function para_present_main(re,sample,h_uitable)

%%21�������ʾ
tmp = sprintf('%5.2f',re.wbc);
wbc = {'WBC' tmp ' ' '10^9/L'};
tmp = sprintf('%5.2f',re.lymn);
lymn = {'LYM#' tmp ' ' '10^9/L'};
tmp = sprintf('%5.2f',re.midn);
midn = {'MID#' tmp ' ' '10^9/L'};
tmp = sprintf('%5.2f',re.grann);
grann = {'GRAN#' tmp ' ' '10^9/L'};
tmp = sprintf('%3.1f',re.lymp);
lymp = {'LYM%' tmp ' ' '%'};
tmp = sprintf('%3.1f',re.midp);
midp = {'MID%' tmp ' ' '%'};
tmp = sprintf('%3.1f',re.granp);
granp = {'GRAN%' tmp ' ' '%'};
tmp = sprintf('%4.2f',re.rbc);
rbc = {'RBC' tmp ' ' '10^12/L'};
tmp = sprintf('%3.0f',re.hgb);
hgb = {'HGB' tmp ' ' 'g/L'};
tmp = sprintf('%3.1f',re.hct);
hct = {'HCT' tmp ' ' '%'};
tmp = sprintf('%4.1f',re.mcv);
mcv = {'MCV' tmp ' ' 'fL'};
tmp = sprintf('%4.1f',re.mch);
mch = {'MCH' tmp ' ' 'pg'};
tmp = sprintf('%4.0f',re.mchc);
mchc = {'MCHC' tmp ' ' 'g/L'};
tmp = sprintf('%4.1f',re.rdw_sd);
rdw_sd = {'RDW_SD' tmp ' ' 'fL'};
tmp = sprintf('%3.1f',re.rdw_cv);
rdw_cv = {'RDW_CV' tmp ' ' '%'};
tmp = sprintf('%4.0f',re.plt);
plt = {'PLT' tmp ' ' '10^9/L'};
tmp = sprintf('%3.1f',re.mpv);
mpv = {'MPV' tmp ' ' 'fL'};
tmp = sprintf('%3.1f',re.pdw);
pdw = {'PDW' tmp ' ' 'fL'};
tmp = sprintf('%4.3f',re.pct);
pct = {'PCT' tmp ' ' '%'};
tmp = sprintf('%3.1f',re.plcr);
plcr = {'PLCR' tmp ' ' '%'};
tmp = sprintf('%4.0f',re.plcc);
plcc = {'PLCC' tmp ' ' '10^9/L'};


blank = {' ' ' ' ' ' ' ' };
tmp = sprintf('%4.1f',re.crp_val);
if re.crp_val < 10
    hscrp = {'Hs-CRP' tmp ' ' 'mg/L'};
    crp = {'CRP' '<10' ' ' 'mg/L'};
else
    hscrp = {'Hs-CRP' '>10' ' ' 'mg/L'};
    crp = {'CRP' tmp ' ' 'mg/L'};
end
switch sample.analysis_mode
    case 0 %CBC
        data = [wbc;lymp;midp;granp;lymn;midn;grann;blank;rbc;hgb;hct;mcv;mch;mchc;...
    rdw_sd;rdw_cv;blank;plt;mpv;pdw;pct;plcr;plcc];
    case 1 %CRP
        data = [crp;hscrp];
    case 2 %CBC+CRP
        data = [wbc;lymp;midp;granp;lymn;midn;grann;blank;rbc;hgb;hct;mcv;mch;mchc;...
    rdw_sd;rdw_cv;blank;plt;mpv;pdw;pct;plcr;plcc;blank;crp;hscrp];
    otherwise
        data = [];
end

set(h_uitable,'data',data);

% --- Executes on selection change in popup_bm.
function popup_bm_Callback(hObject, eventdata, handles)
% hObject    handle to popup_bm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_bm contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_bm


% --- Executes during object creation, after setting all properties.
function popup_bm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_bm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_am.
function popup_am_Callback(hObject, eventdata, handles)
% hObject    handle to popup_am (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_am contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_am


% --- Executes during object creation, after setting all properties.
function popup_am_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_am (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_file_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in popup_wbc_seg.
function popup_wbc_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_seg
contents = cellstr(get(handles.popup_wbc_seg,'String'));
seg_num = str2double(contents{get(handles.popup_wbc_seg,'Value')});
% index_max = length(handles.wbc_width_data) - mod(length(handles.wbc_width_data),seg_num);
% width_data = reshape(handles.wbc_width_data(1:index_max),[],seg_num);
% peak_data = reshape(handles.wbc_peak_data(1:index_max),[],seg_num);
wbc_time = handles.wbc_time;
time_seglen = floor(double(max(wbc_time))/seg_num);
width_data = double(handles.wbc_width_data);
peak_data = double(handles.wbc_peak_data);

for i = 1:seg_num
    width_hist = get_hist_for_seg(max(handles.wbc_width_data),...
        width_data(wbc_time >= (i-1)*time_seglen & wbc_time < i*time_seglen),max(handles.wbc_width_data));
    x = 1:length(width_hist);
    plot(handles.axes_wbc_width,x,width_hist,'linewidth',1.0);
    peak_hist = get_hist_for_seg(256,peak_data(wbc_time >= (i-1)*time_seglen & wbc_time < i*time_seglen),...
        max(handles.wbc_peak_data));
    x = 1:length(peak_hist);
    plot(handles.axes_wbc_vol,x,peak_hist);
    if i == 1
        hold(handles.axes_wbc_width,'on');
        hold(handles.axes_wbc_vol,'on');
    end
    width_legend{i} = num2str(i); 
end
legend(handles.axes_wbc_width,width_legend,'Location','northoutside','Orientation','horizontal');
hold(handles.axes_wbc_width,'off');
hold(handles.axes_wbc_vol,'off');
set(handles.axes_wbc_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
set(handles.axes_wbc_vol,'color',[0,0,0],'xlim',[1 length(peak_hist)],...
    'ytick',[],'XTick',[]);


% --- Executes during object creation, after setting all properties.
function popup_wbc_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_wbc_nps_sec.
function popup_wbc_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_nps_sec
contents = cellstr(get(handles.popup_wbc_nps_sec,'String'));
switch contents{get(handles.popup_wbc_nps_sec,'Value')};
    case '10ms'
        handles.wbc_nps_sec = 1;
    case '50ms'
        handles.wbc_nps_sec = 5;
    case '100ms'
        handles.wbc_nps_sec = 10;
    case '200ms'
        handles.wbc_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.wbc_nps,handles.wbc_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_wbc_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_wbc_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_wbc_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
h_wbc_nps = nps_monitor_alone(nps_data,handles.wbc_nps_sec,handles.axes_wbc_nps,'w',ylim);
%set(h_wbc_nps,'ButtonDownFcn',{@nps_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback
handles.h_rbc_nps = h_wbc_nps;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popup_wbc_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_wbc_nps_smooth.
function popup_wbc_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_wbc_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_wbc_nps_smooth
popup_wbc_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_wbc_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_wbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_seg.
function popup_rbc_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_seg
contents = cellstr(get(handles.popup_rbc_seg,'String'));
seg_num = str2double(contents{get(handles.popup_rbc_seg,'Value')});
% index_max = length(handles.rbc_peak_data) - mod(length(handles.rbc_peak_data),seg_num);
% width_data = double(reshape(handles.rbc_width_data(1:index_max),[],seg_num));
% peak_data = reshape(handles.rbc_peak_data(1:index_max),[],seg_num);
rbc_time = handles.rbc_time;
time_seglen = floor(double(max(rbc_time))/seg_num);
width_data = double(handles.rbc_width_data);
peak_data = double(handles.rbc_peak_data);

for i = 1:seg_num
    width_hist = get_hist_for_seg(max(handles.rbc_width_data),...
        width_data(rbc_time >= (i-1)*time_seglen & rbc_time < i*time_seglen),max(handles.rbc_width_data));
    x = 1:length(width_hist);
    plot(handles.axes_rbc_width,x,width_hist,'linewidth',1.0);
    peak_hist = get_hist_for_seg(256,peak_data(rbc_time >= (i-1)*time_seglen & rbc_time < i*time_seglen),...
        max(handles.rbc_peak_data));
    x = 1:length(peak_hist);
    plot(handles.axes_rbc_vol,x,peak_hist);
    if i == 1
        hold(handles.axes_rbc_width,'on');
        hold(handles.axes_rbc_vol,'on');
    end
    width_legend{i} = num2str(i); 
end

legend(handles.axes_rbc_width,width_legend,'Location','northoutside','Orientation','horizontal');
hold(handles.axes_rbc_width,'off');
hold(handles.axes_rbc_vol,'off');
set(handles.axes_rbc_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
set(handles.axes_rbc_vol,'color',[0,0,0],'xlim',[1 length(peak_hist)],...
    'ytick',[],'XTick',[]);

% --- Executes during object creation, after setting all properties.
function popup_rbc_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_plt_nps_smooth.
function popup_plt_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_nps_smooth
popup_plt_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_plt_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_plt_nps_sec.
function popup_plt_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_nps_sec
contents = cellstr(get(handles.popup_plt_nps_sec,'String'));
switch contents{get(handles.popup_plt_nps_sec,'Value')};
    case '10ms'
        handles.plt_nps_sec = 1;
    case '50ms'
        handles.plt_nps_sec = 5;
    case '100ms'
        handles.plt_nps_sec = 10;
    case '200ms'
        handles.plt_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.plt_nps,handles.plt_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_plt_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_plt_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_plt_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
nps_monitor_alone(nps_data,handles.plt_nps_sec,handles.axes_plt_nps,'g',ylim);

% --- Executes during object creation, after setting all properties.
function popup_plt_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_nps_sec.
function popup_rbc_nps_sec_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_nps_sec contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_nps_sec
contents = cellstr(get(handles.popup_rbc_nps_sec,'String'));
switch contents{get(handles.popup_rbc_nps_sec,'Value')};
    case '10ms'
        handles.rbc_nps_sec = 1;
    case '50ms'
        handles.rbc_nps_sec = 5;
    case '100ms'
        handles.rbc_nps_sec = 10;
    case '200ms'
        handles.rbc_nps_sec = 20;
end
guidata(hObject, handles);
nps_data = change_sec_gap_for_nps(handles.rbc_nps,handles.rbc_nps_sec);
ylim = [min(nps_data)*0.9 max(nps_data*1.1)];
smooth_contents = cellstr(get(handles.popup_rbc_nps_smooth,'String'));
switch smooth_contents{get(handles.popup_rbc_nps_smooth,'Value')}
    case '��ƽ��'
        smooth_step = 1;
    otherwise
        smooth_step = str2double(smooth_contents{get(handles.popup_rbc_nps_smooth,'Value')});
end
nps_data = smooth(nps_data,smooth_step);
h_rbc_nps = nps_monitor_alone(nps_data,handles.rbc_nps_sec,handles.axes_rbc_nps,'r',ylim);
%set(h_rbc_nps,'ButtonDownFcn',{@nps_buttondown_Callback,handles}); % ����ͼ������ButtonDown�ص�����Ϊ�Լ������myCallback
handles.h_rbc_nps = h_rbc_nps;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function popup_rbc_nps_sec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popup_rbc_nps_smooth.
function popup_rbc_nps_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_rbc_nps_smooth contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_rbc_nps_smooth
popup_rbc_nps_sec_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function popup_rbc_nps_smooth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_rbc_nps_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_edit_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_edit_batch_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_batch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ѡ�������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼��������������Ľ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('����������������¼��������ļ�_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(BK_offline_ini.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBC(10^9/L),LYM#(10^9/L),MID#(10^9/L),GRAN#(10^9/L),LYM%%(%%),MID%%(%%),GRAN%%(%%),');
        fprintf(fid,'RBC(10^12/L),HGB(g/L),HCT(%%),MCV(fL),MCH(pg),MCHC(g/L),RDW_SD(fL),RDW_CV(%%),PLT(10^9/L),MPV(fL),PDW(fL),PCT(%%),PLCR(%%),PLCC(10^9/L),CRP(mg/L),����ģʽ,����ģʽ,');
        fprintf(fid,'PLT��Ч������,PLTʶ��������,HGB���׵�ѹ,HGB������ѹ\n');
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cell,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                switch sample.analysis_mode
                    case 0 %CBC
                        am_str = 'CBC';
                    case 1 %CRP
                        am_str = 'CRP';
                    case 2 %CBC+CRP
                        am_str = 'CBC+CRP';
                    otherwise
                        am_str = 'Unknown';
                end
                switch sample.blood_mode
                    case 0 %ȫѪ
                        bm_str = 'ȫѪ';
                    case 1 %Ԥϡ��
                        bm_str = 'Ԥϡ��';
                    otherwise
                        bm_str = 'Unknown';
                end
                %%
                fprintf(fid,'%s,%5.2f,%5.2f,%5.2f,%5.2f,%3.1f,%3.1f,%3.1f,',sample_num,...
                    re.old.wbc,re.old.lymn,re.old.midn,re.old.grann,re.old.lymp,re.old.midp,re.old.granp);
                if header.inf_ver > 3
                    crp = re.old.crp_val;
                else
                    crp = 0;
                end
                fprintf(fid,'%4.2f,%3.0f,%3.1f,%4.1f,%4.1f,%4.0f,%4.1f,%3.1f,',...
                    re.old.rbc,re.old.hgb,re.old.hct,re.old.mcv,re.old.mch,re.old.mchc,re.old.rdw_sd,re.old.rdw_cv);
                fprintf(fid,'%4.0f,%3.1f,%3.1f,%4.3f,%3.1f,%4.0f,%3.1f,%s,%s,',...
                    re.old.plt,re.old.mpv,re.old.pdw,re.old.pct,re.old.plcr,re.old.plcc,crp,am_str,bm_str);
                fprintf(fid,'%9.0f,%9.0f,%4.3f,%4.3f\n',re.old.plt_total_num,re.old.plt_org_num,re.old.hgb_bk_volt,re.old.hgb_me_volt);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end

% --------------------------------------------------------------------
function menu_edit_hgb_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hgb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        sample_name_cell = cell(1,num);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        item_num = 1;
        if ~isempty(file_cellstr)
            hgb_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,~,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                %%
                hgb_mat(1:length(monitor.hgb_data),i) = monitor.hgb_data;
                waitbar(i/(size(file_cellstr,1)+item_num),h);
            end
        end
        %% ����HGB����
        now = fix(clock());
        now_str = sprintf('����������HGB����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        hgb_path = fullfile(BK_offline_ini.filedir,now_str);
        hgb_cell = num2cell(hgb_mat);
        hgb_data = [sample_name_cell;hgb_cell];
        data = cell2table(hgb_data);
        writetable(data, hgb_path);
        waitbar((i+1)/(size(file_cellstr,1)+item_num),h);
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
        
end


% --- Executes when user attempts to close SimpleOptimizedTab.
function SimpleOptimizedTab_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to SimpleOptimizedTab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
refresh_config();
delete(hObject);


% --- Executes when selected object is changed in uibuttongroup_wbc_manual.
function uibuttongroup_wbc_manual_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uibuttongroup_wbc_manual 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global bk_config;
if get(handles.radio_wbc_l1,'value')
    bk_config.line_index = 1;
    
else if get(handles.radio_wbc_l2,'value')
        bk_config.line_index = 2; 
        
    else if get(handles.radio_wbc_l3,'value')
            bk_config.line_index = 3;
        else if get(handles.radio_wbc_l4,'value')
                bk_config.line_index = 4;
            end
        end
    end
end



% --- Executes on button press in button_wbc_refresh.
function button_wbc_refresh_Callback(hObject, eventdata, handles)
% hObject    handle to button_wbc_refresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global bk_config;
line = bk_config.wbc_line;
%line = [15;44;68];
tmp = bk_config.re.new;
header = bk_config.header;
sample = bk_config.sample;
hist = handles.wbc_org_hist;
if line(1) < line(2) && line(2) < line(3) && line(3) < line(4)
    lym_num = sum(hist(line(1)+1:line(2)));
    mid_num = sum(hist(line(2)+1:line(3)));
    gran_num = sum(hist(line(3)+1:line(4)));
    wbc_num = lym_num + mid_num + gran_num;
    if sample.blood_mode == 0
        dilution = 305.1;
    else
        dilution = 501.9;
    end      
    wbc_value = wbc_num * dilution / 402.8 / 1000;
    if wbc_value > 10
        wbc_value = 0.00002555*wbc_value*wbc_value*wbc_value + 0.0002554*wbc_value*wbc_value + 1.026*wbc_value - 0.1579;
    end
    tmp.wbc = wbc_value*sample.wbc_fcb*sample.wbc_ucb;
    tmp.lymp = lym_num/wbc_num*100;
    tmp.midp = mid_num/wbc_num*100;
    tmp.granp = gran_num/wbc_num*100;
    tmp.lymn = tmp.wbc*lym_num/wbc_num;
    tmp.midn = tmp.wbc*mid_num/wbc_num;
    tmp.grann = tmp.wbc*gran_num/wbc_num;
    tmp.wbc_total_num = wbc_num;
    para_present_wbc(tmp,header,handles);
    
else
    msgbox('�����ߴ�С������,���������á�','��ʾ');
    return;
end


% --------------------------------------------------------------------
function menu_edit_hist_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������ֱ��ͼ�Ƚ��������csv�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        sample_name_cell = cell(1,num);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
              %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cellinfo,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
               %%
                wbc_hist_mat(:,i) = re.new.wbc_hist;
                rbc_hist_mat(:,i) = re.new.rbc_hist;
                plt_hist_mat(:,i) = re.new.plt_hist(1:64);
                wbc_width_hist_mat(:,i) = get_hist_for_seg(60,cellinfo.wbc_fullwidth,max(cellinfo.wbc_fullwidth));
                rbc_width_hist_mat(:,i) = get_hist_for_seg(60,cellinfo.rbc_fullwidth,max(cellinfo.rbc_fullwidth));
                wbc_peak_hist_mat(:,i) = get_hist_for_seg(256,cellinfo.wbc_peak,max(cellinfo.wbc_peak));
                rbc_peak_hist_mat(:,i) = get_hist_for_seg(256,cellinfo.rbc_peak,max(cellinfo.rbc_peak));
                waitbar(i/(size(file_cellstr,1)+7),h);                
            end
        end
        %% ����WBCֱ��ͼ����
        now = fix(clock());
        now_str = sprintf('����������WBCֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        wbc_hist_path = fullfile(BK_offline_ini.filedir,now_str);
        wbc_hist_cell = num2cell(wbc_hist_mat);
        wbc_hist_data = [sample_name_cell;wbc_hist_cell];
        data = cell2table(wbc_hist_data);
        writetable(data, wbc_hist_path);
        waitbar((i+1)/(size(file_cellstr,1)+7),h); 
        %% ����RBCֱ��ͼ����
        now_str = sprintf('����������RBCֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        rbc_hist_path = fullfile(BK_offline_ini.filedir,now_str);
        rbc_hist_cell = num2cell(rbc_hist_mat);
        rbc_hist_data = [sample_name_cell;rbc_hist_cell];
        data = cell2table(rbc_hist_data);
        writetable(data, rbc_hist_path);
        waitbar((i+2)/(size(file_cellstr,1)+7),h);
         %% ����PLTֱ��ͼ����
        now_str = sprintf('����������PLTֱ��ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        plt_hist_path = fullfile(BK_offline_ini.filedir,now_str);
        plt_hist_cell = num2cell(plt_hist_mat);
        plt_hist_data = [sample_name_cell;plt_hist_cell];
        data = cell2table(plt_hist_data);
        writetable(data, plt_hist_path);
        waitbar((i+3)/(size(file_cellstr,1)+7),h);
         %% ����WBC���ȷֲ�ͼ����
        now_str = sprintf('����������WBC���ȷֲ�ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        wbc_width_path = fullfile(BK_offline_ini.filedir,now_str);
        wbc_width_cell = num2cell(wbc_width_hist_mat);
        wbc_width_data = [sample_name_cell;wbc_width_cell];
        data = cell2table(wbc_width_data);
        writetable(data, wbc_width_path);
        waitbar((i+4)/(size(file_cellstr,1)+7),h); 
          %% ����RBC���ȷֲ�ͼ����
        now_str = sprintf('����������RBC���ȷֲ�ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        rbc_width_path = fullfile(BK_offline_ini.filedir,now_str);
        rbc_width_cell = num2cell(rbc_width_hist_mat);
        rbc_width_data = [sample_name_cell;rbc_width_cell];
        data = cell2table(rbc_width_data);
        writetable(data, rbc_width_path);
        waitbar((i+5)/(size(file_cellstr,1)+7),h);
          %% ����WBC����ֲ�ͼ����
        now_str = sprintf('����������WBC����ֲ�ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        wbc_peak_path = fullfile(BK_offline_ini.filedir,now_str);
        wbc_peak_cell = num2cell(wbc_peak_hist_mat);
        wbc_peak_data = [sample_name_cell;wbc_peak_cell];
        data = cell2table(wbc_peak_data);
        writetable(data, wbc_peak_path);
        waitbar((i+6)/(size(file_cellstr,1)+7),h);
           %% ����RBC����ֲ�ͼ����
        now_str = sprintf('����������RBC����ֲ�ͼ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        rbc_peak_path = fullfile(BK_offline_ini.filedir,now_str);
        rbc_peak_cell = num2cell(rbc_peak_hist_mat);
        rbc_peak_data = [sample_name_cell;rbc_peak_cell];
        data = cell2table(rbc_peak_data);
        writetable(data, rbc_peak_path);
        waitbar((i+7)/(size(file_cellstr,1)+7),h);
        
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end


% --------------------------------------------------------------------
function menu_edit_crp_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_crp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������ֱ��ͼ�Ƚ��������csv�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        index = 0;
        
        if ~isempty(file_cellstr)
            crp_mat = zeros(300,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cellinfo,monitor] = bk_inf_or_int_recal(filepath,config);
                %%
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                if isfield(monitor,'crp_data')
                    if isempty(monitor.crp_data)
                        continue;
                    end
                else
                    continue;
                end
                index = index + 1;
                
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{index} = sample_num;
                crp_mat(1:length(monitor.crp_data),index) = monitor.crp_data;
                
                waitbar(i/(size(file_cellstr,1)+1),h);
            end
        end
        %% ����CRP����
        if index == 0
            close(h);
            msgbox('Ŀ���ļ�����û�а���crp���ݵ�inf�ļ���','��ʾ');
            return;
        end
        now = fix(clock());
        now_str = sprintf('����������CRP����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        crp_path = fullfile(BK_offline_ini.filedir,now_str);
        crp_cell = num2cell(crp_mat(:,1:index));
        crp_data = [sample_name_cell;crp_cell];
        data = cell2table(crp_data);
        writetable(data, crp_path);
        waitbar((i+1)/(size(file_cellstr,1)+1),h); 
               
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end


% --------------------------------------------------------------------
function menu_edit_hole_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_hole (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������������ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        sample_name_cell = cell(1,num);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        item_num = 4;
        if ~isempty(file_cellstr)
            
            whole_mat = zeros(6000,size(file_cellstr,1));
            rhole_mat = zeros(6000,size(file_cellstr,1));
            wbase_mat = zeros(6000,size(file_cellstr,1));
            rbase_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                %% ����C���Կ�
                [header,sample,re,cellinfo,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                %%
                whole_mat(1:length(monitor.whole_data),i) = monitor.whole_data;
                rhole_mat(1:length(monitor.rhole_data),i) = monitor.rhole_data;
                wbase_mat(1:length(monitor.wbase_data),i) = monitor.wbase_data;
                rbase_mat(1:length(monitor.rbase_data),i) = monitor.rbase_data;
                waitbar(i/(size(file_cellstr,1)+item_num),h);
            end
        end
        %% ����WBC��������
        now = fix(clock());
        now_str = sprintf('����������WBC��������_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        wbase_path = fullfile(BK_offline_ini.filedir,now_str);
        wbase_cell = num2cell(wbase_mat);
        wbase_data = [sample_name_cell;wbase_cell];
        data = cell2table(wbase_data);
        writetable(data, wbase_path);
        waitbar((i+1)/(size(file_cellstr,1)+item_num),h);
        %% ����WBCС�׵�ѹ����
        now_str = sprintf('����������WBCС�׵�ѹ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        whole_path = fullfile(BK_offline_ini.filedir,now_str);
        whole_cell = num2cell(whole_mat);
        whole_data = [sample_name_cell;whole_cell];
        data = cell2table(whole_data);
        writetable(data, whole_path);
        waitbar((i+2)/(size(file_cellstr,1)+item_num),h);
        %% ����WBCС�׵�ѹ����
        now_str = sprintf('����������RBCС�׵�ѹ����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        rhole_path = fullfile(BK_offline_ini.filedir,now_str);
        rhole_cell = num2cell(rhole_mat);
        rhole_data = [sample_name_cell;rhole_cell];
        data = cell2table(rhole_data);
        writetable(data, rhole_path);
        waitbar((i+3)/(size(file_cellstr,1)+item_num),h);
        %% ����RBC��������
        now_str = sprintf('����������RBC��������_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        rbase_path = fullfile(BK_offline_ini.filedir,now_str);
        rbase_cell = num2cell(rbase_mat);
        rbase_data = [sample_name_cell;rbase_cell];
        data = cell2table(rbase_data);
        writetable(data, rbase_path);
        waitbar((i+4)/(size(file_cellstr,1)+item_num),h);
        
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
        
end

% --------------------------------------------------------------------
function menu_edit_kpa_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_kpa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼���������ѹ�����ߵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        sample_name_cell = cell(1,num);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        item_num = 1;
        if ~isempty(file_cellstr)
            kpa_mat = zeros(6000,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cellinfo,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                %%
                ap_data = -(bitand(monitor.air_pressure_data,32767,'int16'));
                ap_data = double(ap_data)/10;
                kpa_mat(1:length(ap_data),i) = ap_data;
                waitbar(i/(size(file_cellstr,1)+item_num),h);
            end
        end
        %% ����HGB����
        now = fix(clock());
        now_str = sprintf('�������������ѹ������_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        kpa_path = fullfile(BK_offline_ini.filedir,now_str);
        kpa_cell = num2cell(kpa_mat);
        kpa_data = [sample_name_cell;kpa_cell];
        data = cell2table(kpa_data);
        writetable(data, kpa_path);
        waitbar((i+1)/(size(file_cellstr,1)+item_num),h);
               
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_file_open_Callback(hObject, eventdata, handles)
% hObject    handle to menu_file_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
button_browse_Callback(hObject, eventdata, handles);


% --------------------------------------------------------------------
function menu_test_Callback(hObject, eventdata, handles)
% hObject    handle to menu_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_test_hole_vol_Callback(hObject, eventdata, handles)
% hObject    handle to menu_test_hole_vol (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�������¿��㷨���ԵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('�����������¿��㷨���Ա���_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(BK_offline_ini.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBCͨ��,RBCͨ��\n');
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
              %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                 config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cell,monitor] = bk_inf_or_int_recal(filepath,config);
                [hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                % WBCС�׵�ѹ
                whole_data = medfilt1(double(monitor.whole_data),15);
                if wbc_pos.start < length(monitor.whole_data) && wbc_pos.end < length(monitor.whole_data)
                    wbc_bool = if_abnormal_voltage(whole_data(wbc_pos.start-200:wbc_pos.end),3);
                    if wbc_bool
                        wbc_msg = '�¿�';
                    else
                        wbc_msg = '����';
                    end
                end
                % RBCС�׵�ѹ
                rhole_data = medfilt1(double(monitor.rhole_data),15);
                if rbc_pos.start < length(monitor.rhole_data) && rbc_pos.end < length(monitor.rhole_data)
                    rbc_bool = if_abnormal_voltage(rhole_data(wbc_pos.start-150:wbc_pos.end),4);
                    if rbc_bool
                        rbc_msg = '�¿�';
                    else
                        rbc_msg = '����';
                    end
                end
               %%
                fprintf(fid,'%s,%s,%s\n',sample_num,wbc_msg,rbc_msg);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
        
    case 'ȡ��'
        
end


% --------------------------------------------------------------------
function menu_edit_recal_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_recal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ѡ�������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼��������������Ľ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('�����������㷨�����������ļ�_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(BK_offline_ini.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,WBC(10^9/L),LYM%%(%%),MID%%(%%),GRAN%%(%%),LYM#(10^9/L),MID#(10^9/L),GRAN#(10^9/L),');
        fprintf(fid,'RBC(10^12/L),HGB(g/L),HCT(%%),MCV(fL),MCH(pg),MCHC(g/L),RDW_CV(%%),RDW_SD(fL),PLT(10^9/L),MPV(fL),PDW(fL),PCT(%%),PLCR(%%),PLCC(10^9/L),CRP(mg/L),����ģʽ,����ģʽ,');
        fprintf(fid,'R1,R2,R3,R4,Rm,R1_tell,R2_tell,R3_tell,R4_tell,wbc_abnormal\n');
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cell,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                switch sample.analysis_mode
                    case 0 %CBC
                        am_str = 'CBC';
                    case 1 %CRP
                        am_str = 'CRP';
                    case 2 %CBC+CRP
                        am_str = 'CBC+CRP';
                    otherwise
                        am_str = 'Unknown';
                end
                switch sample.blood_mode
                    case 0 %ȫѪ
                        bm_str = 'ȫѪ';
                    case 1 %Ԥϡ��
                        bm_str = 'Ԥϡ��';
                    otherwise
                        bm_str = 'Unknown';
                end
                %re.new.plt = re.new.plt*1.43;
                %%
                fprintf(fid,'%s,%5.2f,%3.1f,%3.1f,%3.1f,%5.2f,%5.2f,%5.2f,',sample_num,...
                    re.new.wbc,re.new.lymn,re.new.midn,re.new.grann,re.new.lymp,re.new.midp,re.new.granp);
                if header.inf_ver > 3
                    crp = re.new.crp_val;
                else
                    crp = 0;
                end
                fprintf(fid,'%4.2f,%3.0f,%3.1f,%4.1f,%4.1f,%4.0f,%4.1f,%4.1f,',...
                    re.new.rbc,re.new.hgb,re.new.hct,re.new.mcv,re.new.mch,re.new.mchc,re.new.rdw_sd,re.new.rdw_cv);
                fprintf(fid,'%4.0f,%3.1f,%3.1f,%4.3f,%3.1f,%4.0f,%3.1f,%s,%s,',...
                    re.new.plt,re.new.mpv,re.new.pdw,re.new.pct,re.new.plcr,re.new.plcc,crp,am_str,bm_str);
                %% ֱ��ͼ������Ϣ
                wbc_hist_flag = re.new.wbc_hist_flag;
                wbc_hint = re.new.wbc_hint;
                if bitand(wbc_hist_flag,1)
                    R1 = 'TRUE';
                else
                    R1 = '';
                end
                if bitand(wbc_hist_flag,2)
                    R2 = 'TRUE';
                else
                    R2 = '';
                end
                if bitand(wbc_hist_flag,4)
                    R3 = 'TRUE';
                else
                    R3 = '';
                end
                if bitand(wbc_hist_flag,8)
                    R4 = 'TRUE';
                else
                    R4 = '';
                end
                if bitand(wbc_hist_flag,16)
                    Rm = 'TRUE';
                else
                    Rm = '';
                end
                if bitand(wbc_hint,16)
                    wbc_ab = 'TRUE';
                else
                    wbc_ab = '';
                end
                fprintf(fid,'%s,%s,%s,%s,%s,%4.2f,%4.2f,%4.2f,%4.2f,%s\n',...
                    R1,R2,R3,R4,Rm,re.new.R1_tell,re.new.R2_tell,re.new.R3_tell,re.new.R4_tell,wbc_ab);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end

function copy_histogram(h_axes)

tmpf = figure('visible','off');
copyobj(h_axes,tmpf);
set(tmpf,'units','centimeters','position',[0 0 7.9 2.5]);
set(gca,'units','centimeters','position',[0.1 0.5 7.8 2]);
hgexport(tmpf,'-clipboard');
delete(tmpf);


% --- Executes on button press in button_copy_whist.
function button_copy_whist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_whist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_main_wbc);



% --- Executes on button press in button_copy_phist.
function button_copy_phist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_phist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_main_plt);


% --- Executes on button press in button_copy_rhist.
function button_copy_rhist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_rhist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_main_rbc);


% --- Executes on button press in radio_without_cb.
function radio_without_cb_Callback(hObject, eventdata, handles)
% hObject    handle to radio_without_cb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radio_without_cb
global bk_config;
re = bk_config.re.new;
sample = bk_config.sample;
if get(hObject,'Value')
    re.wbc = re.wbc/sample.wbc_ucb/sample.wbc_fcb;
    re.lymn = re.wbc*re.lymp/100;
    re.midn = re.wbc*re.midp/100;
    re.grann = re.wbc*re.granp/100;
    re.rbc = re.rbc/sample.rbc_ucb/sample.rbc_fcb;
    re.mcv = re.mcv/sample.mcv_ucb/sample.mcv_fcb;
    re.plt = re.plt/sample.plt_ucb/sample.plt_fcb;
    re.hgb = re.hgb/sample.hgb_ucb/sample.hgb_fcb;
    re.hct = re.rbc*re.mcv/10;
    re.mch = re.hgb/re.rbc;
    re.mchc = re.hgb/re.hct*100;
    re.pct = re.plt*re.mpv/10000;
    re.plcc = re.plt*re.plcr/100;
else
end
para_present_main(re,sample,handles.uitable_main_re);




% --- Executes on selection change in popup_plt_seg.
function popup_plt_seg_Callback(hObject, eventdata, handles)
% hObject    handle to popup_plt_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popup_plt_seg contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popup_plt_seg
contents = cellstr(get(handles.popup_plt_seg,'String'));
seg_num = str2double(contents{get(handles.popup_plt_seg,'Value')});
% index_max = length(handles.plt_peak_data) - mod(length(handles.plt_peak_data),seg_num);
% width_data = double(reshape(handles.plt_width_data(1:index_max),[],seg_num));
% peak_data = reshape(handles.plt_peak_data(1:index_max),[],seg_num);
plt_time = handles.plt_time;
time_seglen = floor(double(max(plt_time))/seg_num);
width_data = double(handles.plt_width_data);
peak_data = double(handles.plt_peak_data);

for i = 1:seg_num
    width_hist = get_hist_for_seg(max(handles.plt_width_data),...
        width_data(plt_time >= (i-1)*time_seglen & plt_time < i*time_seglen),max(handles.plt_width_data));
    x = 1:length(width_hist);
    plot(handles.axes_plt_width,x,width_hist,'linewidth',1.0);
    peak_hist = get_hist_for_seg(128,...
        peak_data(plt_time >= (i-1)*time_seglen & plt_time < i*time_seglen),4095);
    x = 1:length(peak_hist);
    plot(handles.axes_plt_vol,x,peak_hist);
    if i == 1
        hold(handles.axes_plt_width,'on');
        hold(handles.axes_plt_vol,'on');
    end
    width_legend{i} = num2str(i); 
end

legend(handles.axes_plt_width,width_legend,'Location','northoutside','Orientation','horizontal');
hold(handles.axes_plt_width,'off');
hold(handles.axes_plt_vol,'off');
set(handles.axes_plt_width,'color',[0,0,0],'xlim',[1 length(width_hist)],...
    'ytick',[],'XTick',[]);
set(handles.axes_plt_vol,'color',[0,0,0],'xlim',[1 64],...
    'ytick',[],'XTick',[]);

% --- Executes during object creation, after setting all properties.
function popup_plt_seg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popup_plt_seg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function crp_start_pos_Callback(hObject, eventdata, handles)
% hObject    handle to crp_start_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_start_pos as text
%        str2double(get(hObject,'String')) returns contents of crp_start_pos as a double


% --- Executes during object creation, after setting all properties.
function crp_start_pos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_start_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function crp_end_pos_Callback(hObject, eventdata, handles)
% hObject    handle to crp_end_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_end_pos as text
%        str2double(get(hObject,'String')) returns contents of crp_end_pos as a double


% --- Executes during object creation, after setting all properties.
function crp_end_pos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_end_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function crp_seglen_Callback(hObject, eventdata, handles)
% hObject    handle to crp_seglen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crp_seglen as text
%        str2double(get(hObject,'String')) returns contents of crp_seglen as a double


% --- Executes during object creation, after setting all properties.
function crp_seglen_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_seglen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_refresh_crp_reaction.
function button_refresh_crp_reaction_Callback(hObject, eventdata, handles)
% hObject    handle to button_refresh_crp_reaction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
global bk_config;
filepath = fullfile(BK_offline_ini.filedir,BK_offline_ini.inf_file_name);
reaction_config.start_pos = str2double(get(handles.crp_start_pos,'string'));
reaction_config.end_pos = str2double(get(handles.crp_end_pos,'string'));
reaction_config.seglen = str2double(get(handles.crp_seglen,'string'));
reaction = get_crp_reaction(filepath,reaction_config);
crp_data = handles.crp_data;
plot_crp(crp_data,handles.axes_crp,reaction_config);
re = bk_config.re.new;
re.crp_reaction = reaction;
crp_result_present(re,handles);



% --- Executes on button press in button_send2calibration.
function button_send2calibration_Callback(hObject, eventdata, handles)
% hObject    handle to button_send2calibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
read_file_list(BK_offline_ini.filedir, handles, 0);
file_cellstr = cellstr(get(handles.listbox1, 'String'));
h=waitbar(0,'���ڴ����У����Ժ�...');
reaction_config.start_pos = str2double(get(handles.crp_start_pos,'string'));
reaction_config.end_pos = str2double(get(handles.crp_end_pos,'string'));
reaction_config.seglen = str2double(get(handles.crp_seglen,'string'));
if ~isempty(file_cellstr)
    file_num = size(file_cellstr,1);
    sample_id = cell(file_num,1);
    reaction = cell(file_num,1);
    for i = 1:file_num
        %% �������㷨
        file_str = char(file_cellstr(i));
        filepath = fullfile(BK_offline_ini.filedir,file_str);
        filename = file_str;
        sample_id{i} = filename(1:length(filename)-4);
        %% ����C���Կ�
        reaction{i} = get_crp_reaction(filepath,reaction_config);
        waitbar(i/(size(file_cellstr,1)+1),h);
    end
end
%% ����CRP����
data = [sample_id reaction];
set(handles.uitable_crp_reaction,'data',data);
waitbar((i+1)/(size(file_cellstr,1)+1),h);
close(h);

function fit_and_present_cali_curve(handles,save_flag)

data = get(handles.uitable_crp_cali_settings,'data');
reaction = cell2mat(data(:,2));
crp = cell2mat(data(:,1));
contents = cellstr(get(handles.crp_cali_point_num,'String'));
data_num = str2double(contents{get(handles.crp_cali_point_num,'Value')});
config.data_num = data_num;
contents = cellstr(get(handles.crp_cali_bloodmode,'String'));
switch contents{get(handles.crp_cali_bloodmode,'Value')};
    case 'ȫѪ'
        config.bm = 0;
    case 'Ԥϡ��'
        config.bm = 1;
end
config.save_flag = save_flag;
reaction = reaction(1:data_num);
crp = crp(1:data_num);
[x,fx] = fit_crp_cali_curve(reaction,crp,config);
cla(handles.axes_crp_cali_curve);
scatter(handles.axes_crp_cali_curve,crp,reaction);
hold(handles.axes_crp_cali_curve,'on');
plot(handles.axes_crp_cali_curve,fx,x,'r');
hold(handles.axes_crp_cali_curve,'off');
xlabel(handles.axes_crp_cali_curve,'crpֵ');
ylabel(handles.axes_crp_cali_curve,'��Ӧ��');
if save_flag
    switch config.bm
    case 0
        msgbox('ȫѪģʽ�µ�crp�������߱���ɹ���','�ɹ���');
    case 1
        msgbox('Ԥϡ��ģʽ�µ�crp�������߱���ɹ���','�ɹ���');
    end
end

% --- Executes on button press in button_generate_cali_curve.
function button_generate_cali_curve_Callback(hObject, eventdata, handles)
% hObject    handle to button_generate_cali_curve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fit_and_present_cali_curve(handles,0);

 


% --- Executes on button press in button_save_cali_curve.
function button_save_cali_curve_Callback(hObject, eventdata, handles)
% hObject    handle to button_save_cali_curve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fit_and_present_cali_curve(handles,1);



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in crp_cali_point_num.
function crp_cali_point_num_Callback(hObject, eventdata, handles)
% hObject    handle to crp_cali_point_num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns crp_cali_point_num contents as cell array
%        contents{get(hObject,'Value')} returns selected item from crp_cali_point_num


% --- Executes during object creation, after setting all properties.
function crp_cali_point_num_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_cali_point_num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in crp_cali_bloodmode.
function crp_cali_bloodmode_Callback(hObject, eventdata, handles)
% hObject    handle to crp_cali_bloodmode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns crp_cali_bloodmode contents as cell array
%        contents{get(hObject,'Value')} returns selected item from crp_cali_bloodmode


% --- Executes during object creation, after setting all properties.
function crp_cali_bloodmode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crp_cali_bloodmode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in button_copy_crp_cali_curve.
function button_copy_crp_cali_curve_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_crp_cali_curve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_crp_cali_curve);


% --------------------------------------------------------------------
function menu_edit_nps_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_nps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼������ֱ��ͼ�Ƚ��������csv�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        
        num = read_file_list(BK_offline_ini.filedir, handles, 0);
        sample_name_cell = cell(1,num);
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        
        if ~isempty(file_cellstr)
            wbc_nps_mat = zeros(100,size(file_cellstr,1));
            rbc_nps_mat = zeros(100,size(file_cellstr,1));
            plt_nps_mat = zeros(100,size(file_cellstr,1));
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                sample_name_cell{i} = sample_num;
                config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cellinfo,monitor] = bk_inf_or_int_recal(filepath,config);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                %%
                num = max(cellinfo.wbc_time);
                if num > 0
                    for j = 1:num
                        index = find(cellinfo.wbc_time==j);
                        wbc_nps(j) = length(index);
                    end
                end
                wbc_nps_mat(1:length(wbc_nps),i) = wbc_nps;
                num = max(cellinfo.rbc_time);
                if num > 0
                    for j = 1:num
                        index = find(cellinfo.rbc_time==j);
                        rbc_nps(j) = length(index);
                    end
                end
                rbc_nps_mat(1:length(rbc_nps),i) = rbc_nps;
                num = max(cellinfo.plt_time);
                if num > 0
                    for j = 1:num
                        index = find(cellinfo.plt_time==j);
                        plt_nps(j) = length(index);
                    end
                end
                plt_nps_mat(1:length(plt_nps),i) = plt_nps;
                waitbar(i/(size(file_cellstr,1)+3),h);
            end
        end
        %% ����WBC_nps����
        now = fix(clock());
        now_str = sprintf('����������WBC_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_file_path = fullfile(BK_offline_ini.filedir,now_str);
        tmp_cell = num2cell(wbc_nps_mat);
        table_data = [sample_name_cell;tmp_cell];
        data = cell2table(table_data);
        writetable(data, out_file_path);
        waitbar((i+1)/(size(file_cellstr,1)+3),h); 
       %% ����RBC_nps����
        now_str = sprintf('����������RBC_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_file_path = fullfile(BK_offline_ini.filedir,now_str);
        tmp_cell = num2cell(rbc_nps_mat);
        table_data = [sample_name_cell;tmp_cell];
        data = cell2table(table_data);
        writetable(data, out_file_path);
        waitbar((i+2)/(size(file_cellstr,1)+3),h); 
        %% ����PLT_nps����
        now_str = sprintf('����������PLT_NPS����_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        out_file_path = fullfile(BK_offline_ini.filedir,now_str);
        tmp_cell = num2cell(plt_nps_mat);
        table_data = [sample_name_cell;tmp_cell];
        data = cell2table(table_data);
        writetable(data, out_file_path);
        waitbar((i+3)/(size(file_cellstr,1)+3),h); 
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end


% --------------------------------------------------------------------
function menu_test_dubious_Callback(hObject, eventdata, handles)
% hObject    handle to menu_test_dubious (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼�����������Ա����㷨���ԵĽ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        now = fix(clock());
        now_str = sprintf('���������������Ա����㷨���Ա���_%d-%d-%d_%d-%d-%d.csv',now(1),now(2),now(3),now(4),now(5),now(6));
        outfilepath = fullfile(BK_offline_ini.filedir,now_str);
        fid = fopen(outfilepath,'wt');
        fprintf(fid,'sample_ID,RBC˫���ԣ�\n');
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
              %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                filename = file_str;
                sample_num = filename(1:length(filename)-4);
                 config.sample_id = filename(1:length(filename)-4);
                %% ����C���Կ�
                config.crp_start_pos = str2double(get(handles.crp_start_pos,'string'));
                config.crp_end_pos = str2double(get(handles.crp_end_pos,'string'));
                config.crp_seglen = str2double(get(handles.crp_seglen,'string'));
                [header,sample,re,cell,monitor] = bk_inf_or_int_recal(filepath,config);
                [hgb_pos,wbc_pos,rbc_pos,kpa_pos] = read_config_table(sample);
                if header.error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,header.error_code);
                    msgbox(str,'����');
                    continue;
                end
                % RBC˫���ԣ�
                rbc_hint = re.new.rbc_hint;
                if bitand(rbc_hint,65536)
                    rbc_bimodality_msg = 'true';
                else
                    rbc_bimodality_msg = 'false';
                end
               
                 %%
                fprintf(fid,'%s,%s\n',sample_num,rbc_bimodality_msg);
                waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        fclose(fid);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
        
    case 'ȡ��'
        
end


% --- Executes on button press in button_copy_wbc_whist.
function button_copy_wbc_whist_Callback(hObject, eventdata, handles)
% hObject    handle to button_copy_wbc_whist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copy_histogram(handles.axes_wbc);


% --------------------------------------------------------------------
function menu_edit_bin_Callback(hObject, eventdata, handles)
% hObject    handle to menu_edit_bin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global BK_offline_ini;
% Construct a questdlg with three options
choice = questdlg('������ѡ�������ǰ�ļ��������з���Ҫ��Ĳ��Լ�¼��������������Ľ��������excel�ļ��У��Ƿ����?','��ʾ','ȷ��','ȡ��','ȷ��');
% Handle response
switch choice
    case 'ȷ��'
        file_cellstr = cellstr(get(handles.listbox1, 'String'));
        h=waitbar(0,'���ڴ����У����Ժ�...');
        if ~isempty(file_cellstr)
            for i = 1:size(file_cellstr,1)
                %% �������㷨
                file_str = char(file_cellstr(i));
                filepath = fullfile(BK_offline_ini.filedir,file_str);
                dat_file_path = strrep(filepath,'.inf','.dat');
                %% ����C���Կ�
                error_code = inf_to_binary(filepath,dat_file_path);
                if error_code
                    str = sprintf('%s�ļ���֧�ֻ�������\n������Ϊ%d��',filename,error_code);
                    msgbox(str,'����');
                    continue;
                end
               waitbar(i/size(file_cellstr,1),h);                
            end
        end
        close(h);
        choice = questdlg('�ѳɹ������ļ����Ƿ�򿪵����ļ������ļ���?','��ʾ','ȷ��','ȡ��','ȷ��');
        % Handle response
        switch choice
            case 'ȷ��'
                winopen(BK_offline_ini.filedir);
            case 'ȡ��'
                
        end
        
    case 'ȡ��'
    
end
