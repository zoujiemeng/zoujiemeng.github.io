function plot_crp(crp_data,h_axes,config)
%% WBCֱ��ͼ��ʾ
cla(h_axes);
plot(h_axes,1:length(crp_data),crp_data,'g','linewidth',2);
hold(h_axes,'on');
start_pos = config.start_pos;
end_pos = config.end_pos;
seglen = config.seglen;
offset = 20;
if start_pos > 0 && start_pos < length(crp_data)
    plot(h_axes,[start_pos start_pos],[crp_data(start_pos)-offset crp_data(start_pos)+offset],...
        'w>-');
    plot(h_axes,[start_pos+seglen start_pos+seglen],[crp_data(start_pos+seglen)-offset crp_data(start_pos+seglen)+offset],...
        'w<-');
end
if end_pos > start_pos && end_pos < length(crp_data)
    plot(h_axes,[end_pos end_pos],[crp_data(end_pos)-offset crp_data(end_pos)+offset],...
        'w>-');
    plot(h_axes,[end_pos+seglen end_pos+seglen],[crp_data(end_pos+seglen)-offset crp_data(end_pos+seglen)+offset],...
        'w<-');
end
set(h_axes,'color',[0,0,0],'ylim',[0 max(crp_data)*1.5]);
