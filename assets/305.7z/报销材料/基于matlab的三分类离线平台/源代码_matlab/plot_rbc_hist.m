function plot_rbc_hist(rbc_dsp_hist,line,h_axes)

%% gauss fit
% gauss_fit_data = double_gauss_func_fit(line(1):line(2),rbc_dsp_hist(line(1):line(2)));
% fid = fopen('gauss_fit_test_data.csv','wt');
% fprintf(fid,'x,y\n');
% for i = line(1):line(2)
%     fprintf(fid,'%6.2f,%6.2f\n',i,rbc_dsp_hist(i));
% end
% fclose(fid);
% plot(h_axes,1:256,rbc_dsp_hist,'bo');
% hold(h_axes,'on');
% plot(h_axes,1:256,gauss_fit_data,'b-');
% hold(h_axes,'off');
%% RBCֱ��ͼ��ʾ
% rbc_dsp_hist = rbc_dsp_hist - min(rbc_dsp_hist) + 1;
% rbc_dsp_hist = [0;rbc_dsp_hist;0];
max_x = 320;
line = double(line)*max_x/length(rbc_dsp_hist);
step = max_x/length(rbc_dsp_hist);
x = step:step:max_x;
fill(h_axes,x,rbc_dsp_hist,'r');
ylim_max = max(rbc_dsp_hist)*1.5;
if ylim_max < 1
    ylim_max = 1;
end
set(h_axes,'color',[0,0,0],'xlim',[0 max_x],'ylim',[0 ylim_max],'XTick',(step:80:max_x),'XTickLabel',{'0' '80' '160' '240' '320'});
hold(h_axes,'on');
plot(h_axes,[line(1) line(1)],[0 max(rbc_dsp_hist)*1.5],'w--');
plot(h_axes,[line(2) line(2)],[0 max(rbc_dsp_hist)*1.5],'w--');
hold(h_axes,'off');