#include <stdio.h>
#include <string.h>
#include "mex.h"
#include "common_func.h"
#include "bk_hgb_main.h"
#include "bk_alg_main.h"

char inf_file_path[MAX_PATH];

int inf_result2software_result(INF_RESULT *inf_re, item_evt_count_temp_t *soft_re)
{
	int i;
	soft_re->wbc.val = inf_re->report_result.wbc;
	soft_re->lymphn.val = inf_re->report_result.lymphn;
	soft_re->midn.val = inf_re->report_result.midn;
	soft_re->grann.val = inf_re->report_result.grann;
	soft_re->lymphp.val = inf_re->report_result.lymphp;
	soft_re->midp.val = inf_re->report_result.midp;
	soft_re->granp.val = inf_re->report_result.granp;

	soft_re->rbc.val = inf_re->report_result.rbc;
	soft_re->hgb.val = inf_re->report_result.hgb;
	soft_re->hct.val = inf_re->report_result.hct;
	soft_re->mcv.val = inf_re->report_result.mcv;
	soft_re->mch.val = inf_re->report_result.mch;
	soft_re->mchc.val = inf_re->report_result.mchc;
	soft_re->rdw_cv.val = inf_re->report_result.rdw_cv;
	soft_re->rdw_sd.val = inf_re->report_result.rdw_sd;

	soft_re->plt.val = inf_re->report_result.plt;
	soft_re->mpv.val = inf_re->report_result.mpv;
	soft_re->pdw.val = inf_re->report_result.pdw;
	soft_re->pct.val = inf_re->report_result.pct;
	soft_re->plcc.val = inf_re->report_result.plcc;
	soft_re->plcr.val = inf_re->report_result.plcr;

	soft_re->crp.val = inf_re->report_result.crp;

	soft_re->whistodata.len = inf_re->wbc_hist.dsp_hist.datalen;
	for (i = 0; i < soft_re->whistodata.len; i++)
	{
		soft_re->whistodata.data[i] = (unsigned short)inf_re->wbc_hist.dsp_hist.datas[i];
	}

	soft_re->rhistodata.len = inf_re->rbc_hist.dsp_hist.datalen;
	for (i = 0; i < soft_re->rhistodata.len; i++)
	{
		soft_re->rhistodata.data[i] = (unsigned short)inf_re->rbc_hist.dsp_hist.datas[i];
	}

	soft_re->phistodata.len = inf_re->plt_hist.dsp_hist.datalen;
	for (i = 0; i < soft_re->phistodata.len; i++)
	{
		soft_re->phistodata.data[i] = (unsigned short)inf_re->plt_hist.dsp_hist.datas[i];
	}

	soft_re->otherresult.wbcline1 = inf_re->wbc_hist.dsp_hist.lines[0];
	soft_re->otherresult.wbcline2 = inf_re->wbc_hist.dsp_hist.lines[1];
	soft_re->otherresult.wbcline3 = inf_re->wbc_hist.dsp_hist.lines[2];
	soft_re->otherresult.wbcline4 = inf_re->wbc_hist.dsp_hist.lines[3];

	soft_re->otherresult.rbclinel = inf_re->rbc_hist.dsp_hist.lines[0];
	soft_re->otherresult.rbcliner = inf_re->rbc_hist.dsp_hist.lines[1];

	soft_re->otherresult.pltlinel = inf_re->plt_hist.dsp_hist.lines[0];
	soft_re->otherresult.pltliner = inf_re->plt_hist.dsp_hist.lines[1];

	soft_re->otherresult.wbcHint = inf_re->other_result.wbc_hint;
	soft_re->otherresult.rbcHint = inf_re->other_result.rbc_hint;
	soft_re->otherresult.pltHint = inf_re->other_result.plt_hint;

	soft_re->otherresult.wmcv = inf_re->other_result.wbc_mcv;
	return 0;
}

int write_bin_file(item_evt_count_temp_t *soft_re, char *file_path)
{
	FILE *fp;
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
	fwrite(soft_re, sizeof(item_evt_count_temp_t), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

//**********************************************************************
// ��������: mexFunction     
// ����˵����matlab���Ե��ú���     
// �� �� ֵ: void	     
// ��    ��: 
//           [out] int nlhs			�����������
//           [out] mxArray * plhs[]	�������matlab��������
//           [in] int nrhs			�����������
//           [in] mxArray * prhs[]	�������matlab��������
//**********************************************************************
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
	char *inf_file_path;
	char *dat_file_path;
	INF_FILE inf;
	item_evt_count_temp_t soft_re;
	int error_code;
		
	if (nlhs != 1) mexErrMsgTxt("1 outputs required");
	if (nrhs != 2) mexErrMsgTxt("2 inputs required");

	inf_file_path = mxArrayToString(prhs[0]);
	dat_file_path = mxArrayToString(prhs[1]);
	memset(&inf, 0, sizeof(INF_FILE));
	memset(&soft_re, 0, sizeof(item_evt_count_temp_t));
	error_code = read_inf_file(inf_file_path, &inf);
	inf_result2software_result(&inf.result, &soft_re);
	write_bin_file(&soft_re, dat_file_path);

	plhs[0] = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(plhs[0]), &error_code, sizeof(int));
		
		
}