#include <stdio.h>
#include <string.h>
#include "mex.h"
#include "common_func.h"
//#include "bk_alg_main.h"


char inf_file_path[MAX_PATH];
// ����CRP������Ϣ
void AlgSetCrpCalInfo(const crp_cal_reaction_info *pstCalInfo, crp_cal_wave *pstWave)
{
	int i = 0;

	printf("AlgSetCrpCalInfo alg. lItemCount = %ld\n", pstCalInfo->lItemCount);

	for (i = 0; i < pstCalInfo->lItemCount; i++)
	{
		printf("crpValue = %f  crpReaction = %f\n", pstCalInfo->astItems[i].
			crpValue, pstCalInfo->astItems[i].crpReaction);
	}


	// ���ɶ�������
	double x1[MAX_CRP_CAL_REACTION_ITEM], y1[MAX_CRP_CAL_REACTION_ITEM];
	double yp0 = 0.0, ypn_1 = 0.0;
	double ypp[MAX_CRP_CAL_REACTION_ITEM];
	FILE *fp = NULL;
	char c = 'N';
	int data_num;

	// ��ȡ����
	data_num = pstCalInfo->lItemCount;
	for (i = 0; i < data_num; i++)
	{
		x1[i] = pstCalInfo->astItems[i].crpReaction;
		y1[i] = pstCalInfo->astItems[i].crpValue;
	}
	insertion_sort4double_array(x1, data_num, y1);
	switch (c)
	{
	case 'n':
	case 'N':
		printf("\nNatural cubic spline case\n");
		ncspline(x1, y1, data_num, data_num, data_num, ypp);
		break; // case 'n'
	case 'c':
	case 'C':
		printf("\nClamped cubic spline case\n");
		clcspline(x1, y1, data_num, data_num, data_num, yp0, ypn_1, ypp);
		break; // case 'c'
	default:
		printf("\nNatural cubic spline case\n");
		ncspline(x1, y1, data_num, data_num, data_num, ypp);
		break;
	}

	// �������������ݴ洢���ļ�
	if (pstCalInfo->lSaveFile)
	{
		switch (pstCalInfo->bm)
		{
		case BloodModeWL:
			if (!(fp = fopen("natural_spline_data_wb.crp", "wb")))
			{
				printf("\ncrp spline file save failed!\n");
				return; //�ļ��򿪴���
			}
			break;
		case BloodModePD:
			if (!(fp = fopen("natural_spline_data_pd.crp", "wb")))
			{
				printf("\ncrp spline file save failed!\n");
				return; //�ļ��򿪴���
			}
			break;
		}

		fwrite(&data_num, sizeof(int), 1, fp);
		fflush(fp);
		fwrite(x1, sizeof(double), data_num, fp);
		fflush(fp);
		fwrite(y1, sizeof(double), data_num, fp);
		fflush(fp);
		fwrite(ypp, sizeof(double), data_num, fp);
		fflush(fp);
		fclose(fp);
		printf("\ncrp spline file saved success!\n");
	}
	// �����������������������ṹ��
	double tmp_x, tmp_fx;
	double A = x1[data_num - 1] - x1[0];
	i = 0;
	int m = MAX_CRP_WAVE_POINT;

	while (i < m)
	{
		double f = i / ((double)m);
		/* xi is a s-curve */
		tmp_x = (3.0 - 2.0 * f) * f * f * A + x1[0];
		csplint(x1, y1, ypp, data_num, tmp_x, &tmp_fx);
		pstWave->afPointX[i] = (float)tmp_x;
		pstWave->afPointY[i] = (float)tmp_fx;
		i++;
	}
	return;
}
//**********************************************************************
// ��������: mexFunction     
// ����˵����matlab���Ե��ú���     
// �� �� ֵ: void	     
// ��    ��: 
//           [out] int nlhs			�����������
//           [out] mxArray * plhs[]	�������matlab��������
//           [in] int nrhs			�����������
//           [in] mxArray * prhs[]	�������matlab��������
//**********************************************************************
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
	double *reaction,*crp;
	int data_num,blood_mode,save_flag,i;
	double *x, *fx;
	crp_cal_reaction_info crp_cali_in;
	crp_cal_wave crp_cali_out;
		
	if (nlhs != 2) mexErrMsgTxt("2 outputs required");
	if (nrhs != 3) mexErrMsgTxt("3 inputs required");

	reaction = mxGetData(prhs[0]);
	crp = mxGetData(prhs[1]);
	data_num = (int)mxGetScalar(mxGetField(prhs[2],0,"data_num"));
	blood_mode = (int)mxGetScalar(mxGetField(prhs[2], 0, "bm"));
	save_flag = (int)mxGetScalar(mxGetField(prhs[2], 0, "save_flag"));

	memset(&crp_cali_in, 0, sizeof(crp_cal_reaction_info));
	crp_cali_in.lItemCount = data_num;
	crp_cali_in.bm = blood_mode;
	crp_cali_in.lSaveFile = save_flag;
	for (i = 0; i < data_num; i++)
	{
		crp_cali_in.astItems[i].crpReaction = reaction[i];
		crp_cali_in.astItems[i].crpValue = crp[i];
	}
	memset(&crp_cali_out, 0, sizeof(crp_cal_wave));
	AlgSetCrpCalInfo(&crp_cali_in,&crp_cali_out);
	
	
	plhs[0] = mxCreateNumericMatrix(MAX_CRP_WAVE_POINT, 1, mxDOUBLE_CLASS, mxREAL);
	x = (double*)mxGetData(plhs[0]);
	
	plhs[1] = mxCreateNumericMatrix(MAX_CRP_WAVE_POINT, 1, mxDOUBLE_CLASS, mxREAL);
	fx = (double*)mxGetData(plhs[1]);
	for (i = 0; i < MAX_CRP_WAVE_POINT; i++)
	{
		x[i] = crp_cali_out.afPointX[i];
		fx[i] = crp_cali_out.afPointY[i];
	}
}