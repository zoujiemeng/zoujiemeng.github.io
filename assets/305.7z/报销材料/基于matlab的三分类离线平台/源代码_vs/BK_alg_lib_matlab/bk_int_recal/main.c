#include <stdio.h>
#include <string.h>
#include "mex.h"
#include "common_func.h"
#include "read_new_inf.h"
#include "bk_alg_main.h"

void set_field_double_val(mxArray *pout, mxArray *ptmp, double val, int index)
{
	ptmp = mxCreateNumericMatrix(1, 1, mxDOUBLE_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &val, sizeof(double));
	mxSetFieldByNumber(pout, 0, index, ptmp);
	return;
}

void set_field_int_val(mxArray *pout, mxArray *ptmp, int val, int index)
{
	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &val, sizeof(int));
	mxSetFieldByNumber(pout, 0, index, ptmp);
	return;
}

mxArray *result2mxArray(INF_RESULT *re,INF_CRP *crp)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "wbc","lymn","midn","grann","lymp","midp",
		"granp","rbc","hgb","hct","mcv","mch","mchc","rdw_cv","rdw_sd","plt",
		"mpv","pdw","pct","plcc","plcr","wbc_hist","rbc_hist","plt_hist",
		"wbc_line","rbc_line","plt_line","wbc_total_num","rbc_total_num",
		"plt_total_num","crp_reaction","crp_ori_val","crp_val","wbc_mcv",
		"lym_mcv","wbc_org_num","rbc_org_num","plt_org_num","hgb_bk_volt",
		"hgb_me_volt","wbc_org_hist","wbc_hist_flag","rbc_hist_flag","R1_tell",
		"R2_tell","R3_tell","R4_tell","rbc_org_hist","wbc_hint","rbc_hint",
		"plt_hint"};
	int field_num;
	int *line;

	field_num = 51;
	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = NULL;
	set_field_double_val(pout, ptmp, re->report_result.wbc, 0);
	set_field_double_val(pout, ptmp, re->report_result.lymphn, 1);
	set_field_double_val(pout, ptmp, re->report_result.midn, 2);
	set_field_double_val(pout, ptmp, re->report_result.grann, 3);
	set_field_double_val(pout, ptmp, re->report_result.lymphp, 4);
	set_field_double_val(pout, ptmp, re->report_result.midp, 5);
	set_field_double_val(pout, ptmp, re->report_result.granp, 6);
	set_field_double_val(pout, ptmp, re->report_result.rbc, 7);
	set_field_double_val(pout, ptmp, re->report_result.hgb, 8);
	set_field_double_val(pout, ptmp, re->report_result.hct, 9);
	set_field_double_val(pout, ptmp, re->report_result.mcv, 10);
	set_field_double_val(pout, ptmp, re->report_result.mch, 11);
	set_field_double_val(pout, ptmp, re->report_result.mchc, 12);
	set_field_double_val(pout, ptmp, re->report_result.rdw_cv, 13);
	set_field_double_val(pout, ptmp, re->report_result.rdw_sd, 14);
	set_field_double_val(pout, ptmp, re->report_result.plt, 15);
	set_field_double_val(pout, ptmp, re->report_result.mpv, 16);
	set_field_double_val(pout, ptmp, re->report_result.pdw, 17);
	set_field_double_val(pout, ptmp, re->report_result.pct, 18);
	set_field_double_val(pout, ptmp, re->report_result.plcc, 19);
	set_field_double_val(pout, ptmp, re->report_result.plcr, 20);
	
	set_field_int_val(pout, ptmp, re->other_result.wbc_hist_flag, 41);
	set_field_int_val(pout, ptmp, re->other_result.rbc_hist_flag, 42);

	set_field_double_val(pout, ptmp, re->other_result.R1_tell, 43);
	set_field_double_val(pout, ptmp, re->other_result.R2_tell, 44);
	set_field_double_val(pout, ptmp, re->other_result.R3_tell, 45);
	set_field_double_val(pout, ptmp, re->other_result.R4_tell, 46);

	set_field_int_val(pout, ptmp, re->other_result.wbc_hint, 48);
	set_field_int_val(pout, ptmp, re->other_result.rbc_hint, 49);
	set_field_int_val(pout, ptmp, re->other_result.plt_hint, 50);

	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->wbc_hist.org_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 40, ptmp);

	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->wbc_hist.dsp_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 21, ptmp);

	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->rbc_hist.org_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 47, ptmp);
	
	ptmp = mxCreateNumericMatrix(256, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->rbc_hist.dsp_hist.datas, sizeof(int) * 256);
	mxSetFieldByNumber(pout, 0, 22, ptmp);

	ptmp = mxCreateNumericMatrix(128, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->plt_hist.dsp_hist.datas, sizeof(int) * 128);
	mxSetFieldByNumber(pout, 0, 23, ptmp);

	ptmp = mxCreateNumericMatrix(re->wbc_hist.dsp_hist.linelen, 1,
		mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), re->wbc_hist.dsp_hist.lines, sizeof(int) * 
		re->wbc_hist.dsp_hist.linelen);
	mxSetFieldByNumber(pout, 0, 24, ptmp);

	ptmp = mxCreateNumericMatrix(2, 1, mxINT32_CLASS, mxREAL);
	line = (int *)mxGetData(ptmp);
	line[0] = re->rbc_hist.dsp_hist.lines[0];
	line[1] = re->rbc_hist.dsp_hist.lines[1];
	mxSetFieldByNumber(pout, 0, 25, ptmp);

	ptmp = mxCreateNumericMatrix(2, 1, mxINT32_CLASS, mxREAL);
	line = (int *)mxGetData(ptmp);
	line[0] = re->plt_hist.dsp_hist.lines[0];
	line[1] = re->plt_hist.dsp_hist.lines[1];
	mxSetFieldByNumber(pout, 0, 26, ptmp);

	set_field_double_val(pout, ptmp, re->other_result.wbc_filter_num, 27);
	set_field_double_val(pout, ptmp, re->other_result.rbc_filter_num, 28);
	set_field_double_val(pout, ptmp, re->other_result.plt_filter_num, 29);

	set_field_double_val(pout, ptmp, crp->reaction, 30);
	set_field_double_val(pout, ptmp, crp->crp_ori_val, 31);
	set_field_double_val(pout, ptmp, crp->crp_val, 32);

	set_field_double_val(pout, ptmp, re->other_result.wbc_mcv, 33);
	set_field_double_val(pout, ptmp, re->other_result.lym_mcv, 34);

	set_field_double_val(pout, ptmp, re->other_result.wbc_org_num, 35);
	set_field_double_val(pout, ptmp, re->other_result.rbc_org_num, 36);
	set_field_double_val(pout, ptmp, re->other_result.plt_org_num, 37);
	set_field_double_val(pout, ptmp, re->other_result.hgb_bk_volt, 38);
	set_field_double_val(pout, ptmp, re->other_result.hgb_me_volt, 39);

	return pout;
}


mxArray *cell_info2mxArray(INF_CELL_LIST *cell)
{
	mxArray *pout, *ppeak, *pfullwidth, *ptime, *pmflag, *ppriwidth, *psubwidth,
		*ptmp,*pbase;
	const char *field_name[] = { "wbc_peak","wbc_fullwidth","wbc_time",
		"rbc_peak", "rbc_fullwidth","rbc_time","plt_peak","plt_fullwidth",
		"plt_time", "wbc_mflag","rbc_mflag","plt_mflag","plt_priwidth",
		"plt_subwidth","reserve","wbc_base","rbc_base","plt_base"};
	int field_num = 18;
	int cell_num,i;
	short *peak, *fullwidth,*time,*mflag,*priwidth,*subwidth,*base;

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);
	// reserve
	i = 0;
	ptmp = NULL;
	set_field_int_val(pout, ptmp, i, 14);
	// wbc cell info
	cell_num = cell->wbc_cell_num;
	ppeak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	peak = (short *)mxGetData(ppeak);
	pfullwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	fullwidth = (short *)mxGetData(pfullwidth);
	ptime = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	time = (short *)mxGetData(ptime);
	pmflag = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mflag = (short *)mxGetData(pmflag);
	pbase = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	base = (short *)mxGetData(pbase);
	for (i = 0; i < cell_num; i++)
	{
		peak[i] = cell->wbc_cell_info[i].PeakValue;
		fullwidth[i] = cell->wbc_cell_info[i].FullWidth;
		time[i] = cell->wbc_cell_info[i].TimeStamp;
		mflag[i] = cell->wbc_cell_info[i].MPulseFlag;
		base[i] = cell->wbc_cell_info[i].BaseLine;
	}
	mxSetFieldByNumber(pout, 0, 0, ppeak);
	mxSetFieldByNumber(pout, 0, 1, pfullwidth);
	mxSetFieldByNumber(pout, 0, 2, ptime);
	mxSetFieldByNumber(pout, 0, 9, pmflag);
	mxSetFieldByNumber(pout, 0, 15, pbase);
	// rbc cell info
	cell_num = cell->rbc_cell_num;
	ppeak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	peak = (short *)mxGetData(ppeak);
	pfullwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	fullwidth = (short *)mxGetData(pfullwidth);
	ptime = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	time = (short *)mxGetData(ptime);
	pmflag = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mflag = (short *)mxGetData(pmflag);
	pbase = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	base = (short *)mxGetData(pbase);
	for (i = 0; i < cell_num; i++)
	{
		peak[i] = cell->rbc_cell_info[i].PeakValue;
		fullwidth[i] = cell->rbc_cell_info[i].FullWidth;
		time[i] = cell->rbc_cell_info[i].TimeStamp;
		mflag[i] = cell->rbc_cell_info[i].MPulseFlag;
		base[i] = cell->rbc_cell_info[i].BaseLine;
	}
	mxSetFieldByNumber(pout, 0, 3, ppeak);
	mxSetFieldByNumber(pout, 0, 4, pfullwidth);
	mxSetFieldByNumber(pout, 0, 5, ptime);
	mxSetFieldByNumber(pout, 0, 10, pmflag);
	mxSetFieldByNumber(pout, 0, 16, pbase);
	// plt cell info
	cell_num = cell->plt_cell_num;
	ppeak = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	peak = (short *)mxGetData(ppeak);
	pfullwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	fullwidth = (short *)mxGetData(pfullwidth);
	ptime = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	time = (short *)mxGetData(ptime);
	pmflag = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	mflag = (short *)mxGetData(pmflag);
	ppriwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	priwidth = (short *)mxGetData(ppriwidth);
	psubwidth = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	subwidth = (short *)mxGetData(psubwidth);
	pbase = mxCreateNumericMatrix(cell_num, 1, mxINT16_CLASS, mxREAL);
	base = (short *)mxGetData(pbase);
	for (i = 0; i < cell_num; i++)
	{
		peak[i] = cell->plt_cell_info[i].PeakValue;
		fullwidth[i] = cell->plt_cell_info[i].FullWidth;
		time[i] = cell->plt_cell_info[i].TimeStamp;
		mflag[i] = cell->plt_cell_info[i].MPulseFlag;
		priwidth[i] = cell->plt_cell_info[i].PriWidth;
		subwidth[i] = cell->plt_cell_info[i].SubWidth;
		base[i] = cell->plt_cell_info[i].BaseLine;
	}
	mxSetFieldByNumber(pout, 0, 6, ppeak);
	mxSetFieldByNumber(pout, 0, 7, pfullwidth);
	mxSetFieldByNumber(pout, 0, 8, ptime);
	mxSetFieldByNumber(pout, 0, 11, pmflag);
	mxSetFieldByNumber(pout, 0, 12, ppriwidth);
	mxSetFieldByNumber(pout, 0, 13, psubwidth);
	mxSetFieldByNumber(pout, 0, 17, pbase);
	return pout;
}

mxArray *monitor2mxArray(INF_NEW_MONITOR *new_monitor, INF_CRP *crp,
	int exception_code)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "hgb_data","whole_data","rhole_data",
		"wbase_data","rbase_data","air_pressure_data","crp_data",
		"wbc_block","rbc_block" };
	int field_num = 9;
	int data_num;
	
	pout = mxCreateStructMatrix(1, 1, field_num, field_name);
	ptmp = NULL;
	// exception
	set_field_int_val(pout, ptmp, exception_code & 0x00000001, 7);
	set_field_int_val(pout, ptmp, exception_code & 0x00000002, 8);
	// hgb data
	data_num = new_monitor->hgb.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->hgb.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	// wbc aperture data
	data_num = new_monitor->wbc_aperture_vol.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->wbc_aperture_vol.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	// rbc aperture data
	data_num = new_monitor->rbc_aperture_vol.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->rbc_aperture_vol.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	// wbc aperture base data
	data_num = new_monitor->wbc_vol_base.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->wbc_vol_base.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	// wbc aperture base data
	data_num = new_monitor->rbc_vol_base.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->rbc_vol_base.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	// air pressure data
	data_num = new_monitor->vacuum_pressure.data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), new_monitor->vacuum_pressure.data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	// crp data
	data_num = crp->data_num;
	ptmp = mxCreateNumericMatrix(data_num, 1, mxINT16_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), crp->data, sizeof(short) * data_num);
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	return pout;
}

mxArray *header2mxArray(INF_HEADER *header, INF_SYSTEM_VER *sys_ver, int error_code)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "error_code","inf_ver","system_ver","timeseq_ver",
		"main_ver","alg_ver","drivefpga_ver","mcu_ver"};
	int field_num = 8;
	//char *str_buff;
	

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &error_code, sizeof(int));
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &header->inf_ver, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	ptmp = mxCreateString(sys_ver->version_system);
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	ptmp = mxCreateString(sys_ver->version_timeseq);
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	ptmp = mxCreateString(sys_ver->version_main_fpga);
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	ptmp = mxCreateString(sys_ver->version_alg);
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	ptmp = mxCreateString(sys_ver->version_drive_fpga);
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	ptmp = mxCreateString(sys_ver->version_mcu);
	mxSetFieldByNumber(pout, 0, 7, ptmp);

	return pout;
}

mxArray *sample2mxArray_inf3(INF_SAMPLE *sample)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "analysis_mode","blood_mode","sample_type" };
	int field_num = 3;


	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->analysis_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->blood_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->sample_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	return pout;
}

mxArray *sample2mxArray_inf4(INF_SAMPLE *sample, INF_CONFIG *config)
{
	mxArray *pout, *ptmp;
	const char *field_name[] = { "analysis_mode","blood_mode","sample_type",
	"wbc_gain","rbc_gain","hgb_gain","crp_gain","wbc_fcb","wbc_ucb","rbc_fcb",
	"rbc_ucb","plt_fcb","plt_ucb","hgb_fcb","hgb_ucb","mcv_fcb","mcv_ucb"};
	int field_num = 17;
	double d_tmp;
	

	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->analysis_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 0, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->blood_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 1, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT8_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &sample->sample_mode, sizeof(byte));
	mxSetFieldByNumber(pout, 0, 2, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->wbc_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 3, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->rbc_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 4, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->hgb_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 5, ptmp);

	ptmp = mxCreateNumericMatrix(1, 1, mxINT32_CLASS, mxREAL);
	memcpy(mxGetPr(ptmp), &config->crp_gain, sizeof(int));
	mxSetFieldByNumber(pout, 0, 6, ptmp);

	//
	d_tmp = config->cb_wbc.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 7);

	d_tmp = config->cb_wbc.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 8);
	//
	d_tmp = config->cb_rbc.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 9);

	d_tmp = config->cb_rbc.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 10);
	//
	d_tmp = config->cb_plt.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 11);

	d_tmp = config->cb_plt.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 12);
	//
	d_tmp = config->cb_hgb.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 13);

	d_tmp = config->cb_hgb.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 14);
	//
	d_tmp = config->cb_mcv.factory_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 15);

	d_tmp = config->cb_mcv.user_cal_factor;
	set_field_double_val(pout, ptmp, d_tmp, 16);

	return pout;
}




int BK_alg_main_offline(INF_FILE *inf_in, INF_RESULT *re_out,char *inf_id)
{
	int exception_code;
	stImpdInput s_impe_input;
	stImpdOutput s_impe_output;
	S_BK_WBC_INPUT s_wbc_input;
	S_BK_WBC_OUTPUT s_wbc_output;
	S_HGB_INPUT s_hgb_input;
	//INF_CRP crp;
	item_evt_count_temp_t bk_result;
	sample_info_t s_sample_info;
	double hgb, crp_val;

	//printf("BK_alg_main --- ALG_VERSION = %s\n", ALG_VERSION);

	// initial
	memset(&bk_result, 0, sizeof(item_evt_count_temp_t));

	// ��ȡУ��ϵ����CRP����
#ifdef BK_LINUX_TEST
	CRPCollectChannel crp_handle;
	item_cal_factor_t s_cal_factor;

	AlgSetCalFactor_test(&s_cal_factor);
	AlgAddCrpData_test(&crp_handle);

#else


#endif // BK_LINUX_TEST

	// wbc channel
	memset(&s_wbc_input, 0, sizeof(S_BK_WBC_INPUT));

	s_wbc_input.wbc_input.cell_list.CellNum = inf_in->cell_list.wbc_cell_num;
	s_wbc_input.wbc_input.cell_list.cell_info = inf_in->cell_list.wbc_cell_info;
	s_wbc_input.alg_pos[0] = -1;
	s_wbc_input.alg_pos[1] = -1;
	s_wbc_input.wbc_input.MeasureTime = 10.0;
	s_wbc_input.wbc_input.lines[0] = 15;
	s_wbc_input.wbc_input.lines[1] = 44;
	s_wbc_input.wbc_input.lines[2] = 68;

	switch (inf_in->sample.blood_mode)
	{
	case BloodModeWL:
		s_wbc_input.wbc_input.Dilution = 305.1;
		break;
	case BloodModePD:
		s_wbc_input.wbc_input.Dilution = 501.9;
		break;
	default:
		break;
	}
	if (inf_in->header.inf_ver > 3)
	{
		s_wbc_input.wbc_input.factory_cal_factor = inf_in->config.cb_wbc.factory_cal_factor;
		s_wbc_input.wbc_input.user_cal_factor = inf_in->config.cb_wbc.user_cal_factor;
	}
	else
	{
		s_wbc_input.wbc_input.factory_cal_factor = (float)1.0;
		s_wbc_input.wbc_input.user_cal_factor = (float)1.0;
	}
	

	s_wbc_input.wbc_input.Volume = 402.8;
	BK_wbc_main_offline(&s_wbc_input, &s_wbc_output);
	printf("wbc_channel_alg_finished!\n");

	// rbc_plt channel
	memset(&s_impe_input, 0, sizeof(stImpdInput));

	s_impe_input.RbcInput.cell_list.CellNum = inf_in->cell_list.rbc_cell_num;
	s_impe_input.RbcInput.cell_list.cell_info = inf_in->cell_list.rbc_cell_info;
	s_impe_input.PltInput.cell_list.CellNum = inf_in->cell_list.plt_cell_num;
	s_impe_input.PltInput.cell_list.cell_info = inf_in->cell_list.plt_cell_info;

	s_impe_input.flag_pulse_alg = 1;
	s_impe_input.RbcInput.RbcConfigPara.rbc_compensation_plan = 1;
	s_impe_input.RbcInput.alg_pos[0] = -1;
	s_impe_input.RbcInput.alg_pos[1] = -1;
	s_impe_input.PltInput.alg_pos[0] = -1;
	s_impe_input.PltInput.alg_pos[1] = -1;
	s_impe_input.RbcInput.MeasureTime = 10.0;
	s_impe_input.PltInput.MeasureTime = 10.0;
	s_impe_input.RbcInput.WorkMode = WORKMODE_BLOOD;
	s_impe_input.RbcInput.BloodMode = BLOODMODE_WHOLEBLOOD;
	s_impe_input.RbcInput.AnalyMode = ANALYSISMODE_CBC_DIFF;
	s_impe_input.RbcInput.SampleMode = SAMPLEMODE_OPEN;

	switch (inf_in->sample.blood_mode)
	{
	case BloodModeWL:
		s_impe_input.RbcInput.Dilution = 16498.5;
		s_impe_input.PltInput.Dilution = 16498.5;

		break;
	case BloodModePD:
		s_impe_input.RbcInput.Dilution = 16439.6;
		s_impe_input.PltInput.Dilution = 16439.6;

		break;
	default:
		break;
	}
	s_impe_input.RbcInput.Volume = 197.3;
	s_impe_input.PltInput.Volume = 197.3;
	if (inf_in->header.inf_ver > 3)
	{
		s_impe_input.RbcInput.RbcConfigPara.rbc_factory_cal_factor =
			inf_in->config.cb_rbc.factory_cal_factor;
		s_impe_input.RbcInput.RbcConfigPara.rbc_user_cal_factor =
			inf_in->config.cb_rbc.user_cal_factor;

		s_impe_input.RbcInput.RbcConfigPara.mcv_factory_cal_factor =
			inf_in->config.cb_mcv.factory_cal_factor;
		s_impe_input.RbcInput.RbcConfigPara.mcv_user_cal_factor =
			inf_in->config.cb_mcv.user_cal_factor;

		s_impe_input.PltInput.PltConfigPara.plt_factory_cal_factor =
			inf_in->config.cb_plt.factory_cal_factor;
		s_impe_input.PltInput.PltConfigPara.plt_user_cal_factor =
			inf_in->config.cb_plt.user_cal_factor;
	}
	else
	{
		s_impe_input.RbcInput.RbcConfigPara.rbc_factory_cal_factor = (float)1.0;
		s_impe_input.RbcInput.RbcConfigPara.rbc_user_cal_factor = (float)1.0;

		s_impe_input.RbcInput.RbcConfigPara.mcv_factory_cal_factor = (float)1.0;
		s_impe_input.RbcInput.RbcConfigPara.mcv_user_cal_factor = (float)1.0;

		s_impe_input.PltInput.PltConfigPara.plt_factory_cal_factor = (float)1.0;
		s_impe_input.PltInput.PltConfigPara.plt_user_cal_factor = (float)1.0;
	}
	


	impdmain_offline(&s_impe_input, &s_impe_output);
		
	printf("rbc_plt_channel_alg_finished!\n");

	// hgb channel
	memset(&s_hgb_input, 0, sizeof(S_HGB_INPUT));
	switch (inf_in->sample.analysis_mode)
	{
	case AnalysisModeCBC:
		s_hgb_input.bk_pos = 10;
		s_hgb_input.me_pos = 3520;
		break;
	case AnalysisModeCBC_CRP:
	case AnalysisModeCRP:
		s_hgb_input.bk_pos = 10;
		s_hgb_input.me_pos = 4330;
		break;
	default:
		break;
	}
	if (inf_in->header.inf_ver > 4)
	{
		s_hgb_input.hgb_bk = (float)inf_in->result.other_result.hgb_bk_volt;
		s_hgb_input.hgb_me = (float)inf_in->result.other_result.hgb_me_volt;
	}
	else
	{
		s_hgb_input.hgb_bk = (float)inf_in->new_monitor.hgb.data[s_hgb_input.bk_pos];
		s_hgb_input.hgb_me = (float)inf_in->new_monitor.hgb.data[s_hgb_input.me_pos];
	}
	
	
	switch (inf_in->sample.blood_mode)
	{
	case BloodModeWL:
		s_hgb_input.Dilution = 305.1;
		break;
	case BloodModePD:
		s_hgb_input.Dilution = 501.9;
		break;
	default:
		break;
	}
	if (inf_in->header.inf_ver > 3)
	{
		s_hgb_input.factory_cal_factor = inf_in->config.cb_hgb.factory_cal_factor;
		s_hgb_input.user_cal_factor = inf_in->config.cb_hgb.user_cal_factor;
	}
	else
	{
		s_hgb_input.factory_cal_factor = (float)1.0;
		s_hgb_input.user_cal_factor = (float)1.0;
	}
	

	s_hgb_input.Volume = 402.8;
	hgb = bk_hgb_main_offline(&s_hgb_input, inf_in->new_monitor.hgb.data);
	printf("HGB_dilution: %4.2f\n", s_hgb_input.Dilution);

	printf("hgb_channel_alg_finished!\n");

	// CRPģ��
	switch (inf_in->sample.analysis_mode)
	{
	case AnalysisModeCBC:
		crp_val = 0.0;
		break;
	case AnalysisModeCBC_CRP:
		crp_val = crp_cal(&inf_in->crp,inf_in->sample.blood_mode);
		crp_val /= (1 - s_impe_output.RbcOutput.RbcReportPara.hct / 100);
		inf_in->crp.crp_val = crp_val;
		break;
	case AnalysisModeCRP:
		crp_val = crp_cal(&inf_in->crp, inf_in->sample.blood_mode);
		crp_val /= (1 - 48.0 / 100);
		inf_in->crp.crp_val = crp_val;
		break;
	default:
		crp_val = 0.0;
		break;
	}
	printf("crp_value: %f\n",crp_val);
	if (crp_val < 0.0)
		crp_val = 0.0;
	// summary
	get_summary_result(&bk_result, &s_impe_output, &s_wbc_output, hgb, crp_val,
		inf_in->sample.analysis_mode);
	memset(re_out, 0, sizeof(INF_RESULT));
	get_inf_result(re_out, &s_hgb_input, &s_wbc_output, &s_impe_output,
		&bk_result);
	memset(&s_sample_info, 0, sizeof(sample_info_t));
	s_sample_info.am = inf_in->sample.analysis_mode;
	exception_code = identify_abnormal_monitor_para(&inf_in->new_monitor, inf_in->sample.analysis_mode);
	// �������ı����ж�
	/*memset(&new_monitor, 0, sizeof(INF_NEW_MONITOR));
	get_inf_new_monitor(&new_monitor, buff, data_handle);
	outInfo->errorFlag = identify_abnormal_monitor_para(&new_monitor, s_sample_info);
	printf("errorFlag:");
	print_bin(outInfo->errorFlag);*/


	//
	
	/*if (error_code = generate_inf_file_4(&new_monitor, &inf_config, &crp,
		&s_wbc_output, &s_impe_output, bk_result, s_sample_info))
		return error_code;*/
	/*if (error_code = generate_inf_file(buff, data_handle, &s_wbc_output,
	&s_impe_output, bk_result))
	return error_code;*/
	//
	//FREE_POINTER(buff);
	free_memory_for_rbc_plt_chan(&s_impe_output);
	FREE_POINTER(s_wbc_output.s_cell_info.s_cell_list.cell_info);
	FREE_POINTER(s_wbc_output.s_cell_info.s_cell_list.cell_nps);
	return exception_code;
}

mxArray *combine_result2mxArray(mxArray *old_re, mxArray *new_re)
{
	mxArray *pout;
	const char *field_name[] = { "old","new" };
	int field_num = 2;


	pout = mxCreateStructMatrix(1, 1, field_num, field_name);

	mxSetFieldByNumber(pout, 0, 0, old_re);
	mxSetFieldByNumber(pout, 0, 1, new_re);
	return pout;
}

// �迹ͨ������ת����������ȡFPGA���������DataLenΪpulse������
int read_fpga_data(stImpdCellList *pCellList, byte *DataAddr, int DataLen)
{
	stImpdPulse *pPulseInfo;
	int i, j;
	unsigned short HeadCheck, EndCheck;

	if (!pCellList || !DataAddr)
	{
		return 121;
	}

	// �ڴ�����
	pPulseInfo = (stImpdPulse *)malloc(sizeof(stImpdPulse)*DataLen);
	if (!pPulseInfo)
		return 122;

	memset(pPulseInfo, 0, sizeof(stImpdPulse)*DataLen);
	j = 0;
	// ��ȡ��Ϣ
	for (i = 0; i < DataLen; i++)
	{
		// FAFB
		HeadCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ��־λ
		DataAddr += 1;

		// ��ֵ
		pPulseInfo[j].PeakValue = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ǰ���
		pPulseInfo[j].PriWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].SubWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ȫ���
		pPulseInfo[j].FullWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].BaseLine = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ʱ���
		pPulseInfo[j].TimeStamp = *((byte *)DataAddr);
		DataAddr += 1;

		// M����־
		pPulseInfo[j].MPulseFlag = (*((byte *)DataAddr) & 0x01);
		DataAddr += 1;

		// ����λ
		DataAddr += 1;

		// У��λ
		DataAddr += 1;

		// FCFD
		EndCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ͷβУ��
		if (HeadCheck == 0xFAFB && EndCheck == 0xFCFD && pPulseInfo[j].PeakValue > 0)
			j++;

	}

	// ��ֵ����
	pCellList->cell_info = pPulseInfo;
	pCellList->CellNum = j;
	return 0;
}

int convert_int2inf(INF_FILE *inf, INT_FILE *intf)
{
	int error_code = 0;
	inf->header.inf_ver = 10;
	//
	strcpy(inf->system_ver.version_int, intf->Record1.Version[VERSION_INF]);
	strcpy(inf->system_ver.version_system, intf->Record1.Version[VERSION_SOFTWARE]);
	strcpy(inf->system_ver.version_timeseq, intf->Record1.Version[VERSION_TIMESEQ]);
	strcpy(inf->system_ver.version_main_fpga, intf->Record1.Version[VERSION_MFPGA]);
	strcpy(inf->system_ver.version_drive_fpga, intf->Record1.Version[VERSION_DFPGA]);
	strcpy(inf->system_ver.version_mcu, intf->Record1.Version[VERSION_MCU]);
	strcpy(inf->system_ver.version_alg, intf->Record1.Version[VERSION_ALG]);
	//
	switch (intf->Record2.AnalysisMode)
	{
	case '1':
		inf->sample.analysis_mode = AnalysisModeCBC;
		break;
	case '4':
		inf->sample.analysis_mode = AnalysisModeCRP;
		break;
	case '5':
		inf->sample.analysis_mode = AnalysisModeCBC_CRP;
		break;
	default:
		break;
	}
	switch (intf->Record2.BloodMode)
	{
	case '1':
		inf->sample.blood_mode = BloodModeWL;
		break;
	case '2':
		inf->sample.blood_mode = BloodModePD;
		break;
	default:
		break;
	}
	//
	inf->config.cb_wbc.factory_cal_factor = (float)intf->Record21.wbc_coef.factory_cali_coef;
	inf->config.cb_wbc.user_cal_factor = (float)intf->Record21.wbc_coef.user_cali_coef;

	inf->config.cb_rbc.factory_cal_factor = (float)intf->Record21.rbc_coef.factory_cali_coef;
	inf->config.cb_rbc.user_cal_factor = (float)intf->Record21.rbc_coef.user_cali_coef;

	inf->config.cb_hgb.factory_cal_factor = (float)intf->Record21.hgb_coef.factory_cali_coef;
	inf->config.cb_hgb.user_cal_factor = (float)intf->Record21.hgb_coef.user_cali_coef;

	inf->config.cb_mcv.factory_cal_factor = (float)intf->Record21.mcv_coef.factory_cali_coef;
	inf->config.cb_mcv.user_cal_factor = (float)intf->Record21.mcv_coef.user_cali_coef;

	inf->config.cb_plt.factory_cal_factor = (float)intf->Record21.plt_coef.factory_cali_coef;
	inf->config.cb_plt.user_cal_factor = (float)intf->Record21.plt_coef.user_cali_coef;
	//
	inf->new_monitor.vacuum_pressure.data_num = 
		intf->Record24.pressuredata_vacuo.bufflen / sizeof(short);
	memcpy(inf->new_monitor.vacuum_pressure.data,
		intf->Record24.pressuredata_vacuo.buffaddr,
		intf->Record24.pressuredata_vacuo.bufflen);
	//
	stImpdCellList wbc_celllist;
	error_code = read_fpga_data(&wbc_celllist,	intf->Record40.wbccelldata.buffaddr, 
		intf->Record40.wbccelldata.bufflen / FPGA_PACK_SIZE);
	inf->cell_list.wbc_cell_num = wbc_celllist.CellNum;
	inf->cell_list.wbc_cell_info = wbc_celllist.cell_info;
	
	stImpdCellList rbc_celllist;
	error_code = read_fpga_data(&rbc_celllist, intf->Record40.rbccelldata.buffaddr,
		intf->Record40.rbccelldata.bufflen / FPGA_PACK_SIZE);
	inf->cell_list.rbc_cell_num = rbc_celllist.CellNum;
	inf->cell_list.rbc_cell_info = rbc_celllist.cell_info;

	stImpdCellList plt_celllist;
	error_code = read_fpga_data(&plt_celllist, intf->Record40.pltcelldata.buffaddr,
		intf->Record40.pltcelldata.bufflen / FPGA_PACK_SIZE);
	inf->cell_list.plt_cell_num = plt_celllist.CellNum;
	inf->cell_list.plt_cell_info = plt_celllist.cell_info;

	/*inf->cell_list.rbc_cell_num = intf->Record40.rbccelldata.bufflen / FPGA_PACK_SIZE;
	inf->cell_list.rbc_cell_info = (stImpdPulse *)malloc(sizeof(stImpdPulse)*
		inf->cell_list.rbc_cell_num);
	error_code = read_fpga_data(inf->cell_list.rbc_cell_info,
		intf->Record40.rbccelldata.buffaddr, inf->cell_list.rbc_cell_num);

	inf->cell_list.plt_cell_num = intf->Record40.pltcelldata.bufflen / FPGA_PACK_SIZE;
	inf->cell_list.plt_cell_info = (stImpdPulse *)malloc(sizeof(stImpdPulse)*
		inf->cell_list.plt_cell_num);
	error_code = read_fpga_data(inf->cell_list.plt_cell_info,
		intf->Record40.pltcelldata.buffaddr, inf->cell_list.plt_cell_num);*/

	inf->new_monitor.hgb.data_num = intf->Record40.hgbvoltdata.bufflen / sizeof(short);
	memcpy(inf->new_monitor.hgb.data, intf->Record40.hgbvoltdata.buffaddr,
		intf->Record40.hgbvoltdata.bufflen);

	inf->crp.data_num = intf->Record40.crpvoltdata.bufflen / sizeof(short);
	memcpy(inf->crp.data, intf->Record40.crpvoltdata.buffaddr,
		intf->Record40.crpvoltdata.bufflen);
	//
	inf->new_monitor.wbc_aperture_vol.data_num = intf->Record41.wbcholevolt.bufflen / sizeof(short);
	memcpy(inf->new_monitor.wbc_aperture_vol.data,
		intf->Record41.wbcholevolt.buffaddr, 
		intf->Record41.wbcholevolt.bufflen);

	inf->new_monitor.wbc_vol_base.data_num = intf->Record41.wbcbasevolt.bufflen / sizeof(short);
	memcpy(inf->new_monitor.wbc_vol_base.data,
		intf->Record41.wbcbasevolt.buffaddr,
		intf->Record41.wbcbasevolt.bufflen);

	inf->new_monitor.rbc_aperture_vol.data_num = intf->Record41.rbcholevolt.bufflen / sizeof(short);
	memcpy(inf->new_monitor.rbc_aperture_vol.data,
		intf->Record41.rbcholevolt.buffaddr,
		intf->Record41.rbcholevolt.bufflen);

	inf->new_monitor.rbc_vol_base.data_num = intf->Record41.rbcbasevolt.bufflen / sizeof(short);
	memcpy(inf->new_monitor.rbc_vol_base.data,
		intf->Record41.rbcbasevolt.buffaddr,
		intf->Record41.rbcbasevolt.bufflen);
	return error_code;
}


//**********************************************************************
// ��������: mexFunction     
// ����˵����matlab���Ե��ú���     
// �� �� ֵ: void	     
// ��    ��: 
//           [out] int nlhs			�����������
//           [out] mxArray * plhs[]	�������matlab��������
//           [in] int nrhs			�����������
//           [in] mxArray * prhs[]	�������matlab��������
//**********************************************************************
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
	char *inf_file_path;
	char *inf_id;
	INF_FILE inf;
	INF_RESULT re;
	INT_FILE intf;
	int exception_code, error_code, crp_start_pos, crp_end_pos, crp_seglen;
	mxArray *old_re, *new_re;
		
	if (nlhs != 5) mexErrMsgTxt("5 outputs required");
	if (nrhs != 2) mexErrMsgTxt("2 inputs required");

	inf_file_path = mxArrayToString(prhs[0]);
	inf_id = mxArrayToString(mxGetField(prhs[1], 0, "sample_id"));
	crp_start_pos = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_start_pos"));
	crp_end_pos = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_end_pos"));
	crp_seglen = (int)mxGetScalar(mxGetField(prhs[1], 0, "crp_seglen"));
	memset(&inf, 0, sizeof(INF_FILE));
	memset(&re, 0, sizeof(INF_RESULT));
	error_code = read_new_inf_file(inf_file_path, &intf);
	exception_code = convert_int2inf(&inf,&intf);
	inf.crp.start_pos = crp_start_pos;
	inf.crp.end_pos = crp_end_pos;
	inf.crp.candidate_len = crp_seglen;
	//
	plhs[0] = header2mxArray(&inf.header, &inf.system_ver, error_code);
	//
	plhs[1] = sample2mxArray_inf4(&inf.sample, &inf.config);
	//
	plhs[3] = cell_info2mxArray(&inf.cell_list);
	//
	old_re = result2mxArray(&inf.result, &inf.crp);
	exception_code = BK_alg_main_offline(&inf, &re, inf_id);
	new_re = result2mxArray(&re, &inf.crp);
	plhs[2] = combine_result2mxArray(old_re, new_re);
	
	//
	plhs[4] = monitor2mxArray(&inf.new_monitor, &inf.crp, exception_code);
	
	//free_memory_for_s_inf_file(&inf);
	free_memory_for_int_file(&intf);
}