#ifndef INT_H  
#define INT_H

#include "alg.h"
#include "protocolalg.h"

#ifndef INF_STRING_LEN
#define INF_STRING_LEN 32
#endif

#ifndef INF_PARA_LEN
#define INF_PARA_LEN 10
#endif

typedef struct 
{
	int  RecordID;            // ID
	int  RecordCRC;           // CRC
	int  RecordLen;           // LEN
	char RecordRetain[6];     // Retain
}stRecordHeader;

typedef struct 
{
	int   FieldID;
	int   FieldNum;
	int   FieldType;
	char *FieldData;
}stFieldData;

enum VERSION
{
	VERSION_INF      = 0x00,               // inf�汾
	VERSION_PROJECT  = 0x01,               // ��Ŀ�汾
	VERSION_SOFTWARE = 0x02,               // �����汾
	VERSION_TIMESEQ  = 0x03,               // ʱ��汾
	VERSION_MFPGA    = 0x04,               // ����FPGA�汾
	VERSION_DFPGA    = 0x05,               // ����FPGA�汾
	VERSION_MCU      = 0x06,               // MCU�汾
	VERSION_ALG      = 0x07,               // �㷨�汾
	VERSION_MAXNUM   = 0x08
};

// Record1����
typedef struct 
{
	char Version[VERSION_MAXNUM][INF_STRING_LEN];
}stRecord1;

// Record2����
typedef struct 
{
	char SampleID[INF_STRING_LEN];         // ����ID
	char AnalysisMode;                     // ����ģʽ
	char BloodMode   ;                     // Ѫ��ģʽ
	char SampleMode  ;                     // ����ģʽ
	char WorkMode    ;                     // ����ģʽ
	char SpecieMode  ;                     // ����ģʽ
	char ScaleMode   ;                     // ��������
}stRecord2;

//// Record3����
//struct stRecord3
//{
//	//char patient_name[INF_STR_LEN];
//}; 
//
//// Record11����
//struct stRecord11
//{
//}; 
//
//// Record12����
//struct stRecord12
//{
//};

// Record20����
typedef struct 
{
	int diff_channel_error;                // Difͨ������
	int wbc_channel_error;                 // Wbcͨ������
	int hgb_channel_error;                 // Hgbͨ������
	int rbc_channel_error;                 // Rbcͨ������
	int crp_channel_error;                 // Crpͨ������
	int ret_channel_error;                 // Retͨ������
}stRecord20;

typedef struct 
{
	int    chaninfo_Measuremode ;          // ����ģʽ
	double chaninfo_volume      ;          // �������
	double chaninfo_dilution    ;          // ����ϡ�ͱ�
	double chaninfo_measuretime ;          // ����ʱ��
	double chaninfo_measurespeed;          // ��������
}stChanInfo;


typedef struct 
{
	double factory_cali_coef;
	double user_cali_coef;
	double intro_transfer_coef;
	double analysis_transfer_coef;
	double reserve;
}stParaCoef;

// Record21����
typedef struct 
{
	stParaCoef wbc_coef;     // У׼ϵ��
	stParaCoef rbc_coef;     // У׼ϵ��
	stParaCoef hgb_coef;     // У׼ϵ��
	stParaCoef mcv_coef;     // У׼ϵ��
	stParaCoef plt_coef;     // У׼ϵ��
	stParaCoef crp_coef;     // У׼ϵ��

	stChanInfo wbcchanInfo;                // Wbcͨ����Ϣ
	stChanInfo diffchanInfo;               // Difͨ����Ϣ
	stChanInfo rbcchanInfo;                // Rbcͨ����Ϣ
	stChanInfo pltchanInfo;                // Pltͨ����Ϣ
	stChanInfo hgbchanInfo;                // Hgbͨ����Ϣ

	double log4p_para[INF_PARA_LEN];
}stRecord21;

//// Record22����
//struct stRecord22
//{
//}; 
//
//// Record23����
//struct stRecord23
//{
//}; 

typedef struct 
{
	int            bufflen;
	unsigned char *buffaddr;
}stbuffdata;

// Record24����
typedef struct 
{
	double     temperature_ambt;
	double     temperature_diff;
	stbuffdata pressuredata_vacuo;
	stbuffdata pressuredata_fluid;
}stRecord24;

// Record40����
typedef struct 
{
	stbuffdata wbccelldata ;
	stbuffdata diffcelldata;
	stbuffdata basocelldata;
	stbuffdata rbccelldata ;
	stbuffdata pltcelldata ;
	stbuffdata hgbvoltdata ;
	stbuffdata crpvoltdata ;
	stbuffdata highs_crp_data;
}stRecord40;

typedef struct 
{
	stbuffdata  wbcholevolt;
	stbuffdata  rbcholevolt;
	stbuffdata  wbcbasevolt;
	stbuffdata  rbcbasevolt;
	stbuffdata  optibackvolt;
	stbuffdata  optibasevolt;
}stRecord41;

typedef struct 
{
	stRecord1  Record1;
	stRecord2  Record2;
	//stRecord3  Record3;
	//stRecord11 Record11;
	//stRecord12 Record12;
	stRecord20 Record20;
	stRecord21 Record21;
	//stRecord23 Record23;
	stRecord24 Record24;
	stRecord40 Record40;
	stRecord41 Record41;
}INT_FILE;
/*----------------------------------------------------------------------------*/
#ifdef __cplusplus      // avoid c++ name mangling
extern "C" {
#endif
int read_new_inf_file(const char *file_path, INT_FILE *int_file);

void free_memory_for_int_file(INT_FILE *intf);
#ifdef __cplusplus
}
#endif

#endif