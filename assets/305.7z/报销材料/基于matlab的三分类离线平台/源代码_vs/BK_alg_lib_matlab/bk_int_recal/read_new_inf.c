//#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "read_new_inf.h"
#include "datatype.h"

//using namespace std;

const int TypeLen[8] = {
	1,    // sizeof(bool)  
	1,    // sizeof(char)  
	2,    // sizeof(short),
	4,    // sizeof(int),
	4,    // sizeof(float),
	8,    // sizeof(double),
	16,   // FPGA Data
	0     // reserve
};

// CRC check function
static uint32 crc_check(byte *buff, int buff_len)
{
	unsigned int crc = 0;
	unsigned char i;
	unsigned char *ptr = buff;
	while (buff_len--) {
		for (i = 0x80; i != 0; i = i >> 1) {
			if ((crc & 0x8000) != 0) {
				crc = crc << 1;
				crc = crc ^ 0x1021;
			}
			else {
				crc = crc << 1;
			}
			if ((*ptr & i) != 0) {
				crc = crc ^ 0x1021;
			}
		}
		ptr++;
	}
	return crc;
}

static int read_field_data(byte *buff, stFieldData *field_data)
{
	memset(field_data, 0, sizeof(stFieldData));
	field_data->FieldID = *(int*)buff;
	buff += sizeof(int);
	field_data->FieldNum = *(int*)buff;
	buff += sizeof(int);
	field_data->FieldType = *buff;
	buff += sizeof(char);
	int field_size = TypeLen[field_data->FieldType - 1] * field_data->FieldNum;
	field_data->FieldData = (char *)malloc(field_size);
	memcpy(field_data->FieldData, buff, field_size);
	return field_size + sizeof(int) * 2 + sizeof(char);
}

static void read_record1(byte *buff, int record_len, stRecord1 *record1)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			memcpy(record1->Version[VERSION_INF], field_data.FieldData, field_size);
			break;
		case 2:
			memcpy(record1->Version[VERSION_PROJECT], field_data.FieldData, field_size);
			break;
		case 3:
			memcpy(record1->Version[VERSION_SOFTWARE], field_data.FieldData, field_size);
			break;
		case 4:
			memcpy(record1->Version[VERSION_TIMESEQ], field_data.FieldData, field_size);
			break;
		case 5:
			memcpy(record1->Version[VERSION_MFPGA], field_data.FieldData, field_size);
			break;
		case 6:
			memcpy(record1->Version[VERSION_DFPGA], field_data.FieldData, field_size);
			break;
		case 7:
			memcpy(record1->Version[VERSION_MCU], field_data.FieldData, field_size);
			break;
		case 8:
			memcpy(record1->Version[VERSION_ALG], field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record2(byte *buff, int record_len, stRecord2 *record2)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			memcpy(record2->SampleID, field_data.FieldData, field_size);
			break;
		case 2:
			memcpy(&record2->AnalysisMode, field_data.FieldData, field_size);
			break;
		case 3:
			memcpy(&record2->BloodMode, field_data.FieldData, field_size);
			break;
		case 4:
			memcpy(&record2->SampleMode, field_data.FieldData, field_size);
			break;
		case 5:
			memcpy(&record2->WorkMode, field_data.FieldData, field_size);
			break;
		case 6:
			memcpy(&record2->SpecieMode, field_data.FieldData, field_size);
			break;
		case 7:
			memcpy(&record2->ScaleMode, field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record20(byte *buff, int record_len, stRecord20 *record20)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			memcpy(&record20->diff_channel_error, field_data.FieldData, field_size);
			break;
		case 2:
			memcpy(&record20->wbc_channel_error, field_data.FieldData, field_size);
			break;
		case 3:
			memcpy(&record20->hgb_channel_error, field_data.FieldData, field_size);
			break;
		case 4:
			memcpy(&record20->rbc_channel_error, field_data.FieldData, field_size);
			break;
		case 5:
			memcpy(&record20->crp_channel_error, field_data.FieldData, field_size);
			break;
		case 6:
			memcpy(&record20->ret_channel_error, field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record21(byte *buff, int record_len, stRecord21 *record21)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			memcpy(&record21->wbc_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 2:
			memcpy(&record21->wbc_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 201:
			memcpy(&record21->rbc_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 202:
			memcpy(&record21->rbc_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 206:
			memcpy(&record21->hgb_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 207:
			memcpy(&record21->hgb_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 216:
			memcpy(&record21->mcv_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 217:
			memcpy(&record21->mcv_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 301:
			memcpy(&record21->plt_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 302:
			memcpy(&record21->plt_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 401:
			memcpy(&record21->crp_coef.factory_cali_coef, field_data.FieldData, field_size);
			break;
		case 402:
			memcpy(&record21->crp_coef.user_cali_coef, field_data.FieldData, field_size);
			break;
		case 2001:
			memcpy(&record21->wbcchanInfo.chaninfo_Measuremode, field_data.FieldData, field_size);
			break;
		case 2003:
			memcpy(&record21->rbcchanInfo.chaninfo_Measuremode, field_data.FieldData, field_size);
			break;
		case 2004:
			memcpy(&record21->pltchanInfo.chaninfo_Measuremode, field_data.FieldData, field_size);
			break;
		case 2005:
			memcpy(&record21->hgbchanInfo.chaninfo_Measuremode, field_data.FieldData, field_size);
			break;
		case 2102:
			memcpy(&record21->wbcchanInfo.chaninfo_dilution, field_data.FieldData, field_size);
			break;
		case 2106:
			memcpy(&record21->rbcchanInfo.chaninfo_dilution, field_data.FieldData, field_size);
			break;
		case 2108:
			memcpy(&record21->pltchanInfo.chaninfo_dilution, field_data.FieldData, field_size);
			break;
		case 2110:
			memcpy(&record21->hgbchanInfo.chaninfo_dilution, field_data.FieldData, field_size);
			break;
		case 3001:
			memcpy(&record21->log4p_para[0], field_data.FieldData, field_size);
			break;
		case 3002:
			memcpy(&record21->log4p_para[1], field_data.FieldData, field_size);
			break;
		case 3003:
			memcpy(&record21->log4p_para[2], field_data.FieldData, field_size);
			break;
		case 3004:
			memcpy(&record21->log4p_para[3], field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record24(byte *buff, int record_len, stRecord24 *record24)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			memcpy(&record24->temperature_ambt, field_data.FieldData, field_size);
			break;
		case 2:
			memcpy(&record24->temperature_diff, field_data.FieldData, field_size);
			break;
		case 3:
			record24->pressuredata_vacuo.buffaddr = (unsigned char *)malloc(field_size);
			record24->pressuredata_vacuo.bufflen = field_size;
			memcpy(record24->pressuredata_vacuo.buffaddr, field_data.FieldData, field_size);
			break;
		case 4:
			record24->pressuredata_fluid.buffaddr = (unsigned char *)malloc(field_size);
			record24->pressuredata_fluid.bufflen = field_size;
			memcpy(record24->pressuredata_fluid.buffaddr, field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record40(byte *buff, int record_len, stRecord40 *record40)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			record40->wbccelldata.buffaddr = (unsigned char *)malloc(field_size);
			record40->wbccelldata.bufflen = field_size;
			memcpy(record40->wbccelldata.buffaddr, field_data.FieldData, field_size);
			break;
		case 2:
			record40->diffcelldata.buffaddr = (unsigned char *)malloc(field_size);
			record40->diffcelldata.bufflen = field_size;
			memcpy(record40->diffcelldata.buffaddr, field_data.FieldData, field_size);
			break;
		case 4:
			record40->rbccelldata.buffaddr = (unsigned char *)malloc(field_size);
			record40->rbccelldata.bufflen = field_size;
			memcpy(record40->rbccelldata.buffaddr, field_data.FieldData, field_size);
			break;
		case 5:
			record40->pltcelldata.buffaddr = (unsigned char *)malloc(field_size);
			record40->pltcelldata.bufflen = field_size;
			memcpy(record40->pltcelldata.buffaddr, field_data.FieldData, field_size);
			break;
		case 6:
			record40->hgbvoltdata.buffaddr = (unsigned char *)malloc(field_size);
			record40->hgbvoltdata.bufflen = field_size;
			memcpy(record40->hgbvoltdata.buffaddr, field_data.FieldData, field_size);
			break;
		case 7:
			record40->crpvoltdata.buffaddr = (unsigned char *)malloc(field_size);
			record40->crpvoltdata.bufflen = field_size;
			memcpy(record40->crpvoltdata.buffaddr, field_data.FieldData, field_size);
			break;
		case 8:
			record40->highs_crp_data.buffaddr = (unsigned char *)malloc(field_size);
			record40->highs_crp_data.bufflen = field_size;
			memcpy(record40->highs_crp_data.buffaddr, field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static void read_record41(byte *buff, int record_len, stRecord41 *record41)
{
	int index = 0;
	stFieldData field_data;
	while (index < record_len)
	{
		index += read_field_data(buff + index, &field_data);
		int field_size = TypeLen[field_data.FieldType - 1] * field_data.FieldNum;
		switch (field_data.FieldID)
		{
		case 1:
			record41->wbcholevolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->wbcholevolt.bufflen = field_size;
			memcpy(record41->wbcholevolt.buffaddr, field_data.FieldData, field_size);
			break;
		case 2:
			record41->rbcholevolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->rbcholevolt.bufflen = field_size;
			memcpy(record41->rbcholevolt.buffaddr, field_data.FieldData, field_size);
			break;
		case 3:
			record41->wbcbasevolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->wbcbasevolt.bufflen = field_size;
			memcpy(record41->wbcbasevolt.buffaddr, field_data.FieldData, field_size);
			break;
		case 4:
			record41->rbcbasevolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->rbcbasevolt.bufflen = field_size;
			memcpy(record41->rbcbasevolt.buffaddr, field_data.FieldData, field_size);
			break;
		case 5:
			record41->optibackvolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->optibackvolt.bufflen = field_size;
			memcpy(record41->optibackvolt.buffaddr, field_data.FieldData, field_size);
			break;
		case 6:
			record41->optibasevolt.buffaddr = (unsigned char *)malloc(field_size);
			record41->optibasevolt.bufflen = field_size;
			memcpy(record41->optibasevolt.buffaddr, field_data.FieldData, field_size);
			break;
		default:
			break;
		}
		FREE_POINTER(field_data.FieldData);
	}

}

static int read_record_of_new_inf(FILE *fp, INT_FILE *int_file)
{
	byte *buff;
	uint32 crc;
	int record_len, record_id;
	int read_num;
	char reserve[6];


	read_num = (int)fread(&record_id, sizeof(int), 1, fp);
	if (!read_num)
		return 0;
	fread(&crc, sizeof(uint32), 1, fp);
	fread(&record_len, sizeof(int), 1, fp);
	fread(reserve, sizeof(char), 6, fp);
	buff = (byte *)calloc(record_len, sizeof(byte));
	fread(buff, sizeof(byte), record_len, fp);
	if (crc != crc_check(buff, record_len))
	{
		FREE_POINTER(buff);
		return -1;
	}
	switch (record_id)
	{
	case 1:
		read_record1(buff, record_len, &int_file->Record1);
		break;
	case 2:
		read_record2(buff, record_len, &int_file->Record2);
		break;
	case 20:
		read_record20(buff, record_len, &int_file->Record20);
		break;
	case 21:
		read_record21(buff, record_len, &int_file->Record21);
		break;
	case 24:
		read_record24(buff, record_len, &int_file->Record24);
		break;
	case 40:
		read_record40(buff, record_len, &int_file->Record40);
		break;
	case 41:
		read_record41(buff, record_len, &int_file->Record41);
		break;
	default:
		return -2;
		break;
	}
	FREE_POINTER(buff);
	return 0;
}

int read_new_inf_file(const char *file_path, INT_FILE *int_file)
{
	FILE *fp;
	int error_code;
	if (!(fp = fopen(file_path, "rb")))
		return 1; //�ļ��򿪴���
	memset(int_file, 0, sizeof(INT_FILE));
	while (!feof(fp))
	{
		if ((error_code = read_record_of_new_inf(fp, int_file)))
		{
			fclose(fp);
			return error_code;
		}

	}
	fclose(fp);
	return 0;
}

void free_memory_for_int_file(INT_FILE *intf)
{
	FREE_POINTER(intf->Record24.pressuredata_vacuo.buffaddr);
	FREE_POINTER(intf->Record40.wbccelldata.buffaddr);
	FREE_POINTER(intf->Record40.rbccelldata.buffaddr);
	FREE_POINTER(intf->Record40.pltcelldata.buffaddr);
	FREE_POINTER(intf->Record40.hgbvoltdata.buffaddr);
	FREE_POINTER(intf->Record40.crpvoltdata.buffaddr);
	FREE_POINTER(intf->Record40.highs_crp_data.buffaddr);
	FREE_POINTER(intf->Record41.wbcholevolt.buffaddr);
	FREE_POINTER(intf->Record41.rbcholevolt.buffaddr);
	FREE_POINTER(intf->Record41.wbcbasevolt.buffaddr);
	FREE_POINTER(intf->Record41.rbcbasevolt.buffaddr);
}