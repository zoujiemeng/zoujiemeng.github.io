#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "alg.h"
#include "protocolalg.h"


#ifdef _WIN32
#ifdef _DEBUG
//#include "vld.h"
#endif // _DEBUG
#endif // _WIN32

extern const NegPressCollectChannel *g_negCollectHandle;
extern const CRPCollectChannel *g_crpCollectHandle;
extern const CRPCollectChannel *g_highCrpCollectHandle;

extern int AlgAddNegPressData_test(NegPressCollectChannel *pstHandle);
extern int AlgAddCrpData_test(CRPCollectChannel *pstHandle, CRPCollectChannel *pstHighHandle);
extern int write_air_pressure_data_to_inf();
extern DataCollectHandle *alg_test_data();
extern int BK_alg_main(unsigned char *buff, DataCollectHandle *data_handle,
	const sample_info_t *pstSampleInfo, item_evt_count_temp_t *bk_result,
	alg_output_info *outInfo);
extern void AlgSetCrpCalInfo(const crp_cal_reaction_info *pstCalInfo, crp_cal_para *pstPara);
extern int bk_generate_new_inf_file(unsigned char *buff, DataCollectHandle *data_handle,
	sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result);

void main()
{
	DataCollectHandle *data_handle;
	item_evt_count_temp_t bk_result;
	sample_info_t s_sample_info;
	NegPressCollectChannel air_handle;
	crp_cal_reaction_info crp_reaction_info;
	alg_output_info out_info;
	CRPCollectChannel crp_handle, highs_crp_handle;


	data_handle = alg_test_data();
	memset(&bk_result, 0, sizeof(item_evt_count_temp_t));
	s_sample_info.bm = BloodModeWL;
	s_sample_info.am = AnalysisModeCBC;
	s_sample_info.wm = WorkModeCount;
	s_sample_info.hgbBlankMs = 100;
	s_sample_info.hgbParaMs = 35200;
	s_sample_info.gainCrp = 10;
	s_sample_info.gainWbc = 42;
	s_sample_info.gainRbc = 20;
	s_sample_info.gainHgb = 5;
	strcpy(s_sample_info.id, "spline_wb_2_2");
	strcpy(s_sample_info.versionAlg, "v0.1.1012");
	strcpy(s_sample_info.versionMainFpga, "v0.2.1012");
	strcpy(s_sample_info.versionSystem, "v0.3.1012");
	strcpy(s_sample_info.versionTimeseq, "v0.4.1012");
	strcpy(s_sample_info.versionDriveFpga, "v0.dfpga.1012");
	strcpy(s_sample_info.versionMCU, "v0.mcu.1012");
	AlgAddCrpData_test(&crp_handle, &highs_crp_handle);
	// ����CRP������Ϣ
	crp_reaction_info.lItemCount = 5;
	crp_reaction_info.bm = BloodModeWL;
	crp_reaction_info.astItems[0].crpValue = 20.0;
	crp_reaction_info.astItems[1].crpValue = 5.0;
	crp_reaction_info.astItems[2].crpValue = 0.0;
	crp_reaction_info.astItems[3].crpValue = 40.0;
	crp_reaction_info.astItems[4].crpValue = 80.0;
	crp_reaction_info.astItems[5].crpValue = 160.0;
	// 2#
	crp_reaction_info.astItems[0].crpReaction = 0.0;
	crp_reaction_info.astItems[1].crpReaction = 33.0;
	crp_reaction_info.astItems[2].crpReaction = 195.0;
	crp_reaction_info.astItems[3].crpReaction = 327.0;
	crp_reaction_info.astItems[4].crpReaction = 445.0;
	crp_reaction_info.astItems[5].crpReaction = 530.0;
	// 7#
	crp_reaction_info.astItems[0].crpReaction = 144.8;
	crp_reaction_info.astItems[1].crpReaction = 28.7;
	crp_reaction_info.astItems[2].crpReaction = 0;
	crp_reaction_info.astItems[3].crpReaction = 279.6;
	crp_reaction_info.astItems[4].crpReaction = 354.2;
	crp_reaction_info.astItems[5].crpReaction = (float)1080.0;
	//AlgSetCrpCalInfo(&crp_reaction_info,&crp_cal_para);


	BK_alg_main((unsigned char *)data_handle, data_handle, &s_sample_info, &bk_result, &out_info);
	AlgAddNegPressData_test(&air_handle);
	//write_air_pressure_data_to_inf();
	bk_generate_new_inf_file((unsigned char *)data_handle, data_handle, &s_sample_info, &bk_result);

	return;
}
