#ifndef ALG_LIB_COMMON_FUNC_H  
#define ALG_LIB_COMMON_FUNC_H

#include "datatype.h"
#include "impedance.h"
#include "alg.h"
#include "protocolalg.h"
#include "bk_wbc_main.h"
#include "bk_hgb_main.h"

#ifndef MAX_MONITOR_NUM
#define MAX_MONITOR_NUM 6000
#endif

typedef struct 
{
	byte inf_ver;
	uint32 rbc_plt_ver; 
	uint32 hgb_ver;
	uint32 wbc_impe_ver;
	uint32 wbc_diff_ver;
	uint32 wbc_baso_ver;
	uint32 reserve[5];
	uint32 serial_num;
}INF_HEADER; //record #1

typedef struct 
{
	byte analysis_mode;
	byte blood_mode;
	byte introduction_mode;
	byte work_mode;
	byte sample_mode;
	byte crp_mode;
}INF_SAMPLE; // record #2

typedef struct
{
	char version_system[MSG_ITEM_STR_LEN];       // ϵͳ����
	char version_timeseq[MSG_ITEM_STR_LEN];       	// ʱ��
	char version_main_fpga[MSG_ITEM_STR_LEN];       	// ���ذ�FPGA
	char version_alg[MSG_ITEM_STR_LEN];       	// �㷨
	char version_drive_fpga[MSG_ITEM_STR_LEN];  // ������FPGA
	char version_mcu[MSG_ITEM_STR_LEN];         // MCU
	char version_int[MSG_ITEM_STR_LEN];         // int
	char reserve[MSG_ITEM_STR_LEN][2];
}INF_SYSTEM_VER; // record #3

typedef struct
{
	int diff_scatter[64][64];
	int baso_scatter[64][64];
}INF_SCATTER; // record #10

typedef struct
{
	item_evt_count_temp_t tmp;
}INF_TEMP_RESULT; // record #12

typedef struct
{
	stHist  org_hist;                           // ԭʼֱ��ͼ
	stHist  dsp_hist;                           // ��ʾֱ��ͼ
}S_HIST_RESULT;

typedef struct
{
	float wbc;
	float lymphn;
	float midn;
	float grann;
	float lymphp;
	float midp;
	float granp;
	float rbc;
	float hgb;
	float hct;
	float mcv;
	float mch;
	float mchc;
	float rdw_cv;
	float rdw_sd;
	float plt;
	float mpv;
	float pdw;
	float pct;
	float plcc;
	float plcr;
	float crp;
}S_REPORT_RESULT;

typedef struct 
{
	short hgb_bk_pos;
	short hgb_me_pos;

	int wbc_org_num;
	int wbc_filter_num;
	int wbc_ghost_num;
	int rbc_org_num;
	int rbc_filter_num;
	int plt_org_num;
	int plt_filter_num;

	int wbc_hist_flag;  // WBCֱ��ͼ������־
	int rbc_hist_flag;  // RBCֱ��ͼ������־
	int plt_hist_flag;  // RBCֱ��ͼ������־

	int wbc_hint;    // WBC������ʾ
	int rbc_hint;    // RBC������ʾ 
	int plt_hint;      // PLT������ʾ

	float wbc_mcv;
	float lym_mcv;
	float hgb_bk_volt;
	float hgb_me_volt;

	float R1_tell;
	float R2_tell;
	float R3_tell;
	float R4_tell;
	int int_reserve;
	float float_reserve;

}S_OTHER_RESULT;

typedef struct
{
	S_REPORT_RESULT report_result;
	S_HIST_RESULT wbc_hist; //WBCֱ��ͼ
	S_HIST_RESULT rbc_hist; //RBCֱ��ͼ
	S_HIST_RESULT plt_hist; //PLTֱ��ͼ
	S_OTHER_RESULT  other_result;
}INF_RESULT; // record #11

typedef struct
{
	int          wbc_cell_num;
	stImpdPulse  *wbc_cell_info;
	int          rbc_cell_num;
	stImpdPulse  *rbc_cell_info;
	int          plt_cell_num;
	stImpdPulse  *plt_cell_info;
	
}INF_CELL_LIST;// record #21,22,23

typedef struct
{
	int data_num;
	short data[300];
	double reaction;
	double crp_val;
	double crp_ori_val;
	int spline_num;
	float x[MAX_CRP_CAL_REACTION_ITEM];
	float y[MAX_CRP_CAL_REACTION_ITEM];
	float ypp[MAX_CRP_CAL_REACTION_ITEM];
	int start_pos;
	int end_pos;
	int candidate_len;
	float hct;
	float reserve[21];
}INF_CRP; // record #25

typedef struct
{
	int data_num;
	short data[MAX_MONITOR_NUM];
}NEW_MONITOR_DATA;

typedef struct
{
	NEW_MONITOR_DATA hgb;
	NEW_MONITOR_DATA wbc_aperture_vol;
	NEW_MONITOR_DATA rbc_aperture_vol;
	NEW_MONITOR_DATA wbc_vol_base;
	NEW_MONITOR_DATA rbc_vol_base;
	NEW_MONITOR_DATA vacuum_pressure;
}INF_NEW_MONITOR; // record #27

typedef struct
{
	int data_num;
	short data[5000];
}MONITOR_DATA;

typedef struct
{
	MONITOR_DATA hgb;
	MONITOR_DATA wbc_aperture_vol;
	MONITOR_DATA rbc_aperture_vol;
	MONITOR_DATA wbc_vol_base;
	MONITOR_DATA rbc_vol_base;
	MONITOR_DATA vacuum_pressure;
	MONITOR_DATA crp;
}INF_MONITOR; // record #26


typedef struct
{
	float factory_cal_factor;
	float user_cal_factor;
}CALIBRATION;

typedef struct
{
	CALIBRATION cb_wbc;
	CALIBRATION cb_rbc;
	CALIBRATION cb_plt;
	CALIBRATION cb_hgb;
	CALIBRATION cb_mcv;

	int wbc_gain;
	int rbc_gain;
	int hgb_gain;
	int crp_gain;

	int wbc_graph_flag;  // WBCֱ��ͼ������־
	int rbc_graph_flag;  // RBCֱ��ͼ������־
	int plt_graph_flag;  // RBCֱ��ͼ������־

	int wbc_para_msg;    // WBC������ʾ
	int rbc_para_msg;    // RBC������ʾ 
	int plt_para_msg;    // PLT������ʾ

	int monitor_error_msg;
	float reserve[6];
}INF_CONFIG; // record #5

typedef struct
{
	INF_HEADER       header;
	INF_SAMPLE       sample;
	INF_SYSTEM_VER   system_ver;
	INF_CONFIG       config;
	INF_RESULT       result;
	INF_TEMP_RESULT  bk_result;
	INF_CELL_LIST    cell_list;
	INF_CRP          crp;
	INF_MONITOR      monitor;
	INF_NEW_MONITOR  new_monitor;
}INF_FILE;

//typedef struct
//{
//	short ls_peak;              
//	byte  ls_width;
//	short ms_peak;              
//	short hs_peak;              
//	byte  time_stamp;
//	byte  cell_type;
//}OPTI_CELL_INFO;
//
//typedef struct
//{
//	int cell_num;
//	OPTI_CELL_INFO *cell_info;
//}S_OPTI_CELL_PACK;
/*----------------------------------------------------------------------------*/
#ifdef __cplusplus      // avoid c++ name mangling
extern "C" {
#endif
	void ncspline(double x[], double y[], int nx, int ny, int n, double ypp[]);
	void clcspline(double x[], double y[], int nx, int ny, int n, double yp0, double yn_1, double ypp[]);
	void tridiag(double x[], int N, double a[], double b[], double c[]);
	void csplint(double x[], double y[], double ypp[], int n, double xi, double *yi);
	int Shell_sort(double A[], int ArraySize);

	int insertion_sort4double_array(double *main_array, int ArraySize, double *sub_array);

	int read_inf_file(const char *file_path, INF_FILE *inf);

	int test_new_inf_file(const char *file_path);

	void free_memory_for_s_inf_file(INF_FILE *inf);

	int generate_inf_file(byte *arm_buff, DataCollectHandle *handle,
		S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		item_evt_count_temp_t *bk_result);

	int generate_inf_file_2(byte *arm_buff, DataCollectHandle *handle,
		S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info,
		const CRPCollectChannel *crp_handle);

	int generate_inf_file_3(byte *arm_buff, DataCollectHandle *handle,
		S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info,
		const CRPCollectChannel *crp_handle);

	int generate_inf_file_4(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
		INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info);

	int generate_inf_file_5(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
		INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		INF_RESULT *result, const sample_info_t *s_sample_info);

	int generate_inf_file_6(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
		INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		INF_RESULT *result, const sample_info_t *s_sample_info);

	uint32 crc_check(byte *buff, int buff_len);

	int get_inf_result(INF_RESULT *result, S_HGB_INPUT *hgb_input,
		S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
		item_evt_count_temp_t *bk_result);

	int solve_ladder_problem(double *data_out, short *data_in, int num, int ladder_num);

	double crp_cal(INF_CRP *crp, int bloodmode);
	double new_crp_cal(INF_CRP *crp, crp_para_info *crp_para, int bloodmode);
	//double crp_cal_tmp(INF_CRP *crp, const char *sample_id);
	double get_crp_reaction(INF_CRP *crp);
	double get_mean_of_short_array(short *array, int data_num);

	int gethist(stHist *pHist, stImpdCellList CellList);

	int cubic_smooth(double *p_data_out, double *p_data_in, int data_num);

	void curvesmooth_gauss(int* dst, int* src, int datalen, int step, double delta);
	void curvesmooth_mean(double *dst, double *src, int datalen, int step);
	void curvesmooth_gauss_int2double(double* dst, int* src, int datalen, int step,
		double delta);

	int dataconvite_impd(stImpdCellList *pCellList, byte *DataAddr, int DataLen);

	int get_max_index_of_double_array_within_range(double *array, int left, int right,
		double *max_val);

	int get_max_index_of_int_array_within_range(int *array, int left, int right,
		int *max_val);

	int get_peak_index_of_int_array_within_range(int *array, int left, int right,
		int *max_val);

	int get_min_index_of_double_array_within_range(double *array, int left, int right,
		double *min_val);

	int get_trough_index_of_int_array_within_range(int *array, int left, int right,
		int *min_val);
#ifdef __cplusplus
}
#endif


#endif
