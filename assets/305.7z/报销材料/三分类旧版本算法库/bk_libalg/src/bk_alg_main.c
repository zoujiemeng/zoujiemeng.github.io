#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdbool.h>
#include "impedance.h"
#include "alg.h"
#include "protocolalg.h"
#include "bk_wbc_main.h"
#include "bk_hgb_main.h"
#include "common_func.h"
#include "new_inf_module.h"


#define ALG_VERSION "1.1.0417"
//#define BK_LINUX_TEST


item_cal_factor_t g_calFactor;
char inf_file_path[MAX_PATH];
const CRPCollectChannel *g_crpCollectHandle;
const CRPCollectChannel *g_highCrpCollectHandle;
const NegPressCollectChannel *g_negCollectHandle;

double g_fRatioWbWBC = 305.1f;
double g_fRatioWbPLT = 16498.5f;
double g_fRatioPreWBC = 502;
double g_fRatioPrePLT = 16449.4f;

static int get_inf_new_monitor(INF_NEW_MONITOR *new_monitor, byte *arm_buff, 
	DataCollectHandle *handle);
	
char *AlgGetVersion(void)
{
	char *pcVersion = ALG_VERSION;
	return pcVersion;
}	

// ����ϡ��ռ�ձ�
void AlgSetDilutionRatio(int lRatioWbWBC, int lRatioWbPLT, int lRatioPreWBC, int lRatioPrePLT)
{
	g_fRatioWbWBC = lRatioWbWBC / 10;
	g_fRatioWbPLT = lRatioWbPLT / 10;
	g_fRatioPreWBC = lRatioPreWBC / 10;
	g_fRatioPrePLT = lRatioPrePLT / 10;
	printf("AlgSetDilutionRatio. %d %d %d %d\n", lRatioWbWBC, lRatioWbPLT, lRatioPreWBC, lRatioPrePLT);
}


// д�븺ѹ������inf�ļ���
int write_air_pressure_data_to_inf()
{
	INF_NEW_MONITOR new_monitor;;
	int data_num, i, offset, record_len;
	unsigned short *short_data_addr;
	FILE *fp;
	byte *buff;
	uint32 crc;


	memset(&new_monitor, 0, sizeof(NEW_MONITOR_DATA));
	if (!(fp = fopen(inf_file_path, "rb+")))
		return 141; //�ļ��򿪴���
	offset = (int)sizeof(INF_NEW_MONITOR)*(-1);
	fseek(fp, offset, SEEK_END);
	fread(&new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	data_num = g_negCollectHandle->ulCount;
	if (data_num > 6000)
		new_monitor.vacuum_pressure.data_num = 6000;
	else
		new_monitor.vacuum_pressure.data_num = data_num;
	short_data_addr = g_negCollectHandle->punAddr;
	printf("VACUUM_PRESSURE_CHANNEL_COUNT: %d;\n", g_negCollectHandle->ulCount);
	for (i = 0; i < new_monitor.vacuum_pressure.data_num; i++)
		new_monitor.vacuum_pressure.data[i] = short_data_addr[i];

	buff = (byte *)&new_monitor;
	record_len = sizeof(INF_NEW_MONITOR);
	crc = crc_check(buff, record_len);
	if (!(fp = fopen(inf_file_path, "rb+")))
		return 141; //�ļ��򿪴���
	offset = (int)(sizeof(INF_NEW_MONITOR)+sizeof(uint32)+sizeof(int))*(-1);
	fseek(fp, offset, SEEK_END);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}


// �����㷨У׼ϵ��
void AlgSetCalFactor(const item_cal_factor_t *pstCalFactor)
{
	printf("SetAlgCalFactor alg\n");
	memcpy(&g_calFactor, pstCalFactor, sizeof(g_calFactor));
	return;
}


// ����CRP������Ϣ
void AlgSetCrpCalInfo(const crp_cal_reaction_info *pstCalInfo, crp_cal_para *pstPara)
{
	int i = 0;
	
	printf("AlgSetCrpCalInfo alg. lItemCount = %ld\n", pstCalInfo->lItemCount);
	
	for(i = 0; i < pstCalInfo->lItemCount; i++)
	{
		printf("crpValue = %f  crpReaction = %f\n", pstCalInfo->astItems[i].
			crpValue, pstCalInfo->astItems[i].crpReaction);
	}
	
	
	//// ������������ʼ��
	//double x1[MAX_CRP_CAL_REACTION_ITEM], y1[MAX_CRP_CAL_REACTION_ITEM];
	//double yp0 = 0.0, ypn_1 = 0.0;
	//double ypp[MAX_CRP_CAL_REACTION_ITEM];
	//FILE *fp = NULL;
	//char c = 'N';
	//int data_num;

	//memset(pstWave, 0, sizeof(pstWave));

	//// ��ȡ����
	//data_num = pstCalInfo->lItemCount;
	//for (i = 0; i < data_num; i++)
	//{
	//	x1[i] = pstCalInfo->astItems[i].crpReaction;
	//	y1[i] = pstCalInfo->astItems[i].crpValue;
	//}
	//insertion_sort4double_array(x1, data_num, y1);
	//switch (c)
	//{
	//case 'n':
	//case 'N':
	//	printf("\nNatural cubic spline case\n");
	//	ncspline(x1, y1, data_num, data_num, data_num, ypp);
	//	break; // case 'n'
	//case 'c':
	//case 'C':
	//	printf("\nClamped cubic spline case\n");
	//	clcspline(x1, y1, data_num, data_num, data_num, yp0, ypn_1, ypp);
	//	break; // case 'c'
	//default:
	//	printf("\nNatural cubic spline case\n");
	//	ncspline(x1, y1, data_num, data_num, data_num, ypp);
	//	break;
	//}

	//// �������������ݴ洢���ļ�
	//if (pstCalInfo->lSaveFile)
	//{
	//	switch (pstCalInfo->bm)
	//	{
	//	case BloodModeWL:
	//		if (!(fp = fopen("natural_spline_data_wb.crp", "wb")))
	//		{
	//			printf("\ncrp spline file save failed!\n");
	//			pstWave->lPointNum = 0;
	//			return; //�ļ��򿪴���
	//		}
	//		break;
	//	case BloodModePD:
	//		if (!(fp = fopen("natural_spline_data_pd.crp", "wb")))
	//		{
	//			printf("\ncrp spline file save failed!\n");
	//			pstWave->lPointNum = 0;
	//			return; //�ļ��򿪴���
	//		}
	//		break;
	//	}
	//	
	//	fwrite(&data_num, sizeof(int), 1, fp);
	//	fflush(fp);
	//	fwrite(x1, sizeof(double), data_num, fp);
	//	fflush(fp);
	//	fwrite(y1, sizeof(double), data_num, fp);
	//	fflush(fp);
	//	fwrite(ypp, sizeof(double), data_num, fp);
	//	fflush(fp);
	//	fclose(fp);
	//	printf("\ncrp spline file saved success!\n");
	//}
	//// �����������������������ṹ��
	//double tmp_x, tmp_fx;
	//double A = x1[data_num - 1] - x1[0];
	//i = 0;
	//int m = MAX_CRP_WAVE_POINT;

	//while (i < m)
	//{
	//	double f = i / ((double)m);
	//	/* xi is a s-curve */
	//	tmp_x = (3.0 - 2.0 * f) * f * f * A + x1[0];
	//	csplint(x1, y1, ypp, data_num, tmp_x, &tmp_fx);
	//	pstWave->afPointX[i] = (float)tmp_x;
	//	pstWave->afPointY[i] = (float)tmp_fx;
	//	i++;
	//}
	//pstWave->lPointNum = i;
	//return;
}


// ����CRPУ����Ϣ
void AlgSetCrpReCalInfo(const crp_recal_reaction_info *pstCalInfo, crp_cal_para *pstPara)
{

}


crp_para_info g_stCrpParaInfo;
// ����CRPУ׼����
void AlgSetCrpParaInfo(const crp_para_info *pstPara)
{
    memcpy(&g_stCrpParaInfo, pstPara, sizeof(crp_para_info));
}

void AlgSetCrpParaInfo_test(crp_para_info *pstPara)
{
	pstPara->calMethod = CRP_METHOD_LOG4P;
	pstPara->stWbPara.lParaNum = 4;
	//
	pstPara->stWbPara.afPara[0] = 31607.74;
	pstPara->stWbPara.afPara[1] = 82.43;
	pstPara->stWbPara.afPara[2] = 1.14;
	pstPara->stWbPara.afPara[3] = 19977619.1;
	memcpy(&g_stCrpParaInfo, pstPara, sizeof(crp_para_info));
}



void AlgSetCalFactor_test(item_cal_factor_t *pstCalFactor)
{
	memset(pstCalFactor, 0, sizeof(item_cal_factor_t));
	pstCalFactor->wbFactoryCalFactor.fWbc = (float)101;
	pstCalFactor->wbCalFactor.fWbc = (float)99;
	pstCalFactor->wbFactoryCalFactor.fRbc = (float)102;
	pstCalFactor->wbCalFactor.fRbc = (float)98;
	pstCalFactor->wbFactoryCalFactor.fMcv = (float)103;
	pstCalFactor->wbCalFactor.fMcv = (float)97;
	pstCalFactor->wbFactoryCalFactor.fPlt = (float)104;
	pstCalFactor->wbCalFactor.fPlt = (float)94;
	pstCalFactor->wbFactoryCalFactor.fHgb = (float)105;
	pstCalFactor->wbCalFactor.fHgb = (float)95;
	printf("SetAlgCalFactor test alg\n");
	memcpy(&g_calFactor, pstCalFactor, sizeof(g_calFactor));
	return;
}
	
// �ⲿ���ݸ��㷨ģ��CRP����
int AlgAddCrpData(const CRPCollectChannel *pstLowHandle, const CRPCollectChannel *pstHighHandle)
{
	printf("AlgAddCrpData alg. ulCount = %ld.  punAddr = %ld, ulCount = %ld.  punAddr = %ld\n",
		pstLowHandle->ulCount, (int)(pstLowHandle->punAddr), pstHighHandle->ulCount, (int)(pstHighHandle->punAddr));
	g_crpCollectHandle = pstLowHandle;
	g_highCrpCollectHandle = pstHighHandle;
	return 0;
}

int AlgAddCrpData_test(CRPCollectChannel *pstLowHandle, CRPCollectChannel *pstHighHandle)
{
	int i,count = 300;
	memset(pstLowHandle, 0, sizeof(CRPCollectChannel));
	memset(pstHighHandle, 0, sizeof(CRPCollectChannel));
	pstLowHandle->punAddr = (unsigned short *)calloc(count,sizeof(unsigned short));
	pstHighHandle->punAddr = (unsigned short *)calloc(count, sizeof(unsigned short));
	for (i = 0; i < count; i++)
	{
		pstLowHandle->punAddr[i] = (unsigned short)(3*i + 1);
		pstHighHandle->punAddr[i] = (unsigned short)((3 * i + 1)*40);
	}
		
	pstLowHandle->ulCount = count;
	pstHighHandle->ulCount = count;
	g_crpCollectHandle = pstLowHandle;
	g_highCrpCollectHandle = pstHighHandle;
	printf("AlgAddCrpData test alg\n");
	printf("AlgAddCrpData alg. ulCount = %ld.  punAddr = %ld, ulCount = %ld.  punAddr = %ld\n",
		pstLowHandle->ulCount, (int)(pstLowHandle->punAddr), pstHighHandle->ulCount, (int)(pstHighHandle->punAddr));
	return 0;
}

// �ⲿ���ݸ��㷨ģ�鸺ѹ����
int AlgAddNegPressData(const NegPressCollectChannel *pstHandle)
{
	printf("AlgAddNegPressData alg\n");
	g_negCollectHandle = pstHandle;
	return 0;
}

int AlgAddNegPressData_test(NegPressCollectChannel *pstHandle)
{
	
	int i, count = 5000;
	memset(pstHandle, 0, sizeof(NegPressCollectChannel));
	pstHandle->punAddr = (unsigned short *)calloc(count, sizeof(unsigned short));
	for (i = 0; i < count; i++)
		pstHandle->punAddr[i] = (unsigned short)(i + 1);
	pstHandle->ulCount = count;
	g_negCollectHandle = pstHandle;
	printf("AlgAddNegPressData test alg\n");
	return 0;
}

// �����ض�
bool wbc_para_truncation(item_evt_count_temp_t *bk_result)
{
	// per�ض�
	int LymPer = (int)(bk_result->lymphp.val * 10 + 0.5);
	int MidPer = (int)(bk_result->midp.val * 10 + 0.5);
	int GranPer = (int)(bk_result->granp.val * 10 + 0.5);

	if (1000 - LymPer - MidPer > 0)
	{
		GranPer = 1000 - LymPer - MidPer;
	}
	else if (1000 - MidPer - GranPer > 0)
	{
		LymPer = 1000 - MidPer - GranPer;
	}
	else if (1000 - LymPer - GranPer > 0)
	{
		MidPer = 1000 - GranPer - LymPer;
	}

	bk_result->lymphp.val = 0.1*LymPer;
	bk_result->midp.val = 0.1*MidPer;
	bk_result->granp.val = 0.1*GranPer;

	// num�ض�
	int Wbc = (int)(bk_result->wbc.val * 100 + 0.5);

	int LymCount = (int)(1.0*LymPer*Wbc / 1000 + 0.5);
	int MidCount = (int)(1.0*MidPer*Wbc / 1000 + 0.5);
	int GranCount = (int)(1.0*GranPer*Wbc / 1000 + 0.5);

	if (Wbc - LymCount - MidCount > 0)
	{
		GranCount = Wbc - LymCount - MidCount;
	}
	else if (Wbc - GranCount - MidCount > 0)
	{
		LymCount = Wbc - GranCount - MidCount;
	}
	else if (Wbc - GranCount - LymCount > 0)
	{
		MidCount = Wbc - GranCount - LymCount;
	}

	bk_result->wbc.val = 0.01*Wbc;
	bk_result->grann.val = 0.01*GranCount;
	bk_result->lymphn.val = 0.01*LymCount;
	bk_result->grann.val = 0.01*MidCount;

	return true;
}

int identify_low_hole_voltage(short *data, int data_num)
{
	int i , low_num = 0;
	for (i = 0; i < data_num; i++)
	{
		if (data[i] < 1)
			low_num++;
	}
	if (low_num > 5)
		return 1;
	return 0;
}

int identify_abnormal_base(short *data, int data_num)
{
	int i, low_num = 0;
	for (i = 0; i < data_num; i++)
	{
		if (data[i] == 4095)
			low_num++;
	}
	if (low_num > 10)
		return 1;
	return 0;
}

int identify_abnormal_monitor_para(INF_NEW_MONITOR *new_monitor,
	int analysis_mode)
{
	int wbc_start_pos, wbc_end_pos, rbc_start_pos, rbc_end_pos, data_num;
	int flag_code = 0;
	short data[MAX_MONITOR_NUM];
	switch (analysis_mode)
	{
	case AnalysisModeCBC:
		wbc_start_pos = 1610 - 291;
		wbc_end_pos = 2610;
		data_num = wbc_end_pos - wbc_start_pos;
		memcpy(data, new_monitor->wbc_aperture_vol.data + wbc_start_pos,
			sizeof(short)*data_num);
		/*if (identify_hole_block(data, data_num))
			flag_code |= ErrorFlagWbcBlock;*/
		/*if (identify_low_hole_voltage(data, data_num))
			flag_code |= ErrorFlagWbcHoleVLow;

		memcpy(data, new_monitor->wbc_vol_base.data + wbc_start_pos, 
			sizeof(short)*data_num);
		if (identify_abnormal_base(data, data_num))
			flag_code |= ErrorFlagWbcBaseLineAbnormal;*/

		rbc_start_pos = 1610 - 291;
		rbc_end_pos = 2610;
		data_num = rbc_end_pos - rbc_start_pos;
		memcpy(data, new_monitor->rbc_aperture_vol.data + rbc_start_pos, 
			sizeof(short)*data_num);
		/*if (identify_hole_block(data, data_num))
			flag_code |= ErrorFlagRbcBlock;*/
		/*if (identify_low_hole_voltage(data, data_num))
			flag_code |= ErrorFlagRbcHoleVLow;

		memcpy(data, new_monitor->rbc_vol_base.data + rbc_start_pos, 
			sizeof(short)*data_num);
		if (identify_abnormal_base(data, data_num))
			flag_code |= ErrorFlagRbcBaseLineAbnormal;*/

		break;
	case AnalysisModeCBC_CRP:
		wbc_start_pos = 1600 - 291;
		wbc_end_pos = 2600;
		data_num = wbc_end_pos - wbc_start_pos;
		memcpy(data, new_monitor->wbc_aperture_vol.data + wbc_start_pos, 
			sizeof(short)*data_num);
		/*if (identify_hole_block(data, data_num))
			flag_code |= ErrorFlagWbcBlock;*/
		/*if (identify_low_hole_voltage(data, data_num))
			flag_code |= ErrorFlagWbcHoleVLow;

		memcpy(data, new_monitor->wbc_vol_base.data + wbc_start_pos, 
			sizeof(short)*data_num);
		if (identify_abnormal_base(data, data_num))
			flag_code |= ErrorFlagWbcBaseLineAbnormal;*/

		rbc_start_pos = 1600 - 291;
		rbc_end_pos = 2600;
		data_num = rbc_end_pos - rbc_start_pos;
		memcpy(data, new_monitor->rbc_aperture_vol.data + rbc_start_pos, 
			sizeof(short)*data_num);
		/*if (identify_hole_block(data, data_num))
			flag_code |= ErrorFlagRbcBlock;*/
		/*if (identify_low_hole_voltage(data, data_num))
			flag_code |= ErrorFlagRbcHoleVLow;

		memcpy(data, new_monitor->rbc_vol_base.data + rbc_start_pos, 
			sizeof(short)*data_num);
		if (identify_abnormal_base(data, data_num))
			flag_code |= ErrorFlagRbcBaseLineAbnormal;*/
		break;
	default:
		break;
	}
	return flag_code;
}

int get_inf_config(INF_CONFIG *inf_config, stImpdInput * s_impe_input, 
	S_BK_WBC_INPUT * s_wbc_input, S_HGB_INPUT * s_hgb_input, 
	const sample_info_t * s_sample_info, item_evt_count_temp_t *bk_result,
	alg_output_info *outInfo)
{

	inf_config->wbc_gain = s_sample_info->gainWbc;
	inf_config->rbc_gain = s_sample_info->gainRbc;
	inf_config->hgb_gain = s_sample_info->gainHgb;
	inf_config->crp_gain = s_sample_info->gainCrp;

	inf_config->cb_wbc.factory_cal_factor = s_wbc_input->wbc_input.factory_cal_factor;
	inf_config->cb_wbc.user_cal_factor = s_wbc_input->wbc_input.user_cal_factor;

	inf_config->cb_rbc.factory_cal_factor = s_impe_input->RbcInput.
		RbcConfigPara.rbc_factory_cal_factor;
	inf_config->cb_rbc.user_cal_factor = s_impe_input->RbcInput.
		RbcConfigPara.rbc_user_cal_factor;

	inf_config->cb_mcv.factory_cal_factor = s_impe_input->RbcInput.
		RbcConfigPara.mcv_factory_cal_factor;
	inf_config->cb_mcv.user_cal_factor = s_impe_input->RbcInput.
		RbcConfigPara.mcv_user_cal_factor;

	inf_config->cb_plt.factory_cal_factor = s_impe_input->PltInput.
		PltConfigPara.plt_factory_cal_factor;
	inf_config->cb_plt.user_cal_factor = s_impe_input->PltInput.
		PltConfigPara.plt_user_cal_factor;

	inf_config->cb_hgb.factory_cal_factor = s_hgb_input->factory_cal_factor;
	inf_config->cb_hgb.user_cal_factor = s_hgb_input->user_cal_factor;

	inf_config->wbc_graph_flag = bk_result->otherresult.wbcGraphflag;
	inf_config->rbc_graph_flag = bk_result->otherresult.rbcGraphflag;
	inf_config->plt_graph_flag = bk_result->otherresult.pltGraphflag;

	inf_config->wbc_para_msg = bk_result->otherresult.wbcHint;
	inf_config->rbc_para_msg = bk_result->otherresult.rbcHint;
	inf_config->plt_para_msg = bk_result->otherresult.pltHint;

	inf_config->monitor_error_msg = outInfo->errorFlag;
	return 0;
}

int get_inf_crp(INF_CRP *crp, const CRPCollectChannel *crp_handle,
	int analysis_mode)
{
	int i, data_num;
	unsigned short *short_data_addr;
	int start_pos = 100;
	int end_pos = 230;
	int offset = 0;

	data_num = crp_handle->ulCount;
	if (data_num > 300)
		crp->data_num = 300;
	else
		crp->data_num = data_num;
	short_data_addr = crp_handle->punAddr;
	printf("CRP_CHANNEL_COUNT: %d;\n", crp_handle->ulCount);
	for (i = 0; i < crp->data_num; i++)
		crp->data[i] = (short)short_data_addr[i];

	crp->candidate_len = 5;
	switch (analysis_mode)
	{
	case AnalysisModeCBC:
		break;
	case AnalysisModeCBC_CRP:
		crp->start_pos = start_pos;
		crp->end_pos = end_pos;
		break;
	case AnalysisModeCRP:
		crp->start_pos = start_pos + offset;
		crp->end_pos = end_pos + offset;
		break;
	default:
		break;
	}
	return 0;
}

void print_bin(int n)
{
	int l = sizeof(n) * 8;//��λ��
	int i;
	if (n == 0)
	{
		printf("0\n");
		return;
	}
	for (i = l - 1; i >= 0; i--)//��ȥ��λ0.
	{
		if (n&(1 << i)) break;
	}

	for (; i >= 0; i--)
		printf("%d", (n&(1 << i)) != 0);
	printf("\n");
}

int get_wbc_channel_clinical_flag(item_evt_count_temp_t *bk_result)
{
	int wbc_hint = 0;
	if (bk_result->wbc.val < 2.5) // ��ϸ������
		wbc_hint |= HintFlagWbcLess;
	if (bk_result->wbc.val > 18.0) // ��ϸ������
		wbc_hint |= HintFlagWbcMore;
	if (bk_result->grann.val < 1.0) // ��ϸ������
		wbc_hint |= HintFlagGranLess;
	if (bk_result->grann.val > 11.0) // ��ϸ������
		wbc_hint |= HintFlagGranMore;
	if (bk_result->lymphn.val < 0.8) // �ܰ�ϸ������
		wbc_hint |= HintFlagLymphLess;
	if (bk_result->lymphn.val > 4.0) // �ܰ�ϸ������
		wbc_hint |= HintFlagLymphMore;
	if (bk_result->midn.val > 1.5) // �м�ϸ������
		wbc_hint |= HintFlagMidMore;
	if (bk_result->otherresult.wbcGraphflag & GraphFlagR1 ||
		bk_result->otherresult.wbcGraphflag & GraphFlagR2 ||
		bk_result->otherresult.wbcGraphflag & GraphFlagR3 ||
		bk_result->otherresult.wbcGraphflag & GraphFlagR4)
		wbc_hint |= HintFlagWbcAbnormal; //��ϸ���ֲ��쳣
	printf("wbc_hint:");
	print_bin(wbc_hint);
	return wbc_hint;
}

int get_rbc_channel_clinical_flag(item_evt_count_temp_t *bk_result,
	stImpdOutput * ImpdOutput)
{
	int rbc_hint = 0;
	if (bk_result->rbc.val > 6.5) // ��ϸ������
		rbc_hint |= HintFlagRbcMore;
	if (bk_result->rdw_cv.val > 22.0 && bk_result->rdw_sd.val > 64.0) // ��ϸ����С����
		rbc_hint |= HintFlagRbcInequality;
	if (bk_result->mcv.val > 113.0) // ��ϸ���Ժ�ϸ��
		rbc_hint |= HintFlagRbcOversized;
	if (bk_result->mcv.val < 70.0) // Сϸ���Ժ�ϸ��
		rbc_hint |= HintFlagRbcSmallsize;
	if (bk_result->hgb.val < 90.0) // ƶѪ
		rbc_hint |= HintFlagRbcIDA;
	if (bk_result->mchc.val < 290.0) // ��ɫ��
		rbc_hint |= HintFlagRbcHypochromic;
	if (ImpdOutput->RbcOutput.RbcFeaturePara.BimodalityFlag)
		rbc_hint |= HintFlagRbcBimodality;
	printf("rbc_hint:");
	print_bin(rbc_hint);
	return rbc_hint;
}

int get_plt_channel_clinical_flag(item_evt_count_temp_t *bk_result)
{
	int plt_hint = 0;
	if (bk_result->plt.val < 60.0) // ѪС�����
		plt_hint |= HintFlagPltLess;
	if (bk_result->plt.val > 600.0) // ѪС������
		plt_hint |= HintFlagPltMore;
	printf("plt_hint:");
	print_bin(plt_hint);
	return plt_hint;
}

int get_summary_result(item_evt_count_temp_t *bk_result, stImpdOutput * ImpdOutput,
	S_BK_WBC_OUTPUT *s_wbc_output, double hgb, double crp_val,int analysis_mode)
{
	int i;

	bk_result->wbc.val = (float32)s_wbc_output->s_report_para.wbc_value;
	bk_result->lymphp.val = (float32)s_wbc_output->s_report_para.lym_per;
	bk_result->midp.val = (float32)s_wbc_output->s_report_para.mid_per;
	bk_result->granp.val = (float32)s_wbc_output->s_report_para.gran_per;
	bk_result->lymphn.val = (float32)s_wbc_output->s_report_para.lym_value;
	bk_result->midn.val = (float32)s_wbc_output->s_report_para.mid_value;
	bk_result->grann.val = (float32)s_wbc_output->s_report_para.gran_value;

	bk_result->rbc.val = (float32)ImpdOutput->RbcOutput.RbcReportPara.Rbc;
	bk_result->hct.val = (float32)ImpdOutput->RbcOutput.RbcReportPara.hct;
	bk_result->mcv.val = (float32)ImpdOutput->RbcOutput.RbcReportPara.Mcv;
	bk_result->rdw_cv.val = (float32)ImpdOutput->RbcOutput.RbcReportPara.Rdw_cv;
	bk_result->rdw_sd.val = (float32)ImpdOutput->RbcOutput.RbcReportPara.Rdw_sd;

	bk_result->hgb.val = (float32)hgb;
	if (bk_result->rbc.val < EPSILON)
		bk_result->mch.val = (float32)0.0;
	else
		bk_result->mch.val = (float32)hgb / bk_result->rbc.val;
	if (bk_result->hct.val < EPSILON)
		bk_result->mchc.val = (float32)0.0;
	else
		bk_result->mchc.val = (float32)hgb / bk_result->hct.val * 100;

	bk_result->plt.val = (float32)ImpdOutput->PltOutput.PltReportPara.Plt;
	bk_result->mpv.val = (float32)ImpdOutput->PltOutput.PltReportPara.Mpv;
	bk_result->pdw.val = (float32)ImpdOutput->PltOutput.PltReportPara.Pdw;
	bk_result->pct.val = (float32)ImpdOutput->PltOutput.PltReportPara.pct;
	bk_result->plcc.val = (float32)ImpdOutput->PltOutput.PltReportPara.Plcc;
	bk_result->plcr.val = (float32)ImpdOutput->PltOutput.PltReportPara.Plcr;

	bk_result->crp.val = (float32)crp_val;


	bk_result->rhistodata.len = ImpdOutput->RbcOutput.RbcGraphPara.DspHist.datalen;
	for (i = 0; i < bk_result->rhistodata.len; i++)
		bk_result->rhistodata.data[i] = (uint16)ImpdOutput->RbcOutput.RbcGraphPara.DspHist.datas[i];

	bk_result->whistodata.len = s_wbc_output->s_graph.org_hist.datalen;
	for (i = 0; i < bk_result->whistodata.len; i++)
		bk_result->whistodata.data[i] = (uint16)s_wbc_output->s_graph.org_hist.datas[i];

	bk_result->phistodata.len = ImpdOutput->PltOutput.PltGraphPara.DspHist.datalen;
	for (i = 0; i < bk_result->phistodata.len; i++)
		bk_result->phistodata.data[i] = (uint16)ImpdOutput->PltOutput.PltGraphPara.DspHist.datas[i];

	bk_result->otherresult.wbcline1 = s_wbc_output->s_graph.org_hist.lines[0];
	bk_result->otherresult.wbcline2 = s_wbc_output->s_graph.org_hist.lines[1];
	bk_result->otherresult.wbcline3 = s_wbc_output->s_graph.org_hist.lines[2];
	bk_result->otherresult.wbcline4 = s_wbc_output->s_graph.org_hist.lines[3];

	bk_result->otherresult.wmcv = (float32)s_wbc_output->s_other_para.wbc_mcv;

	bk_result->otherresult.rbclinel = ImpdOutput->RbcOutput.RbcGraphPara.DspHist.lines[0];
	bk_result->otherresult.rbcliner = ImpdOutput->RbcOutput.RbcGraphPara.DspHist.lines[1];

	bk_result->otherresult.pltlinel = ImpdOutput->PltOutput.PltGraphPara.DspHist.lines[0];
	bk_result->otherresult.pltliner = ImpdOutput->PltOutput.PltGraphPara.DspHist.lines[1];

	// �㷨ȷ�������ֱ�����Ϣ:WBC channel
#ifdef BK_LINUX_TEST
	
#endif // BK_LINUX_TEST
	switch (analysis_mode)
	{
	case AnalysisModeCBC:
	case AnalysisModeCBC_CRP:
		bk_result->otherresult.wbcGraphflag = s_wbc_output->s_other_para.wbc_hist_flag;
		bk_result->otherresult.wbcHint = get_wbc_channel_clinical_flag(bk_result);
		bk_result->otherresult.rbcHint = get_rbc_channel_clinical_flag(bk_result,ImpdOutput);
		bk_result->otherresult.pltHint = get_plt_channel_clinical_flag(bk_result);
		break;
	case AnalysisModeCRP:
		break;
	default:
		break;
	}
	

	// ���������������־���
	printf("wbc: %4.1f 10^9/L\n", bk_result->wbc.val);
	printf("rbc: %4.1f 10^12/L\n", bk_result->rbc.val);
	printf("hgb: %4.1f g/L\n", bk_result->hgb.val);
	printf("mcv: %4.1f g/L\n", bk_result->mcv.val);
	printf("plt: %4.1f 10^9/L\n", bk_result->plt.val);

	printf("crp: %4.1f mg/L\n", bk_result->crp.val);
	return 0;
}

static void initial_para_mark(item_evt_count_temp_t *bk_result)
{
	bk_result->wbc.mark = ParaMarkNormal;
	bk_result->lymphp.mark = ParaMarkNormal;
	bk_result->midp.mark = ParaMarkNormal;
	bk_result->granp.mark = ParaMarkNormal;
	bk_result->lymphn.mark = ParaMarkNormal;
	bk_result->midn.mark = ParaMarkNormal;
	bk_result->grann.mark = ParaMarkNormal;

	bk_result->rbc.mark = ParaMarkNormal;
	bk_result->hgb.mark = ParaMarkNormal;
	bk_result->mcv.mark = ParaMarkNormal;
	bk_result->hct.mark = ParaMarkNormal;
	bk_result->mch.mark = ParaMarkNormal;
	bk_result->mchc.mark = ParaMarkNormal;
	bk_result->rdw_cv.mark = ParaMarkNormal;
	bk_result->rdw_sd.mark = ParaMarkNormal;

	bk_result->plt.mark = ParaMarkNormal;
	bk_result->mpv.mark = ParaMarkNormal;
	bk_result->pdw.mark = ParaMarkNormal;
	bk_result->pct.mark = ParaMarkNormal;
	bk_result->plcc.mark = ParaMarkNormal;
	bk_result->plcr.mark = ParaMarkNormal;

	bk_result->crp.mark = ParaMarkNormal;
}

// ��Ϣ�ۺ�
bool collect_para_mark(item_evt_count_temp_t *bk_result, const sample_info_t
	*s_sample_info)
{
	int i = 0;
	int j = 0;

	// ��ʼ������mark

	// 1�����Բ�������
	

	// 2 �����������
	// 2.1 ��ϸ�������������
	if (bk_result->wbc.val < 0.5)
	{
		// ��������
		bk_result->lymphp.mark = ParaMarkStar;
		bk_result->midp.mark = ParaMarkStar;
		bk_result->granp.mark = ParaMarkStar;
		bk_result->lymphn.mark = ParaMarkStar;
		bk_result->midn.mark = ParaMarkStar;
		bk_result->grann.mark = ParaMarkStar;
	}

	// 2.2 ��ϸ�������������
	if (bk_result->rbc.val < 0.2)
	{
		// ��������
		bk_result->mcv.mark = ParaMarkStar;
		bk_result->hct.mark = ParaMarkStar;
		bk_result->mch.mark = ParaMarkStar;
		bk_result->mchc.mark = ParaMarkStar;
		bk_result->rdw_cv.mark = ParaMarkStar;
		bk_result->rdw_sd.mark = ParaMarkStar;

		// ��������
		bk_result->otherresult.rbcHint = 0;
		bk_result->otherresult.rbcGraphflag = 0;

		// ֱ��ͼ����
		memset(bk_result->rhistodata.data, 0, sizeof(unsigned short) * 256);

		// �ֽ��ߴ���
		bk_result->otherresult.rbclinel = 40;
		bk_result->otherresult.rbcliner = 255;
	}

	// 2.3 ѪС�������������
	if (bk_result->plt.val < 10)
	{
		// ��������
		bk_result->mpv.mark = ParaMarkStar;
		bk_result->pdw.mark = ParaMarkStar;
		bk_result->pct.mark = ParaMarkStar;
		bk_result->plcc.mark = ParaMarkStar;
		bk_result->plcr.mark = ParaMarkStar;

		// ��������
		bk_result->otherresult.pltHint= 0;
		bk_result->otherresult.pltGraphflag = 0;

		// ֱ��ͼ����
		if (bk_result->plt.val < 1)
		{
			memset(bk_result->phistodata.data, 0, sizeof(unsigned short) * 128);
		}

		// �ֽ��ߴ���
		bk_result->otherresult.pltlinel = 5;
		bk_result->otherresult.pltliner = 63;
	}

	// 3 ģʽ�Բ�������
	if (s_sample_info->am == AnalysisModeCRP)
	{
		bk_result->wbc.mark = ParaMarkBlank;
		bk_result->lymphp.mark = ParaMarkBlank;
		bk_result->midp.mark = ParaMarkBlank;
		bk_result->granp.mark = ParaMarkBlank;
		bk_result->lymphn.mark = ParaMarkBlank;
		bk_result->midn.mark = ParaMarkBlank;
		bk_result->grann.mark = ParaMarkBlank;

		bk_result->rbc.mark = ParaMarkBlank;
		bk_result->hgb.mark = ParaMarkBlank;
		bk_result->mcv.mark = ParaMarkBlank;
		bk_result->hct.mark = ParaMarkBlank;
		bk_result->mch.mark = ParaMarkBlank;
		bk_result->mchc.mark = ParaMarkBlank;
		bk_result->rdw_cv.mark = ParaMarkBlank;
		bk_result->rdw_sd.mark = ParaMarkBlank;

		bk_result->plt.mark = ParaMarkBlank;
		bk_result->mpv.mark = ParaMarkBlank;
		bk_result->pdw.mark = ParaMarkBlank;
		bk_result->pct.mark = ParaMarkBlank;
		bk_result->plcc.mark = ParaMarkBlank;
		bk_result->plcr.mark = ParaMarkBlank;
	}

	if (s_sample_info->am == AnalysisModeCBC)
	{
		bk_result->crp.mark = ParaMarkBlank;
	}

	// ��Ҫ������ʾ��Χ����
	if (s_sample_info->am == AnalysisModeCBC || s_sample_info->am == AnalysisModeCBC_CRP)
	{
		if (bk_result->wbc.val < 0.0
			|| bk_result->wbc.val > 999.99)
		{
			bk_result->wbc.mark = ParaMarkStar;
			bk_result->lymphp.mark = ParaMarkStar;
			bk_result->midp.mark = ParaMarkStar;
			bk_result->granp.mark = ParaMarkStar;
			bk_result->lymphn.mark = ParaMarkStar;
			bk_result->midn.mark = ParaMarkStar;
			bk_result->grann.mark = ParaMarkStar;
		}

		if (bk_result->rbc.val < 0.0 || bk_result->rbc.val > 18.0
			|| bk_result->hgb.val < 0.0 || bk_result->hgb.val > 300.0
			|| bk_result->hct.val < 0.0 || bk_result->hct.val > 80.0
			)
		{
			bk_result->rbc.mark = ParaMarkStar;
			bk_result->hgb.mark = ParaMarkStar;
			bk_result->mcv.mark = ParaMarkStar;
			bk_result->hct.mark = ParaMarkStar;
			bk_result->mch.mark = ParaMarkStar;
			bk_result->mchc.mark = ParaMarkStar;
			bk_result->rdw_cv.mark = ParaMarkStar;
			bk_result->rdw_sd.mark = ParaMarkStar;
		}

		if (bk_result->plt.val < 0.0 || bk_result->plt.val > 9999.0)
		{
			bk_result->plt.mark = ParaMarkStar;
			bk_result->mpv.mark = ParaMarkStar;
			bk_result->pdw.mark = ParaMarkStar;
			bk_result->pct.mark = ParaMarkStar;
			bk_result->plcc.mark = ParaMarkStar;
			bk_result->plcr.mark = ParaMarkStar;
		}
	}


	if (s_sample_info->am == AnalysisModeCRP)
	{
		if (bk_result->crp.val < 0.0 || bk_result->crp.val > 9999.0)
		{
			bk_result->crp.mark = ParaMarkStar;
		}
	}

	return true;
}

void initial_wbc_channel(S_BK_WBC_INPUT *s_wbc_input, unsigned char *buff,
	DataCollectHandle *data_handle, const sample_info_t *s_sample_info)
{
	memset(s_wbc_input, 0, sizeof(S_BK_WBC_INPUT));

	s_wbc_input->wbc_input.DataAddr = buff +
		data_handle->astChannels[COLLECT_CHANNEL_WBC_PULSE].ulAddr;
	s_wbc_input->wbc_input.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_WBC_PULSE].ulCount / FPGA_PACK_SIZE;
	s_wbc_input->alg_pos[0] = -1;
	s_wbc_input->alg_pos[1] = -1;
	s_wbc_input->wbc_input.MeasureTime = 10.0;
	s_wbc_input->wbc_input.lines[0] = 20;
	s_wbc_input->wbc_input.lines[1] = 50;
	s_wbc_input->wbc_input.lines[2] = 70;

	switch (s_sample_info->bm)
	{
	case BloodModeWL:
		s_wbc_input->wbc_input.Dilution = 305.1;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_wbc_input->wbc_input.factory_cal_factor = g_calFactor.wbFactoryCalFactor.fWbc / 100;
			s_wbc_input->wbc_input.user_cal_factor = g_calFactor.wbCalFactor.fWbc / 100;
			break;
		case WorkModeCalFactory:
			s_wbc_input->wbc_input.factory_cal_factor = (float)1.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)1.0;
			break;
		case WorkModeCal:
			s_wbc_input->wbc_input.factory_cal_factor = (float)g_calFactor.
				wbFactoryCalFactor.fWbc / 100;
			s_wbc_input->wbc_input.user_cal_factor = (float)1.0;
			break;
		case WorkModeCrpCal:
			s_wbc_input->wbc_input.factory_cal_factor = (float)0.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)0.0;
			break;
		default:
			s_wbc_input->wbc_input.factory_cal_factor = (float)-1.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)-1.0;
			break;
		}
		break;
	case BloodModePD:
		s_wbc_input->wbc_input.Dilution = 501.9;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_wbc_input->wbc_input.factory_cal_factor = g_calFactor.pdFactoryCalFactor.fWbc / 100;
			s_wbc_input->wbc_input.user_cal_factor = g_calFactor.pdCalFactor.fWbc / 100;
			break;
		case WorkModeCalFactory:
			s_wbc_input->wbc_input.factory_cal_factor = (float)1.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)1.0;
			break;
		case WorkModeCal:
			s_wbc_input->wbc_input.factory_cal_factor = (float)g_calFactor.
				pdFactoryCalFactor.fWbc / 100;
			s_wbc_input->wbc_input.user_cal_factor = (float)1.0;
			break;
		case WorkModeCrpCal:
			s_wbc_input->wbc_input.factory_cal_factor = (float)0.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)0.0;
			break;
		default:
			s_wbc_input->wbc_input.factory_cal_factor = (float)-1.0;
			s_wbc_input->wbc_input.user_cal_factor = (float)-1.0;
			break;
		}
		
		break;
	default:
		break;
	}
	s_wbc_input->wbc_input.Volume = 402.8;
}

void initial_rbc_plt_channel(stImpdInput *s_impe_input, unsigned char *buff,
	DataCollectHandle *data_handle, const sample_info_t *s_sample_info)
{
	memset(s_impe_input, 0, sizeof(stImpdInput));

	s_impe_input->RbcInput.DataAddr = buff +
		data_handle->astChannels[COLLECT_CHANNEL_RBC_PULSE].ulAddr;
	s_impe_input->RbcInput.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_RBC_PULSE].ulCount / FPGA_PACK_SIZE;
	s_impe_input->PltInput.DataAddr = buff +
		data_handle->astChannels[COLLECT_CHANNEL_PLT_PULSE].ulAddr;
	s_impe_input->PltInput.data_num = data_handle->
		astChannels[COLLECT_CHANNEL_PLT_PULSE].ulCount / FPGA_PACK_SIZE;

	s_impe_input->flag_pulse_alg = 1;
	s_impe_input->RbcInput.RbcConfigPara.rbc_compensation_plan = 1;
	s_impe_input->RbcInput.alg_pos[0] = -1;
	s_impe_input->RbcInput.alg_pos[1] = -1;
	s_impe_input->PltInput.alg_pos[0] = -1;
	s_impe_input->PltInput.alg_pos[1] = -1;
	s_impe_input->RbcInput.MeasureTime = 10.0;
	s_impe_input->PltInput.MeasureTime = 10.0;
	
	switch (s_sample_info->bm)
	{
	case BloodModeWL:
		s_impe_input->RbcInput.Dilution = 16498.5;
		s_impe_input->PltInput.Dilution = 16498.5;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				g_calFactor.wbCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fMcv / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				g_calFactor.wbCalFactor.fMcv / 100;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fPlt / 100;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				g_calFactor.wbCalFactor.fPlt / 100; 
			break;
		case WorkModeCalFactory:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)1.0;;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)1.0;;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)1.0;;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)1.0;;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)1.0;;
			break;
		case WorkModeCal:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fMcv / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)1.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				g_calFactor.wbFactoryCalFactor.fPlt / 100;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)1.0;
			break;
		case WorkModeCrpCal:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)0.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)0.0;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)0.0;
			break;
		default:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)-1.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)-1.0;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)-1.0;
			break;
		}
		
		break;
	case BloodModePD:
		s_impe_input->RbcInput.Dilution = 16439.6;
		s_impe_input->PltInput.Dilution = 16439.6;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				g_calFactor.pdCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fMcv / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				g_calFactor.pdCalFactor.fMcv / 100;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fPlt / 100;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				g_calFactor.pdCalFactor.fPlt / 100;
			break;
		case WorkModeCalFactory:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)1.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)1.0;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)1.0;
			break;
		case WorkModeCal:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fRbc / 100;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fMcv / 100;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)1.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				g_calFactor.pdFactoryCalFactor.fPlt / 100;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)1.0;
			break;
		case WorkModeCrpCal:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)0.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)0.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)0.0;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)0.0;
			break;
		default:
			s_impe_input->RbcInput.RbcConfigPara.rbc_factory_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.rbc_user_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_factory_cal_factor =
				(float)-1.0;
			s_impe_input->RbcInput.RbcConfigPara.mcv_user_cal_factor =
				(float)-1.0;

			s_impe_input->PltInput.PltConfigPara.plt_factory_cal_factor =
				(float)-1.0;
			s_impe_input->PltInput.PltConfigPara.plt_user_cal_factor =
				(float)-1.0;
			break;
		}
		
		break;
	default:
		break;
	}
	s_impe_input->RbcInput.Volume = 197.3;
	s_impe_input->PltInput.Volume = 197.3;
}

void initial_hgb_channel(S_HGB_INPUT *s_hgb_input, unsigned char *buff,
	DataCollectHandle *data_handle, const sample_info_t *s_sample_info)
{
	memset(s_hgb_input, 0, sizeof(S_HGB_INPUT));
	/*switch (s_sample_info->am)
	{
	case AnalysisModeCBC:
		s_hgb_input->bk_pos = 10;
		s_hgb_input->me_pos = 3520;
		break;
	case AnalysisModeCBC_CRP:
		s_hgb_input->bk_pos = 10;
		s_hgb_input->me_pos = 4330;
		break;
	default:
		break;
	}
	s_hgb_input->hgb_bk = s_sample_info->hgbBlank;
	s_hgb_input->hgb_me = s_sample_info->hgbPara;*/
	s_hgb_input->bk_pos = s_sample_info->hgbBlankMs/10;
	s_hgb_input->me_pos = s_sample_info->hgbParaMs/10;
	s_hgb_input->DataAddr = buff +
		data_handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	s_hgb_input->data_num = data_handle->astChannels[COLLECT_CHANNEL_HGB].ulCount
		/ sizeof(short);
	switch (s_sample_info->bm)
	{
	case BloodModeWL:
		s_hgb_input->Dilution = 305.1;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_hgb_input->factory_cal_factor = g_calFactor.
				wbFactoryCalFactor.fHgb / 100;
			s_hgb_input->user_cal_factor = g_calFactor.wbCalFactor.fHgb / 100;
			break;
		case WorkModeCalFactory:
			s_hgb_input->factory_cal_factor = (float)1.0;
			s_hgb_input->user_cal_factor = (float)1.0;
			break;
		case WorkModeCal:
			s_hgb_input->factory_cal_factor = g_calFactor.
				wbFactoryCalFactor.fHgb / 100;
			s_hgb_input->user_cal_factor = (float)1.0;
			break;
		case WorkModeCrpCal:
			s_hgb_input->factory_cal_factor = (float)0.0;
			s_hgb_input->user_cal_factor = (float)0.0;
			break;
		default:
			s_hgb_input->factory_cal_factor = (float)-1.0;
			s_hgb_input->user_cal_factor = (float)-1.0;
			break;
		}
		
		break;
	case BloodModePD:
		s_hgb_input->Dilution = 501.9;
		switch (s_sample_info->wm)
		{
		case WorkModeCount:
		case WorkModeQC:
			s_hgb_input->factory_cal_factor = g_calFactor.pdFactoryCalFactor.fHgb / 100;
			s_hgb_input->user_cal_factor = g_calFactor.pdCalFactor.fHgb / 100;
			break;
		case WorkModeCalFactory:
			s_hgb_input->factory_cal_factor = (float)1.0;
			s_hgb_input->user_cal_factor = (float)1.0;
			break;
		case WorkModeCal:
			s_hgb_input->factory_cal_factor = g_calFactor.
				pdFactoryCalFactor.fHgb / 100;
			s_hgb_input->user_cal_factor = (float)1.0;
			break;
		case WorkModeCrpCal:
			s_hgb_input->factory_cal_factor = (float)0.0;
			s_hgb_input->user_cal_factor = (float)0.0;
			break;
		default:
			s_hgb_input->factory_cal_factor = (float)-1.0;
			s_hgb_input->user_cal_factor = (float)-1.0;
			break;
		}
		
		break;
	default:
		break;
	}

	s_hgb_input->Volume = 402.8;
}



int BK_alg_main(unsigned char *buff, DataCollectHandle *data_handle, 
	const sample_info_t *s_sample_info, item_evt_count_temp_t *bk_result, alg_output_info *outInfo)
{
	int error_code;
	stImpdInput s_impe_input;
	stImpdOutput s_impe_output;
	S_BK_WBC_INPUT s_wbc_input;
	S_BK_WBC_OUTPUT s_wbc_output;
	S_HGB_INPUT s_hgb_input;
	INF_NEW_MONITOR new_monitor;
	INF_CRP crp;
	/*INF_CONFIG inf_config;
	INF_RESULT inf_result;*/
	
	double hgb, crp_val;
	
	printf("BK_alg_main --- ALG_VERSION = %s\n", ALG_VERSION);

	// initial
	memset(bk_result, 0, sizeof(item_evt_count_temp_t));
	outInfo->errorFlag = 0;
	printf("blood_mode: %d\n", s_sample_info->bm);
	printf("analysis_mode: %d\n", s_sample_info->am);
	printf("work_mode: %d\n", s_sample_info->wm);

	printf("wbc_gain: %d\n", s_sample_info->gainWbc);
	printf("rbc_gain: %d\n", s_sample_info->gainRbc);
	printf("hgb_gain: %d\n", s_sample_info->gainHgb);
	printf("crp_gain: %d\n", s_sample_info->gainCrp);

	printf("hgb_bk_pos: %d ms\n", s_sample_info->hgbBlankMs);
	printf("hgb_me_pos: %d ms\n", s_sample_info->hgbParaMs);

	// ��ȡУ��ϵ����CRP����
#ifdef BK_LINUX_TEST
	item_cal_factor_t s_cal_factor;
	crp_para_info crp_para;
	AlgSetCalFactor_test(&s_cal_factor);
	AlgSetCrpParaInfo_test(&crp_para);
#endif // BK_LINUX_TEST
	
	if (s_sample_info->am == AnalysisModeCRP)
	{
		// wbc channel
		initial_wbc_channel(&s_wbc_input, buff, data_handle, s_sample_info);
		memset(&s_wbc_output, 0, sizeof(S_BK_WBC_OUTPUT));

		// rbc_plt channel
		initial_rbc_plt_channel(&s_impe_input, buff, data_handle, s_sample_info);
		impdmain(&s_impe_input, &s_impe_output);
		printf("rbc_plt_channel_alg_finished!\n");

		// hgb channel
		initial_hgb_channel(&s_hgb_input, buff, data_handle, s_sample_info);
		hgb = 0.0;
		
		// �������ı����ж�
		memset(&new_monitor, 0, sizeof(INF_NEW_MONITOR));
		outInfo->errorFlag = 0;
	} 
	else
	{
		// �������ı����ж�
		memset(&new_monitor, 0, sizeof(INF_NEW_MONITOR));
		get_inf_new_monitor(&new_monitor, buff, data_handle);
		//outInfo->errorFlag = identify_abnormal_monitor_para(&new_monitor, s_sample_info);
		// wbc channel
		initial_wbc_channel(&s_wbc_input, buff, data_handle, s_sample_info);
		BK_wbc_main(&s_wbc_input, &s_wbc_output);
		printf("wbc_channel_alg_finished!\n");

		// rbc_plt channel
		initial_rbc_plt_channel(&s_impe_input, buff, data_handle, s_sample_info);
		if (error_code = impdmain(&s_impe_input, &s_impe_output))
			return error_code;
		printf("rbc_plt_channel_alg_finished!\n");

		// hgb channel
		initial_hgb_channel(&s_hgb_input, buff, data_handle, s_sample_info);
		hgb = bk_hgb_main_offline(&s_hgb_input, new_monitor.hgb.data);
		if (s_hgb_input.hgb_bk < 3.85 && s_hgb_input.hgb_bk > 4.85)
		{
			hgb = -1.0;
			outInfo->errorFlag |= ErrorFlagHgbBlankAbnormal;
		}
		printf("hgb_channel_alg_finished!\n");
		printf("errorFlag:");
		print_bin(outInfo->errorFlag);
	}
	

	// CRPģ��
	memset(&crp, 0, sizeof(INF_CRP));
	get_inf_crp(&crp, g_crpCollectHandle, s_sample_info->am);

	// crp����ģʽ
	if (s_sample_info->wm == WorkModeCrpCal)
	{
		crp_val = get_crp_reaction(&crp);
		crp.reaction = crp_val;
	}
	else
	{
		switch (s_sample_info->am)
		{
		case AnalysisModeCBC:
			crp_val = 0.0;
			break;
		case AnalysisModeCBC_CRP:
		case AnalysisModeCRP:
			//crp_val = crp_cal(&crp);
			crp_val = new_crp_cal(&crp, &g_stCrpParaInfo,s_sample_info->bm);
			crp_val /= (1 - s_impe_output.RbcOutput.RbcReportPara.hct / 100);
			crp.crp_val = crp_val;
			break;
		default:
			crp_val = 0.0;
			break;
		}
	}
	
	// summary
	get_summary_result(bk_result, &s_impe_output, &s_wbc_output, hgb, crp_val,
		s_sample_info->am);
	wbc_para_truncation(bk_result);
	collect_para_mark(bk_result, s_sample_info);
	//
	/*memset(&inf_config, 0, sizeof(INF_CONFIG));
	get_inf_config(&inf_config, &s_impe_input, &s_wbc_input, &s_hgb_input,
		s_sample_info,bk_result,outInfo);
	memset(&inf_result, 0, sizeof(INF_RESULT));
	get_inf_result(&inf_result, &s_hgb_input, &s_wbc_output, &s_impe_output, 
		bk_result);*/
	/*if (error_code = generate_inf_file_6(&new_monitor, &inf_config, &crp,
		&s_wbc_output, &s_impe_output, &inf_result, s_sample_info))
		return error_code;*/
	//

	memcpy(bk_result->otherresult.infFilePath, inf_file_path, sizeof(char) * 64);
	printf("%s\n", bk_result->otherresult.infFilePath);
	//FREE_POINTER(buff);
	free_memory_for_rbc_plt_chan(&s_impe_output);
	FREE_POINTER(s_wbc_output.s_cell_info.s_cell_list.cell_info);
	FREE_POINTER(s_wbc_output.s_cell_info.s_cell_list.cell_nps);
	return 0;
}


int get_inf_new_monitor(INF_NEW_MONITOR * new_monitor, byte * arm_buff, DataCollectHandle * handle)
{
	int  i, data_num;
	byte *data_addr;
	// hgb data
	data_num = handle->astChannels[COLLECT_CHANNEL_HGB].ulCount
		/ sizeof(short);
	if (data_num > 6000)
		new_monitor->hgb.data_num = 6000;
	else
		new_monitor->hgb.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	printf("HGB_CHANNEL_COUNT: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulCount);
	printf("HGB_CHANNEL_ADDR: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr);
	for (i = 0; i < new_monitor->hgb.data_num; i++)
	{
		new_monitor->hgb.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor->wbc_aperture_vol.data_num = 6000;
	else
		new_monitor->wbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr;
	printf("WBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount);
	printf("WBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < new_monitor->wbc_aperture_vol.data_num; i++)
	{
		new_monitor->wbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor->rbc_aperture_vol.data_num = 6000;
	else
		new_monitor->rbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr;
	printf("RBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount);
	printf("RBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < new_monitor->rbc_aperture_vol.data_num; i++)
	{
		new_monitor->rbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc base data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor->wbc_vol_base.data_num = 6000;
	else
		new_monitor->wbc_vol_base.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr;
	printf("WBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount);
	printf("WBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr);
	for (i = 0; i < new_monitor->wbc_vol_base.data_num; i++)
	{
		new_monitor->wbc_vol_base.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc base data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor->rbc_vol_base.data_num = 6000;
	else
		new_monitor->rbc_vol_base.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr;
	printf("RBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount);
	printf("RBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr);
	for (i = 0; i < new_monitor->rbc_vol_base.data_num; i++)
	{
		new_monitor->rbc_vol_base.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	//
	printf("DIFF_L_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_L_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	printf("DIFF_M_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_M_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	return 0;
}

#ifndef GAUSS_FIT

#endif

