#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "bk_wbc_main.h"
#include "common_func.h"
#ifdef GAUSS_FIT
#include "fit_functions.h"
#endif


static int wbc_para_cal(S_BK_WBC_INPUT * s_input, S_BK_WBC_OUTPUT *s_output);

static void initial_line(S_BK_WBC_INPUT * s_input, S_BK_WBC_OUTPUT *s_output)
{
	s_output->s_graph.org_hist.linelen = 4;
	if (s_input->wbc_input.lines[0] == -1)
		s_output->s_graph.org_hist.lines[0] = 20;
	else
		s_output->s_graph.org_hist.lines[0] = s_input->wbc_input.lines[0];

	if (s_input->wbc_input.lines[1] == -1)
		s_output->s_graph.org_hist.lines[1] = 50;
	else
		s_output->s_graph.org_hist.lines[1] = s_input->wbc_input.lines[1];

	if (s_input->wbc_input.lines[2] == -1)
		s_output->s_graph.org_hist.lines[2] = 70;
	else
		s_output->s_graph.org_hist.lines[2] = s_input->wbc_input.lines[2];

	s_output->s_graph.org_hist.lines[3] = s_output->s_graph.org_hist.datalen - 1;
}

static int get_gran_start_pos(int *hist_data, int gran_end_pos,
	int gran_peak_pos, int lym_end_pos)
{
	int i, gran_num,tmp_num,gran_start_pos;
	gran_num = 0;
	for (i = gran_end_pos; i > gran_peak_pos; i--)
		gran_num += hist_data[i];
	gran_num *= 2;
	gran_num += hist_data[gran_peak_pos];

	tmp_num = 0;
	gran_start_pos = 0;
	for (i = gran_end_pos; i > lym_end_pos; i--)
	{
		tmp_num += hist_data[i];
		if (tmp_num >= gran_num)
		{
			gran_start_pos = i;
			break;
		}
	}
	return gran_start_pos;
}

static void wbc_classification_for_double_array(stHist *wbc_hist, double *hist_data)
{
	
	int ghost_peak_pos, lym_start_pos, lym_peak_pos, lym_end_pos, gran_end_pos,
		gran_peak_pos, gran_start_pos, mid_trough_pos, gran_subpeak_pos;
	int i, j, ghost_redge, lym_redge, gran_redge;
	double ghost_peak_val, lym_peak_val, lym_start_val, total_max_val,
		gran_end_val, gran_peak_val, mid_trough_val;
	int lym_num, tmp_num;
	
	ghost_redge = 16;
	lym_redge = 50;
	gran_redge = 200;

	total_max_val = 0.0;
	get_max_index_of_double_array_within_range(hist_data, 0, WBC_HIST_DATALEN, 
		&total_max_val);

	ghost_peak_val = 0.0;
	ghost_peak_pos = get_max_index_of_double_array_within_range(hist_data, 0, 
		ghost_redge, &ghost_peak_val);

	lym_peak_val = 0.0;
	lym_peak_pos = get_max_index_of_double_array_within_range(hist_data, ghost_redge,
		lym_redge, &lym_peak_val);

	lym_start_val = total_max_val + 1.0;
	lym_start_pos = get_min_index_of_double_array_within_range(hist_data, 
		ghost_peak_pos, lym_peak_pos, &lym_start_val);
	if (lym_start_pos == 0)
		return;

	gran_end_val = total_max_val + 1.0;
	gran_end_pos = get_min_index_of_double_array_within_range(hist_data,
		gran_redge, WBC_HIST_DATALEN, &gran_end_val);

	gran_peak_val = 0.0;
	gran_peak_pos = get_max_index_of_double_array_within_range(hist_data,
		lym_redge, gran_end_pos, &gran_peak_val);
	//
	lym_num = 0;
	for (i = lym_start_pos; i <= lym_peak_pos; i++)
		lym_num += wbc_hist->datas[i];
	lym_num *= 2;
	//lym_num += wbc_hist->datas[lym_peak_pos];
	
	tmp_num = 0;
	lym_end_pos = 0;
	for (i = lym_start_pos; i < gran_peak_pos;i++)
	{
		tmp_num += wbc_hist->datas[i];
		if (tmp_num >= lym_num)
		{
			lym_end_pos = i + 1;
			break;
		}
	}
	if (lym_end_pos == 0)
		return;
	//
	gran_start_pos = get_gran_start_pos(wbc_hist->datas, gran_end_pos,
		gran_peak_pos, lym_end_pos);
	gran_subpeak_pos = gran_peak_pos;
	if (gran_start_pos == 0 || gran_start_pos <= lym_end_pos)
	{
		for (j = gran_peak_pos + 1; j < gran_end_pos-2; j++)
		{
			if (hist_data[j] < hist_data[j+1] &&
				hist_data[j+2] < hist_data[j+1])
			{
				gran_subpeak_pos = j + 1;
				break;
			}
		}
	}
	gran_start_pos = get_gran_start_pos(wbc_hist->datas, gran_end_pos,
		gran_subpeak_pos, lym_end_pos);
	if (gran_start_pos == 0 || gran_start_pos <= lym_end_pos)
		return;
	mid_trough_val = total_max_val + 1.0;
	mid_trough_pos = get_min_index_of_double_array_within_range(hist_data, lym_end_pos,
		gran_peak_pos, &mid_trough_val);
	if (gran_start_pos - mid_trough_pos > 15 || gran_start_pos < mid_trough_pos)
	{
		gran_start_pos = mid_trough_pos + 5;
	}


	if (lym_start_pos > 0 && lym_start_pos < 50)
		wbc_hist->lines[0] = lym_start_pos;
	if (lym_end_pos > 0 && lym_end_pos < gran_start_pos)
	{
		wbc_hist->lines[1] = lym_end_pos;
		wbc_hist->lines[2] = gran_start_pos;
	}
	if (gran_end_pos > 0 && gran_end_pos <= WBC_HIST_DATALEN)
		wbc_hist->lines[3] = gran_end_pos;

}

#ifdef GAUSS_FIT
static double gsl_gauss_fit_for_int_array(int *src_data, int left, int right)
{
	CFData values;
	int data_num, i, j, max_value, max_index;
	double var[4];
	var[0] = var[1] = var[2] = var[3] = 1.0;

	max_value = 0;
	max_index = get_max_index_of_int_array_within_range(src_data,
		left, right, &max_value);
	var[1] = max_value;
	var[2] = max_index;
	values.model = gaussian;
	data_num = right - left;
	values.datalen = data_num;
	values.varlen = 4;

	double *xv;
	double *yv;
	double *mv;
	double *d1v;
	double *d2v;
	double *d3v;
	double *d4v;

	xv = (double *)malloc(sizeof(double) * data_num);
	yv = (double *)malloc(sizeof(double) * data_num);
	mv = (double *)malloc(sizeof(double) * data_num);
	d1v = (double *)malloc(sizeof(double) * data_num);
	d2v = (double *)malloc(sizeof(double) * data_num);
	d3v = (double *)malloc(sizeof(double) * data_num);
	d4v = (double *)malloc(sizeof(double) * data_num);

	values.x = xv;
	values.y = yv;
	values.m = mv;
	values.d1 = d1v;
	values.d2 = d2v;
	values.d3 = d3v;
	values.d4 = d4v;

	j = 0;
	for (i = left; i < right; i++)
	{
		values.x[j] = i;
		values.y[j] = src_data[i];
		j++;
	}

	levenberg_marquardt(&values, var);

	return var[2];
}



static void wbc_classification_for_int_array(S_BK_WBC_OUTPUT *s_output, int *hist_data)
{

	int ghost_peak_pos1, lym_start_pos, lym_peak_pos, lym_end_pos, gran_end_pos,
		gran_peak_pos, gran_start_pos, tmp_pos, ghost_peak_pos2;
	int i, ghost_redge, lym_redge, gran_redge;
	int ghost_peak_val, lym_peak_val, lym_start_val, total_max_val,
		l2_l3_gap;
	int lym_num, tmp_num, tmp;
	double atan1, atan2, multi, sub;

	ghost_redge = 16;
	lym_redge = 50;
	gran_redge = 210;

	// ��ȡȫ�����ֵ����С��10����Ĭ�Ϸ��ദ��
	total_max_val = 0;
	for (i = 0; i < WBC_HIST_DATALEN; i++)
	{
		if (total_max_val < hist_data[i])
		{
			total_max_val = hist_data[i];
		}
	}
	if (total_max_val < 10)
		return;


	// ��ȡѪӰ��ֵ
	ghost_peak_val = 0;
	ghost_peak_pos1 = get_peak_index_of_int_array_within_range(hist_data, 0,
		ghost_redge, &ghost_peak_val);
	

	// ��ȡlym��ֵ
	lym_peak_val = 0;
	lym_peak_pos = get_peak_index_of_int_array_within_range(hist_data, ghost_redge,
		lym_redge, &lym_peak_val);
	if (!lym_peak_pos)
	{
		s_output->s_research_para.lym_peak_index = (s_output->s_graph.org_hist.
			lines[1] + s_output->s_graph.org_hist.lines[2]) / 2;
		tmp = 0;
		s_output->s_research_para.gran_peak_index = 
			get_max_index_of_int_array_within_range(hist_data, s_output->s_graph.org_hist.
				lines[1], s_output->s_graph.org_hist.lines[3], &tmp);
		return;
	}
	else
		s_output->s_research_para.lym_peak_index = lym_peak_pos;
		

	// ��ȡlym��ʼ�㣬��L1
	lym_start_val = total_max_val + 1;
	lym_start_pos = get_trough_index_of_int_array_within_range(hist_data,
		ghost_peak_pos1, lym_peak_pos, &lym_start_val);
	if (lym_start_pos)
	{
		s_output->s_graph.org_hist.lines[0] = lym_start_pos;
	}

	// 
	lym_num = 0;
	for (i = lym_start_pos; i <= lym_peak_pos; i++)
		lym_num += s_output->s_graph.org_hist.datas[i];
	lym_num *= 2;
	//lym_num += wbc_hist->datas[lym_peak_pos];

	tmp_num = 0;
	lym_end_pos = 0;
	/*for (i = lym_start_pos; i < WBC_HIST_DATALEN; i++)
	{
		tmp_num += wbc_hist->datas[i];
		if (tmp_num >= lym_num)
		{
			lym_end_pos = i + 1;
			break;
		}
	}*/
	// ��ȡlym��ֹ�㣬��L2
	tmp_num = WBC_HIST_DATALEN;
	tmp_pos = 0;
	for (i = lym_peak_pos + 2; i < WBC_HIST_DATALEN - 2; ++i)
	{
		atan1 = atan((hist_data[i + 2] - hist_data[i]) / 2.0);
		atan2 = atan((hist_data[i] - hist_data[i - 2]) / 2.0);

		multi = atan1*atan2;
		if (multi < 0.00001 && i - lym_peak_pos > 8 &&
			hist_data[i] * 10 < 6 * lym_peak_val)
		{
			tmp_pos = i;
			break;
		}
	}
	if (tmp_pos - lym_peak_pos < 35)
	{
		lym_end_pos = tmp_pos;
	} 
	else
	{
		tmp_pos = 0;
		tmp = total_max_val + 1;
		for (i = lym_peak_pos + 2; i < lym_peak_pos + 26; ++i)
		{
			atan1 = atan((hist_data[i + 2] - hist_data[i]) / 2.0);
			atan2 = atan((hist_data[i] - hist_data[i - 2]) / 2.0);

			sub = fabs(atan1 - atan2);
			if (sub > 1.1 && i - lym_end_pos < 10 && i - lym_peak_pos > 11 &&
				fabs(atan1) < fabs(atan2) && tmp > hist_data[i])
			{
				tmp_pos = i;
				tmp = hist_data[i];
			}
		}
		if (tmp_pos)
			lym_end_pos = tmp_pos; 
		else
			lym_end_pos = 44;

	}
	
	
	if (lym_end_pos)
		s_output->s_graph.org_hist.lines[1] = lym_end_pos;

	// ��ȡgran��ֹ�㣬��L4
	ghost_peak_val = 0;
	ghost_peak_pos2 = WBC_HIST_DATALEN;
	for (i = WBC_HIST_DATALEN - 2; i > gran_redge + 2; i--)
	{
		if (hist_data[i - 2] < hist_data[i] && hist_data[i] > hist_data[i + 2])
		{
			ghost_peak_pos2 = i;
			break;
		}
	}
	gran_end_pos = WBC_HIST_DATALEN - 1;
	for (i = ghost_peak_pos2 - 1; i > gran_redge + 1; i--)
	{
		if (hist_data[i - 1] >= hist_data[i] && hist_data[i] <= hist_data[i + 1])
		{
			gran_end_pos = i;
			break;
		}
	}
	s_output->s_graph.org_hist.lines[3] = gran_end_pos;

	// ��˹��ϻ�ȡgran�ķ�ֵλ��
	gran_peak_pos = (int)gsl_gauss_fit_for_int_array(hist_data, lym_end_pos,
		gran_end_pos);
	// ����������ȡL2-L3�ľ���
	l2_l3_gap = (int)(0.23*(gran_peak_pos - lym_end_pos) + 4.99);
	if (l2_l3_gap < 5)
	{
		l2_l3_gap = 5;
		gran_peak_pos = lym_end_pos + l2_l3_gap;
	}
		
	s_output->s_research_para.gran_peak_index = gran_peak_pos;
	gran_start_pos = lym_end_pos + l2_l3_gap;
	s_output->s_graph.org_hist.lines[2] = gran_start_pos;

	/*gran_peak_val = 0;
	gran_peak_pos = get_peak_index_of_int_array_within_range(hist_data,
		lym_end_pos, gran_end_pos, &gran_peak_val);
	if (gran_peak_pos > lym_end_pos + 25 && gran_peak_pos < gran_end_pos &&
		s_output->s_graph.org_hist.lines[1] + 25 > gran_peak_pos - 10)
	{
		gran_start_pos = gran_peak_pos - 10;
		
	}
	else
	{
		gran_start_pos = s_output->s_graph.org_hist.lines[1] + 25;
		
	}
	tmp = 0;
	s_output->s_research_para.gran_peak_index =
		get_max_index_of_int_array_within_range(hist_data, lym_end_pos,
			gran_end_pos, &tmp);
	s_output->s_graph.org_hist.lines[2] = gran_start_pos;*/
	////
	//tmp = 0;
	//gran_subpeak_pos = 0;
	//for (i = gran_peak_pos - 9; i < gran_peak_pos + 10; i++)
	//{
	//	if (hist_data[i - 1] <= hist_data[i] && hist_data[i] >= hist_data[i + 1])
	//	{
	//		if (tmp < hist_data[i] && hist_data[i] < gran_peak_val &&
	//			hist_data[i] * 10 > gran_peak_val * 9)
	//		{
	//			tmp = hist_data[i];
	//			gran_subpeak_pos = i;
	//		}
	//	}
	//}
	//if (gran_subpeak_pos)
	//{
	//	gran_peak_pos = (gran_peak_pos + gran_subpeak_pos) / 2;
	//} 
	////
	//gran_num = 0;
	//for (i = gran_end_pos; i > gran_peak_pos; i--)
	//	gran_num += wbc_hist->datas[i];
	//gran_num *= 2;
	////lym_num += wbc_hist->datas[lym_peak_pos];

	//tmp_num = 0;
	//gran_start_pos = 0;
	//for (i = gran_end_pos; i > 0; i--)
	//{
	//	tmp_num += wbc_hist->datas[i];
	//	if (tmp_num >= gran_num)
	//	{
	//		gran_start_pos = i;
	//		break;
	//	}
	//}
	//if (gran_start_pos < lym_end_pos + 20)
	//	gran_start_pos = lym_end_pos + 20;
	

}
#endif

static int get_wbc_histogram_flag(S_BK_WBC_OUTPUT *s_output)
{
	int hist_flag, r4_num;
	int flag_num;
	double r1_per,r2_per,r3_per;
	stHist dsp_hist;

	//
	dsp_hist = s_output->s_graph.dsp_hist;
	hist_flag = 0;
	flag_num = 0;
	// R1 : L1 height per
	/*r1_line = 35 * WBC_HIST_DATALEN / WBC_HIST_MAX_FL;
	r1_num = 0;
	for (i = 0; i <= r1_line; i++)
		r1_num += dsp_hist.datas[i];
	lym_num = 0;
	for (i = 0; i <= dsp_hist.lines[1]; i++)
		lym_num += dsp_hist.datas[i];*/
	r1_per = (double)dsp_hist.datas[dsp_hist.lines[0]] / dsp_hist.
		datas[s_output->s_research_para.lym_peak_index] * 100.0;
	s_output->s_research_para.R1_tell = r1_per;

	if (dsp_hist.datas[dsp_hist.lines[0]] > 9 && r1_per > 60.0)
	{
		hist_flag |= GraphFlagR1;
		flag_num++;
	}
		

	// R2: L2 height per
	r2_per = (double)dsp_hist.datas[dsp_hist.lines[1]] / dsp_hist.
		datas[s_output->s_research_para.lym_peak_index] * 100.0;
	s_output->s_research_para.R2_tell = r2_per;
	if (dsp_hist.datas[dsp_hist.lines[1]] > 9 && r2_per > 40)
	{
		hist_flag |= GraphFlagR2;
		flag_num++;
	}
		

	// R3: L3 height per
	r3_per = (double)dsp_hist.datas[dsp_hist.lines[2]] / dsp_hist.
		datas[s_output->s_research_para.gran_peak_index] * 100.0;
	s_output->s_research_para.R3_tell = r3_per;
	if (dsp_hist.datas[dsp_hist.lines[2]] > 9 && r3_per > 70.0)
	{
		hist_flag |= GraphFlagR3;
		flag_num++;
	}
	// R4: L4 number > 25
	/*r4_num = 0;
	for (i = wbc_hist.lines[3]; i < WBC_HIST_DATALEN; i++)
		r4_num += wbc_hist.datas[i];*/
	r4_num = dsp_hist.datas[dsp_hist.lines[3]];
	s_output->s_research_para.R4_tell = (double)r4_num;
	if (r4_num > 25)
	{
		hist_flag |= GraphFlagR4;
		flag_num++;
	}
	if (flag_num >= 2)
	{
		hist_flag |= GraphFlagRm;
	}
	return hist_flag;

}

static int detect_nps_abnormal(stImpdPulse *cell_info, int cell_num)
{
	int nps_seg_mean[WBC_NPS_SEG_NUM] = {0}, nps[WBC_NPS_MAX_NUM] = { 0 };
	int i, j, time_stamp_max, seg_num;

	time_stamp_max = 0;
	for (i = 0; i < cell_num; i++)
	{
		if (time_stamp_max < cell_info[i].TimeStamp)
			time_stamp_max = cell_info[i].TimeStamp;
		if (cell_info[i].TimeStamp < WBC_NPS_MAX_NUM)
			nps[cell_info[i].TimeStamp]++;
	}

	if (time_stamp_max == 0)
		return 0;

	seg_num = time_stamp_max / WBC_NPS_SEG_NUM;
	if (seg_num == 0)
		return 0;
	for (i = 0; i < WBC_NPS_SEG_NUM; i++)
	{
		for (j = 0; j < seg_num; j++)
		{
			nps_seg_mean[i] += nps[j + i*seg_num];
		}
		nps_seg_mean[i] /= seg_num;
	}
	if (nps_seg_mean[0] * 10 > nps_seg_mean[1] * 11 &&
		nps_seg_mean[1] * 10 > nps_seg_mean[2] * 11 &&
		nps_seg_mean[WBC_NPS_SEG_NUM - 2] > 
		nps_seg_mean[WBC_NPS_SEG_NUM - 1] )
		return seg_num;
	else
		return 0;

}

double get_gaussian_equation_result(double a, double mu, double sigma_2, double x)
{
	return a*exp(-(x - mu)*(x - mu) / sigma_2);
}

int get_ratio_index_of_max(stHist *wbc_hist, int max_index, int ratio_val)
{
	int ratio_index,i;
	ratio_index = 0;
	for (i = max_index; i > wbc_hist->lines[0]; i--)
	{
		if (wbc_hist->datas[i] < ratio_val)
		{
			ratio_index = i;
			break;
		}
	}
	return ratio_index;
}

void remove_ghost_of_wbc_histogram(stHist *wbc_hist)
{
	int lym_peak_val, i, lym_peak_index,half_max_index,gauss_re;
	double a, mu, sigma_2,half_y;

	lym_peak_index = get_peak_index_of_int_array_within_range(wbc_hist->datas, 
		wbc_hist->lines[0], wbc_hist->lines[1], &lym_peak_val);
	if (!lym_peak_index)
	{
		lym_peak_index = (wbc_hist->lines[0] + wbc_hist->lines[1]) / 2;
		lym_peak_val = wbc_hist->datas[lym_peak_index];
	}
		
		
	a = (double)lym_peak_val;
	mu = (double)lym_peak_index;

	half_max_index = get_ratio_index_of_max(wbc_hist, lym_peak_index, 
		lym_peak_val / 2);
	if (!half_max_index)
		half_max_index = get_ratio_index_of_max(wbc_hist, lym_peak_index, 
			lym_peak_val * 3 / 4);
	if (!half_max_index)
		half_max_index = get_ratio_index_of_max(wbc_hist, lym_peak_index,
			lym_peak_val * 4 / 5);
	if (!half_max_index)
		half_max_index = get_ratio_index_of_max(wbc_hist, lym_peak_index,
			lym_peak_val * 9 / 10);
	if (!half_max_index)
		half_y = 0.5;
	else
		half_y = (double)wbc_hist->datas[half_max_index];
	sigma_2 = -(half_max_index - mu)*(half_max_index - mu) / (log(half_y / a));
	if(half_max_index == 0)
		half_max_index = lym_peak_index;
	for (i = 1; i < half_max_index; i++)
	{
		gauss_re = (int)(get_gaussian_equation_result(a, mu, sigma_2, i) + 0.5);
		wbc_hist->datas[i] = gauss_re;
	}
	wbc_hist->datas[0] = 0;
	return;
}

int BK_wbc_main(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output)
{
	int wbc_start_pos,wbc_end_pos,i;
	stImpdCellList wbc_cell_list1, wbc_cell_list2;

	memset(s_output, 0, sizeof(S_BK_WBC_OUTPUT));
	//
	memset(&wbc_cell_list1, 0, sizeof(stImpdCellList));

	dataconvite_impd(&wbc_cell_list1, s_input->wbc_input.DataAddr,
		s_input->wbc_input.data_num);

	memset(&wbc_cell_list2, 0, sizeof(stImpdCellList));

	wbc_cell_list2.CellNum = 0;
	wbc_cell_list2.cell_info = (stImpdPulse *)calloc(wbc_cell_list1.CellNum,
		sizeof(stImpdPulse));

	if (s_input->alg_pos[0] == -1)
	{
		wbc_start_pos = 0;
		wbc_end_pos = wbc_cell_list1.CellNum;
	}
	else
	{
		wbc_start_pos = s_input->alg_pos[0];
		wbc_end_pos = s_input->alg_pos[1];
	}

	for (i = wbc_start_pos; i < wbc_end_pos; i++)
	{
		memcpy(&wbc_cell_list2.cell_info[wbc_cell_list2.CellNum],
			&wbc_cell_list1.cell_info[i], sizeof(stImpdPulse));
		wbc_cell_list2.CellNum++;
	}
	wbc_cell_list2.nps_num = wbc_cell_list1.nps_num;
	wbc_cell_list2.cell_nps = (short *)calloc(wbc_cell_list2.nps_num,
		sizeof(short));
	memcpy(wbc_cell_list2.cell_nps, wbc_cell_list1.cell_nps,
		wbc_cell_list2.nps_num * sizeof(short));

	s_output->s_cell_info.s_cell_list = wbc_cell_list2;
	FREE_POINTER(wbc_cell_list1.cell_info);
	FREE_POINTER(wbc_cell_list1.cell_nps);
	wbc_cell_list1.CellNum = 0;
	
	
	//
	s_output->s_graph.org_hist.datalen = 256;
	gethist(&s_output->s_graph.org_hist, s_output->s_cell_info.s_cell_list);
	//
	initial_line(s_input, s_output);
	s_output->s_graph.dsp_hist = s_output->s_graph.org_hist;
	curvesmooth_gauss(s_output->s_graph.dsp_hist.datas,
		s_output->s_graph.dsp_hist.datas, WBC_HIST_DATALEN, 4, 2);
	curvesmooth_gauss(s_output->s_graph.dsp_hist.datas,
		s_output->s_graph.dsp_hist.datas, WBC_HIST_DATALEN, 4, 2);
	
	//

	wbc_para_cal(s_input,s_output);
	return 0;
}

int wbc_para_cal(S_BK_WBC_INPUT *s_input,S_BK_WBC_OUTPUT *s_output)
{
	int WbcGhostNum = 0;
	int Typ1CellNum = 0;
	int Typ2CellNum = 0;
	int Typ3CellNum = 0;
	int WbcMcvSum = 0;
	int wbc_total_num = 0;
	double wbc_value, measure_time, volume, dilution;
	double wbc_factory_cal_factor, wbc_user_cal_factor;
	int i;
	
	// ������ʼ��
	wbc_value = 0.0;
	measure_time = s_input->wbc_input.MeasureTime;
	// Ghost������
	for (i = 0; i < s_output->s_graph.org_hist.lines[0]; i++)
	{
		WbcGhostNum += s_output->s_graph.org_hist.datas[i];
	}

	// Lym������
	for (i = s_output->s_graph.org_hist.lines[0]; i < s_output->s_graph.org_hist.lines[1]; i++)
	{
		Typ1CellNum += s_output->s_graph.org_hist.datas[i];
		WbcMcvSum += i*s_output->s_graph.org_hist.datas[i];
	}
	s_output->s_other_para.lym_mcv = (1.0*WbcMcvSum / Typ1CellNum) * 400 /
		WBC_HIST_DATALEN;
	// Mid������
	for (i = s_output->s_graph.org_hist.lines[1]; i < s_output->s_graph.org_hist.lines[2]; i++)
	{
		Typ2CellNum += s_output->s_graph.org_hist.datas[i];
		WbcMcvSum += i*s_output->s_graph.org_hist.datas[i];
	}

	// Gran������
	for (i = s_output->s_graph.org_hist.lines[2]; i < s_output->s_graph.org_hist.lines[3]; i++)
	{
		Typ3CellNum += s_output->s_graph.org_hist.datas[i];
		WbcMcvSum += i*s_output->s_graph.org_hist.datas[i];
	}

	// Wbc������
	wbc_total_num = Typ1CellNum + Typ2CellNum + Typ3CellNum;
	s_output->s_other_para.wbc_total_num = wbc_total_num;

	// Wbcֵ
	volume = s_input->wbc_input.Volume;
	dilution = s_input->wbc_input.Dilution;
	wbc_value = wbc_total_num * dilution * 10.0 / measure_time / volume / 1000.0;

	// nps�쳣У��
	if (s_output->s_research_para.nps_abnormal_flag)
		wbc_value *= WBC_NPS_SEG_NUM;

	// wbc����У��
	if (wbc_value > 10.0)
	{
		wbc_value = 0.00002555*wbc_value*wbc_value*wbc_value +
			0.0002554*wbc_value*wbc_value + 1.026*wbc_value - 0.1579;
	}

	// WBCУ׼
	wbc_factory_cal_factor = s_input->wbc_input.factory_cal_factor;
	wbc_user_cal_factor = s_input->wbc_input.user_cal_factor;
	printf("WBC_factory_cal_factor: %5.4f\n", wbc_factory_cal_factor);
	printf("WBC_user_cal_factor: %5.4f\n", wbc_user_cal_factor);
	wbc_value = wbc_value * wbc_factory_cal_factor * wbc_user_cal_factor;
		
	if (s_output->s_other_para.wbc_total_num > 0)
	{
		s_output->s_other_para.wbc_mcv = (1.0*WbcMcvSum / wbc_total_num) * 400 /
			WBC_HIST_DATALEN;

		s_output->s_report_para.lym_per = 100.0*Typ1CellNum / wbc_total_num;
		s_output->s_report_para.mid_per = 100.0*Typ2CellNum / wbc_total_num;
		s_output->s_report_para.gran_per = 100.0*Typ3CellNum / wbc_total_num;

		s_output->s_report_para.lym_value = wbc_value*Typ1CellNum / wbc_total_num;
		s_output->s_report_para.mid_value = wbc_value*Typ2CellNum / wbc_total_num;
		s_output->s_report_para.gran_value = wbc_value*Typ3CellNum / wbc_total_num;

		s_output->s_report_para.wbc_value = wbc_value;
	}

	return 0;
}

int bk_wbc_main_org_alg(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output)
{
	int wbc_start_pos, wbc_end_pos, i;
	//double hist_data[WBC_HIST_DATALEN];
	stImpdCellList wbc_cell_list1, wbc_cell_list2;

	memset(s_output, 0, sizeof(S_BK_WBC_OUTPUT));
	//
	wbc_cell_list1 = s_input->wbc_input.cell_list;

	memset(&wbc_cell_list2, 0, sizeof(stImpdCellList));

	wbc_cell_list2.CellNum = 0;
	wbc_cell_list2.cell_info = (stImpdPulse *)calloc(wbc_cell_list1.CellNum,
		sizeof(stImpdPulse));

	if (s_input->alg_pos[0] == -1)
	{
		wbc_start_pos = 0;
		wbc_end_pos = wbc_cell_list1.CellNum;
	}
	else
	{
		wbc_start_pos = s_input->alg_pos[0];
		wbc_end_pos = s_input->alg_pos[1];
	}

	for (i = wbc_start_pos; i < wbc_end_pos; i++)
	{
		memcpy(&wbc_cell_list2.cell_info[wbc_cell_list2.CellNum],
			&wbc_cell_list1.cell_info[i], sizeof(stImpdPulse));
		wbc_cell_list2.CellNum++;
	}
	wbc_cell_list2.nps_num = wbc_cell_list1.nps_num;
	wbc_cell_list2.cell_nps = (short *)calloc(wbc_cell_list2.nps_num,
		sizeof(short));
	memcpy(wbc_cell_list2.cell_nps, wbc_cell_list1.cell_nps,
		wbc_cell_list2.nps_num * sizeof(short));

	s_output->s_cell_info.s_cell_list = wbc_cell_list2;
	FREE_POINTER(wbc_cell_list1.cell_info);
	FREE_POINTER(wbc_cell_list1.cell_nps);
	wbc_cell_list1.CellNum = 0;

	//
	s_output->s_graph.org_hist.datalen = 256;
	gethist(&s_output->s_graph.org_hist, s_output->s_cell_info.s_cell_list);
	//
	initial_line(s_input, s_output);
	s_output->s_graph.dsp_hist = s_output->s_graph.org_hist;
	curvesmooth_gauss(s_output->s_graph.dsp_hist.datas,
		s_output->s_graph.dsp_hist.datas, WBC_HIST_DATALEN, 4, 2);


	//
	wbc_para_cal(s_input, s_output);
	return 0;
}

int BK_wbc_main_offline(S_BK_WBC_INPUT *s_input, S_BK_WBC_OUTPUT *s_output)
{
	int wbc_start_pos, wbc_end_pos, i, nps_seg_num;
	int tmp_hist_data[WBC_HIST_DATALEN];
	stImpdCellList wbc_cell_list1, wbc_cell_list2;

	memset(s_output, 0, sizeof(S_BK_WBC_OUTPUT));
	//
	wbc_cell_list1 = s_input->wbc_input.cell_list;

	memset(&wbc_cell_list2, 0, sizeof(stImpdCellList));

	wbc_cell_list2.CellNum = 0;
	wbc_cell_list2.cell_info = (stImpdPulse *)calloc(wbc_cell_list1.CellNum,
		sizeof(stImpdPulse));

	if (s_input->alg_pos[0] == -1)
	{
		wbc_start_pos = 0;
		wbc_end_pos = wbc_cell_list1.CellNum;
	}
	else
	{
		wbc_start_pos = s_input->alg_pos[0];
		wbc_end_pos = s_input->alg_pos[1];
	}
	nps_seg_num = detect_nps_abnormal(wbc_cell_list1.cell_info,
		wbc_cell_list1.CellNum);
	if (nps_seg_num > 0)
	{
		s_output->s_research_para.nps_abnormal_flag = 1;
		for (i = wbc_start_pos; i < wbc_end_pos; i++)
		{
			if (wbc_cell_list1.cell_info[i].TimeStamp >=
				nps_seg_num*(WBC_NPS_SEG_NUM - 1) &&
				wbc_cell_list1.cell_info[i].TimeStamp <
				nps_seg_num*WBC_NPS_SEG_NUM)
			{
				memcpy(&wbc_cell_list2.cell_info[wbc_cell_list2.CellNum],
					&wbc_cell_list1.cell_info[i], sizeof(stImpdPulse));
				wbc_cell_list2.CellNum++;
			}
			
		}
	}
	else
	{
		s_output->s_research_para.nps_abnormal_flag = 0;
		for (i = wbc_start_pos; i < wbc_end_pos; i++)
		{
			memcpy(&wbc_cell_list2.cell_info[wbc_cell_list2.CellNum],
				&wbc_cell_list1.cell_info[i], sizeof(stImpdPulse));
			wbc_cell_list2.CellNum++;
		}
	}
		

	
	wbc_cell_list2.nps_num = wbc_cell_list1.nps_num;
	wbc_cell_list2.cell_nps = (short *)calloc(wbc_cell_list2.nps_num,
		sizeof(short));
	memcpy(wbc_cell_list2.cell_nps, wbc_cell_list1.cell_nps,
		wbc_cell_list2.nps_num * sizeof(short));

	s_output->s_cell_info.s_cell_list = wbc_cell_list2;
	FREE_POINTER(wbc_cell_list1.cell_info);
	FREE_POINTER(wbc_cell_list1.cell_nps);
	wbc_cell_list1.CellNum = 0;

	//
	s_output->s_graph.org_hist.datalen = 256;
	gethist(&s_output->s_graph.org_hist, s_output->s_cell_info.s_cell_list);
	//
	initial_line(s_input, s_output);
	s_output->s_graph.dsp_hist = s_output->s_graph.org_hist;
	curvesmooth_gauss(tmp_hist_data,s_output->s_graph.org_hist.datas, 
		WBC_HIST_DATALEN, 4, 2);
	curvesmooth_gauss(s_output->s_graph.dsp_hist.datas,tmp_hist_data,
		WBC_HIST_DATALEN, 4, 2);
#ifdef GAUSS_FIT
	wbc_classification_for_int_array(s_output, s_output->s_graph.dsp_hist.datas);
#endif
	
	/*curvesmooth_gauss_int2double(hist_data, s_output->s_graph.dsp_hist.datas,
		WBC_HIST_DATALEN, 4, 2);
	cubic_smooth(s_output->s_research_para.double_hist, hist_data, WBC_HIST_DATALEN);
	wbc_classification_for_double_array(&s_output->s_graph.org_hist,hist_data);
	for (i = 0; i < WBC_HIST_DATALEN; i++)
	{
		s_output->s_graph.org_hist.datas[i] = (int)s_output->s_research_para.double_hist[i];
	}*/

	memcpy(s_output->s_graph.dsp_hist.lines, s_output->s_graph.org_hist.lines,
		sizeof(int)*s_output->s_graph.org_hist.linelen);
	s_output->s_other_para.wbc_hist_flag = get_wbc_histogram_flag(s_output);
	remove_ghost_of_wbc_histogram(&s_output->s_graph.dsp_hist);
	wbc_para_cal(s_input, s_output);
	return 0;
}