#ifndef BK_ALG_LIB_HGB_MAIN_H
#define BK_ALG_LIB_HGB_MAIN_H

typedef struct
{
	// ������Ϣ
	int                 bk_pos;					 //background position
	int                 me_pos;					 //measure position
	double              Volume;                  // �������
	double              Dilution;                // ����ϡ�ͱ�
	// ģʽ��Ϣ
	float               hgb_bk;
	float               hgb_me;
	// ͨ����Ϣ
	unsigned char      *DataAddr;                // ���ݵ�ַ
	int                 data_num;                // ���ݸ���
	//У׼��Ϣ
	float factory_cal_factor;
	float user_cal_factor;
}S_HGB_INPUT;

/*----------------------------------------------------------------------------*/
#ifdef __cplusplus      // avoid c++ name mangling
extern "C" {
#endif
	double bk_hgb_main(S_HGB_INPUT *s_input);
	double bk_hgb_main_offline(S_HGB_INPUT *s_input, short *hgb_data);
#ifdef __cplusplus
}
#endif

#endif
