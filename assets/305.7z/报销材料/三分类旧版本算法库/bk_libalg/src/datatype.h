#ifndef VK_DATATYPES_H  
#define VK_DATATYPES_H

#include <stdint.h>

typedef unsigned char       byte;
typedef unsigned char       uint8;
typedef unsigned short      uint16;
typedef unsigned int        uint32;
typedef unsigned long long  uint64;

typedef char       int8;
typedef short      int16;
typedef int        int32;
typedef long long  int64;

typedef float float32;
typedef double float64;
typedef unsigned long ubool;

// ����ֵ����
#define  EPSILON    0.00001
#define  PI         3.1415926
#define  TRUE       (1)
#define  FALSE      (0)
#define  MAX_PATH   (256)

#define FREE_POINTER(var) \
    { \
        free(var);\
        var = NULL;\
    } 

// ���ֵ����Сֵ
#define max(a,b)  (((a) > (b)) ? (a) : (b))
#define min(a,b)  (((a) < (b)) ? (a) : (b))

// ��С������ת��(16λ)
#define Swap16(X)   ( (((unsigned short)(X)&0xff00)>>8) | (((unsigned short)(X)&0x00ff)<<8) )

// ��С������ת��(32λ)
#define Swap32(X)   ( (((UINT32)(X)&0xff000000)>>24) | (((UINT32)(X)&0x00ff0000)>>8)  \
	|(((UINT32)(X)&0x0000ff00)<<8) | (((UINT32)(X)&0x000000ff)<<24) )

#endif