#ifndef ALG_RESOURCE_H
#define ALG_RESOURCE_H

#define  POINTER_FREE(p)    if (p != NULL)   \
							{                \
							delete[] p;  \
							p = NULL;    \
							}


#endif