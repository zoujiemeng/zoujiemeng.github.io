#ifndef BK_ALG_LIB_ALG_MAIN_H
#define BK_ALG_LIB_ALG_MAIN_H

#include "common_func.h"

/*----------------------------------------------------------------------------*/
#ifdef __cplusplus      // avoid c++ name mangling
extern "C" {
#endif
	void print_bin(int n);
	int get_summary_result(item_evt_count_temp_t *bk_result, stImpdOutput * ImpdOutput,
		S_BK_WBC_OUTPUT *s_wbc_output, double hgb, double crp_val, int analysis_mode);
#ifdef __cplusplus
}
#endif

#endif
