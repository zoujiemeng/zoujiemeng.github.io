#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include "datatype.h"
#include "impedance.h"
#include "protocolalg.h"
#include "alg.h"
#include "common_func.h"
#ifdef GAUSS_FIT
	#include "fit_functions.h"
#endif




static int impdinit(stImpdInput *ImpdInput,stImpdOutput *ImpdOutput);
static int impdconfigpara(stDivConfigPara *DivConfigPara,
	stRbcConfigPara *RbcConfigPara,
	stPltConfigPara *PltConfigPara);
static int impdsigprocess(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput);
static int impdclassify(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput);
static int impdparacal(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput);


/*******************************************************************
// �� �� ���� impdmain
// ��    �ܣ� �迹ͨ���㷨������
********************************************************************/
int impdmain(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput||!ImpdOutput)
	{
		return -1;
	}

	// 1 ��ʼ��
	if (error_code = impdinit(ImpdInput,ImpdOutput))
	    return error_code;
	
	// 2 ��ȡ���ò���
	if (error_code = impdconfigpara(&(ImpdInput->DivConfigPara),
		&(ImpdInput->RbcInput.RbcConfigPara),
		&(ImpdInput->PltInput.PltConfigPara)))
		return error_code;
	

	// 3 �źŴ���
	if (error_code = impdsigprocess(ImpdInput, ImpdOutput))
		return error_code;
	

	// 4 ֱ��ͼ�ֽ�ģ��
	if(error_code = impdclassify(ImpdInput, ImpdOutput))
		return error_code;
	
	// 5 ��������
	if (error_code = impdparacal(ImpdInput, ImpdOutput))
		return error_code;
	return 0;
}

/*******************************************************************
// �� �� ���� impdinit
// ��    �ܣ� �迹ͨ����ʼ������
********************************************************************/
static int impdinit(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	//FILE *fp;
	if (!ImpdInput || !ImpdOutput)
		return -1;
	
	memset(ImpdOutput, 0, sizeof(stImpdOutput));
	
	//if (!(fp = fopen(ImpdInput->file_path, "rb")))
	//	return 15; //�ļ��򿪴���
	//			   //
	//fread(&ImpdInput->flag_pulse_alg, sizeof(char), 1, fp);
	//fclose(fp);

	return 0;
}

/*******************************************************************
// �� �� ���� getimpdconfigpara
// ��    �ܣ� ��ȡ�迹ͨ�����ò���
********************************************************************/
static int impdconfigpara(stDivConfigPara *DivConfigPara,
	stRbcConfigPara *RbcConfigPara,
	stPltConfigPara *PltConfigPara)
{
	if (!DivConfigPara || !RbcConfigPara || !PltConfigPara)
	{
		return -1;
	}

	// RBC��PLT�ֽ����
	DivConfigPara->Alg_I_Divide_DefaultDivideLine = 48;              // Ĭ��RBC/PLT�ֽ���
	DivConfigPara->Alg_I_Divide_MinLine = 32;              // �ֽ��������
	DivConfigPara->Alg_I_Divide_MaxLine = 56;              // �ֽ��������
	DivConfigPara->Alg_I_Divide_GaussSmoothStep = 6;               // ��˹ƽ������С
	DivConfigPara->Alg_I_Divide_GaussSmoothDelta = 3;               // ��˹ƽ����׼��
	DivConfigPara->Alg_I_Divide_FirstPeakEndPos = 48;              // ��һ����Ľ�ֹλ��
	DivConfigPara->Alg_I_Divide_FirstVolEndPos = 96;              // ��һ���ȵĽ�ֹλ��
	DivConfigPara->Alg_I_Divide_NegParticleLinePer = 0.3;             // ��Ч������Ⱥ�ٷֱ�
	DivConfigPara->Alg_I_Divide_DivideK = 5;               // ͳ�Ʒ������ֽ��߽���
	DivConfigPara->Alg_I_Divide_FitCurveMeanMinth = 6;               // �������Mean��Сֵ
	DivConfigPara->Alg_I_Divide_FitCurveMeanMaxth = 7;               // �������Mean���ֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaMinth = 8.0;             // �������Delta��Сֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaMaxth = 15.0;            // �������Delta���ֵ
	DivConfigPara->Alg_I_Divide_FitCurveDeltaStep = 0.1;            // �������Delta����
	DivConfigPara->Alg_I_Divide_FitCurveFitErrorPer = 0.25;            // �������������ٷֱ�

	// RBCͨ�����ò���
	RbcConfigPara->Alg_R_Dsf_RbcPeakMinTh = 90;              // Dsf����Rbc��ֵ��С�߶�
	RbcConfigPara->Alg_R_Dsf_PulseNumMinTh = 1000;            // Dsf����Rbc�����������
	RbcConfigPara->Alg_R_Sig_DsfHistSmoothStep = 6;               // RbcDsfֱ��ͼ��˹ƽ������
	RbcConfigPara->Alg_R_Sig_DsfHistSmoothDelta = 3;               // RbcDsfֱ��ͼ��˹ƽ����׼��
	RbcConfigPara->Alg_R_Cal_SubBackGround = 20;              // RBC������������
	RbcConfigPara->Alg_R_Cal_dRbcExpCoff = 2.6;             // RBC���Ӳ���ϵ��
	RbcConfigPara->Alg_R_Cal_dMcvAdjustCoff = 0.81;             // MCV����ϵ��
	RbcConfigPara->Alg_R_Cal_RdwBaseLinePer = 0.20;            // Rdw���߸߶�
	//RbcConfigPara->Alg_R_Cal_dRdwSdAdjustCoff = 3.99;            // RdwSd����ϵ��
	RbcConfigPara->Alg_R_Cal_dRdwSdAdjustCoff = 0.6;            // RdwSd����ϵ��
	//RbcConfigPara->Alg_R_Cal_dRdwCvAdjustCoff = 85.8;            // RdwCv����ϵ��
	RbcConfigPara->Alg_R_Cal_dRdwCvAdjustCoff = 112.4;            // RdwCv����ϵ��
	RbcConfigPara->Alg_R_Cal_SkewnessBaseLinePer = 0.20;            // ƫ�Ȼ��߰ٷֱ�
	RbcConfigPara->Alg_R_Cal_KurtosisBaseLinePer = 0.20;            // �ͶȻ��߰ٷֱ�

	// PLTͨ�����ò���
	PltConfigPara->Alg_P_Cal_SubBackGround = 120;             // PLT������������
	PltConfigPara->Alg_P_Cal_dPltExpCoff = 5.6;             // PLT���Ӳ���ϵ��
	PltConfigPara->Alg_P_Cal_dMpvAdjustCoff = 0.794;            // MPV����ϵ��
	PltConfigPara->Alg_P_Cal_dPdwBaseLinePer = 0.20;            // Pdw���߸߶�
	//PltConfigPara->Alg_P_Cal_dPdwAdjustCoff = 9.54;            // Pdw����ϵ��
	PltConfigPara->Alg_P_Cal_dPdwAdjustCoff = 1.0;            // Pdw����ϵ��
	PltConfigPara->Alg_P_Cal_LargePltTh = 23;              // ��PLT��ֵ

	return 0;
}

int read_cell_data_from_p2o(char *file_path, stImpdCellList *cell_list, short cell_code)
{
	FILE *fp;
	char flag_pulse_alg;
	short code_from_p2o;
	int cell_num, nps_num;

	if (!(fp = fopen(file_path, "rb")))
		return 15; //�ļ��򿪴���
				   //
	fread(&flag_pulse_alg, sizeof(char), 1, fp);
	fread(&code_from_p2o, sizeof(short), 1, fp);
	fread(&cell_num, sizeof(int), 1, fp);
	if (code_from_p2o == cell_code)
	{
		cell_list->CellNum = cell_num;
		cell_list->cell_info = (stImpdPulse *)calloc(cell_num,
			sizeof(stImpdPulse));
		fread(cell_list->cell_info, sizeof(stImpdPulse), cell_num, fp);
		fread(&cell_list->nps_num, sizeof(int), 1, fp);
		cell_list->cell_nps = (short *)calloc(cell_list->nps_num, sizeof(short));
		fread(cell_list->cell_nps, sizeof(short), cell_list->nps_num, fp);
		fclose(fp);
		return 0;
	}
	fseek(fp, cell_num * sizeof(stImpdPulse), SEEK_CUR);
	fread(&nps_num, sizeof(int), 1, fp);
	fseek(fp, nps_num * sizeof(short), SEEK_CUR);
	fread(&code_from_p2o, sizeof(short), 1, fp);
	fread(&cell_num, sizeof(int), 1, fp);
	if (code_from_p2o == cell_code)
	{
		cell_list->CellNum = cell_num;
		cell_list->cell_info = (stImpdPulse *)calloc(cell_num,
			sizeof(stImpdPulse));
		fread(cell_list->cell_info, sizeof(stImpdPulse), cell_num, fp);
		fread(&cell_list->nps_num, sizeof(int), 1, fp);
		cell_list->cell_nps = (short *)calloc(cell_list->nps_num, sizeof(short));
		fread(cell_list->cell_nps, sizeof(short), cell_list->nps_num, fp);
		fclose(fp);
		return 0;
	}
	fseek(fp, cell_num * sizeof(stImpdPulse), SEEK_CUR);
	fread(&nps_num, sizeof(int), 1, fp);
	fseek(fp, nps_num * sizeof(short), SEEK_CUR);
	fread(&code_from_p2o, sizeof(short), 1, fp);
	fread(&cell_num, sizeof(int), 1, fp);
	if (code_from_p2o == cell_code)
	{
		cell_list->CellNum = cell_num;
		cell_list->cell_info = (stImpdPulse *)calloc(cell_num,
			sizeof(stImpdPulse));
		fread(cell_list->cell_info, sizeof(stImpdPulse), cell_num, fp);
		fread(&cell_list->nps_num, sizeof(int), 1, fp);
		cell_list->cell_nps = (short *)calloc(cell_list->nps_num, sizeof(short));
		fread(cell_list->cell_nps, sizeof(short), cell_list->nps_num, fp);
		fclose(fp);
		return 0;
	}
	fclose(fp);
	return 101; //
}

// ˫���������������㣨BimodalityFlag��
bool  get_bimodality_flag(stHist *DspHist)
{
	bool BimodalityFlag = false;

	double RbcHist[Rbc_Hist_DataLen] = { 0 };
	double RbcDecHist1[Rbc_Hist_DataLen] = { 0 };
	double RbcDecHist2[Rbc_Hist_DataLen] = { 0 };

	int NormalHeight = 255;

	int i = 0;
	int j = 0;

	// ��ȡ��ʾֱ��ͼ
	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		RbcHist[i] = DspHist->datas[i];
	}

	// ֱ��ͼƽ��
	curvesmooth_mean(RbcHist, RbcHist, Rbc_Hist_DataLen, 6);

	// ��һ��
	double Max = 0;

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		if (Max < RbcHist[i])
		{
			Max = RbcHist[i];
		}
	}

	if (Max == 0)
	{
		return BimodalityFlag;
	}

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		RbcHist[i] = RbcHist[i] * NormalHeight / Max;
	}

	// ����һ�ס����ײ��
	for (i = 1; i < Rbc_Hist_DataLen; i++)
	{
		RbcDecHist1[i] = RbcHist[i] - RbcHist[i - 1];
	}

	for (i = 1; i < Rbc_Hist_DataLen; i++)
	{
		RbcDecHist2[i] = RbcDecHist1[i] - RbcDecHist1[i - 1];
	}

	curvesmooth_mean(RbcDecHist2, RbcDecHist2, Rbc_Hist_DataLen, 3);

	// ����Ȥ����(ROI)ѡ�� (ROILeft/ROIRight)
	int RoiLeft = 0;
	int RoiRight = 0;

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		if (RbcHist[i] > 255 * 0.1)
		{
			RoiLeft = i;
			break;
		}
	}

	for (i = Rbc_Hist_DataLen - 2; i > 0; i--)
	{
		if (RbcHist[i] > 255 * 0.1)
		{
			RoiRight = i;
			break;
		}
	}

	RoiLeft = RoiLeft > 10 ? RoiLeft : 10;
	RoiLeft = RoiLeft < 120 ? RoiLeft : 120;
	RoiRight = RoiRight > 50 ? RoiRight : 50;
	RoiRight = RoiRight < 230 ? RoiRight : 230;

	// RbcDecHist2���ߴ�Խ���߼��
	int CrossNum = 0;
	int CrossPos[Rbc_Hist_DataLen] = { 0 };
	for (i = RoiLeft; i < RoiRight; i++)
	{
		if ((RbcDecHist2[i - 1] * RbcDecHist2[i] < 0)
			|| (RbcDecHist2[i - 1] * RbcDecHist2[i + 1] < 0
				&& RbcDecHist2[i]  <  EPSILON && RbcDecHist2[i]  > -EPSILON
				)
			|| (RbcDecHist2[i - 1] * RbcDecHist2[i + 2] < 0
				&& RbcDecHist2[i]  <  EPSILON && RbcDecHist2[i]  > -EPSILON
				&& RbcDecHist2[i + 1]<  EPSILON && RbcDecHist2[i + 1]> -EPSILON
				)
			)
		{
			CrossPos[CrossNum] = i;
			CrossNum++;
		}
	}

	if (CrossNum < 4)
	{
		return BimodalityFlag;
	}

	// ��Ч�����
	int    ValidAreaNum = 0;
	double ValidAreaHill[Rbc_Hist_DataLen] = { 0 };

	for (i = 0; i < CrossNum - 1; i++)
	{
		double ValidArea = 0;

		for (j = CrossPos[i]; j < CrossPos[i + 1]; j++)
		{
			ValidArea += RbcDecHist2[j];
		}

		if (ValidArea > 5.0
			|| ValidArea < -5.0)
		{
			ValidAreaHill[ValidAreaNum] = ValidArea;
			ValidAreaNum++;
		}

	}

	if (ValidAreaNum >= 3)
	{
		for (i = 1; i < ValidAreaNum - 1; i++)
		{
			if (ValidAreaHill[i - 1] * ValidAreaHill[i] < 0
				&& ValidAreaHill[i + 1] * ValidAreaHill[i] < 0)
			{
				BimodalityFlag = true;
			}
		}
	}

	return BimodalityFlag;
}

#ifdef GAUSS_FIT
double gsl_gauss_fit(stHist *rbc_dsp_hist)
{
	CFData values;
	int data_num, i, j, max_value, max_index;
	int hist_tmp_data[Rbc_Hist_DataLen];
	double var[4];
	var[0] = var[1] = var[2] = var[3] = 1.0;

	max_value = 0;
	max_index = get_max_index_of_int_array_within_range(rbc_dsp_hist->datas,
		rbc_dsp_hist->lines[0], rbc_dsp_hist->lines[1], &max_value);
	if (max_value < 10)
	{
		return 0.0;
	}
	var[1] = max_value;
	var[2] = max_index;
	values.model = gaussian;
	data_num = rbc_dsp_hist->lines[1] - rbc_dsp_hist->lines[0];
	values.datalen = data_num;
	values.varlen = 4;

	double *xv;
	double *yv;
	double *mv;
	double *d1v;
	double *d2v;
	double *d3v;
	double *d4v;

	xv = (double *)malloc(sizeof(double) * data_num);
	yv = (double *)malloc(sizeof(double) * data_num);
	mv = (double *)malloc(sizeof(double) * data_num);
	d1v = (double *)malloc(sizeof(double) * data_num);
	d2v = (double *)malloc(sizeof(double) * data_num);
	d3v = (double *)malloc(sizeof(double) * data_num);
	d4v = (double *)malloc(sizeof(double) * data_num);

	values.x = xv;
	values.y = yv;
	values.m = mv;
	values.d1 = d1v;
	values.d2 = d2v;
	values.d3 = d3v;
	values.d4 = d4v;

	j = 0;
	for (i = rbc_dsp_hist->lines[0]; i < rbc_dsp_hist->lines[1]; i++)
	{
		values.x[j] = i;
		values.y[j] = rbc_dsp_hist->datas[i];
		j++;
	}

	levenberg_marquardt(&values, var);

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		hist_tmp_data[i] = (int)(var[0] + var[1] * exp(-(i - var[2])*
			(i - var[2]) / (var[3] * var[3])));
	}

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		rbc_dsp_hist->datas[i] = hist_tmp_data[i] -
			hist_tmp_data[rbc_dsp_hist->lines[0]];
	}



	return var[2];
}
#endif

// RbcDsf����
static int RbcDSF(stRbcConfigPara RbcConfigPara, stHist *pHist, stImpdCellList CellList)
{
	int  Alg_R_Dsf_RbcPeakMinTh, Alg_R_Dsf_PulseNumMinTh,i,j;
	int    rfreq[Dsf_Wide_len][Rbc_Hist_DataLen];
	int    rpct[Dsf_Wide_len] = { 0 };
	double rpcts[Dsf_Wide_len] = { 0 };
	int ValidNum = 0,vline = 0;
	double rp;

	if (!pHist)
		return -1;
	Alg_R_Dsf_RbcPeakMinTh = RbcConfigPara.Alg_R_Dsf_RbcPeakMinTh;
	Alg_R_Dsf_PulseNumMinTh = RbcConfigPara.Alg_R_Dsf_PulseNumMinTh;
	memset(rfreq, 0, sizeof(int)*Dsf_Wide_len*Rbc_Hist_DataLen);
	memset(pHist->datas, 0, sizeof(pHist->datas));

	// ������ȡ��߶ȷֲ�ֱ��ͼ
	for (i = 0; i < CellList.CellNum; i++)
	{
		if (CellList.cell_info[i].PeakValue > Alg_R_Dsf_RbcPeakMinTh)
		{
			int index = CellList.cell_info[i].PeakValue / 16;
			int width = CellList.cell_info[i].width;

			if (width >= 0 && width < Dsf_Wide_len)
			{
				rfreq[width][index]++;
			}

			ValidNum++;
		}
	}

	// ͳ����������ֱ�Ӽ���
	if (ValidNum < Alg_R_Dsf_PulseNumMinTh)
	{
		for (i = 0; i < Rbc_Hist_DataLen; i++)

		{
			for (j = 0; j < Dsf_Wide_len; j++)
			{
				pHist->datas[i] += rfreq[j][i];
			}
		}

		return 0;
	}

	// dsf����������vline
	for (i = 0; i < Dsf_Wide_len; i++)
	{
		for (j = 0; j < Rbc_Hist_DataLen; j++)
		{
			rpct[i] += rfreq[i][j];
		}
	}

	rpcts[0] = rpct[0] / ValidNum;
	for (i = 1; i < Dsf_Wide_len; i++)
	{

		rpcts[i] += rpcts[i - 1] + 1.0*rpct[i] / ValidNum;
	}

	if (rpcts[Dsf_Wide_len - 1] < Dsf_Pulse_per)
	{
		for (i = 0; i < Rbc_Hist_DataLen; i++)
		{
			for (j = 0; j < Dsf_Wide_len; j++)
			{
				pHist->datas[i] += rfreq[j][i];
			}
		}

		return 0;
	}

	for (i = 0; i < Dsf_Wide_len; i++)
	{
		if (rpcts[i] >= Dsf_Pulse_per)
		{
			vline = i - 1;
			break;
		}
	}

	// dsfֱ��ͼ����
	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		for (j = 0; j <= vline; j++)
		{
			pHist->datas[i] += rfreq[j][i];
		}
	}

	// dsfֱ��ͼ����
	rp = 1.0*(Dsf_Pulse_per - rpcts[vline]) / (rpcts[vline + 1] - rpcts[vline]);

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		pHist->datas[i] += (int)(rp*rfreq[vline + 1][i]);
	}

	return 0;
}


static int RbcHistProcess(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	int error_code;
	
	if (!RbcInput || !RbcOutput)
        return -1;

	// ���ò���
	int Alg_R_Sig_DsfHistSmoothStep = RbcInput->RbcConfigPara.Alg_R_Sig_DsfHistSmoothStep;
	int Alg_R_Sig_DsfHistSmoothDelta = RbcInput->RbcConfigPara.Alg_R_Sig_DsfHistSmoothDelta;

	// 1��RBC������������
	RbcOutput->RbcGraphPara.DspHist.datalen = Rbc_Hist_DataLen;
	RbcOutput->RbcGraphPara.DspHist.linelen = Rbc_Hist_LineLen;

	if (error_code = RbcDSF(RbcInput->RbcConfigPara,
		&(RbcOutput->RbcGraphPara.DspHist),
		RbcOutput->RbcFeaturePara.ImpdCellList))
		return error_code;

	// 2��RBC����ֱ��ͼƽ��
	curvesmooth_gauss(RbcOutput->RbcGraphPara.DspHist.datas,
		RbcOutput->RbcGraphPara.DspHist.datas,
		Rbc_Hist_DataLen,
		Alg_R_Sig_DsfHistSmoothStep,
		Alg_R_Sig_DsfHistSmoothDelta);

	// 3��RBCԭʼֱ��ͼ����
	RbcOutput->RbcGraphPara.OrgHist.datalen = 256;
	RbcOutput->RbcGraphPara.OrgHist.linelen = 2;

	gethist(&(RbcOutput->RbcGraphPara.OrgHist), 
		RbcOutput->RbcFeaturePara.ImpdCellList);

	return 0;
}

// Pltֱ��ͼ�źŴ���
static int PltHistProcess(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (!PltInput || !PltOutput)
		return -1;
	
	// ԭʼֱ��ͼ����
	PltOutput->PltGraphPara.OrgHist.datalen = 128;
	PltOutput->PltGraphPara.OrgHist.linelen = 2;

	gethist(&(PltOutput->PltGraphPara.OrgHist), PltOutput->PltFeaturePara.ImpdCellList);

	return 0;
}

/*******************************************************************
// �� �� ���� impdsigprocess
// ��    �ܣ� �迹ͨ���źŴ���
********************************************************************/
int impdsigprocess(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code,i,rbc_start_pos,rbc_end_pos,plt_start_pos,plt_end_pos;
	stImpdCellList RbcCellList1, RbcCellList2, PltCellList1, PltCellList2;
	if (!ImpdInput|| !ImpdOutput)
	{
		return -1;
	}

	// 1��DATA����ת��---------------------------------------
	// 1.1 RBC����ת��
	memset(&RbcCellList1, 0, sizeof(stImpdCellList));

	dataconvite_impd(&RbcCellList1, ImpdInput->RbcInput.DataAddr, 
		ImpdInput->RbcInput.data_num);

	memset(&RbcCellList2, 0, sizeof(stImpdCellList));

	RbcCellList2.CellNum = 0;
	RbcCellList2.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
		sizeof(stImpdPulse));
	if (ImpdInput->flag_pulse_alg == 1)
	{
		if (ImpdInput->RbcInput.alg_pos[0] == -1)
		{
			rbc_start_pos = 0;
			rbc_end_pos = RbcCellList1.CellNum;
		}
		else
		{
			rbc_start_pos = ImpdInput->RbcInput.alg_pos[0];
			rbc_end_pos = ImpdInput->RbcInput.alg_pos[1];
		}
		//for (int i = 0; i < RbcCellList1.CellNum; i++)
		for (i = rbc_start_pos; i < rbc_end_pos; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].FullWidth < 60
				&& RbcCellList1.cell_info[i].FullWidth > 8
				&& RbcCellList1.cell_info[i].PriWidth < 24
				&& RbcCellList1.cell_info[i].PriWidth  > 2
				&& RbcCellList1.cell_info[i].SubWidth < 22
				&& RbcCellList1.cell_info[i].SubWidth  > 2
				&& RbcCellList1.cell_info[i].PriWidth + 
				RbcCellList1.cell_info[i].SubWidth < 35
				&& RbcCellList1.cell_info[i].PriWidth + 
				RbcCellList1.cell_info[i].SubWidth > 4
				&& RbcCellList1.cell_info[i].PeakValue < 4096
				&& RbcCellList1.cell_info[i].PeakValue > 100
				)
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]), &(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}
		RbcCellList2.nps_num = RbcCellList1.nps_num;
		RbcCellList2.cell_nps = (short *)calloc(RbcCellList2.nps_num, 
			sizeof(short));
		memcpy(RbcCellList2.cell_nps, RbcCellList1.cell_nps, 
			RbcCellList2.nps_num * sizeof(short));

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;
		ImpdOutput->RbcOutput.RbcServicePara.rbc_org_num = RbcCellList1.CellNum;
		FREE_POINTER(RbcCellList1.cell_info);
		FREE_POINTER(RbcCellList1.cell_nps);
		RbcCellList1.CellNum = 0;

		// 1.2 PLT����ת��
		memset(&PltCellList1, 0, sizeof(stImpdCellList));

		dataconvite_impd(&PltCellList1, ImpdInput->PltInput.DataAddr, 
			ImpdInput->PltInput.data_num);

		memset(&PltCellList2, 0, sizeof(stImpdCellList));

		PltCellList2.CellNum = 0;
		PltCellList2.cell_info = (stImpdPulse *)calloc(PltCellList1.CellNum,
			sizeof(stImpdPulse));

		if (ImpdInput->PltInput.alg_pos[0] == -1)
		{
			plt_start_pos = 0;
			plt_end_pos = PltCellList1.CellNum;
		}
		else
		{
			plt_start_pos = ImpdInput->PltInput.alg_pos[0];
			plt_end_pos = ImpdInput->PltInput.alg_pos[1];
		}
		//for (int i = 0; i < PltCellList1.CellNum; i++)
		for (i = plt_start_pos; i < plt_end_pos; i++)
		{
			// ������Ч���ж�
			/*if (PltCellList1.cell_info[i].FullWidth < 200
				&& PltCellList1.cell_info[i].FullWidth > 12
				&& PltCellList1.cell_info[i].PriWidth < 50
				&& PltCellList1.cell_info[i].PriWidth  > 3
				&& PltCellList1.cell_info[i].SubWidth < 40
				&& PltCellList1.cell_info[i].SubWidth  > 1
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth < 80
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth > 10
				&& PltCellList1.cell_info[i].PeakValue < 2200
				&& PltCellList1.cell_info[i].PeakValue > 120
				)*/
			if (PltCellList1.cell_info[i].FullWidth < 60
				&& PltCellList1.cell_info[i].FullWidth > 8
				&& PltCellList1.cell_info[i].PriWidth < 13
				&& PltCellList1.cell_info[i].PriWidth  > 3
				&& PltCellList1.cell_info[i].SubWidth < 24
				&& PltCellList1.cell_info[i].SubWidth  > 3
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth < 56
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth > 7
				&& PltCellList1.cell_info[i].PeakValue < 4096
				&& PltCellList1.cell_info[i].PeakValue > 255
				)
			{
				memcpy(&(PltCellList2.cell_info[PltCellList2.CellNum]), &(PltCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList2.CellNum++;
			}
		}

		PltCellList2.nps_num = PltCellList1.nps_num;
		PltCellList2.cell_nps = (short *)calloc(PltCellList2.nps_num,
			sizeof(short));
		memcpy(PltCellList2.cell_nps, PltCellList1.cell_nps,
			PltCellList2.nps_num * sizeof(short));
		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList2;
		ImpdOutput->PltOutput.PltServicePara.plt_org_num = PltCellList1.CellNum;

		FREE_POINTER(PltCellList1.cell_info);
		FREE_POINTER(PltCellList1.cell_nps);
		PltCellList1.CellNum = 0;
	} 
	else if (ImpdInput->flag_pulse_alg == 2)
	{
		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue >=
				(int)(16.7 * 40 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;

		// 1.2 PLT����ת��
		memset(&PltCellList1, 0, sizeof(stImpdCellList));
		PltCellList1.CellNum = 0;
		PltCellList1.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
			sizeof(stImpdPulse));

		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue <
				(int)(16.7 * 50 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(PltCellList1.cell_info[PltCellList1.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList1.CellNum++;
			}
		}
		FREE_POINTER(RbcCellList1.cell_info);

		for (i = 0; i < PltCellList1.CellNum; i++)
			PltCellList1.cell_info[i].PeakValue *= 4;

		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList1;
	}
	
	
	// 2���¿��ж�
	

	// 3��RBCͨ���źŴ���
	if(error_code = RbcHistProcess(&(ImpdInput->RbcInput), 
		&(ImpdOutput->RbcOutput)))
		return error_code;
	
	// 4��PLTͨ���źŴ���
	if(error_code = PltHistProcess(&(ImpdInput->PltInput), 
		&(ImpdOutput->PltOutput)))
		return error_code;
	return 0;
}

// ͳ�Ʒ������ֽ���
static int RbcPltDivide_Statistics(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int i, DivideLine,MaxAValue,MaxAPos,MinBValue, MinBPos, MaxCValue, MaxCPos;
	int *RbcPltHist;
	double NegParticleLine = 0.0;
	double NegParticleSwarm[Plt_Hist_DataLen];
	double SumDen = 0.0;
	double SumNum = 0.0;


	// �㷨���ò���
	int    Alg_I_Divide_DefaultDivideLine = ImpdInput->DivConfigPara.Alg_I_Divide_DefaultDivideLine;     // Ĭ��RBC/PLT�ֽ���
	int    Alg_I_Divide_MinLine = ImpdInput->DivConfigPara.Alg_I_Divide_MinLine;               // �ֽ��������
	int    Alg_I_Divide_MaxLine = ImpdInput->DivConfigPara.Alg_I_Divide_MaxLine;               // �ֽ��������
	 
	int    Alg_I_Divide_GaussSmoothStep = ImpdInput->DivConfigPara.Alg_I_Divide_GaussSmoothStep;       // ��˹ƽ������С
	int    Alg_I_Divide_GaussSmoothDelta = ImpdInput->DivConfigPara.Alg_I_Divide_GaussSmoothDelta;      // ��˹ƽ����׼�� 
	int    Alg_I_Divide_FirstPeakEndPos = ImpdInput->DivConfigPara.Alg_I_Divide_FirstPeakEndPos;       // ��һ����Ľ�ֹλ��
	int    Alg_I_Divide_FirstVolEndPos = ImpdInput->DivConfigPara.Alg_I_Divide_FirstVolEndPos;        // ��һ���ȵĽ�ֹλ��
	double Alg_I_Divide_NegParticleLinePer = ImpdInput->DivConfigPara.Alg_I_Divide_NegParticleLinePer;    // ��Ч������Ⱥ�ٷֱ�
	int    Alg_I_Divide_DivideK = ImpdInput->DivConfigPara.Alg_I_Divide_DivideK;               // ͳ�Ʒ������ֽ��߽���

	DivideLine = Alg_I_Divide_DefaultDivideLine;

	

	if (!ImpdInput || !ImpdOutput)
		return -1;

	// 1 ͳ�Ʒ������ֽ���
	
	RbcPltHist = (int *)calloc(Plt_Hist_DataLen,sizeof(int));

	if (RbcPltHist == NULL)
	{
		ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;
		return 101;
	}

	memcpy(RbcPltHist, ImpdOutput->PltOutput.PltGraphPara.OrgHist.datas, sizeof(int)*Plt_Hist_DataLen);

	curvesmooth_gauss(RbcPltHist, RbcPltHist, Plt_Hist_DataLen,
		Alg_I_Divide_GaussSmoothStep, Alg_I_Divide_GaussSmoothDelta);

	curvesmooth_gauss(RbcPltHist, RbcPltHist, Plt_Hist_DataLen,
		Alg_I_Divide_GaussSmoothStep, Alg_I_Divide_GaussSmoothDelta);


	// 1.1 ��ǰ48ͨ�����ֵ
	MaxAValue = 0;
	MaxAPos = 0;

	for (i = 0; i < Alg_I_Divide_FirstPeakEndPos; i++)
	{
		if (MaxAValue < RbcPltHist[i])
		{
			MaxAValue = RbcPltHist[i];
			MaxAPos = i;
		}
	}

	// 1.2 �����ֵ��96ͨ����Сֵ
	MinBValue = MaxAValue;
	MinBPos = MaxAPos;

	for (i = MinBPos; i < Alg_I_Divide_FirstVolEndPos; i++)
	{
		if (MinBValue > RbcPltHist[i])
		{
			MinBValue = RbcPltHist[i];
			MinBPos = i;
		}
	}

	// δ�ҵ���Сֵ���˳�
	if (MaxAValue <= MinBValue)
	{
		FREE_POINTER(RbcPltHist);
		ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;
		return 0;
	}

	// 1.3 ����Сֵ������ֵ
	MaxCValue = 0;
	MaxCPos = 0;

	for (i = MinBPos; i < Plt_Hist_DataLen; i++)
	{
		if (MaxCValue < RbcPltHist[i])
		{
			MaxCValue = RbcPltHist[i];
			MaxCPos = i;
		}
	}

	// δ�ҵ���С֮������ֵ���˳�
	if (MaxCPos == 0)
	{
		FREE_POINTER(RbcPltHist);
		ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;
		return 0;
	}

	// 1.4 �����Ч������Ⱥ
	

	if (MaxAValue < MaxCValue)
	{
		NegParticleLine = Alg_I_Divide_NegParticleLinePer*(MaxAValue - MinBValue) + MinBValue;
	}
	else
	{
		NegParticleLine = Alg_I_Divide_NegParticleLinePer*(MaxCValue - MinBValue) + MinBValue;
	}

	memset(NegParticleSwarm, 0, sizeof(double)*Plt_Hist_DataLen);

	for (i = MaxAPos; i < MaxCPos; i++)
	{
		NegParticleSwarm[i] = NegParticleLine - RbcPltHist[i];

		if (NegParticleSwarm[i] < 0)
		{
			NegParticleSwarm[i] = 0;
		}
	}

	
	for (i = 0; i < Plt_Hist_DataLen; i++)
	{
		SumDen += pow(1.0*NegParticleSwarm[i], Alg_I_Divide_DivideK);
		SumNum += i*pow(1.0*NegParticleSwarm[i], Alg_I_Divide_DivideK);
	}

	if (SumDen > EPSILON)
	{
		DivideLine = (int)(SumNum / SumDen);
	}

	if (DivideLine > Alg_I_Divide_MaxLine)
	{
		DivideLine = Alg_I_Divide_MaxLine;
	}

	if (DivideLine < Alg_I_Divide_MinLine)
	{
		DivideLine = Alg_I_Divide_MinLine;
	}

	FREE_POINTER(RbcPltHist);

	ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;

	return 0;
}

static int RbcPltDivide_CurveFit(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int i, DivideLine, LeftMean, RightMean, DivideLine_PLT,DivideLine_Rbc;
	int *RbcHist ,*FitHist;
	int    MaxValue = 0;
	int    MaxPos = 0;
	int    Mean = 0;
	double Delta = 0.0;
	int MinFitError = 10000000;
	int FitError = 0;
	int     TempMean = 0;
	double  TempDelta = 0.0;
	int TempCellNum1 = 0;
	int TempCellNum2 = 0;


	// �㷨���ò���
	int    Alg_I_RbcPltDivide_MinLine = ImpdInput->DivConfigPara.Alg_I_Divide_MinLine;               // �ֽ��������
	int    Alg_I_RbcPltDivide_MaxLine = ImpdInput->DivConfigPara.Alg_I_Divide_MaxLine;               // �ֽ��������
	int    FitCurveMeanMinth = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveMeanMinth;     // �������Mean��Сֵ
	int    FitCurveMeanMaxth = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveMeanMaxth;     // �������Mean���ֵ
	double FitCurveDeltaMinth = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaMinth;    // �������Delta��Сֵ
	double FitCurveDeltaMaxth = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaMaxth;    // �������Delta���ֵ
	double FitCurveDeltaStep = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveDeltaStep;     // �������Delta����
	double FitCurveFitErrorPer = ImpdInput->DivConfigPara.Alg_I_Divide_FitCurveFitErrorPer;   // �������������ٷֱ�

	DivideLine = ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine;

	if (!ImpdInput || !ImpdOutput)
		return -1;

	// 1 ��ȡֱ��ͼ��Ϣ
	RbcHist = (int*)calloc(Rbc_Hist_DataLen, sizeof(int));
	FitHist = (int*)calloc(Rbc_Hist_DataLen, sizeof(int));

	if (RbcHist == NULL	|| FitHist == NULL)
	{
		FREE_POINTER(RbcHist);
		FREE_POINTER(FitHist);

		ImpdOutput->RbcOutput.RbcServicePara.RbcPltDivideLine = DivideLine / 2;
		ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;

		return 102;
	}

	memcpy(RbcHist, ImpdOutput->RbcOutput.RbcGraphPara.DspHist.datas, sizeof(int)*Rbc_Hist_DataLen);
	memset(FitHist, 0, sizeof(int)*Rbc_Hist_DataLen);

	// 2 ��ȡֱ��ͼ��ϲ���
	
	// 2.1 ��RBCֱ��ͼ���ֵ����λ��
	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		if (MaxValue < RbcHist[i])
		{
			MaxValue = RbcHist[i];
			MaxPos = i;
		}
	}

	if (MaxValue <= 0)
	{
		FREE_POINTER(RbcHist);
		FREE_POINTER(FitHist);

		ImpdOutput->RbcOutput.RbcServicePara.RbcPltDivideLine = DivideLine / 2;
		ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;

		return 0;
	}

	// 2.2 ��С������
	
	LeftMean = MaxPos - FitCurveMeanMinth;
	RightMean = MaxPos + FitCurveMeanMaxth;

	LeftMean = LeftMean > 0 ? LeftMean : 0;
	LeftMean = LeftMean < Rbc_Hist_DataLen ? LeftMean : Rbc_Hist_DataLen - 1;

	RightMean = RightMean > 0 ? RightMean : 0;
	RightMean = RightMean < Rbc_Hist_DataLen ? RightMean : Rbc_Hist_DataLen - 1;

	for (TempMean = LeftMean; TempMean < RightMean; TempMean++)
	{
		for (TempDelta = FitCurveDeltaMinth; TempDelta < FitCurveDeltaMaxth; TempDelta += FitCurveDeltaStep)
		{
			// ���ֱ��ͼ����
			for (i = 0; i < Rbc_Hist_DataLen; i++)
			{
				FitHist[i] = (int)(MaxValue*exp(-1.0*(i - TempMean)*(i - TempMean) / (2 * TempDelta*TempDelta)) + 0.5);
			}

			FitError = 0;

			for (i = MaxPos; i < Rbc_Hist_DataLen; i++)
			{
				if (RbcHist[i] < FitCurveFitErrorPer*MaxValue)
				{
					break;
				}

				FitError += (RbcHist[i] - FitHist[i])*(RbcHist[i] - FitHist[i]);
			}

			if (MinFitError > FitError)
			{
				MinFitError = FitError;

				Mean = TempMean;
				Delta = TempDelta;
			}
		}
	}

	// 2.3 ���ֱ��ͼ����
	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		FitHist[i] = (int)(MaxValue*exp(-1.0*(i - Mean)*(i - Mean) / (2 * Delta*Delta)) + 0.5);
	}

	// 3 �ֽ���΢��
	DivideLine_PLT = DivideLine;
	DivideLine_Rbc = DivideLine / 2;
	for (i = 0; i < DivideLine_Rbc; i++)
	{
		TempCellNum1 += FitHist[i];
	}

	for (i = DivideLine_PLT; i > 0; i--)
	{
		TempCellNum2 += ImpdOutput->PltOutput.PltGraphPara.OrgHist.datas[i];

		if (TempCellNum2 > TempCellNum1)
		{
			DivideLine_PLT = i;

			break;
		}
	}

	// �ֽ���λ���޶�
	DivideLine = DivideLine_PLT;

	if (DivideLine < Alg_I_RbcPltDivide_MinLine)
	{
		DivideLine = Alg_I_RbcPltDivide_MinLine;
	}
	else if (DivideLine > Alg_I_RbcPltDivide_MaxLine)
	{
		DivideLine = Alg_I_RbcPltDivide_MaxLine;
	}

	FREE_POINTER(RbcHist);
	FREE_POINTER(FitHist);

	ImpdOutput->RbcOutput.RbcServicePara.RbcPltDivideLine = DivideLine / 2;
	ImpdOutput->PltOutput.PltServicePara.RbcPltDivideLine = DivideLine;

	return 0;
}

static int impdclassify(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput || !ImpdOutput)
		return -1;
	
	// 1��ͳ�Ʒ������ֽ���
	if(error_code = RbcPltDivide_Statistics(ImpdInput, ImpdOutput))
		return error_code;
	

	// 2��ֱ��ͼ��Ϸֽ��ߵ���
	if(error_code = RbcPltDivide_CurveFit(ImpdInput, ImpdOutput))
		return error_code;
	return 0;
}

// RBCֱ��ͼ����
static void BuildRbcHist(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	int firstline, secondline, i;
	// 1 ��ʾֱ��ͼ����

	// 2 ��һ�ֽ�������
	firstline = RbcOutput->RbcServicePara.RbcPltDivideLine;

	// 3 �ڶ��ֽ�������
	secondline = 250;

	for (i = secondline; i > 1; i--)
	{
		if (RbcOutput->RbcGraphPara.DspHist.datas[i] > 0
			&& RbcOutput->RbcGraphPara.DspHist.datas[i] <= RbcOutput->RbcGraphPara.DspHist.datas[i - 1])
		{
			secondline = i;
			break;
		}
	}

	if (secondline < 230)
	{
		secondline = 230;
	}

	RbcOutput->RbcGraphPara.OrgHist.lines[0] = firstline;
	RbcOutput->RbcGraphPara.DspHist.lines[0] = firstline;

	RbcOutput->RbcGraphPara.OrgHist.lines[1] = secondline;
	RbcOutput->RbcGraphPara.DspHist.lines[1] = secondline;

	return ;
}

static int RbcCompensation(int RbcTotal, double dExpCoff)
{
	int RbcTotalNum;
	double tmpdouble, tmpRbcCompFac, tmpRbcTotal;
	// one
	tmpdouble = dExpCoff*RbcTotal*0.000001;
	tmpRbcCompFac = (exp(-1 * tmpdouble) + exp(-2 * tmpdouble) + 1) / 3;
	tmpRbcTotal = RbcTotal / tmpRbcCompFac;

	// two
	tmpdouble = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac = (exp(-1 * tmpdouble) + exp(-2 * tmpdouble) + 1) / 3;
	tmpRbcTotal = RbcTotal / tmpRbcCompFac;

	// three
	tmpdouble = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac = (exp(-1 * tmpdouble) + exp(-2 * tmpdouble) + 1) / 3;
	tmpRbcTotal = RbcTotal / tmpRbcCompFac;

	// four
	tmpdouble = dExpCoff*tmpRbcTotal*0.000001;
	tmpRbcCompFac = (exp(-1 * tmpdouble) + exp(-2 * tmpdouble) + 1) / 3;

	RbcTotalNum = (int)(RbcTotal / tmpRbcCompFac);

	return RbcTotalNum;
}

// RBC����̬�������㣨RBC��
static void RbcNoShapeParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	int     SubBackGround = RbcInput->RbcConfigPara.Alg_R_Cal_SubBackGround;
	double  fRbcExpCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRbcExpCoff;
	int    i, RbcTotal = 0;
	double dRbc, Dilution, Volume;
	double MeasureTime = RbcInput->MeasureTime;
	double rbc_factory_cal_factor, rbc_user_cal_factor;

	// 1������RBC������
	// 1.1������RBCʶ��������
	
	for (i = RbcOutput->RbcGraphPara.OrgHist.lines[0]; 
		i <= RbcOutput->RbcGraphPara.OrgHist.lines[1]; i++)
	{
		RbcTotal += RbcOutput->RbcGraphPara.OrgHist.datas[i];
	}

	// 1.2�����Ӳ���
	// ʱ�����Ӳ�������
	/*double MeasureTime = RbcInput->MeasureTime;
	double TraverseTime = RbcOutput->RbcFeaturePara.TraverseTime;

	if (TraverseTime > EPSINON)
	{
		RbcTotal = (int)(1.0*RbcTotal / TraverseTime*MeasureTime + 0.5);
	}*/
	dRbc = 0.0;
	if (RbcInput->RbcConfigPara.rbc_compensation_plan == 0)
	{
		// ���Ӳ���
		RbcTotal = RbcCompensation(RbcTotal, fRbcExpCoff);

		// ������
		RbcTotal -= SubBackGround;

		RbcOutput->RbcServicePara.RbcTotalNum = RbcTotal;

		// 1.3��Rbcֵ����
		dRbc = 0.0;
		Dilution = RbcInput->Dilution;
		Volume = RbcInput->Volume;

		if (Volume > EPSILON)
		{
			dRbc = RbcTotal * Dilution / Volume / 1000000;
			dRbc = 0.0184*dRbc*dRbc + 0.9297*dRbc - 0.02443;
		}
			

		if (dRbc < EPSILON)
			dRbc = 0.0;
	} 
	else if (RbcInput->RbcConfigPara.rbc_compensation_plan == 1)
	{
		RbcOutput->RbcServicePara.RbcTotalNum = RbcTotal;
		Dilution = RbcInput->Dilution;
		Volume = RbcInput->Volume;
		dRbc = (double)RbcTotal * Dilution / Volume / 1000000;
		dRbc = dRbc * 10 / MeasureTime;

		if (dRbc < 3.50 || dRbc > 5.0)
			dRbc = 0.0184*dRbc*dRbc + 0.9297*dRbc - 0.02443;
		if (dRbc < EPSILON)
			dRbc = 0.0;
	}
	// ����У׼
	rbc_factory_cal_factor = RbcInput->RbcConfigPara.rbc_factory_cal_factor;
	rbc_user_cal_factor = RbcInput->RbcConfigPara.rbc_user_cal_factor;
	printf("RBC_factory_cal_factor: %5.4f\n", rbc_factory_cal_factor);
	printf("RBC_user_cal_factor: %5.4f\n", rbc_user_cal_factor);
	dRbc = dRbc * rbc_factory_cal_factor * rbc_user_cal_factor;

	RbcOutput->RbcReportPara.Rbc = dRbc;

	return ;
}

// RBC��̬�������㣨MCV/RDW_SD/RDW_CV��
static void RbcShapeParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	double dMcvAdjustCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dMcvAdjustCoff;
	double dRdwBaseLinePer = RbcInput->RbcConfigPara.Alg_R_Cal_RdwBaseLinePer;
	double dRdwsdAdjustCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRdwSdAdjustCoff;
	double dRdwCvAdjustCoff = RbcInput->RbcConfigPara.Alg_R_Cal_dRdwCvAdjustCoff;
	double dMcv = 0;
	double dSumDen = 0.0;
	double dSumNum = 0.0;
	double dRdw_sd = 0.0;
	double dRdw_cv = 0.0;
	double dmean = 0.0;
	double dSD = 0.0;
	int i, FirstLine, SecondLine, Peaky, j, rdw_line[2];
	int RbcTmpHist[Rbc_Hist_DataLen] = { 0 };
	double mcv_factory_cal_factor, mcv_user_cal_factor;


	FirstLine = RbcOutput->RbcGraphPara.DspHist.lines[0];
	SecondLine = RbcOutput->RbcGraphPara.DspHist.lines[1];

	// MCV����
	
	for (i = FirstLine; i <= SecondLine; i++)
	{
		dSumDen += RbcOutput->RbcGraphPara.OrgHist.datas[i];
		dSumNum += i*RbcOutput->RbcGraphPara.OrgHist.datas[i];
	}

#ifdef GAUSS_FIT
	RbcOutput->RbcGraphPara.OrgHist = RbcOutput->RbcGraphPara.DspHist;
	dMcv = gsl_gauss_fit(&RbcOutput->RbcGraphPara.DspHist) *
		320 / Rbc_Hist_DataLen;
	if (RbcOutput->RbcFeaturePara.BimodalityFlag)
	{
		RbcOutput->RbcGraphPara.DspHist = RbcOutput->RbcGraphPara.OrgHist;
	}
#else
	if (dSumDen > EPSILON)
	{
		dMcv = dMcvAdjustCoff*dSumNum / dSumDen * 320 / Rbc_Hist_DataLen;
	}
#endif
	
	// ����У׼
	mcv_factory_cal_factor = RbcInput->RbcConfigPara.mcv_factory_cal_factor;
	mcv_user_cal_factor = RbcInput->RbcConfigPara.mcv_user_cal_factor;
	printf("MCV_factory_cal_factor: %5.4f\n", mcv_factory_cal_factor);
	printf("MCV_user_cal_factor: %5.4f\n", mcv_user_cal_factor);
	dMcv = dMcv * mcv_factory_cal_factor * mcv_user_cal_factor;

	RbcOutput->RbcReportPara.Mcv = dMcv;
	RbcOutput->RbcReportPara.hct = RbcOutput->RbcReportPara.Rbc * dMcv / 10.0;

	// RDW_CV/RDW_SD����
	
	// 1 ����ֱ��ͼ����ȡ5%��ֵ���²��֣�
	
	Peaky = 0;
	for (i = FirstLine; i <= SecondLine; i++)
	{
		if (Peaky < RbcOutput->RbcGraphPara.DspHist.datas[i])
		{
			Peaky = RbcOutput->RbcGraphPara.DspHist.datas[i];
		}
	}

	for (i = FirstLine; i <= SecondLine; i++)
	{
		if (RbcOutput->RbcGraphPara.DspHist.datas[i] > dRdwBaseLinePer*Peaky)
		{
			RbcTmpHist[i] = RbcOutput->RbcGraphPara.DspHist.datas[i];
		}
	}

	// 2 ���ֵ
	dSumDen = 0.0;
	dSumNum = 0.0;

	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		dSumDen += RbcTmpHist[i];
		dSumNum += i*RbcTmpHist[i];
	}

	if (dSumDen > 0)
	{
		dmean = dSumNum / dSumDen;
	}

	// 3 �󷽲�
	dSumNum = 0.0;
	for (i = 0; i < Rbc_Hist_DataLen; i++)
	{
		dSumNum += (i - dmean)*(i - dmean)*RbcTmpHist[i];
	}

	if (dSumDen > 0)
	{
		dSD = dSumNum / dSumDen;
	}

	// Rdw_Cv����
	// dRdw_sd = dRdwsdAdjustCoff*sqrt(dSD) * 320 / Rbc_Hist_DataLen;

	if (dmean > 0)
	{
		dRdw_cv = dRdwCvAdjustCoff*sqrt(dSD) / dmean;
	}
	// rdw_sd���㣬20171106����sysmex�������
	j = 0;
	memset(rdw_line, 0, sizeof(int) * 2);
	for (i = FirstLine; i <= SecondLine; i++)
	{
		if (j == 0)
		{
			if (RbcOutput->RbcGraphPara.DspHist.datas[i] >= 0.2*Peaky)
				rdw_line[j++] = i;
		}
		else if (j == 1)
		{
			if (RbcOutput->RbcGraphPara.DspHist.datas[i] <= 0.2*Peaky)
				rdw_line[j++] = i;
		}
		else if (j == 2)
			break;
	}
	dRdw_sd = dRdwsdAdjustCoff * (double)(rdw_line[1] - rdw_line[0]) * 320 / Rbc_Hist_DataLen;
	printf("rdw_sd modified value: %f\n", dRdw_sd);
	RbcOutput->RbcReportPara.Rdw_sd = dRdw_sd > 0 ? dRdw_sd : 0;
	RbcOutput->RbcReportPara.Rdw_cv = dRdw_cv;

	return ;
}

// RBC�����������㣨Skewness/Kurtosis��
bool RbcFeatureParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (RbcInput == NULL
		|| RbcOutput == NULL)
	{
		return false;
	}

	RbcOutput->RbcFeaturePara.BimodalityFlag = get_bimodality_flag(&RbcOutput->
		RbcGraphPara.DspHist);

	return true;
}

/*******************************************************************
// Rbcͨ����������
********************************************************************/
static int RbcParaCal(stRbcInput *RbcInput, stRbcOutput *RbcOutput)
{
	if (!RbcInput || !RbcOutput)
	{
		return -1;
	}

	// 1 ֱ��ͼ�ֽ�������
	BuildRbcHist(RbcInput, RbcOutput);

	// 3 ������������
	RbcFeatureParaCal(RbcInput, RbcOutput);

	// 2 �����������
	// 2.1 ����̬��������
	RbcNoShapeParaCal(RbcInput, RbcOutput);

	// 2.2 ��̬��������
	RbcShapeParaCal(RbcInput, RbcOutput);
	

	

	return 0;
}

// PLTֱ��ͼ�ֽ�������
static void BuildPltHist(stPltInput *PltInput, stPltOutput *PltOutput)
{
	
	int i, firstline, secondline;

	// 1 ֱ��ͼ����
	PltOutput->PltGraphPara.DspHist = PltOutput->PltGraphPara.OrgHist;
	PltOutput->PltGraphPara.DspHist.datalen = 128;

	curvesmooth_gauss(PltOutput->PltGraphPara.DspHist.datas,
		PltOutput->PltGraphPara.DspHist.datas, Plt_Hist_DataLen, 4, 2);

	curvesmooth_gauss(PltOutput->PltGraphPara.DspHist.datas,
		PltOutput->PltGraphPara.DspHist.datas, Plt_Hist_DataLen, 4, 2);

	// 2 ��һ�ֽ���
	firstline = 0;
	for (i = 0; i < Plt_Hist_DataLen; i++)
	{
		if (PltOutput->PltGraphPara.OrgHist.datas[i] > 0)
		{
			firstline = i;
			break;
		}
	}

	// 3 �ڶ��ֽ���
	secondline = PltOutput->PltServicePara.RbcPltDivideLine;
	secondline = 48;
	PltOutput->PltGraphPara.OrgHist.lines[0] = firstline;
	PltOutput->PltGraphPara.DspHist.lines[0] = firstline;

	PltOutput->PltGraphPara.OrgHist.lines[1] = secondline;
	PltOutput->PltGraphPara.DspHist.lines[1] = secondline;

	return ;
}

// PLT����̬�������㣨PLT��
static void PltNoShapeParaCal_offline(stPltInput *PltInput, stPltOutput *PltOutput)
{

	/*int     SubBackGround = PltInput->PltConfigPara.Alg_P_Cal_SubBackGround;
	double  fPltExpCoff = PltInput->PltConfigPara.Alg_P_Cal_dPltExpCoff;*/
	double MeasureTime = PltInput->MeasureTime;
	double  dPlt, Volume, Dilution;
	double plt_factory_cal_factor, plt_user_cal_factor;
	int i, PltTotal;


	// 1��PLTֵ����
	// 1.1������PLTʶ��������
	PltTotal = 0;
	for (i = PltOutput->PltGraphPara.OrgHist.lines[0]; i <= PltOutput->PltGraphPara.OrgHist.lines[1]; i++)
	{
		PltTotal += PltOutput->PltGraphPara.OrgHist.datas[i];
	}

	// 1.2�����Ӳ���
	// ʱ�����Ӳ�������
	/*
	if (TraverseTime > EPSINON)
	{
	PltTotal = (int)(1.0*PltTotal / TraverseTime*MeasureTime + 0.5);
	}*/

	// ������
	PltTotal -= 50;
	if (PltTotal < 0)
		PltTotal = 0;

	PltOutput->PltServicePara.PltTotalNum = PltTotal;

	// 1.3��Pltֵ����
	Volume = PltInput->Volume;
	Dilution = PltInput->Dilution;

	dPlt = (double)PltTotal*Dilution / Volume / 1000;
	dPlt = dPlt * 10 / MeasureTime;
	//
	//dPlt *= 1.7;
	// ����У׼
	plt_factory_cal_factor = PltInput->PltConfigPara.plt_factory_cal_factor;
	plt_user_cal_factor = PltInput->PltConfigPara.plt_user_cal_factor;
	printf("PLT_factory_cal_factor: %5.4f\n", plt_factory_cal_factor);
	printf("PLT_user_cal_factor: %5.4f\n", plt_user_cal_factor);
	dPlt = dPlt * plt_factory_cal_factor * plt_user_cal_factor;

	PltOutput->PltReportPara.Plt = dPlt;

	return;
}

// PLT����̬�������㣨PLT��
static void PltNoShapeParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	
	/*int     SubBackGround = PltInput->PltConfigPara.Alg_P_Cal_SubBackGround;
	double  fPltExpCoff = PltInput->PltConfigPara.Alg_P_Cal_dPltExpCoff;*/
	/*double MeasureTime = PltInput->MeasureTime;
	double TraverseTime = PltOutput->PltFeaturePara.TraverseTime;*/
	double MeasureTime = PltInput->MeasureTime;
	double  dPlt, Volume, Dilution;
	double plt_factory_cal_factor, plt_user_cal_factor;
	int i, PltTotal;


	// 1��PLTֵ����
	// 1.1������PLTʶ��������
	PltTotal = 0;
	for (i = PltOutput->PltGraphPara.OrgHist.lines[0]; i <= PltOutput->PltGraphPara.OrgHist.lines[1]; i++)
	{
		PltTotal += PltOutput->PltGraphPara.OrgHist.datas[i];
	}

	// 1.2�����Ӳ���
	// ʱ�����Ӳ�������
	/*
	if (TraverseTime > EPSINON)
	{
		PltTotal = (int)(1.0*PltTotal / TraverseTime*MeasureTime + 0.5);
	}*/

	// ������
	PltTotal -= 50;
	if (PltTotal < 0)
		PltTotal = 0;

	// ���Ӳ���
	//RbcTotal = PltInput->RbcTotalNum;
	//PltTotal = PltCompensation(RbcTotal, PltTotal, fPltExpCoff);

	PltOutput->PltServicePara.PltTotalNum = PltTotal;

	// 1.3��Pltֵ����
	Volume = PltInput->Volume;
	Dilution = PltInput->Dilution;

	dPlt = (double)PltTotal*Dilution / Volume / 1000;
	//dPlt = 5.788 * dPlt * dPlt + 92.9 * dPlt;
	dPlt = dPlt * 10 / MeasureTime;//0823������
	dPlt = dPlt * 1.62;
	
	/*if (Volume > EPSINON)
	{
		dPlt = PltTotal * Dilution / Volume / 1000;
	}

	if (dPlt < EPSINON)
	{
		dPlt = 0;
	}*/

	// ����У׼
	plt_factory_cal_factor = PltInput->PltConfigPara.plt_factory_cal_factor;
	plt_user_cal_factor = PltInput->PltConfigPara.plt_user_cal_factor;
	printf("PLT_factory_cal_factor: %5.4f\n", plt_factory_cal_factor);
	printf("PLT_user_cal_factor: %5.4f\n", plt_user_cal_factor);
	dPlt = dPlt * plt_factory_cal_factor * plt_user_cal_factor;

	PltOutput->PltReportPara.Plt = dPlt;

	return ;
}

// PLT��̬�������㣨MPV/PDW/PLCR/PLCC��
static void PltShapeParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	
	double Alg_P_Cal_dMpvAdjustCoff = PltInput->PltConfigPara.Alg_P_Cal_dMpvAdjustCoff;
	//double Alg_P_Cal_dPdwBaseLinePer = PltInput->PltConfigPara.Alg_P_Cal_dPdwBaseLinePer;
	double Alg_P_Cal_dPdwAdjustCoff = PltInput->PltConfigPara.Alg_P_Cal_dPdwAdjustCoff;
	int    Alg_P_Cal_LargePltTh = PltInput->PltConfigPara.Alg_P_Cal_LargePltTh;
	int i = 0, peak_value, pdw_line[2],j;
	double dMpv, dSumDen, dSumNum, dPdw, dSum1, dSum2, dSum3, dPltTotal, dPlcr,
		dPlcc;

	// 1 MPV����
	dMpv = 0;
	dSumDen = 0.0;
	dSumNum = 0.0;

	for (i = PltOutput->PltGraphPara.DspHist.lines[0]; i < PltOutput->PltGraphPara.DspHist.lines[1]; i++)
	{
		dSumDen += PltOutput->PltGraphPara.DspHist.datas[i];
		dSumNum += i*PltOutput->PltGraphPara.DspHist.datas[i];
	}

	if (dSumDen > EPSILON)
	{
		dMpv = Alg_P_Cal_dMpvAdjustCoff*dSumNum / dSumDen * 40 / 64;
	}

	PltOutput->PltReportPara.Mpv = dMpv;
	PltOutput->PltReportPara.pct = PltOutput->PltReportPara.Plt * dMpv / 10000;

	// 2 PDW����,20171106�޸ģ�����sysmex�������
	dPdw = 0.0;

	dSum1 = 0.0;
	dSum2 = 0.0;
	dSum3 = 0.0;

	/*for (i = PltOutput->PltGraphPara.DspHist.lines[0]; i < PltOutput->PltGraphPara.DspHist.lines[1]; i++)
	{
		dSum1 += PltOutput->PltGraphPara.DspHist.datas[i] * log(i + 0.1)*log(i + 0.1);
		dSum2 += PltOutput->PltGraphPara.DspHist.datas[i] * log(i + 0.1);
		dSum3 += PltOutput->PltGraphPara.DspHist.datas[i];
	}

	if (dSum3 > EPSINON)
	{
		dPdw = Alg_P_Cal_dPdwAdjustCoff*exp(sqrt((dSum1 - dSum2*dSum2 / dSum3) / dSum3));
	}*/
	peak_value = 0;
	for (i = PltOutput->PltGraphPara.DspHist.lines[0]; i < PltOutput->PltGraphPara.DspHist.lines[1]; i++)
	{
		if (peak_value < PltOutput->PltGraphPara.DspHist.datas[i])
			peak_value = PltOutput->PltGraphPara.DspHist.datas[i];
	}
	

	j = 0;
	for (i = PltOutput->PltGraphPara.DspHist.lines[0]; i <= 64; i++)
	{
		if (j == 0)
		{
			if (PltOutput->PltGraphPara.DspHist.datas[i] >= 0.2*peak_value)
				pdw_line[j++] = i;
		}
		else if (j == 1)
		{
			if (PltOutput->PltGraphPara.DspHist.datas[i] <= 0.2*peak_value)
				pdw_line[j++] = i;
		}
		else if (j == 2)
			break;
	}
	if (j == 1)
		pdw_line[1] = 64;
	dPdw = Alg_P_Cal_dPdwAdjustCoff * (double)(pdw_line[1] - pdw_line[0]) * 80 / Plt_Hist_DataLen;
	printf("pdw modified value: %f\n", dPdw);
	PltOutput->PltReportPara.Pdw = dPdw;

	// 3 PLCR����
	dPltTotal = 0.0;
	dPlcr = 0.0;
	dPlcc = 0.0;

	for (i = 0; i < PltOutput->PltGraphPara.OrgHist.lines[1]; i++)
	{
		dPltTotal += PltOutput->PltGraphPara.DspHist.datas[i];
	}

	for (i = Alg_P_Cal_LargePltTh; i < PltOutput->PltGraphPara.OrgHist.lines[1]; i++)
	{
		dPlcr += PltOutput->PltGraphPara.DspHist.datas[i];
	}

	if (dPltTotal > EPSILON)
	{
		dPlcr = dPlcr / dPltTotal;
	}

	PltOutput->PltReportPara.Plcr = dPlcr*100;
	PltOutput->PltReportPara.Plcc = dPlcr*PltOutput->PltReportPara.Plt;
	return ;
}

// PLTͨ����������
static int PltParaCal_offline(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (!PltInput || !PltOutput)
		return -1;

	// 1 ͼ����Ϣ����
	BuildPltHist(PltInput, PltOutput);

	// 2 �����������
	// 2.1 ����̬��������
	PltNoShapeParaCal_offline(PltInput, PltOutput);

	// 2.2 ��̬��������
	PltShapeParaCal(PltInput, PltOutput);


	// 3 ������������
	//PltFeatureParaCal(PltInput, PltOutput);

	return 0;
}

// PLTͨ����������
static int PltParaCal(stPltInput *PltInput, stPltOutput *PltOutput)
{
	if (!PltInput || !PltOutput)
		return -1;
	
	// 1 ͼ����Ϣ����
	BuildPltHist(PltInput, PltOutput);

	// 2 �����������
	// 2.1 ����̬��������
	PltNoShapeParaCal(PltInput, PltOutput);

	// 2.2 ��̬��������
	PltShapeParaCal(PltInput, PltOutput);
	

	// 3 ������������
	//PltFeatureParaCal(PltInput, PltOutput);

	return 0;
}

static int impdparacal_offline(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput || !ImpdOutput)
		return -1;


	// 1��RBC��������
	if (error_code = RbcParaCal(&(ImpdInput->RbcInput), &(ImpdOutput->RbcOutput)))
		return error_code;

	// 2��PLT��������
	ImpdInput->PltInput.RbcTotalNum =
		ImpdOutput->RbcOutput.RbcServicePara.RbcTotalNum;

	if (error_code = PltParaCal_offline(&(ImpdInput->PltInput), &(ImpdOutput->PltOutput)))
		return error_code;

	return 0;
}

static int impdparacal(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput  || !ImpdOutput )
		return -1;
	
	
	// 1��RBC��������
	if(error_code = RbcParaCal(&(ImpdInput->RbcInput),&(ImpdOutput->RbcOutput)))
		return error_code;
	
	// 2��PLT��������
	ImpdInput->PltInput.RbcTotalNum = 
		ImpdOutput->RbcOutput.RbcServicePara.RbcTotalNum;

	if(error_code = PltParaCal(&(ImpdInput->PltInput),&(ImpdOutput->PltOutput)))
		return error_code;

	return 0;
}

int free_memory_for_rbc_plt_chan(stImpdOutput *ImpdOutput)
{
	FREE_POINTER(ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info);
	FREE_POINTER(ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList.cell_nps);

	FREE_POINTER(ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList.cell_info);
	FREE_POINTER(ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList.cell_nps);
	return 0;
}

/*******************************************************************
// �� �� ���� impdsigprocess_offline
// ��    �ܣ� �迹ͨ���źŴ���
********************************************************************/
int impdsigprocess_offline(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code, i, rbc_start_pos, rbc_end_pos, plt_start_pos, plt_end_pos;
	stImpdCellList RbcCellList1, RbcCellList2, PltCellList1, PltCellList2;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1��DATA����ת��---------------------------------------
	// 1.1 RBC����ת��
	RbcCellList1 = ImpdInput->RbcInput.cell_list;

	memset(&RbcCellList2, 0, sizeof(stImpdCellList));

	RbcCellList2.CellNum = 0;
	RbcCellList2.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
		sizeof(stImpdPulse));
	if (ImpdInput->flag_pulse_alg == 1)
	{
		if (ImpdInput->RbcInput.alg_pos[0] == -1)
		{
			rbc_start_pos = 0;
			rbc_end_pos = RbcCellList1.CellNum;
		}
		else
		{
			rbc_start_pos = ImpdInput->RbcInput.alg_pos[0];
			rbc_end_pos = ImpdInput->RbcInput.alg_pos[1];
		}
		//for (int i = 0; i < RbcCellList1.CellNum; i++)
		for (i = rbc_start_pos; i < rbc_end_pos; i++)
		{
			// ������Ч���ж�
			/*if (RbcCellList1.cell_info[i].FullWidth < 60
				&& RbcCellList1.cell_info[i].FullWidth > 8
				&& RbcCellList1.cell_info[i].PriWidth < 24
				&& RbcCellList1.cell_info[i].PriWidth  > 2
				&& RbcCellList1.cell_info[i].SubWidth < 22
				&& RbcCellList1.cell_info[i].SubWidth  > 2
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth < 35
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth > 4
				&& RbcCellList1.cell_info[i].PeakValue < 4096
				&& RbcCellList1.cell_info[i].PeakValue > 100
				)*/
			if (RbcCellList1.cell_info[i].FullWidth < 60
				&& RbcCellList1.cell_info[i].FullWidth > 8
				&& RbcCellList1.cell_info[i].PriWidth < 24
				&& RbcCellList1.cell_info[i].PriWidth  > 2
				&& RbcCellList1.cell_info[i].SubWidth < 22
				&& RbcCellList1.cell_info[i].SubWidth  > 2
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth < 35
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth > 4
				&& RbcCellList1.cell_info[i].PeakValue < 4096
				&& RbcCellList1.cell_info[i].PeakValue > 100
				)
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]), &(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}
		RbcCellList2.nps_num = RbcCellList1.nps_num;
		RbcCellList2.cell_nps = (short *)calloc(RbcCellList2.nps_num,
			sizeof(short));
		memcpy(RbcCellList2.cell_nps, RbcCellList1.cell_nps,
			RbcCellList2.nps_num * sizeof(short));

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;
		ImpdOutput->RbcOutput.RbcServicePara.rbc_org_num = RbcCellList1.CellNum;
		FREE_POINTER(RbcCellList1.cell_info);
		FREE_POINTER(RbcCellList1.cell_nps);
		RbcCellList1.CellNum = 0;

		// 1.2 PLT����ת��
		PltCellList1 = ImpdInput->PltInput.cell_list;

		memset(&PltCellList2, 0, sizeof(stImpdCellList));

		PltCellList2.CellNum = 0;
		PltCellList2.cell_info = (stImpdPulse *)calloc(PltCellList1.CellNum,
			sizeof(stImpdPulse));

		if (ImpdInput->PltInput.alg_pos[0] == -1)
		{
			plt_start_pos = 0;
			plt_end_pos = PltCellList1.CellNum;
		}
		else
		{
			plt_start_pos = ImpdInput->PltInput.alg_pos[0];
			plt_end_pos = ImpdInput->PltInput.alg_pos[1];
		}
		//for (int i = 0; i < PltCellList1.CellNum; i++)
		for (i = plt_start_pos; i < plt_end_pos; i++)
		{
			// ������Ч���ж�
			/*if (PltCellList1.cell_info[i].FullWidth < 80
			&& PltCellList1.cell_info[i].FullWidth > 8
			&& PltCellList1.cell_info[i].PriWidth < 32
			&& PltCellList1.cell_info[i].PriWidth  > 3
			&& PltCellList1.cell_info[i].SubWidth < 26
			&& PltCellList1.cell_info[i].SubWidth  > 3
			&& PltCellList1.cell_info[i].PriWidth +
			PltCellList1.cell_info[i].SubWidth < 56
			&& PltCellList1.cell_info[i].PriWidth +
			PltCellList1.cell_info[i].SubWidth > 7
			&& PltCellList1.cell_info[i].PeakValue < 4096
			&& PltCellList1.cell_info[i].PeakValue > 224
			)*/
			if (PltCellList1.cell_info[i].FullWidth < 60
				&& PltCellList1.cell_info[i].FullWidth > 8
				&& PltCellList1.cell_info[i].PriWidth < 13
				&& PltCellList1.cell_info[i].PriWidth  > 3
				&& PltCellList1.cell_info[i].SubWidth < 24
				&& PltCellList1.cell_info[i].SubWidth  > 3
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth < 56
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth > 7
				&& PltCellList1.cell_info[i].PeakValue < 4096
				&& PltCellList1.cell_info[i].PeakValue > 255
				)
			{
				memcpy(&(PltCellList2.cell_info[PltCellList2.CellNum]), &(PltCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList2.CellNum++;
			}
		}

		PltCellList2.nps_num = PltCellList1.nps_num;
		PltCellList2.cell_nps = (short *)calloc(PltCellList2.nps_num,
			sizeof(short));
		memcpy(PltCellList2.cell_nps, PltCellList1.cell_nps,
			PltCellList2.nps_num * sizeof(short));
		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList2;
		ImpdOutput->PltOutput.PltServicePara.plt_org_num = PltCellList1.CellNum;
		FREE_POINTER(PltCellList1.cell_info);
		FREE_POINTER(PltCellList1.cell_nps);
		PltCellList1.CellNum = 0;
	}
	else if (ImpdInput->flag_pulse_alg == 2)
	{
		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue >=
				(int)(16.7 * 40 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;

		// 1.2 PLT����ת��
		memset(&PltCellList1, 0, sizeof(stImpdCellList));
		PltCellList1.CellNum = 0;
		PltCellList1.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
			sizeof(stImpdPulse));

		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue <
				(int)(16.7 * 50 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(PltCellList1.cell_info[PltCellList1.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList1.CellNum++;
			}
		}
		FREE_POINTER(RbcCellList1.cell_info);

		for (i = 0; i < PltCellList1.CellNum; i++)
			PltCellList1.cell_info[i].PeakValue *= 4;

		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList1;
	}


	// 2���¿��ж�


	// 3��RBCͨ���źŴ���
	if (error_code = RbcHistProcess(&(ImpdInput->RbcInput),
		&(ImpdOutput->RbcOutput)))
		return error_code;

	// 4��PLTͨ���źŴ���
	if (error_code = PltHistProcess(&(ImpdInput->PltInput),
		&(ImpdOutput->PltOutput)))
		return error_code;
	return 0;
}

/*******************************************************************
// �� �� ���� impdsigprocess_org_alg
// ��    �ܣ� �迹ͨ���źŴ���
********************************************************************/
int impdsigprocess_org_alg(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code, i, rbc_start_pos, rbc_end_pos, plt_start_pos, plt_end_pos;
	stImpdCellList RbcCellList1, RbcCellList2, PltCellList1, PltCellList2;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1��DATA����ת��---------------------------------------
	// 1.1 RBC����ת��
	RbcCellList1 = ImpdInput->RbcInput.cell_list;

	memset(&RbcCellList2, 0, sizeof(stImpdCellList));

	RbcCellList2.CellNum = 0;
	RbcCellList2.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
		sizeof(stImpdPulse));
	if (ImpdInput->flag_pulse_alg == 1)
	{
		if (ImpdInput->RbcInput.alg_pos[0] == -1)
		{
			rbc_start_pos = 0;
			rbc_end_pos = RbcCellList1.CellNum;
		}
		else
		{
			rbc_start_pos = ImpdInput->RbcInput.alg_pos[0];
			rbc_end_pos = ImpdInput->RbcInput.alg_pos[1];
		}
		//for (int i = 0; i < RbcCellList1.CellNum; i++)
		for (i = rbc_start_pos; i < rbc_end_pos; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].FullWidth < 60
				&& RbcCellList1.cell_info[i].FullWidth > 8
				&& RbcCellList1.cell_info[i].PriWidth < 24
				&& RbcCellList1.cell_info[i].PriWidth  > 2
				&& RbcCellList1.cell_info[i].SubWidth < 22
				&& RbcCellList1.cell_info[i].SubWidth  > 2
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth < 35
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth > 4
				&& RbcCellList1.cell_info[i].PeakValue < 4096
				&& RbcCellList1.cell_info[i].PeakValue > 100)
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]), &(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}
		RbcCellList2.nps_num = RbcCellList1.nps_num;
		RbcCellList2.cell_nps = (short *)calloc(RbcCellList2.nps_num,
			sizeof(short));
		memcpy(RbcCellList2.cell_nps, RbcCellList1.cell_nps,
			RbcCellList2.nps_num * sizeof(short));

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;
		ImpdOutput->RbcOutput.RbcServicePara.rbc_org_num = RbcCellList1.CellNum;
		FREE_POINTER(RbcCellList1.cell_info);
		FREE_POINTER(RbcCellList1.cell_nps);
		RbcCellList1.CellNum = 0;

		// 1.2 PLT����ת��
		PltCellList1 = ImpdInput->PltInput.cell_list;

		memset(&PltCellList2, 0, sizeof(stImpdCellList));

		PltCellList2.CellNum = 0;
		PltCellList2.cell_info = (stImpdPulse *)calloc(PltCellList1.CellNum,
			sizeof(stImpdPulse));

		if (ImpdInput->PltInput.alg_pos[0] == -1)
		{
			plt_start_pos = 0;
			plt_end_pos = PltCellList1.CellNum;
		}
		else
		{
			plt_start_pos = ImpdInput->PltInput.alg_pos[0];
			plt_end_pos = ImpdInput->PltInput.alg_pos[1];
		}
		//for (int i = 0; i < PltCellList1.CellNum; i++)
		for (i = plt_start_pos; i < plt_end_pos; i++)
		{
			// ������Ч���ж�
			if (PltCellList1.cell_info[i].FullWidth < 200
				&& PltCellList1.cell_info[i].FullWidth > 12
				&& PltCellList1.cell_info[i].PriWidth < 50
				&& PltCellList1.cell_info[i].PriWidth  > 3
				&& PltCellList1.cell_info[i].SubWidth < 40
				&& PltCellList1.cell_info[i].SubWidth  > 1
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth < 80
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth > 10
				&& PltCellList1.cell_info[i].PeakValue < 2200
				&& PltCellList1.cell_info[i].PeakValue > 120
				)
			{
				memcpy(&(PltCellList2.cell_info[PltCellList2.CellNum]), &(PltCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList2.CellNum++;
			}
		}

		PltCellList2.nps_num = PltCellList1.nps_num;
		PltCellList2.cell_nps = (short *)calloc(PltCellList2.nps_num,
			sizeof(short));
		memcpy(PltCellList2.cell_nps, PltCellList1.cell_nps,
			PltCellList2.nps_num * sizeof(short));
		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList2;
		ImpdOutput->PltOutput.PltServicePara.plt_org_num = PltCellList1.CellNum;
		FREE_POINTER(PltCellList1.cell_info);
		FREE_POINTER(PltCellList1.cell_nps);
		PltCellList1.CellNum = 0;
	}
	else if (ImpdInput->flag_pulse_alg == 2)
	{
		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue >=
				(int)(16.7 * 40 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;

		// 1.2 PLT����ת��
		memset(&PltCellList1, 0, sizeof(stImpdCellList));
		PltCellList1.CellNum = 0;
		PltCellList1.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
			sizeof(stImpdPulse));

		for (i = 0; i < RbcCellList1.CellNum; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].PeakValue <
				(int)(16.7 * 50 * Rbc_Hist_DataLen / 320))
			{
				memcpy(&(PltCellList1.cell_info[PltCellList1.CellNum]),
					&(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList1.CellNum++;
			}
		}
		FREE_POINTER(RbcCellList1.cell_info);

		for (i = 0; i < PltCellList1.CellNum; i++)
			PltCellList1.cell_info[i].PeakValue *= 4;

		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList1;
	}


	// 2���¿��ж�


	// 3��RBCͨ���źŴ���
	if (error_code = RbcHistProcess(&(ImpdInput->RbcInput),
		&(ImpdOutput->RbcOutput)))
		return error_code;

	// 4��PLTͨ���źŴ���
	if (error_code = PltHistProcess(&(ImpdInput->PltInput),
		&(ImpdOutput->PltOutput)))
		return error_code;
	return 0;
}

/*******************************************************************
// �� �� ���� impdmain_org_alg
// ��    �ܣ� �迹ͨ���㷨������
********************************************************************/
int impdmain_org_alg(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1 ��ʼ��
	if (error_code = impdinit(ImpdInput, ImpdOutput))
		return error_code;

	// 2 ��ȡ���ò���
	if (error_code = impdconfigpara(&(ImpdInput->DivConfigPara),
		&(ImpdInput->RbcInput.RbcConfigPara),
		&(ImpdInput->PltInput.PltConfigPara)))
		return error_code;


	// 3 �źŴ���
	if (error_code = impdsigprocess_org_alg(ImpdInput, ImpdOutput))
		return error_code;


	// 4 ֱ��ͼ�ֽ�ģ��
	if (error_code = impdclassify(ImpdInput, ImpdOutput))
		return error_code;

	// 5 ��������
	if (error_code = impdparacal(ImpdInput, ImpdOutput))
		return error_code;
#ifdef BK_BEK_API_TEST
	// ����bek�ļ�
	if (error_code = generate_bek_file(ImpdInput, ImpdOutput))
		return error_code;
#endif

	return 0;
}





/*******************************************************************
// �� �� ���� impdmain_offline
// ��    �ܣ� �迹ͨ���㷨������
********************************************************************/
int impdmain_offline(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1 ��ʼ��
	if (error_code = impdinit(ImpdInput, ImpdOutput))
		return error_code;

	// 2 ��ȡ���ò���
	if (error_code = impdconfigpara(&(ImpdInput->DivConfigPara),
		&(ImpdInput->RbcInput.RbcConfigPara),
		&(ImpdInput->PltInput.PltConfigPara)))
		return error_code;


	// 3 �źŴ���
	if (error_code = impdsigprocess_offline(ImpdInput, ImpdOutput))
		return error_code;


	// 4 ֱ��ͼ�ֽ�ģ��
	if (error_code = impdclassify(ImpdInput, ImpdOutput))
		return error_code;

	// 5 ��������
	if (error_code = impdparacal_offline(ImpdInput, ImpdOutput))
		return error_code;

	return 0;
}


/*******************************************************************
// �� �� ���� impdsigprocess
// ��    �ܣ� �迹ͨ���źŴ���
********************************************************************/
static int impdsigprocess_vk_tmp(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code, i, rbc_start_pos, rbc_end_pos, plt_start_pos, plt_end_pos;
	stImpdCellList RbcCellList1, RbcCellList2, PltCellList1, PltCellList2;
	char rbc_file_path[MAX_PATH], plt_file_path[MAX_PATH];
	int file_len;
	unsigned char *buff;
	FILE *fp;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1��DATA����ת��---------------------------------------
		
	// 1.1 RBC����ת��
	strcpy(rbc_file_path, ImpdInput->file_path);
	strcat(rbc_file_path, "Rbc");
	if (!(fp = fopen(rbc_file_path, "rb")))
		return 111; //�ļ��򿪴���

	fseek(fp, 0, SEEK_END);
	file_len = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	buff = (byte *)calloc(file_len, sizeof(byte));

	file_len = (int)fread(buff, sizeof(byte), file_len, fp);
	fclose(fp);

	memset(&RbcCellList1, 0, sizeof(stImpdCellList));
	dataconvite_impd(&RbcCellList1, buff, file_len / 16);

	memset(&RbcCellList2, 0, sizeof(stImpdCellList));

	RbcCellList2.CellNum = 0;
	RbcCellList2.cell_info = (stImpdPulse *)calloc(RbcCellList1.CellNum,
		sizeof(stImpdPulse));
	if (ImpdInput->flag_pulse_alg == 1)
	{
		if (ImpdInput->RbcInput.alg_pos[0] == -1)
		{
			rbc_start_pos = 0;
			rbc_end_pos = RbcCellList1.CellNum;
		}
		else
		{
			rbc_start_pos = ImpdInput->RbcInput.alg_pos[0];
			rbc_end_pos = ImpdInput->RbcInput.alg_pos[1];
		}
		//for (int i = 0; i < RbcCellList1.CellNum; i++)
		for (i = rbc_start_pos; i < rbc_end_pos; i++)
		{
			// ������Ч���ж�
			if (RbcCellList1.cell_info[i].FullWidth < 60
				&& RbcCellList1.cell_info[i].FullWidth > 8
				&& RbcCellList1.cell_info[i].PriWidth < 24
				&& RbcCellList1.cell_info[i].PriWidth  > 2
				&& RbcCellList1.cell_info[i].SubWidth < 22
				&& RbcCellList1.cell_info[i].SubWidth  > 2
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth < 35
				&& RbcCellList1.cell_info[i].PriWidth +
				RbcCellList1.cell_info[i].SubWidth > 4
				&& RbcCellList1.cell_info[i].PeakValue < 4096
				&& RbcCellList1.cell_info[i].PeakValue > 100
				)
			{
				memcpy(&(RbcCellList2.cell_info[RbcCellList2.CellNum]), &(RbcCellList1.cell_info[i]), sizeof(stImpdPulse));
				RbcCellList2.CellNum++;
			}
		}
		RbcCellList2.nps_num = RbcCellList1.nps_num;
		RbcCellList2.cell_nps = (short *)calloc(RbcCellList2.nps_num,
			sizeof(short));
		memcpy(RbcCellList2.cell_nps, RbcCellList1.cell_nps,
			RbcCellList2.nps_num * sizeof(short));

		ImpdOutput->RbcOutput.RbcFeaturePara.ImpdCellList = RbcCellList2;
		ImpdOutput->RbcOutput.RbcServicePara.rbc_org_num = RbcCellList1.CellNum;
		FREE_POINTER(RbcCellList1.cell_info);
		FREE_POINTER(RbcCellList1.cell_nps);
		RbcCellList1.CellNum = 0;

		// 1.2 PLT����ת��
		strcpy(plt_file_path, ImpdInput->file_path);
		strcat(plt_file_path, "Plt");
		if (!(fp = fopen(plt_file_path, "rb")))
			return 111; //�ļ��򿪴���

		fseek(fp, 0, SEEK_END);
		file_len = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		free(buff);
		buff = (byte *)calloc(file_len, sizeof(byte));

		file_len = (int)fread(buff, sizeof(byte), file_len, fp);
		fclose(fp);

		memset(&PltCellList1, 0, sizeof(stImpdCellList));

		dataconvite_impd(&PltCellList1, buff, file_len / 16);

		memset(&PltCellList2, 0, sizeof(stImpdCellList));

		PltCellList2.CellNum = 0;
		PltCellList2.cell_info = (stImpdPulse *)calloc(PltCellList1.CellNum,
			sizeof(stImpdPulse));

		if (ImpdInput->PltInput.alg_pos[0] == -1)
		{
			plt_start_pos = 0;
			plt_end_pos = PltCellList1.CellNum;
		}
		else
		{
			plt_start_pos = ImpdInput->PltInput.alg_pos[0];
			plt_end_pos = ImpdInput->PltInput.alg_pos[1];
		}
		//for (int i = 0; i < PltCellList1.CellNum; i++)
		for (i = plt_start_pos; i < plt_end_pos; i++)
		{
			// ������Ч���ж�
			/*if (PltCellList1.cell_info[i].FullWidth < 40
			&& PltCellList1.cell_info[i].FullWidth > 8
			&& PltCellList1.cell_info[i].PriWidth < 16
			&& PltCellList1.cell_info[i].PriWidth  > 3
			&& PltCellList1.cell_info[i].SubWidth < 15
			&& PltCellList1.cell_info[i].SubWidth  > 3
			&& PltCellList1.cell_info[i].PriWidth +
			PltCellList1.cell_info[i].SubWidth < 28
			&& PltCellList1.cell_info[i].PriWidth +
			PltCellList1.cell_info[i].SubWidth > 7
			&& PltCellList1.cell_info[i].PeakValue < 4096
			&& PltCellList1.cell_info[i].PeakValue > 224
			)*/
			if (PltCellList1.cell_info[i].FullWidth < 200
				&& PltCellList1.cell_info[i].FullWidth > 12
				&& PltCellList1.cell_info[i].PriWidth < 50
				&& PltCellList1.cell_info[i].PriWidth  > 3
				&& PltCellList1.cell_info[i].SubWidth < 40
				&& PltCellList1.cell_info[i].SubWidth  > 1
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth < 80
				&& PltCellList1.cell_info[i].PriWidth +
				PltCellList1.cell_info[i].SubWidth > 10
				&& PltCellList1.cell_info[i].PeakValue < 2200
				&& PltCellList1.cell_info[i].PeakValue > 120
				)
			{
				memcpy(&(PltCellList2.cell_info[PltCellList2.CellNum]), &(PltCellList1.cell_info[i]), sizeof(stImpdPulse));
				PltCellList2.CellNum++;
			}
		}

		PltCellList2.nps_num = PltCellList1.nps_num;
		PltCellList2.cell_nps = (short *)calloc(PltCellList2.nps_num,
			sizeof(short));
		memcpy(PltCellList2.cell_nps, PltCellList1.cell_nps,
			PltCellList2.nps_num * sizeof(short));
		ImpdOutput->PltOutput.PltFeaturePara.ImpdCellList = PltCellList2;
		ImpdOutput->PltOutput.PltServicePara.plt_org_num = PltCellList1.CellNum;

		FREE_POINTER(PltCellList1.cell_info);
		FREE_POINTER(PltCellList1.cell_nps);
		PltCellList1.CellNum = 0;
	}
	// 2���¿��ж�


	// 3��RBCͨ���źŴ���
	if (error_code = RbcHistProcess(&(ImpdInput->RbcInput),
		&(ImpdOutput->RbcOutput)))
		return error_code;

	// 4��PLTͨ���źŴ���
	if (error_code = PltHistProcess(&(ImpdInput->PltInput),
		&(ImpdOutput->PltOutput)))
		return error_code;
	return 0;
}

/*******************************************************************
// �� �� ���� impdmain_offline
// ��    �ܣ� �迹ͨ���㷨������
********************************************************************/
int impdmain_vk_tmp(stImpdInput *ImpdInput, stImpdOutput *ImpdOutput)
{
	int error_code;
	if (!ImpdInput || !ImpdOutput)
	{
		return -1;
	}

	// 1 ��ʼ��
	if (error_code = impdinit(ImpdInput, ImpdOutput))
		return error_code;

	// 2 ��ȡ���ò���
	if (error_code = impdconfigpara(&(ImpdInput->DivConfigPara),
		&(ImpdInput->RbcInput.RbcConfigPara),
		&(ImpdInput->PltInput.PltConfigPara)))
		return error_code;


	// 3 �źŴ���
	if (error_code = impdsigprocess_vk_tmp(ImpdInput, ImpdOutput))
		return error_code;


	// 4 ֱ��ͼ�ֽ�ģ��
	if (error_code = impdclassify(ImpdInput, ImpdOutput))
		return error_code;

	// 5 ��������
	if (error_code = impdparacal(ImpdInput, ImpdOutput))
		return error_code;
	return 0;
}
