#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "bk_hgb_main.h"
#include "datatype.h"
#include "common_func.h"

static int read_hgb_data(short **hgb_data, unsigned char *data_addr,
	int data_num);



double bk_hgb_main(S_HGB_INPUT *s_input)
{
	
	double hgb_cal;
	double hgb_factory_cal_factor, hgb_user_cal_factor;

	if (s_input->hgb_bk < EPSILON || s_input->hgb_me < EPSILON)
	{
		return -1.0;
	}
	hgb_cal = log10(s_input->hgb_bk / s_input->hgb_me) * s_input->Dilution;


	//hgb_cal = -0.0021*hgb_cal*hgb_cal + 2.8144 * hgb_cal;
	//// HGB����У��
	hgb_cal *= 1.95;
	if(hgb_cal < 115.0 || hgb_cal > 150.0)
		hgb_cal = (1.018*hgb_cal - 3.384);
	//hgb_final = 0.0003634*hgb_final*hgb_final + 0.9567*hgb_final - 2.883;
	if (hgb_cal < 60)
		hgb_cal += 2.1;
	// HGBУ׼
	hgb_factory_cal_factor = s_input->factory_cal_factor;
	hgb_user_cal_factor = s_input->user_cal_factor;
	printf("HGB_factory_cal_factor: %5.4f\n", hgb_factory_cal_factor);
	printf("HGB_user_cal_factor: %5.4f\n", hgb_user_cal_factor);
	hgb_cal = hgb_cal * hgb_factory_cal_factor * hgb_user_cal_factor;

	return hgb_cal > 0 ? hgb_cal : 0.0;
}

/*******************************************************************
// �� �� ���� getvolvalue
// ��    �ܣ� ��ȡHgb��ѹֵ(���ס�����)
********************************************************************/
double get_hgb_vol(short* volarray, int roi_num, int reject_num)
{
	if (volarray == NULL || roi_num < reject_num)
	{
		return -1.0;
	}

	int    index = 0;

	double volvalue = 0.0;

	for (int i = 0; i < reject_num; i++)
	{
		double dmaxbia = 0.0;

		volvalue = get_mean_of_short_array(volarray, roi_num - i);

		for (int j = 0; j < roi_num - i; j++)
		{
			if (dmaxbia < abs(volarray[j] - volvalue))
			{
				dmaxbia = abs(volarray[j] - volvalue);
				index = j;
			}
		}

		short dtemp = volarray[index];
		volarray[index] = volarray[roi_num - 1 - i];
		volarray[roi_num - 1 - i] = (short)(dtemp);
	}

	volvalue = get_mean_of_short_array(volarray, roi_num - reject_num);

	return volvalue;
}

int read_hgb_data(short **hgb_data, unsigned char *data_addr,
	int data_num)
{
	int i;
	short *data;

	if (!data_addr)
		return 131;

	data = (short *)calloc(data_num, sizeof(short));

	for (i = 0; i < data_num; i++)
	{
		data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	*hgb_data = data;
	return 0;
}

double bk_hgb_main_offline(S_HGB_INPUT *s_input, short *hgb_data)
{

	double hgb_cal;
	double hgb_factory_cal_factor, hgb_user_cal_factor;
	double bk_mean, me_mean;
	int bk_pos, me_pos;

	bk_pos = s_input->bk_pos;
	me_pos = s_input->me_pos;
	
	int roi_num = 25;
	int reject_num = 4;
	bk_mean = get_hgb_vol(hgb_data + bk_pos, roi_num, reject_num);
	s_input->hgb_bk = bk_mean / 4095 * 5;
	me_mean = get_hgb_vol(hgb_data + me_pos, roi_num, reject_num);
	s_input->hgb_me = me_mean / 4095 * 5;
	hgb_cal = log10(bk_mean / me_mean) * s_input->Dilution;
	

	//hgb_cal = -0.0021*hgb_cal*hgb_cal + 2.8144 * hgb_cal;
	//// HGB����У��
	hgb_cal *= 1.95;
	if (hgb_cal < 115.0 || hgb_cal > 150.0)
		hgb_cal = (1.018*hgb_cal - 3.384);
	//hgb_final = 0.0003634*hgb_final*hgb_final + 0.9567*hgb_final - 2.883;
	if (hgb_cal < 60)
		hgb_cal += 2.1;
	// HGBУ׼
	hgb_factory_cal_factor = s_input->factory_cal_factor;
	hgb_user_cal_factor = s_input->user_cal_factor;
	printf("HGB_factory_cal_factor: %5.4f\n", hgb_factory_cal_factor);
	printf("HGB_user_cal_factor: %5.4f\n", hgb_user_cal_factor);
	hgb_cal = hgb_cal * hgb_factory_cal_factor * hgb_user_cal_factor;

	return hgb_cal > 0 ? hgb_cal : 0.0;
}
