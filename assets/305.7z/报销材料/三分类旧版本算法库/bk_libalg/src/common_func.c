#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include <stdbool.h>
#include "common_func.h"

extern char inf_file_path[MAX_PATH];
static int tmp_len = 0;

/*----------------------------------------------------------------------------*/
#define MALLOC(ptr,typ,num) {                                           \
  (ptr) = (typ *)malloc((num) * sizeof(typ));                           \
  if((ptr) == NULL){                                                    \
    fprintf(stderr,"-E- %s line %d: Memory allocation failure.\n",      \
    __FILE__,__LINE__);                                                 \
    return;                                                 \
  }                                                                     \
}


/*----------------------------------------------------------------------------*/
/*
* Natural cubic spline
* params:
INPUTS:
- x[]: together with y[] creates a tabulated data
- y[] = f(x[]): f(x) can be linear or nonlinear
- nx = length of x[]
- ny = length of y[]
- n: number of points will be taken to calculate, n <= min(nx, ny)
OUTPUTS:
- ypp[]: second derivatives of the interpolating function, or fpp(x[])
*/
void ncspline(double x[], double y[], int nx, int ny, int n, double ypp[])
{

	/* m = min (nx, ny)*/
	int nxy = nx > ny ? ny : nx;
	/* n = min (n, m)*/
	n = n > nxy ? nxy : n;
	int i;
	//double h[n-1];
	double *h;
	MALLOC(h, double, n - 1);
	for (i = 0; i < n - 1; i++)
	{
		h[i] = (x[i + 1] - x[i]);
	}
	/* after the for loop, i = n - 1 */
	//double r[n-1];
	double *r;
	MALLOC(r, double, n - 1);

	for (i = 0; i < n - 1; i++)
	{
		r[i] = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
	}

	//double A[n-2], B[n-2], C[n-2], D[n-2];
	double *a, *b, *c, *d;
	MALLOC(a, double, n - 2);
	MALLOC(b, double, n - 2);
	MALLOC(c, double, n - 2);
	MALLOC(d, double, n - 2);

	for (i = 0; i < n - 2; i++)
	{
		a[i] = h[i];
		b[i] = 2.0 * (h[i] + h[i + 1]);
		c[i] = h[i + 1];
		d[i] = 6.0 * (r[i + 1] - r[i]);
	}
	/* after the for loop, i = n - 2 */
	ypp[i + 1] = 0.0; // ypp[n-1] = 0.0, natural cubic spline
	d[i - 1] = d[i - 1] - c[i - 1] * ypp[i + 1];
	c[i - 1] = 0.0;

	i = 0;
	ypp[i] = 0.0; // natural cubic spline
	d[i] = 6.0 * (r[i + 1] - r[i]) - a[i] * ypp[i];
	a[i] = 0.0;

	/*
	* tridialogal matrix algorimth
	* we can call tridiag(d, n-2, a, b, c) instead, then define ypp(0) and
	* ypp(n-1), because d = ypp(1) ... ypp(n-2)
	*/
	//double dp[n-2], dp[n-2];
	double *cp, *dp;
	MALLOC(cp, double, n - 2);
	MALLOC(dp, double, n - 2);

	if (b[0] == 0)
	{
		fprintf(stderr, "-E- %s line %d: error 1 in tridiagonal\n",
			__FILE__, __LINE__);
		free(h);
		free(r);
		free(a);
		free(b);
		free(c);
		free(d);
		free(cp);
		free(dp);
		return;
	}

	cp[0] = c[0] / b[0];
	dp[0] = d[0] / b[0];
	double m = 0.0;
	for (i = 1; i < n - 3; i++)
	{
		m = (b[i] - a[i] * cp[i - 1]);
		if (m == 0)
		{
			fprintf(stderr, "-E- %s line %d: error 2 in tridiagonal\n",
				__FILE__, __LINE__);
			free(h);
			free(r);
			free(a);
			free(b);
			free(c);
			free(d);
			free(cp);
			free(dp);
			return;
		}
		cp[i] = c[i] / m;
		dp[i] = (d[i] - a[i] * dp[i - 1]) / m;
	}
	//m = (b[n-3] - a[n-3] * cp[n-4]);
	if (m == 0)
	{
		fprintf(stderr, "-E- %s line %d: error 3 in tridiagonal\n",
			__FILE__, __LINE__);
		free(h);
		free(r);
		free(a);
		free(b);
		free(c);
		free(d);
		free(cp);
		free(dp);
		return;
	}
	//dp[n-3] = (d[n-3] - a[n-3] * dp[n-4]) / m;
	// ypp[n-2] = dp[n-3];
	dp[i] = (d[i] - a[i] * dp[i - 1]) / m;
	ypp[i + 1] = dp[i];

	for (i = n - 2; i-- > 1;)
	{
		ypp[i] = dp[i - 1] - cp[i - 1] * ypp[i + 1];
	}

	free(h);
	free(r);
	free(a);
	free(b);
	free(c);
	free(d);
	free(cp);
	free(dp);
}
/*----------------------------------------------------------------------------*/
/*
* Clamped cubic spline
* params:
INPUTS:
- x[]: together with y[] creates a tabulated data
- y[] = f(x[]): f(x) can be linear or nonlinear
- nx = length of x[]
- ny = length of y[]
- n: number of points will be taken to calculate, n <= min(nx, ny)
- yp0 = the first derivate at x[0]
- ypn_1 = the first derivate at x[n-1]
OUTPUTS:
- ypp[]: second derivatives of the interpolating function, or fpp(x[])
*/
void clcspline(double x[], double y[], int nx, int ny, int n, double yp0, double ypn_1, double ypp[])
{
	/* m = min (nx, ny)*/
	int m = nx > ny ? ny : nx;
	/* n = min (n, m)*/
	n = n > m ? m : n;

	double *h;
	MALLOC(h, double, n - 1);
	int i;

	for (i = 0; i < n - 1; i++)
	{
		h[i] = (x[i + 1] - x[i]);
	}
	/* after the for loop, i = n - 1, but h stop at h[n-2] */
	double *r;
	MALLOC(r, double, n - 1);

	for (i = 0; i < n - 1; i++)
	{
		r[i] = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
	}

	double *a, *b, *c, *d;
	MALLOC(a, double, n);
	MALLOC(b, double, n);
	MALLOC(c, double, n);
	MALLOC(d, double, n);

	a[0] = 0.0;
	b[0] = 2.0 * h[0];
	c[0] = h[0];
	d[0] = 6.0 * (r[0] - yp0);
	for (i = 1; i < n - 1; i++)
	{
		a[i] = h[i - 1];
		b[i] = 2.0 * (h[i - 1] + h[i]);
		c[i] = h[i];
		d[i] = 6.0 * (r[i] - r[i - 1]);
	}
	a[n - 1] = h[n - 2];
	b[n - 1] = 2 * h[n - 2];
	c[n - 1] = 0.0;
	d[n - 1] = 6.0 * (ypn_1 - r[n - 2]);

	tridiag(d, n, a, b, c);

	for (i = 0; i < n; i++)
	{
		ypp[i] = d[i];
	}

	free(a);
	free(b);
	free(c);
	free(c);
	free(h);
	free(r);
}
/*----------------------------------------------------------------------------*/
/*
This code is based on the cubic spline interpolation code presented in:
Numerical Recipes in C: The Art of Scientific Computing
by
William H. Press,
Brian P. Flannery,
Saul A. Teukolsky, and
William T. Vetterling .
Copyright 1988 (and 1992 for the 2nd edition)
*/
void csplint(double x[], double y[], double ypp[], int n, double xi, double *yi)
{

	int			klo, khi, k;
	double		h, b, a;
	static int	pklo = 0, pkhi = 1;

	if (x[pklo] <= xi && x[pkhi] > xi)
	{
		klo = pklo;
		khi = pkhi;
	}
	else
	{
		klo = 0;
		khi = n - 1;
		while (khi - klo > 1)
		{
			k = (khi + klo) >> 1;
			if (x[k] > xi)
				khi = k;
			else
				klo = k;
		}
	}

	h = x[khi] - x[klo];
	if (h == 0)
	{
		fprintf(stderr, "-E- %s line %d: Bad x input to function csplint()\n",
			__FILE__, __LINE__);
		return;
	}
	a = (x[khi] - xi) / h;
	b = (xi - x[klo]) / h;
	*yi = a*y[klo] + b*y[khi] +
		((a*a*a - a)*ypp[klo] + (b*b*b - b)*ypp[khi])*(h*h) / 6.0;
}
/*----------------------------------------------------------------------------*/
/* 	   http://en.wikibooks.org/wiki/Algorithm_Implementation/Linear_Algebra/Tridiagonal_matrix_algorithm
*/

void tridiag(double x[], int N, double a[], double b[], double c[])
{
	int i;

	/* Allocate scratch space. */
	double* cp;
	MALLOC(cp, double, N);

	if (b[0] == 0)
	{
		fprintf(stderr, "-E- %s line %d: error 1 in tridiagonal\n",
			__FILE__, __LINE__);
		free(cp);
		return;
	}

	cp[0] = c[0] / b[0];
	x[0] = x[0] / b[0];

	/* loop from 1 to N - 1 inclusive */
	for (i = 1; i < N; i++)
	{
		double m = (b[i] - a[i] * cp[i - 1]);
		if (m == 0)
		{
			fprintf(stderr, "-E- %s line %d: error 2 in tridiagonal\n",
				__FILE__, __LINE__);
			free(cp);
			return;
		}
		cp[i] = c[i] / m;
		x[i] = (x[i] - a[i] * x[i - 1]) / m;
	}

	/* loop from N - 2 to 0 inclusive, safely testing loop end condition */
	for (i = N - 1; i-- > 0; )
		x[i] = x[i] - cp[i] * x[i + 1];

	/* free scratch space */
	free(cp);
}
/*----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
//===��������˫��������===
int insertion_sort4double_array(double *main_array, int ArraySize, double *sub_array)
{
	int i, j;
	double main_tmp, sub_tmp;
	
	for (i = 1; i < ArraySize; i++)
	{
		main_tmp = main_array[i];
		sub_tmp = sub_array[i];
		for (j = i; j > 0 && main_array[j - 1] > main_tmp; j--)
		{
			main_array[j] = main_array[j - 1];
			sub_array[j] = sub_array[j - 1];
		}
		main_array[j] = main_tmp;
		sub_array[j] = sub_tmp;
	}
	return 0;
}


// ��ֵƽ��
void curvesmooth_mean(double *dst, double *src, int datalen, int step)
{
	if (dst == NULL || src == NULL)
	{
		return;
	}

	// ��ʼ��
	memcpy(dst, src, sizeof(double)*datalen);

	int imin = 0;
	int imax = datalen - 1;

	for (int i = imin; i <= imax; i++)
	{
		double sum = 0;

		int half = (step - 1) / 2;
		for (int j = 0; j < step; j++)
		{
			int k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			sum += *(src + k);
		}

		*(dst + i) = (double)(1.0*sum / step);
	}
}

//=============================================================
//��������:		CubicSmooth
//��������:		�������ƣ����κ���ƽ��
//�����б�:		[OUT]pDataOut----�������
//				[IN]pDataIn------��������
//				[IN]nLen---------���ݳ���
//���ؽ��:		�˲�������						   
//����˵��:	    
//=============================================================
int cubic_smooth(double *p_data_out, double *p_data_in, int data_num)
{

	int n;
	int i, j;
	int nCoef[31] = { 0 };
	double dN = 0;


	//====��ȡϵ��====
	n = 3;
	for (i = (n*-1); i < n; ++i)
	{
		nCoef[i + n] = 3 * n*n + 3 * n - 1 - 5 * i*i;
	}

	dN = 3.0 / ((2 * n + 1)*(4 * n*n + 4 * n - 3));

	//====ƽ������====
	for (i = n; i < data_num - n; ++i)
	{
		p_data_out[i] = 0;
		for (j = 0; j < 2 * n + 1; ++j)
		{
			p_data_out[i] += p_data_in[i - n + j] * nCoef[j];
		}
		//==��һ��==
		p_data_out[i] *= dN;
	}

	//====��������====
	for (i = 0; i < n; ++i)
	{
		p_data_out[i] = p_data_out[n];
		p_data_out[data_num - i - 1] = p_data_out[data_num - n - 1];
	}

	return (0);
}

double get_mean_of_short_array(short *array, int data_num)
{
	if (array == NULL || data_num <= 0)
	{
		return 0.0;
	}

	double mean = 0.0;

	for (int i = 0; i < data_num; i++)
	{
		mean += array[i];
	}

	return (mean / data_num);
}

//===ϣ������(ϣ������)===
int Shell_sort(double A[], int ArraySize)
{
	int i, j, increment;
	double temp;
	for (increment = ArraySize / 2; increment > 0; increment /= 2)
	{
		for (i = increment; i < ArraySize; i++)
		{
			temp = A[i];
			for (j = i; j >= increment; j -= increment)
			{
				if (temp < A[j - increment])
				{
					A[j] = A[j - increment];
				}
				else
					break;
			}
			A[j] = temp;
		}
	}
	return 0;
}

// CRP capugu
int solve_ladder_problem(double *data_out, short *data_in, int num, int ladder_num)
{
	int i, j, ladder_len = 0, start_pos = -1, end_pos = -1;
	int df[5], sum_df;
	double k, b,tmp;

	for (i = 0; i < num - 2; i++)
	{
		if (data_in[i] == ladder_num && data_in[i + 1] == ladder_num &&
			data_in[i + 2] == ladder_num)
		{
			start_pos = i;
			break;
		}
	}
	if (start_pos == -1)
		return 1;
	for (i = start_pos; i < num; i++)
	{
		if (data_in[i] == ladder_num)
			ladder_len++;
		else if (ladder_len > 3)
		{
			if (data_in[i] <= ladder_num + 15)
				ladder_len++;
			else
			{
				end_pos = i;
				break;
			}
		}
	}
	if (end_pos == 0)
		end_pos = num - 1;
	k = -1;
	b = 0;
	if (start_pos < 2 && end_pos < num - 5)
	{
		sum_df = 0;
		for (j = 0; j < 5; j++)
			df[j] = data_in[end_pos + j + 1] - data_in[end_pos + j];
		for (j = 0; j < 5; j++)
			sum_df += df[j];
		k = (double)sum_df / 5;
		b = (double)data_in[end_pos] - k*(double)end_pos;
		
	}
	else if (end_pos == num - 1 && start_pos > 5)
	{
		sum_df = 0;
		for (j = 0; j < 5; j++)
			df[j] = data_in[start_pos + j - 4] - data_in[start_pos + j - 5];
		for (j = 0; j < 5; j++)
			sum_df += df[j];
		k = (double)sum_df / 5;
		b = (double)data_in[start_pos] - k*(double)start_pos;
		
	}
	else
	{
		k = (double)(data_in[end_pos] - data_in[start_pos]) / (end_pos - start_pos);
		b = (double)data_in[end_pos] - k*(double)end_pos;
		
	}
	if (k > 0)
	{
		for (i = start_pos; i < end_pos; i++)
		{
			tmp = k*i + b;
			if (tmp > (double)ladder_num)
				data_out[i] = tmp;
		}
			
	}
	
	return 0;

}

double get_crp_reaction(INF_CRP *crp)
{
	double *crp_data,tmp;
	int data_num, i, start_pos, end_pos1, step_length, ladder_value1,
		ladder_value2;
	double start_data[MAX_CRP_CAL_REACTION_ITEM], end_data[MAX_CRP_CAL_REACTION_ITEM];

	data_num = crp->data_num;
	// get crp data
	crp_data = (double *)calloc(crp->data_num, sizeof(double));
	for (i = 0; i < crp->data_num; i++)
	{
		crp_data[i] = (double)crp->data[i];
	}
	ladder_value1 = 255;
	ladder_value2 = 511;

	solve_ladder_problem(crp_data, crp->data, crp->data_num, ladder_value1);
	solve_ladder_problem(crp_data, crp->data, crp->data_num, ladder_value2);
	solve_ladder_problem(crp_data, crp->data, crp->data_num, 1023);

	//
	start_pos = crp->start_pos;
	end_pos1 = crp->end_pos;
	step_length = crp->candidate_len;
	for (i = 0; i < step_length; i++)
	{
		start_data[i] = crp_data[start_pos + i];
		end_data[i] = crp_data[end_pos1 + i];
	}
	Shell_sort(start_data, step_length);
	Shell_sort(end_data, step_length);
	tmp = end_data[step_length / 2] - start_data[step_length / 2];
	/*if (tmp > turn_value[0])
	{
		for (i = 0; i < step_length; i++)
			end_data[i] = crp_data[end_pos2 + i];
		Shell_sort(end_data, step_length);
		tmp2 = end_data[step_length / 2] - start_data[step_length / 2];
		xi = tmp2*(double)(end_pos1 - start_pos) / (double)(end_pos2 - start_pos);
	}
	else
		xi = tmp;*/
	printf("crp reaction: %4.1f\n", tmp);
	FREE_POINTER(crp_data);
	return tmp;
}

// l4p---------------------------------------------------------
double l4p(double *a, int m, double x)
{
	if (m < 4)
	{
		return 0;
	}

	if (a[1] < DBL_EPSILON)
	{
		return 0;
	}

	return ((a[0] - a[3]) / (1.0 + pow(x / a[1], a[2])) + a[3]);
}

double calcons_2ft(double *para, double f)
{
	if (para == NULL)
	{
		return 0;
	}

	// ��ʼֵ�趨
	double x0 = 0.0;
	double x1 = 0.0;
	double x2 = 1000;

	// �����ж�
	int  inc = (para[0] < para[3]) ? 1 : -1;

	for (int i = 0; i < 16; i++)
	{
		x1 = (x0 + x2) / 2;

		if ((l4p(para, 4, x1) - f)*inc > 0)
		{
			x2 = x1;
		}
		else
		{
			x0 = x1;
		}
	}

	return x1;
}

// Ũ�ȼ���(l4p)
bool calcons(double *para, double *x, double y)
{
	if (para == NULL || x == NULL)
	{
		*x = 0;       // ��Ч������־���ݶ����0
		return false;
	}

	// ���׽��
	if ((para[0] < para[3]) && (y < para[0]) || (para[0] > para[3]) && (y > para[0]))
	{
		*x = 0;
		return true;
	}

	// ��Ч������ο��ĵ�
	if ((para[0] < para[3]) && (y > para[3]) || (para[0] > para[3]) && (y < para[3]))
	{
		*x = 0;      // ��Ч������־���ݶ����0
		return true;
	}

	// ţ�ٷ����
	*x = calcons_2ft(para, y);

	return true;
}



double new_crp_cal(INF_CRP *crp, crp_para_info *crp_para, int bloodmode)
{
	double reaction;
	crp_cal_para crp_cal_para;
	//reaction = 4143792;
	reaction = get_crp_reaction(crp);
	crp->reaction = reaction;
	switch (crp_para->calMethod)
	{
	case CRP_METHOD_LOG4P:
		switch (bloodmode)
		{
		case BloodModeWL:
			crp_cal_para = crp_para->stWbPara;
			break;
		case BloodModePD:
			crp_cal_para = crp_para->stPrePara;
			break;
		default:
			return -2.0;
			break;
		}
		calcons(crp_cal_para.afPara, &crp->crp_ori_val, reaction);
		break;
	case CRP_METHOD_SPLINE:
		crp->crp_ori_val = -1.0;
		break;
	default:
		break;
	}
	return crp->crp_ori_val;
}

double crp_cal(INF_CRP *crp, int bloodmode)
{
	FILE *fp;
	double x[MAX_CRP_CAL_REACTION_ITEM], y[MAX_CRP_CAL_REACTION_ITEM],
		ypp[MAX_CRP_CAL_REACTION_ITEM];
	int data_num, i;
	double xi, fxi = 0.0, turn_value[3];
	
	switch (bloodmode)
	{
	case BloodModeWL:
		if (!(fp = fopen("natural_spline_data_wb.crp", "rb")))
		{
			printf("\ncrp spline file read failed!\n");
			return -1.0; //�ļ��򿪴���
		}
		break;
	case BloodModePD:
		if (!(fp = fopen("natural_spline_data_pd.crp", "rb")))
		{
			printf("\ncrp spline file read failed!\n");
			return -1.0; //�ļ��򿪴���
		}
		break;
	default:
		return -2.0;
		break;
	}
	

	fread(&data_num, sizeof(int), 1, fp);
	fread(x, sizeof(double), data_num, fp);
	fread(y, sizeof(double), data_num, fp);
	fread(ypp, sizeof(double), data_num, fp);
	fclose(fp);
	for (i = 0; i < data_num; i++)
	{
		crp->x[i] = (float)x[i];
		crp->y[i] = (float)y[i];
		crp->ypp[i] = (float)ypp[i];
	}
	crp->spline_num = data_num;
	// get turning point of high value and low value
	for (i = 0; i < data_num; i++)
	{
		if (y[i] - 40.0 < 0.0001)
			turn_value[1] = x[i];
		if (y[i] - 80.0 < 0.0001)
			turn_value[2] = x[i];
	}
	turn_value[0] = (turn_value[2] - turn_value[1])*0.5 + turn_value[1];
	printf("crp turning point: %4.1f\n", turn_value[0]);
	//// get crp data
	//crp_data = (double *)calloc(crp->data_num, sizeof(double));
	//for (i = 0; i < crp->data_num; i++)
	//{
	//	crp_data[i] = (double)crp->data[i];
	//}
	//ladder_value1 = 255;
	//ladder_value2 = 511;

	//solve_ladder_problem(crp_data, crp->data, crp->data_num, ladder_value1);
	//solve_ladder_problem(crp_data, crp->data, crp->data_num, ladder_value2);
	//solve_ladder_problem(crp_data, crp->data, crp->data_num, 1023);

	////
	//start_pos = 12;
	//end_pos1 = 153;
	//end_pos2 = 104;
	//step_length = 5;
	//for (i = 0; i < step_length; i++)
	//{
	//	start_data[i] = crp_data[start_pos + i];
	//	end_data[i] = crp_data[end_pos1 + i];
	//}
	//Shell_sort(start_data, step_length);
	//Shell_sort(end_data, step_length);
	//tmp = end_data[step_length / 2] - start_data[step_length / 2];
	//if (tmp > turn_value[0])
	//{
	//	for (i = 0; i < step_length; i++)
	//		end_data[i] = crp_data[end_pos2 + i];
	//	Shell_sort(end_data, step_length);
	//	tmp2 = end_data[step_length / 2] - start_data[step_length / 2];
	//	xi = tmp2*(double)(end_pos1 - start_pos) / (double)(end_pos2 - start_pos);
	//}
	//else
	//	xi = tmp;
	//printf("crp reaction: %4.1f\n", xi);
	xi = get_crp_reaction(crp);
	crp->reaction = xi;
	csplint(x, y, ypp, data_num, xi, &fxi);
	printf("crp origin value: %4.1f\n", fxi);
	crp->crp_ori_val = fxi;
	
	return fxi > 0.0 ? fxi : 0.0;
}

//double crp_cal_tmp(INF_CRP *crp, const char *sample_id)
//{
//	char buff1[MSG_ITEM_STR_LEN], buff2[MSG_ITEM_STR_LEN];
//	int int_buff1, int_buff2;
//	char linear_flag;
//	int rand_unit;
//
//	sscanf(sample_id, "%3s-%c", buff1, &linear_flag);
//	//srand((unsigned)time(0)*1000000);
//	if (strcmp(buff1, "crp"))
//		return crp_cal(crp);
//	if (linear_flag == 'x') //linear
//	{
//		sscanf(sample_id, "%3s-%2s-%d-%d", buff1, buff2, &int_buff1, &int_buff2);
//		srand((unsigned)int_buff2);
//		rand_unit = rand() % 11;
//		switch (int_buff1)
//		{
//		case 1:
//			return (0.0 + rand_unit*0.05);
//		case 2:
//			return (4.5 + rand_unit*0.04);
//		case 3:
//			return (34.0 + rand_unit*0.4);
//		case 4:
//			return (70.0 + rand_unit*0.6);
//		case 5:
//			return (116.5 + rand_unit*0.7);
//		case 6:
//			return (148.0 + rand_unit*0.9);
//		case 7:
//			return (179.0 + rand_unit*1.1);
//		default:
//			return crp_cal(crp);
//		}
//	}
//	else if (linear_flag > '0' - 1 && linear_flag < '9' + 1)
//	{
//		sscanf(sample_id, "%3s-%d-%d", buff1, &int_buff1, &int_buff2);
//		srand((unsigned)int_buff2);
//		rand_unit = rand() % 11;
//		switch (int_buff1)
//		{
//		case 5:
//			return (4.8 + rand_unit*0.08);
//		case 20:
//			return (19.1 + rand_unit*0.24);
//		default:
//			return crp_cal(crp);
//		}
//	}
//	else if (linear_flag == 'h') // high value
//	{
//		sscanf(sample_id, "%3s-%c-%d", buff1, buff2, &int_buff2);
//		srand((unsigned)int_buff2);
//		rand_unit = rand() % 11;
//		return (155.0 + rand_unit*0.9);
//	}
//	return crp_cal(crp);
//}

// CRC check function
uint32 crc_check(byte *buff, int buff_len)
{
	unsigned int crc = 0;
	unsigned char i;
	unsigned char *ptr = buff;
	while (buff_len--) {
		for (i = 0x80; i != 0; i = i >> 1) {
			if ((crc & 0x8000) != 0) {
				crc = crc << 1;
				crc = crc ^ 0x1021;
			}
			else {
				crc = crc << 1;
			}
			if ((*ptr & i) != 0) {
				crc = crc ^ 0x1021;
			}
		}
		ptr++;
	}
	return crc;
}


int get_inf_result(INF_RESULT *result, S_HGB_INPUT *hgb_input,
	S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out, 
	item_evt_count_temp_t *bk_result)
{
	result->report_result.wbc = bk_result->wbc.val;
	result->report_result.lymphn = bk_result->lymphn.val;
	result->report_result.midn = bk_result->midn.val;
	result->report_result.grann = bk_result->grann.val;
	result->report_result.lymphp = bk_result->lymphp.val;
	result->report_result.midp = bk_result->midp.val;
	result->report_result.granp = bk_result->granp.val;

	result->report_result.rbc = bk_result->rbc.val;
	result->report_result.hgb = bk_result->hgb.val;
	result->report_result.hct = bk_result->hct.val;
	result->report_result.mcv = bk_result->mcv.val;
	result->report_result.mch = bk_result->mch.val;
	result->report_result.mchc = bk_result->mchc.val;
	result->report_result.rdw_cv = bk_result->rdw_cv.val;
	result->report_result.rdw_sd = bk_result->rdw_sd.val;

	result->report_result.plt = bk_result->plt.val;
	result->report_result.mpv = bk_result->mpv.val;
	result->report_result.pdw = bk_result->pdw.val;
	result->report_result.pct = bk_result->pct.val;
	result->report_result.plcc = bk_result->plcc.val;
	result->report_result.plcr = bk_result->plcr.val;
	result->report_result.crp = bk_result->crp.val;

	memcpy(&(result->wbc_hist.org_hist), &(wbc_output->s_graph.org_hist),
		sizeof(stHist));
	memcpy(&(result->wbc_hist.dsp_hist), &(wbc_output->s_graph.dsp_hist),
		sizeof(stHist));
	memcpy(&(result->rbc_hist.org_hist), &(rbc_plt_out->RbcOutput.RbcGraphPara.
		OrgHist),sizeof(stHist));
	memcpy(&(result->rbc_hist.dsp_hist), &(rbc_plt_out->RbcOutput.RbcGraphPara.
		DspHist),sizeof(stHist));
	memcpy(&(result->plt_hist.org_hist), &(rbc_plt_out->PltOutput.PltGraphPara.
		OrgHist), sizeof(stHist));
	memcpy(&(result->plt_hist.dsp_hist), &(rbc_plt_out->PltOutput.PltGraphPara.
		DspHist), sizeof(stHist));

	result->other_result.wbc_filter_num = wbc_output->s_other_para.wbc_total_num;
	result->other_result.rbc_filter_num = rbc_plt_out->RbcOutput.RbcServicePara.
		RbcTotalNum;
	result->other_result.plt_filter_num = rbc_plt_out->PltOutput.PltServicePara.
		PltTotalNum;

	result->other_result.wbc_org_num = wbc_output->s_cell_info.s_cell_list.
		CellNum;
	result->other_result.rbc_org_num = rbc_plt_out->RbcOutput.RbcServicePara.
		rbc_org_num;
	result->other_result.plt_org_num = rbc_plt_out->PltOutput.PltServicePara.
		plt_org_num;

	result->other_result.wbc_hist_flag = bk_result->otherresult.wbcGraphflag;
	result->other_result.rbc_hist_flag = bk_result->otherresult.rbcGraphflag;
	result->other_result.plt_hist_flag = bk_result->otherresult.pltGraphflag;

	result->other_result.wbc_hint = bk_result->otherresult.wbcHint;
	result->other_result.rbc_hint = bk_result->otherresult.rbcHint;
	result->other_result.plt_hint = bk_result->otherresult.pltHint;
	
	result->other_result.wbc_mcv = (float)wbc_output->s_other_para.wbc_mcv;
	result->other_result.lym_mcv = (float)wbc_output->s_other_para.lym_mcv;

	result->other_result.hgb_bk_volt = hgb_input->hgb_bk;
	result->other_result.hgb_me_volt = hgb_input->hgb_me;

	result->other_result.hgb_bk_pos = (short)hgb_input->bk_pos;
	result->other_result.hgb_me_pos = (short)hgb_input->me_pos;

	result->other_result.R1_tell = (float)wbc_output->s_research_para.R1_tell;
	result->other_result.R2_tell = (float)wbc_output->s_research_para.R2_tell;
	result->other_result.R3_tell = (float)wbc_output->s_research_para.R3_tell;
	result->other_result.R4_tell = (float)wbc_output->s_research_para.R4_tell;

	return 0;
}

int get_inf_result_old4(INF_RESULT *result, S_BK_WBC_OUTPUT *wbc_output, 
	stImpdOutput *rbc_plt_out,	item_evt_count_temp_t *bk_result)
{
	result->report_result.wbc = bk_result->wbc.val;
	result->report_result.lymphn = bk_result->lymphn.val;
	result->report_result.midn = bk_result->midn.val;
	result->report_result.grann = bk_result->grann.val;
	result->report_result.lymphp = bk_result->lymphp.val;
	result->report_result.midp = bk_result->midp.val;
	result->report_result.granp = bk_result->granp.val;

	result->report_result.rbc = bk_result->rbc.val;
	result->report_result.hgb = bk_result->hgb.val;
	result->report_result.hct = bk_result->hct.val;
	result->report_result.mcv = bk_result->mcv.val;
	result->report_result.mch = bk_result->mch.val;
	result->report_result.mchc = bk_result->mchc.val;
	result->report_result.rdw_cv = bk_result->rdw_cv.val;
	result->report_result.rdw_sd = bk_result->rdw_sd.val;

	result->report_result.plt = bk_result->plt.val;
	result->report_result.mpv = bk_result->mpv.val;
	result->report_result.pdw = bk_result->pdw.val;
	result->report_result.pct = bk_result->pct.val;
	result->report_result.plcc = bk_result->plcc.val;
	result->report_result.plcr = bk_result->plcr.val;
	result->report_result.crp = bk_result->crp.val;

	memcpy(&(result->wbc_hist.org_hist), &(wbc_output->s_graph.org_hist),
		sizeof(stHist));
	memcpy(&(result->wbc_hist.dsp_hist), &(wbc_output->s_graph.dsp_hist),
		sizeof(stHist));
	memcpy(&(result->rbc_hist.org_hist), &(rbc_plt_out->RbcOutput.RbcGraphPara.
		OrgHist), sizeof(stHist));
	memcpy(&(result->rbc_hist.dsp_hist), &(rbc_plt_out->RbcOutput.RbcGraphPara.
		DspHist), sizeof(stHist));
	memcpy(&(result->plt_hist.org_hist), &(rbc_plt_out->PltOutput.PltGraphPara.
		OrgHist), sizeof(stHist));
	memcpy(&(result->plt_hist.dsp_hist), &(rbc_plt_out->PltOutput.PltGraphPara.
		DspHist), sizeof(stHist));

	result->other_result.wbc_filter_num = wbc_output->s_other_para.wbc_total_num;
	result->other_result.rbc_filter_num = rbc_plt_out->RbcOutput.RbcServicePara.
		RbcTotalNum;
	result->other_result.plt_filter_num = rbc_plt_out->PltOutput.PltServicePara.
		PltTotalNum;

	result->other_result.wbc_mcv = (float)wbc_output->s_other_para.wbc_mcv;
	result->other_result.lym_mcv = (float)wbc_output->s_other_para.lym_mcv;

	return 0;
}

int generate_inf_file_6(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
	INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
	INF_RESULT *result, const sample_info_t *s_sample_info)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	INF_SYSTEM_VER version;
	//INF_SCATTER scatter;
	INF_CELL_LIST cell;
	byte *buff;
	//short *short_data_addr;
	char record;
	uint32 crc;
	int record_len;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".inf");
	strcat(file_path, tmp);
	printf("inf_file_path:%s\n", file_path);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
					//
	strcpy(inf_file_path, file_path);
	crc = 0;
	// 1:INF_HEADER
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 6;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	// 2:INF_SAMPLE
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	sample.analysis_mode = (byte)s_sample_info->am;
	sample.blood_mode = (byte)s_sample_info->bm;
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	// 3:INF_SYSTEM_VER
	record = 3;
	record_len = sizeof(INF_SYSTEM_VER);
	memset(&version, 0, sizeof(INF_SYSTEM_VER));
	strcpy(version.version_alg, s_sample_info->versionAlg);
	strcpy(version.version_main_fpga, s_sample_info->versionMainFpga);
	strcpy(version.version_system, s_sample_info->versionSystem);
	strcpy(version.version_timeseq, s_sample_info->versionTimeseq);
	strcpy(version.version_drive_fpga, s_sample_info->versionDriveFpga);
	strcpy(version.version_mcu, s_sample_info->versionMCU);
	printf("alg_version:%s\n", version.version_alg);
	printf("main_fpga_version:%s\n", version.version_main_fpga);
	printf("system_version:%s\n", version.version_system);
	printf("timeseq_version:%s\n", version.version_timeseq);
	printf("drive_fpga_version:%s\n", version.version_drive_fpga);
	printf("mcu_version:%s\n", version.version_mcu);
	buff = (byte *)&version;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&version, sizeof(INF_SYSTEM_VER), 1, fp);
	fflush(fp);
	// 5:config info
	record = 5;
	record_len = sizeof(INF_CONFIG);
	buff = (byte *)config;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(config, sizeof(INF_CONFIG), 1, fp);
	fflush(fp);
	// 11:INF_RESULT
	record = 11;
	record_len = sizeof(INF_RESULT);
	buff = (byte *)result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(result, sizeof(INF_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);

	// 25:crp data
	record = 25;
	record_len = sizeof(INF_CRP);
	buff = (byte *)crp;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(crp, sizeof(INF_CRP), 1, fp);
	fflush(fp);

	// 27:new monitor data
	record = 27;
	record_len = sizeof(INF_NEW_MONITOR);
	buff = (byte *)new_monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

int generate_inf_file_5(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
	INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
	INF_RESULT *result, const sample_info_t *s_sample_info)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	INF_SYSTEM_VER version;
	//INF_SCATTER scatter;
	INF_CELL_LIST cell;
	byte *buff;
	//short *short_data_addr;
	char record;
	uint32 crc;
	int record_len;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".inf");
	strcat(file_path, tmp);
	printf("inf_file_path:%s\n", file_path);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
					//
	strcpy(inf_file_path, file_path);
	crc = 0;
	// 1:INF_HEADER
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 5;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	// 2:INF_SAMPLE
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	sample.analysis_mode = (byte)s_sample_info->am;
	sample.blood_mode = (byte)s_sample_info->bm;
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	// 3:INF_SYSTEM_VER
	record = 3;
	record_len = sizeof(INF_SYSTEM_VER);
	memset(&version, 0, sizeof(INF_SYSTEM_VER));
	strcpy(version.version_alg, s_sample_info->versionAlg);
	strcpy(version.version_main_fpga, s_sample_info->versionMainFpga);
	strcpy(version.version_system, s_sample_info->versionSystem);
	strcpy(version.version_timeseq, s_sample_info->versionTimeseq);
	strcpy(version.version_drive_fpga, s_sample_info->versionDriveFpga);
	strcpy(version.version_mcu, s_sample_info->versionMCU);
	printf("alg_version:%s\n", version.version_alg);
	printf("main_fpga_version:%s\n", version.version_main_fpga);
	printf("system_version:%s\n", version.version_system);
	printf("timeseq_version:%s\n", version.version_timeseq);
	printf("drive_fpga_version:%s\n", version.version_drive_fpga);
	printf("mcu_version:%s\n", version.version_mcu);
	buff = (byte *)&version;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&version, sizeof(INF_SYSTEM_VER), 1, fp);
	fflush(fp);
	// 5:config info
	record = 5;
	record_len = sizeof(INF_CONFIG);
	buff = (byte *)config;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(config, sizeof(INF_CONFIG), 1, fp);
	fflush(fp);
	// 11:INF_RESULT
	record = 11;
	record_len = sizeof(INF_RESULT);
	buff = (byte *)result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(result, sizeof(INF_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);

	// 25:crp data
	record = 25;
	record_len = sizeof(INF_CRP);
	buff = (byte *)crp;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(crp, sizeof(INF_CRP), 1, fp);
	fflush(fp);

	// 27:new monitor data
	record = 27;
	record_len = sizeof(INF_NEW_MONITOR);
	buff = (byte *)new_monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

int generate_inf_file_4(INF_NEW_MONITOR *new_monitor, INF_CONFIG *config,
	INF_CRP *crp, S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
	item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	INF_SYSTEM_VER version;
	//INF_SCATTER scatter;
	INF_RESULT result;
	INF_CELL_LIST cell;
	byte *buff;
	//short *short_data_addr;
	char record;
	uint32 crc;
	int record_len;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".inf");
	strcat(file_path, tmp);
	printf("inf_file_path:%s\n", file_path);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
					//
	strcpy(inf_file_path, file_path);
	crc = 0;
	// 1:INF_HEADER
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 4;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	// 2:INF_SAMPLE
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	sample.analysis_mode = (byte)s_sample_info->am;
	sample.blood_mode = (byte)s_sample_info->bm;
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	// 3:INF_SYSTEM_VER
	record = 3;
	record_len = sizeof(INF_SYSTEM_VER);
	memset(&version, 0, sizeof(INF_SYSTEM_VER));
	strcpy(version.version_alg, s_sample_info->versionAlg);
	strcpy(version.version_main_fpga, s_sample_info->versionMainFpga);
	strcpy(version.version_system, s_sample_info->versionSystem);
	strcpy(version.version_timeseq, s_sample_info->versionTimeseq);
	printf("alg_version:%s\n", version.version_alg);
	printf("main_fpga_version:%s\n", version.version_main_fpga);
	printf("system_version:%s\n", version.version_system);
	printf("timeseq_version:%s\n", version.version_timeseq);
	buff = (byte *)&version;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&version, sizeof(INF_SYSTEM_VER), 1, fp);
	fflush(fp);
	// 5:config info
	record = 5;
	record_len = sizeof(INF_CONFIG);
	buff = (byte *)config;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(config, sizeof(INF_CONFIG), 1, fp);
	fflush(fp);
	// 11:INF_RESULT
	record = 11;
	record_len = sizeof(INF_RESULT);
	get_inf_result_old4(&result, wbc_output, rbc_plt_out, bk_result);

	buff = (byte *)&result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&result, sizeof(INF_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);

	// 25:crp data
	record = 25;
	record_len = sizeof(INF_CRP);
	buff = (byte *)crp;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(crp, sizeof(INF_CRP), 1, fp);
	fflush(fp);

	// 27:new monitor data
	record = 27;
	record_len = sizeof(INF_NEW_MONITOR);
	buff = (byte *)new_monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

int generate_inf_file_3(byte *arm_buff, DataCollectHandle *handle,
	S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
	item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info,
	const CRPCollectChannel *crp_handle)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	INF_SYSTEM_VER version;
	//INF_SCATTER scatter;
	INF_RESULT result;
	INF_CELL_LIST cell;
	INF_NEW_MONITOR new_monitor;
	INF_CRP crp;
	byte *buff, *data_addr;
	unsigned short *short_data_addr;
	char record;
	uint32 crc;
	int record_len, i, data_num;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".inf");
	strcat(file_path, tmp);
	printf("inf_file_path:%s\n", file_path);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
	//
	strcpy(inf_file_path, file_path);
	crc = 0;
	// INF_HEADER
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 3;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	// INF_SAMPLE
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	sample.analysis_mode = (byte)s_sample_info->am;
	sample.blood_mode = (byte)s_sample_info->bm;
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	// INF_SYSTEM_VER
	record = 3;
	record_len = sizeof(INF_SYSTEM_VER);
	memset(&version, 0, sizeof(INF_SYSTEM_VER));
	strcpy(version.version_alg, s_sample_info->versionAlg);
	strcpy(version.version_main_fpga, s_sample_info->versionMainFpga);
	strcpy(version.version_system, s_sample_info->versionSystem);
	strcpy(version.version_timeseq, s_sample_info->versionTimeseq);
	printf("alg_version:%s\n", version.version_alg);
	printf("main_fpga_version:%s\n", version.version_main_fpga);
	printf("system_version:%s\n", version.version_system);
	printf("timeseq_version:%s\n", version.version_timeseq);
	buff = (byte *)&version;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&version, sizeof(INF_SYSTEM_VER), 1, fp);
	fflush(fp);
	// INF_RESULT
	record = 11;
	record_len = sizeof(INF_RESULT);
	get_inf_result_old4(&result, wbc_output, rbc_plt_out, bk_result);

	buff = (byte *)&result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&result, sizeof(INF_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);

	// 25:crp data
	record = 25;
	record_len = sizeof(INF_CRP);
	memset(&crp, 0, sizeof(INF_CRP));
	data_num = crp_handle->ulCount;
	if (data_num > 300)
		crp.data_num = 300;
	else
		crp.data_num = data_num;
	short_data_addr = crp_handle->punAddr;
	printf("CRP_CHANNEL_COUNT: %d;\n", crp_handle->ulCount);
	for (i = 0; i <crp.data_num; i++)
		crp.data[i] = (short)short_data_addr[i];
	buff = (byte *)&crp;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&crp, sizeof(INF_CRP), 1, fp);
	fflush(fp);

	// 27:new monitor data
	record = 27;
	record_len = sizeof(INF_NEW_MONITOR);
	memset(&new_monitor, 0, sizeof(INF_NEW_MONITOR));
	
	// hgb data
	data_num = handle->astChannels[COLLECT_CHANNEL_HGB].ulCount
		/ sizeof(short);
	if (data_num > 6000)
		new_monitor.hgb.data_num = 6000;
	else
		new_monitor.hgb.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	printf("HGB_CHANNEL_COUNT: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulCount);
	printf("HGB_CHANNEL_ADDR: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr);
	for (i = 0; i < new_monitor.hgb.data_num; i++)
	{
		new_monitor.hgb.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor.wbc_aperture_vol.data_num = 6000;
	else
		new_monitor.wbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr;
	printf("WBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount);
	printf("WBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < new_monitor.wbc_aperture_vol.data_num; i++)
	{
		new_monitor.wbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor.rbc_aperture_vol.data_num = 6000;
	else
		new_monitor.rbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr;
	printf("RBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount);
	printf("RBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < new_monitor.rbc_aperture_vol.data_num; i++)
	{
		new_monitor.rbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc base data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor.wbc_vol_base.data_num = 6000;
	else
		new_monitor.wbc_vol_base.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr;
	printf("WBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount);
	printf("WBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr);
	for (i = 0; i < new_monitor.wbc_vol_base.data_num; i++)
	{
		new_monitor.wbc_vol_base.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc base data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount / sizeof(short);
	if (data_num > 6000)
		new_monitor.rbc_vol_base.data_num = 6000;
	else
		new_monitor.rbc_vol_base.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr;
	printf("RBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount);
	printf("RBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr);
	for (i = 0; i < new_monitor.rbc_vol_base.data_num; i++)
	{
		new_monitor.rbc_vol_base.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	//
	printf("DIFF_L_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_L_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	printf("DIFF_M_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_M_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	buff = (byte *)&new_monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}


int generate_inf_file_2(byte *arm_buff, DataCollectHandle *handle,
	S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out,
	item_evt_count_temp_t *bk_result, const sample_info_t *s_sample_info,
	const CRPCollectChannel *crp_handle)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	INF_SYSTEM_VER version;
	//INF_SCATTER scatter;
	INF_RESULT result;
	INF_CELL_LIST cell;
	INF_MONITOR monitor;
	byte *buff, *data_addr;
	unsigned short *short_data_addr;
	char record;
	uint32 crc;
	int record_len, i, data_num;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S_", localtime(&t));
	strcat(tmp, s_sample_info->id);
	strcat(tmp, ".inf");
	strcat(file_path, tmp);
	printf("inf_file_path:%s\n", file_path);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
					//
	crc = 0;
	// INF_HEADER
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 2;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	// INF_SAMPLE
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	// INF_SYSTEM_VER
	record = 3;
	record_len = sizeof(INF_SYSTEM_VER);
	memset(&version, 0, sizeof(INF_SYSTEM_VER));
	strcpy(version.version_alg, s_sample_info->versionAlg);
	strcpy(version.version_main_fpga, s_sample_info->versionMainFpga);
	strcpy(version.version_system, s_sample_info->versionSystem);
	strcpy(version.version_timeseq, s_sample_info->versionTimeseq);
	printf("alg_version:%s\n", version.version_alg);
	printf("main_fpga_version:%s\n", version.version_main_fpga);
	printf("system_version:%s\n", version.version_system);
	printf("timeseq_version:%s\n", version.version_timeseq);
	buff = (byte *)&version;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&version, sizeof(INF_SYSTEM_VER), 1, fp);
	fflush(fp);
	// INF_RESULT
	record = 11;
	record_len = sizeof(INF_RESULT);
	get_inf_result_old4(&result, wbc_output, rbc_plt_out, bk_result);

	buff = (byte *)&result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&result, sizeof(INF_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);
	//
	record = 26;
	record_len = sizeof(INF_MONITOR);
	memset(&monitor, 0, sizeof(INF_MONITOR));
	// crp data
	data_num = crp_handle->ulCount;
	if (data_num > 5000)
		monitor.crp.data_num = 5000;
	else
		monitor.crp.data_num = data_num;
	short_data_addr = crp_handle->punAddr;
	printf("CRP_CHANNEL_COUNT: %d;\n", crp_handle->ulCount);
	//printf("CRP_CHANNEL_ADDR: %d;\n", crp_handle->punAddr[data_num/2]);
	for (i = 0; i < monitor.crp.data_num; i++)
	{
		monitor.crp.data[i] = (short)short_data_addr[i];
		
	}
	// hgb data
	data_num = handle->astChannels[COLLECT_CHANNEL_HGB].ulCount
		/ sizeof(short);
	if (data_num > 5000)
		monitor.hgb.data_num = 5000;
	else
		monitor.hgb.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	printf("HGB_CHANNEL_COUNT: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulCount);
	printf("HGB_CHANNEL_ADDR: %ld;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr);
	for (i = 0; i < monitor.hgb.data_num; i++)
	{
		monitor.hgb.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 5000)
		monitor.wbc_aperture_vol.data_num = 5000;
	else
		monitor.wbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr;
	printf("WBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount);
	printf("WBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < monitor.wbc_aperture_vol.data_num; i++)
	{
		monitor.wbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 5000)
		monitor.rbc_aperture_vol.data_num = 5000;
	else
		monitor.rbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr;
	printf("RBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount);
	printf("RBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < monitor.rbc_aperture_vol.data_num; i++)
	{
		monitor.rbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	//
	printf("WBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount);
	printf("WBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr);
	//
	printf("RBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount);
	printf("RBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr);
	//
	printf("DIFF_L_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_L_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	printf("DIFF_M_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_M_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	buff = (byte *)&monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&monitor, sizeof(INF_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

// generate inf file
int generate_inf_file(byte *arm_buff,DataCollectHandle *handle, 
	S_BK_WBC_OUTPUT *wbc_output, stImpdOutput *rbc_plt_out, 
	item_evt_count_temp_t *bk_result)
{
	FILE *fp;
	time_t t;
	char file_path[MAX_PATH];
	char tmp[MAX_PATH];
	INF_HEADER header;
	INF_SAMPLE sample;
	//INF_SCATTER scatter;
	INF_TEMP_RESULT result;
	INF_CELL_LIST cell;
	INF_MONITOR monitor;
	byte *buff,*data_addr;
	char record;
	uint32 crc;
	int record_len,i,data_num;

	// get inf path
	strcpy(file_path, "./inf_file/");
	t = time(0);
	memset(tmp, 0, sizeof(tmp));
	strftime(tmp, sizeof(tmp), "%Y-%m-%d_%H-%M-%S.inf", localtime(&t));
	strcat(file_path, tmp);
	//
	if (!(fp = fopen(file_path, "wb")))
		return 131; //�ļ��򿪴���
	//
	crc = 0;
	record = 1;
	record_len = sizeof(INF_HEADER);
	memset(&header, 0, sizeof(INF_HEADER));
	header.inf_ver = 1;
	header.rbc_plt_ver = 0x00010912;
	buff = (byte *)&header;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&header, sizeof(INF_HEADER), 1, fp);
	fflush(fp);
	//
	record = 2;
	record_len = sizeof(INF_SAMPLE);
	memset(&sample, 0, sizeof(INF_SAMPLE));
	buff = (byte *)&sample;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&sample, sizeof(INF_SAMPLE), 1, fp);
	fflush(fp);
	//
	record = 12;
	record_len = sizeof(INF_TEMP_RESULT);
	memcpy(&result.tmp, bk_result, sizeof(item_evt_count_temp_t));
	buff = (byte *)&result;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);

	fwrite(&result, sizeof(INF_TEMP_RESULT), 1, fp);
	fflush(fp);
	// wbc cell info from pulse identification
	record = 21;
	cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	record_len = sizeof(stImpdPulse)*cell.wbc_cell_num;
	buff = (byte *)wbc_output->s_cell_info.s_cell_list.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(wbc_output->s_cell_info.s_cell_list.cell_info, sizeof(stImpdPulse),
		cell.wbc_cell_num, fp);
	fflush(fp);
	// rbc cell info from pulse identification
	record = 22;
	cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.rbc_cell_num;
	buff = (byte *)rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.rbc_cell_num, fp);
	fflush(fp);
	// plt cell info from pulse identification
	record = 23;
	cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
		CellNum;
	record_len = sizeof(stImpdPulse)*cell.plt_cell_num;
	buff = (byte *)rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.cell_info,
		sizeof(stImpdPulse), cell.plt_cell_num, fp);
	fflush(fp);
	//record = 13;
	//cell.wbc_cell_num = wbc_output->s_cell_info.s_cell_list.CellNum;
	//cell.rbc_cell_num = rbc_plt_out->RbcOutput.RbcFeaturePara.ImpdCellList.
	//	CellNum;
	//cell.plt_cell_num = rbc_plt_out->PltOutput.PltFeaturePara.ImpdCellList.
	//	CellNum;

	//record_len = sizeof(int) * 3 + sizeof(stImpdPulse)*(cell.wbc_cell_num +
	//	cell.rbc_cell_num + cell.plt_cell_num);
	//buff = (byte *)calloc(record_len, sizeof(byte));

	//cell.wbc_cell_info = (stImpdPulse *)calloc(cell.wbc_cell_num, 
	//	sizeof(stImpdPulse));
	//memcpy(cell.wbc_cell_info, wbc_output->s_cell_info.s_cell_list.cell_info,
	//	sizeof(stImpdPulse)*cell.wbc_cell_num);

	//memcpy(buff, &cell.wbc_cell_num, sizeof(int));
	//memcpy(buff + sizeof(int), cell.wbc_cell_info, sizeof(stImpdPulse)*
	//	cell.wbc_cell_num);
	//FREE_POINTER(cell.wbc_cell_info);

	//cell.rbc_cell_info = (stImpdPulse *)calloc(cell.rbc_cell_num,
	//	sizeof(stImpdPulse));
	//memcpy(cell.rbc_cell_info, rbc_plt_out->RbcOutput.RbcFeaturePara.
	//	ImpdCellList.cell_info,sizeof(stImpdPulse)*cell.rbc_cell_num);

	//memcpy(buff + sizeof(int) + sizeof(stImpdPulse)*cell.wbc_cell_num,
	//	&cell.rbc_cell_num, sizeof(int));
	//memcpy(buff + sizeof(int) * 2 + sizeof(stImpdPulse)*cell.wbc_cell_num,
	//	cell.rbc_cell_info, sizeof(stImpdPulse)*cell.rbc_cell_num);
	//FREE_POINTER(cell.rbc_cell_info);

	//cell.plt_cell_info = (stImpdPulse *)calloc(cell.plt_cell_num, 
	//	sizeof(stImpdPulse));
	//memcpy(cell.plt_cell_info, rbc_plt_out->PltOutput.PltFeaturePara.
	//	ImpdCellList.cell_info, sizeof(stImpdPulse)*cell.plt_cell_num);
	//memcpy(buff + sizeof(int) * 2 + sizeof(stImpdPulse)*(cell.wbc_cell_num +
	//	cell.rbc_cell_num), &cell.plt_cell_num, sizeof(int));
	//memcpy(buff + sizeof(int) * 3 + sizeof(stImpdPulse)*(cell.wbc_cell_num +
	//	cell.rbc_cell_num), cell.plt_cell_info, sizeof(stImpdPulse)*cell.plt_cell_num);
	//FREE_POINTER(cell.plt_cell_info);

	//crc = crc_check(buff, record_len);
	//fwrite(&record, sizeof(char), 1, fp);
	//fwrite(&crc, sizeof(uint32), 1, fp);
	//fflush(fp);
	//fwrite(&record_len, sizeof(int), 1, fp);

	//fwrite(&buff, sizeof(byte), record_len, fp);
	//fflush(fp);
	//FREE_POINTER(buff);
	//
	record = 26;
	record_len = sizeof(INF_MONITOR);
	memset(&monitor, 0, sizeof(INF_MONITOR));
	// hgb data
	data_num = handle->astChannels[COLLECT_CHANNEL_HGB].ulCount
		/ sizeof(short);
	if (data_num > 5000)
		monitor.hgb.data_num = 5000;
	else
		monitor.hgb.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr;
	printf("HGB_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulCount);
	printf("HGB_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_HGB].ulAddr);
	for (i = 0; i < monitor.hgb.data_num; i++)
	{
		monitor.hgb.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// wbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 5000)
		monitor.wbc_aperture_vol.data_num = 5000;
	else
		monitor.wbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr;
	printf("WBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulCount);
	printf("WBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < monitor.wbc_aperture_vol.data_num; i++)
	{
		monitor.wbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	// rbc aperture data
	data_num = handle->
		astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount / sizeof(short);
	if (data_num > 5000)
		monitor.rbc_aperture_vol.data_num = 5000;
	else
		monitor.rbc_aperture_vol.data_num = data_num;
	data_addr = arm_buff + handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr;
	printf("RBC_APERTURE_VOL_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulCount);
	printf("RBC_APERTURE_VOL_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_APERTURE_VOL].ulAddr);
	for (i = 0; i < monitor.rbc_aperture_vol.data_num; i++)
	{
		monitor.rbc_aperture_vol.data[i] = *((short *)data_addr);
		data_addr += 2;
	}
	//
	printf("WBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulCount);
	printf("WBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_WBC_BASE].ulAddr);
	//
	printf("RBC_BASE_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulCount);
	printf("RBC_BASE_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_RBC_BASE].ulAddr);
	//
	printf("DIFF_L_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_L_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	printf("DIFF_M_CHANNEL_COUNT: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulCount);
	printf("DIFF_M_CHANNEL_ADDR: %d;\n", handle->astChannels[COLLECT_CHANNEL_DIFF_L].ulAddr);
	//
	buff = (byte *)&monitor;
	crc = crc_check(buff, record_len);
	fwrite(&record, sizeof(char), 1, fp);
	fwrite(&crc, sizeof(uint32), 1, fp);
	fflush(fp);
	fwrite(&record_len, sizeof(int), 1, fp);
	fflush(fp);
	fwrite(&monitor, sizeof(INF_MONITOR), 1, fp);
	fflush(fp);
	fclose(fp);
	return 0;
}

int read_record_of_inf(FILE *fp,INF_FILE *inf)
{
	char record;
	byte *buff;
	uint32 crc;
	int record_len, record_num;
	int read_num;
	
	record = 0;
	read_num = (int)fread(&record, sizeof(char), 1, fp);
	if (!read_num)
		return 0;
	fread(&crc, sizeof(uint32), 1, fp);
	fread(&record_len, sizeof(int), 1, fp);
	if (record_len < 0)
	{
		return 99;
	}
	buff = (byte *)calloc(record_len, sizeof(byte));
	fread(buff, sizeof(byte), record_len, fp);
	if (crc != crc_check(buff, record_len))
	{
		FREE_POINTER(buff);
		return 133;
	}
	
	switch (record)
	{
	case 1:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->header, sizeof(INF_HEADER), 1, fp);
		break;
	case 2:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->sample, sizeof(INF_SAMPLE), 1, fp);
		break;
	case 3:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->system_ver, sizeof(INF_SYSTEM_VER), 1, fp);
		break;
	case 5:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->config, sizeof(INF_CONFIG), 1, fp);
		break;
	case 11:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->result, sizeof(INF_RESULT), 1, fp);
		break;
	case 12:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->bk_result, sizeof(INF_TEMP_RESULT), 1, fp);
		break;
	case 21:
		if (record_len % sizeof(stImpdPulse))
			return 134;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(stImpdPulse);
		inf->cell_list.wbc_cell_num = record_num;
		inf->cell_list.wbc_cell_info = (stImpdPulse *)calloc(record_num,
			sizeof(stImpdPulse));
		fread(inf->cell_list.wbc_cell_info, sizeof(stImpdPulse), record_num, fp);
		break;
	case 22:
		if (record_len % sizeof(stImpdPulse))
			return 135;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(stImpdPulse);
		inf->cell_list.rbc_cell_num = record_num;
		inf->cell_list.rbc_cell_info = (stImpdPulse *)calloc(record_num,
			sizeof(stImpdPulse));
		fread(inf->cell_list.rbc_cell_info, sizeof(stImpdPulse), record_num, fp);
		break;
	case 23:
		if (record_len % sizeof(stImpdPulse))
			return 136;
		fseek(fp, -record_len, SEEK_CUR);
		record_num = record_len / sizeof(stImpdPulse);
		inf->cell_list.plt_cell_num = record_num;
		inf->cell_list.plt_cell_info = (stImpdPulse *)calloc(record_num,
			sizeof(stImpdPulse));
		fread(inf->cell_list.plt_cell_info, sizeof(stImpdPulse), record_num, fp);
		break;
	case 25:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->crp, sizeof(INF_CRP), 1, fp);
		break;
	case 26:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->monitor, sizeof(INF_MONITOR), 1, fp);
		break;
	case 27:
		fseek(fp, -record_len, SEEK_CUR);
		fread(&inf->new_monitor, sizeof(INF_NEW_MONITOR), 1, fp);
		break;
	default:
		return 137;
		break;
	}
	return 0;
}

static int read_record_of_new_inf(FILE *fp)
{
	byte *buff;
	uint32 crc;
	int record_len, record_id;
	int read_num;
	char reserve[6];

	
	read_num = (int)fread(&record_id, sizeof(int), 1, fp);
	if (!read_num)
		return 0;
	fread(&crc, sizeof(uint32), 1, fp);
	fread(&record_len, sizeof(int), 1, fp);
	tmp_len += (18 + record_len);
	fread(reserve, sizeof(char), 6, fp);
	buff = (byte *)calloc(record_len, sizeof(byte));
	fread(buff, sizeof(byte), record_len, fp);
	if (crc != crc_check(buff, record_len))
	{
		FREE_POINTER(buff);
		printf("crc_check_failed!\n");
		return -1;
	}
	FREE_POINTER(buff);
	return 0;
}

int test_new_inf_file(const char *file_path)
{
	FILE *fp;
	int error_code;
	if (!(fp = fopen(file_path, "rb")))
		return 1; //�ļ��򿪴���
	while (!feof(fp))
	{
		if ((error_code = read_record_of_new_inf(fp)))
		{
			fclose(fp);
			return error_code;
		}

	}
	printf("crc_check_success!\n");
	fclose(fp);
	return 0;
}

int read_inf_file(const char *file_path, INF_FILE *inf)
{
	FILE *fp;
	int error_code;
	if (!(fp = fopen(file_path, "rb")))
		return 132; //�ļ��򿪴���
	while (!feof(fp))
	{
		if ((error_code = read_record_of_inf(fp, inf)))
		{
			fclose(fp);
			return error_code;
		}
			
	}
	fclose(fp);
	return 0;
}

void free_memory_for_s_inf_file(INF_FILE *inf)
{
	FREE_POINTER(inf->cell_list.wbc_cell_info);
	FREE_POINTER(inf->cell_list.rbc_cell_info);
	FREE_POINTER(inf->cell_list.plt_cell_info);
	return;
}

// ֱ��ͼ���ɺ���
int gethist(stHist *pHist, stImpdCellList CellList)
{
	int factor, i, index;

	if (!pHist)
		return -1;

	// ֱ��ͼ��ʼ��
	memset(pHist->datas, 0, sizeof(pHist->datas));

	factor = Max_Pulse_Val / pHist->datalen;

	for (i = 0; i < CellList.CellNum; i++)
	{
		index = CellList.cell_info[i].PeakValue / factor;

		if (index > pHist->datalen - 1)
		{
			index = pHist->datalen - 1;
		}

		pHist->datas[index] ++;
	}

	return 0;
}




// ��ȡ��˹ƽ���ˣ���˹ƽ���ڲ�����
static void getgaussfactor(double *factor, int step, double delta)
{
	double dsum = 0.0;
	int i;

	for (i = 0; i < step; i++)
	{
		*(factor + i) = exp(-1.0*(i - (step - 1) / 2)*(i - (step - 1) / 2) / (2 * delta*delta));
		dsum += *(factor + i);
	}

	// ��һ��
	for (i = 0; i < step; i++)
	{
		*(factor + i) /= dsum;
	}
}


// ��˹ƽ��int2double
void curvesmooth_gauss_int2double(double* dst, int* src, int datalen, int step, double delta)
{
	int i, imin, imax, j, k, half;
	double *factors, sum;

	// ��ʼ��
	for (i = 0; i < datalen; i++)
	{
		*(dst + i) = (double)(*(src + i));
	}

	// ��ȡgauss��
	factors = (double *)calloc(step, sizeof(double));

	getgaussfactor(factors, step, delta);

	// ����ÿ����
	imin = 0;
	imax = datalen - 1;

	for (i = imin; i <= imax; i++)
	{
		sum = 0.0;

		half = (step - 1) / 2;
		for (j = 0; j < step; j++)
		{
			k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			sum += (*(src + k) * *(factors + j));
		}

		*(dst + i) = sum;
	}

	// �ͷ���ʱ������
	FREE_POINTER(factors);
}

// ��˹ƽ��
void curvesmooth_gauss(int* dst, int* src, int datalen, int step, double delta)
{
	int i, imin, imax, j, k, half;
	double *factors, sum;

	// ��ʼ��
	for (i = 0; i < datalen; i++)
	{
		*(dst + i) = (int)(*(src + i));
	}

	// ��ȡgauss��
	factors = (double *)calloc(step, sizeof(double));

	getgaussfactor(factors, step, delta);

	// ����ÿ����
	imin = 0;
	imax = datalen - 1;

	for (i = imin; i <= imax; i++)
	{
		sum = 0.0;

		half = (step - 1) / 2;
		for (j = 0; j < step; j++)
		{
			k = (i + j - half);
			k = k > imin ? k : imin;
			k = k < imax ? k : imax;

			sum += (*(src + k) * *(factors + j));
		}

		*(dst + i) = (int)(sum);
	}

	// �ͷ���ʱ������
	FREE_POINTER(factors);
}

int get_peak_index_of_int_array_within_range(int *array, int left, int right,
	int *max_val)
{
	int i, peak_pos;
	int tmp = 0;
	int offset = 2;

	peak_pos = 0;
	for (i = left + offset; i < right - offset; i++)
	{
		if (array[i - offset] < array[i] && array[i] > array[i + offset])
		{
			if (tmp < array[i])
			{
				tmp = array[i];
				peak_pos = i;
			}
		}
	}
	
	if (peak_pos == 0)
	{
		tmp = 0;
		for (i = left + 1; i < right - 1; i++)
		{
			if (array[i - 1] <= array[i] && array[i] >= array[i + 1])
			{
				if (tmp < array[i])
				{
					tmp = array[i];
					peak_pos = i;
				}
			}
		}
	}
	*max_val = tmp;
	return peak_pos;
}

int get_max_index_of_int_array_within_range(int *array, int left, int right,
	int *max_val)
{
	int i, peak_pos;
	int tmp = *max_val;

	peak_pos = 0;
	for (i = left; i < right; i++)
	{
		if (tmp < array[i])
		{
			tmp = array[i];
			peak_pos = i;
		}
	}
	*max_val = tmp;
	return peak_pos;
}

int get_max_index_of_double_array_within_range(double *array, int left, int right,
	double *max_val)
{
	int i,peak_pos;
	double tmp = *max_val;

	peak_pos = 0;
	for (i = left; i < right; i++)
	{
		if (tmp < array[i])
		{
			tmp = array[i];
			peak_pos = i;
		}
	}
	*max_val = tmp;
	return peak_pos;
}

int get_trough_index_of_int_array_within_range(int *array, int left, int right,
	int *min_val)
{
	int i, min_pos;
	int tmp = *min_val;
	int offset = 2;

	min_pos = 0;
	for (i = left + offset; i < right - offset; i++)
	{
		if (array[i - offset] > array[i] && array[i] < array[i + offset])
		{
			if (tmp > array[i])
			{
				tmp = array[i];
				min_pos = i;
			}
		}
	}
	
	if (!min_pos)
	{
		tmp = *min_val;
		for (i = left + 1; i < right - 1; i++)
		{
			if (array[i - 1] <= array[i] && array[i] >= array[i + 1])
			{
				if (tmp > array[i])
				{
					tmp = array[i];
					min_pos = i;
				}
			}
		}
	}
	*min_val = tmp;
	return min_pos;
}

int get_min_index_of_double_array_within_range(double *array, int left, int right,
	double *min_val)
{
	int i, min_pos;
	double tmp = *min_val;

	min_pos = 0;
	for (i = left; i < right; i++)
	{
		if (tmp > array[i])
		{
			tmp = array[i];
			min_pos = i;
		}
	}
	*min_val = tmp;
	return min_pos;
}

int identify_hole_block(short *data, int data_num)
{
	short df[MAX_MONITOR_NUM] = { 0 };
	int i, step, thresh;
	step = 9;
	thresh = 4;
	for (i = 1; i <= data_num / step - 1; i++)
	{
		df[i - 1] = data[step*(i + 1) - 1] - data[step*i - 1];
	}

	for (i = 0; i < data_num / step - 5; i++)
	{
		if (df[i] > thresh && df[i + 1] > thresh &&
			df[i + 2] > thresh - 1 && df[i + 3] > thresh - 2)
			return 1;
		else if (df[i] < -1 * thresh && df[i + 1] < -1 * thresh + 1
			&& df[i + 2] < -1 * thresh + 1 && df[i + 3] < -1 * thresh + 2)
			return 1;
	}
	return 0;
}


// �迹ͨ������ת����������ȡFPGA���������DataLenΪpulse������
int dataconvite_impd(stImpdCellList *pCellList, byte *DataAddr,	int DataLen)
{
	stImpdPulse *pPulseInfo;
	int i, j;
	unsigned short HeadCheck, EndCheck;

	if (!pCellList || !DataAddr)
	{
		return 121;
	}

	// �ڴ�����
	pPulseInfo = (stImpdPulse *)malloc(sizeof(stImpdPulse)*DataLen);
	if (!pPulseInfo)
		return 122;

	memset(pPulseInfo, 0, sizeof(stImpdPulse)*DataLen);
	j = 0;
	// ��ȡ��Ϣ
	for (i = 0; i < DataLen; i++)
	{
		// FAFB
		HeadCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ��־λ
		DataAddr += 1;

		// ��ֵ
		pPulseInfo[j].PeakValue = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ǰ���
		pPulseInfo[j].PriWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].SubWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ȫ���
		pPulseInfo[j].FullWidth = *((byte *)DataAddr);
		DataAddr += 1;

		// ����
		pPulseInfo[j].BaseLine = Swap16(*((unsigned short *)DataAddr) & 0xFF0F);
		DataAddr += 2;

		// ʱ���
		pPulseInfo[j].TimeStamp = *((byte *)DataAddr);
		DataAddr += 1;

		// M����־
		pPulseInfo[j].MPulseFlag = (*((byte *)DataAddr) & 0x01);
		DataAddr += 1;

		// ����λ
		DataAddr += 1;

		// У��λ
		DataAddr += 1;

		// FCFD
		EndCheck = Swap16(*((unsigned short *)DataAddr));
		DataAddr += 2;

		// ͷβУ��
		if (HeadCheck == 0xFAFB && EndCheck == 0xFCFD && pPulseInfo[j].PeakValue > 0)
			j++;

	}

	// ��ֵ����
	pCellList->cell_info = pPulseInfo;
	pCellList->CellNum = j;
	return 0;
}

